# Limpieza de Contactos Duplicados

## Descripción

Este script identifica y elimina contactos duplicados en la tabla `supplier_contacts` de la base de datos. Es útil para limpiar datos duplicados que pueden haber sido creados durante migraciones o importaciones.

## Funcionalidades

- **Detección automática**: Encuentra contactos duplicados basándose en la combinación de nombre, teléfono y email
- **Fusión inteligente**: Preserva la información más completa y marca correctamente los contactos primarios
- **Modo seguro**: Por defecto ejecuta en modo simulación (dry-run) sin modificar datos
- **Verificación**: Confirma que la limpieza fue exitosa

## Uso

## Uso

### Modo Interactivo (Recomendado)
Ejecuta cualquiera de los wrappers interactivos que muestran un menu:

```bash
# Batch file (Windows)
utilities/cleanup_duplicate_contacts.bat

# PowerShell (Windows)
utilities/cleanup_duplicate_contacts.ps1
```

Ambos muestran el mismo menu:
```
Selecciona una opcion:

  1. Verificar estado actual (buscar duplicados)
  2. Simulacion (mostrar duplicados sin eliminar)
  3. Aplicar limpieza (eliminar duplicados)
  4. Salir
```

### Modo Directo (Avanzado)
Para uso programatico o scripting, ejecuta el script Python directamente:

```bash
# Verificar estado
python scripts/cleanup_duplicate_contacts.py --verify-only

# Simulacion
python scripts/cleanup_duplicate_contacts.py

# Aplicar cambios
python scripts/cleanup_duplicate_contacts.py --apply
```

## Cómo Funciona

1. **Identificación**: Busca grupos de contactos que tienen el mismo nombre, teléfono y email (ignorando mayúsculas/minúsculas)
2. **Selección**: Elige el contacto más completo como el que se conservará
3. **Fusión**: Transfiere información faltante de los duplicados al contacto principal
4. **Limpieza**: Elimina los contactos duplicados
5. **Verificación**: Confirma que no quedan duplicados

## Criterios de Deduplicación

Dos contactos se consideran duplicados si coinciden en:
- Nombre del contacto (ignorando mayúsculas/minúsculas y espacios)
- Número de teléfono (ignorando mayúsculas/minúsculas y espacios)
- Dirección de email (ignorando mayúsculas/minúsculas y espacios)

## Seguridad

- **Modo simulación**: Por defecto no modifica la base de datos
- **Backup recomendado**: Realiza un backup antes de aplicar cambios
- **Verificación**: Siempre verifica el resultado después de la limpieza
- **Transaccional**: Los cambios se hacen en transacciones para mantener consistencia

## Ejemplos de Salida

### Simulación
```
===============================================================
LIMPIEZA: Eliminar Contactos Duplicados de Proveedores
Versión: 1.0.0
===============================================================

🔍 MODO SIMULACIÓN - No se realizarán cambios
Ejecuta con dry_run=False para aplicar los cambios

Procesando 3 grupos de duplicados...

  Supplier 1: 2 duplicados encontrados
  Supplier 5: 3 duplicados encontrados
  Supplier 12: 2 duplicados encontrados

===============================================================
RESUMEN DE SIMULACIÓN:
  Grupos de duplicados encontrados: 3
  Para aplicar los cambios, ejecuta con dry_run=False
===============================================================
```

### Aplicación
```
===============================================================
LIMPIEZA: Eliminar Contactos Duplicados de Proveedores
Versión: 1.0.0
===============================================================

⚠️  MODO REAL - Se eliminarán contactos duplicados
¿Continuar? (sí/no): sí

Procesando 3 grupos de duplicados...

  Supplier 1: 2 duplicados encontrados
    Kept contact ID 15, removed 2 duplicates
  Supplier 5: 3 duplicados encontrados
    Kept contact ID 28, removed 3 duplicates
  Supplier 12: 2 duplicados encontrados
    Kept contact ID 45, removed 2 duplicates

===============================================================
RESUMEN DE LIMPIEZA:
  Grupos procesados: 3
  Contactos duplicados eliminados: 7
  Contactos únicos preservados: 3
===============================================================
```

## Notas Importantes

- **Backup primero**: Siempre realiza un backup de la base de datos antes de ejecutar en modo real
- **Pruebas**: Ejecuta primero en modo simulación para ver qué cambios se harán
- **Verificación**: Después de la limpieza, verifica que los datos sean correctos
- **Contactos primarios**: El script preserva la designación de contacto primario
- **Información preservada**: Se mantiene la información más completa de cada grupo de duplicados

## Integración con Instalador

Este script puede ejecutarse:
- Manualmente cuando se detecten duplicados
- Como parte de tareas de mantenimiento
- Después de migraciones de datos
- Antes de actualizaciones importantes

## Soporte

Si encuentras problemas o necesitas ayuda:
1. Ejecuta en modo simulación primero
2. Revisa los logs de salida
3. Verifica la integridad de la base de datos
4. Contacta al administrador del sistema
# Service Killer Script for Sistema de Proveedores
# This script forcefully stops and removes the Windows service and related processes

param(
    [string]$ServiceName = "SistemaProveedores"
)

$ErrorActionPreference = "Stop"

# Check for administrator privileges
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Request administrator privileges if not running as admin
if (-not (Test-Administrator)) {
    Write-Host "This script requires administrator privileges." -ForegroundColor Yellow
    Write-Host "Requesting elevation..." -ForegroundColor Yellow

    $scriptPath = $MyInvocation.MyCommand.Path
    $arguments = ""
    if ($ServiceName -ne "SistemaProveedores") {
        $arguments = "-ServiceName $ServiceName"
    }

    Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$scriptPath`" $arguments" -Verb RunAs -Wait
    exit $LASTEXITCODE
}

Write-Host "=== Service Killer for $ServiceName ===" -ForegroundColor Cyan
Write-Host ""

# Step 1: Stop the service gracefully
Write-Host "Step 1: Stopping service..." -ForegroundColor Yellow
try {
    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($service -and $service.Status -ne "Stopped") {
        Stop-Service -Name $ServiceName -Force -ErrorAction Stop
        Write-Host "  ✅ Service stopped successfully" -ForegroundColor Green
    } else {
        Write-Host "  ℹ️  Service was already stopped or not found" -ForegroundColor Gray
    }
} catch {
    Write-Host "  ⚠️  Failed to stop service gracefully: $($_.Exception.Message)" -ForegroundColor Yellow
}

# Step 2: Kill related Python processes
Write-Host "Step 2: Killing related Python processes..." -ForegroundColor Yellow
$pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -like "*app.py*" -or
    $_.CommandLine -like "*run.bat*" -or
    $_.CommandLine -like "*$ServiceName*"
}

if ($pythonProcesses) {
    Write-Host "  Found $($pythonProcesses.Count) Python process(es) to terminate" -ForegroundColor Gray
    foreach ($process in $pythonProcesses) {
        try {
            Stop-Process -Id $process.Id -Force -ErrorAction Stop
            Write-Host "  ✅ Terminated Python process PID: $($process.Id)" -ForegroundColor Green
        } catch {
            Write-Host "  ⚠️  Failed to terminate process $($process.Id): $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
} else {
    Write-Host "  ℹ️  No related Python processes found" -ForegroundColor Gray
}

# Step 3: Remove the service
Write-Host "Step 3: Removing service..." -ForegroundColor Yellow
try {
    $result = sc.exe delete $ServiceName 2>&1
    if ($LASTEXITCODE -eq 0 -or $result -match "service does not exist") {
        Write-Host "  ✅ Service removed successfully" -ForegroundColor Green
    } else {
        Write-Host "  ⚠️  sc.exe result: $result" -ForegroundColor Yellow
    }
} catch {
    Write-Host "  ❌ Failed to remove service: $($_.Exception.Message)" -ForegroundColor Red
}

# Step 4: Final verification
Write-Host "Step 4: Verification..." -ForegroundColor Yellow
$service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($service) {
    Write-Host "  ❌ Service still exists" -ForegroundColor Red
} else {
    Write-Host "  ✅ Service completely removed" -ForegroundColor Green
}

$remainingProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -like "*app.py*" -or
    $_.CommandLine -like "*run.bat*" -or
    $_.CommandLine -like "*$ServiceName*"
}

if ($remainingProcesses) {
    Write-Host "  ⚠️  $($remainingProcesses.Count) Python process(es) still running" -ForegroundColor Yellow
} else {
    Write-Host "  ✅ No related processes running" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== Cleanup Complete ===" -ForegroundColor Cyan
Write-Host "The $ServiceName service and related processes have been terminated." -ForegroundColor White
Write-Host ""
Write-Host "Press any key to exit..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
# Guía de Actualización - Sistema de Proveedores

## 🔄 Actualización Segura de Versiones

Este documento explica cómo actualizar el Sistema de Gestión de Proveedores sin perder datos.

---

## ✅ Garantías de Preservación de Datos

El instalador `setup-complete.ps1` **garantiza** que durante una actualización:

### 🔒 Siempre se Preserva:
- ✅ **Base de datos completa** (`proveedores.db`)
  - Todos tus proveedores
  - Todos tus items/materiales
  - Todas las relaciones precio-item-proveedor
  - Todas las órdenes de compra
  
- ✅ **Configuración personalizada** (`config.ini`)
  - Nombre de tu empresa
  - Ruta del logo personalizado
  - Configuraciones del sistema
  
- ✅ **Archivos personalizados**
  - Logo de la empresa (`static/logo.*`)
  - Respaldos anteriores

### 🔄 Se Actualiza:
- ⚡ Código de la aplicación (`app.py`, `models.py`, `database.py`)
- ⚡ Archivos estáticos del sistema (`static/`, `templates/`)
- ⚡ Dependencias de Python (si cambió `requirements.txt`)
- ⚡ Scripts de inicio (`start.bat`, `start.sh`)
- ⚡ Versión en `config.ini`

---

## 📥 Proceso de Actualización

### Paso 1: Descarga la Nueva Versión

Descarga el ZIP de la nueva versión:
- Desde GitHub Releases
- O del sitio web oficial
- O recibido por email

Ejemplo: `proveedores-v0.2.zip`

### Paso 2: Extrae sobre la Instalación Existente

```powershell
# Opción A: Extrae directamente en el directorio de instalación
# El instalador detectará los archivos existentes

# Opción B: Extrae en ubicación temporal y copia archivos
# Luego ejecuta el instalador desde allí
```

### Paso 3: Ejecuta el Instalador

**Windows:**
```powershell
cd C:\Users\TuUsuario\SistemaProveedores
.\setup-complete.ps1
```

### Paso 4: Confirma la Actualización

El instalador mostrará:

```
================================================================
  RESUMEN DE CONFIGURACION
================================================================

Ubicacion:  C:\Users\TuUsuario\SistemaProveedores

[INFO] Instalacion existente detectada!

Se encontro una instalacion anterior en:
C:\Users\TuUsuario\SistemaProveedores

Los siguientes datos se preservaran:
  [X] Configuracion (config.ini)
  [X] Base de datos (proveedores.db - 245.67 KB)

IMPORTANTE: Tus proveedores, productos y pedidos NO se borraran.

Continuar con la actualizacion? (S/N):
```

### Paso 5: La Actualización se Completa Automáticamente

El instalador:
1. ✅ Crea respaldo en carpeta `backup_YYYYMMDD_HHMMSS/`
2. ✅ Copia nuevos archivos del sistema
3. ✅ Preserva `config.ini` existente
4. ✅ Preserva `proveedores.db` existente
5. ✅ **Actualiza esquema de base de datos** (agrega nuevas columnas si es necesario)
6. ✅ Actualiza entorno virtual
7. ✅ Instala nuevas dependencias
8. ✅ Actualiza scripts de inicio
9. ✅ Muestra resumen de actualización

---

## 🆕 Primera Instalación vs. Actualización

### Primera Instalación

El instalador te preguntará:
- 📂 ¿Dónde quieres instalar?
- 🏢 ¿Nombre de tu empresa?
- 🖼️ ¿Ruta al logo?

### Actualización (Instalación Existente Detectada)

El instalador:
- 🔍 Detecta instalación existente automáticamente
- 🔒 Preserva configuración actual (no pregunta de nuevo)
- 💾 Crea respaldo automático
- ⚡ Solo actualiza archivos del sistema

---

## 📦 Respaldos Automáticos

Cada actualización crea un respaldo en:

```
C:\Users\TuUsuario\SistemaProveedores\
  ├── backup_20260203_145623/
  │   ├── config.ini
  │   └── proveedores.db
  ├── backup_20260310_092145/
  │   ├── config.ini
  │   └── proveedores.db
  └── ...
```

**Características:**
- ✅ Respaldo automático antes de cada actualización
- ✅ Incluye fecha y hora en el nombre
- ✅ Preserva configuración y base de datos
- ✅ No se borran automáticamente (puedes eliminarlos manualmente)

---

## 🔧 Restaurar desde Respaldo (si es necesario)

Si algo sale mal, puedes restaurar manualmente:

```powershell
# Detén el servidor
# Ctrl+C en la ventana donde corre

# Copia los archivos del respaldo
cd C:\Users\TuUsuario\SistemaProveedores
copy backup_20260203_145623\config.ini .
copy backup_20260203_145623\proveedores.db .

# Reinicia el servidor
.\start.bat
```

---

## 🆘 Preguntas Frecuentes

### ¿Perderé mis datos al actualizar?

**No.** El instalador preserva automáticamente:
- Base de datos (`proveedores.db`)
- Configuración (`config.ini`)
- Logo personalizado

### ¿Necesito desinstalar la versión anterior?

**No.** Simplemente ejecuta el nuevo instalador sobre la instalación existente.

### ¿Qué pasa si cancelo la actualización?

Si cancelas **antes** de confirmar (cuando pregunta S/N), no se hace ningún cambio.

### ¿Puedo volver a una versión anterior?

Sí, pero requiere restauración manual:
1. Descarga la versión anterior
2. Extrae los archivos
3. Restaura tu `config.ini` y `proveedores.db` desde el respaldo
4. Ejecuta el instalador de la versión anterior

### ¿Los respaldos ocupan mucho espacio?

Depende del tamaño de tu base de datos. Una base de datos con:
- 100 proveedores
- 500 items
- 1000 órdenes

Ocupa aproximadamente 2-5 MB por respaldo.

### ¿Puedo eliminar respaldos antiguos?

Sí, puedes eliminar carpetas `backup_*` manualmente cuando ya no las necesites.

### ¿Necesito permisos de administrador para actualizar?

**No.** Las actualizaciones NO requieren permisos de administrador porque:
- Solo modifican archivos en tu directorio de usuario
- No instalan software a nivel de sistema
- No modifican PATH ni variables de entorno

**Excepción:** Si necesitas instalar Python por primera vez, la auto-instalación SÍ requiere permisos de administrador. Pero para actualizaciones normales del sistema, NO es necesario.

---

## 📝 Registro de Cambios por Versión

### v0.1 (Febrero 2026) - Versión Inicial
- ✨ Primera versión estable
- ✨ Instalador con detección de actualización
- ✨ Preservación automática de datos
- ✨ Respaldos automáticos

### v0.2 (Planeada)
- 🔄 Sistema de migración de base de datos
- 📊 Dashboard con estadísticas
- 📄 Exportación a PDF
- 👥 Sistema de usuarios

---

## 🛡️ Políticas de Compatibilidad

### Base de Datos

La estructura de la base de datos puede cambiar entre versiones. El sistema:

- **v0.1 → v0.2:** Ejecutará migraciones automáticas si es necesario
- **Siempre preserva datos:** Los datos nunca se borran
- **Respaldo antes de migrar:** Crea respaldo automático

### Configuración

El archivo `config.ini` es compatible hacia adelante:
- Nuevas versiones agregan campos nuevos
- Campos antiguos se preservan
- No se eliminan configuraciones existentes

### API REST

La API REST mantiene compatibilidad:
- Endpoints existentes se mantienen
- Nuevos endpoints se agregan
- Cambios incompatibles se marcan claramente

---

## 📞 Soporte

Si tienes problemas durante la actualización:

1. Verifica el respaldo en `backup_YYYYMMDD_HHMMSS/`
2. Revisa los mensajes de error
3. Consulta la sección [Troubleshooting](README.md#-troubleshooting) en el README
4. Restaura desde respaldo si es necesario

---

**Actualizado:** Febrero 2026  
**Versión del documento:** 1.0

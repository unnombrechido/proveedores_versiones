# Force Service Cleanup - Run as Administrator
# This script aggressively removes the SistemaProveedores service and related processes

param(
    [switch]$Force
)

Write-Host ""
Write-Host "============================================================" -ForegroundColor Red
Write-Host "  LIMPIEZA FORZADA DE SERVICIOS - ADMINISTRADOR" -ForegroundColor Red
Write-Host "============================================================" -ForegroundColor Red
Write-Host ""

# Check if running as administrator
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[ERROR] Este script debe ejecutarse como ADMINISTRADOR" -ForegroundColor Red
    Write-Host ""
    Write-Host "Para ejecutarlo como administrador:" -ForegroundColor Yellow
    Write-Host "1. Clic derecho en el archivo .ps1" -ForegroundColor White
    Write-Host "2. Seleccionar 'Ejecutar con PowerShell como administrador'" -ForegroundColor White
    Write-Host ""
    Read-Host "Presiona Enter para salir"
    exit 1
}

Write-Host "[OK] Ejecutando como administrador" -ForegroundColor Green
Write-Host ""

$serviceName = 'SistemaProveedores'

Write-Host "=== LIMPIEZA FORZADA DEL SERVICIO ===" -ForegroundColor Red
Write-Host ""

# 1. Force stop any running processes first
Write-Host "1. Forzando terminacion de procesos..." -ForegroundColor Yellow
$killed = 0

# Kill all python processes
Get-Process -Name 'python' -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        Write-Host "   Terminando Python PID: $($_.Id)" -ForegroundColor Red
        $_.Kill()
        $killed++
    } catch {
        Write-Host "   Error terminando $($_.Id): $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

# Kill CMD processes related to the service
Get-Process -Name 'cmd' -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -like '*run.bat*' -or $_.CommandLine -like '*SistemaProveedores*'
} | ForEach-Object {
    try {
        Write-Host "   Terminando CMD PID: $($_.Id)" -ForegroundColor Red
        $_.Kill()
        $killed++
    } catch {
        Write-Host "   Error terminando $($_.Id): $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

Write-Host "   Procesos terminados: $killed" -ForegroundColor Green
Write-Host ""

# 2. Force service removal
Write-Host "2. Removiendo servicio forzosamente..." -ForegroundColor Yellow

# Stop and delete service
& sc.exe stop $serviceName 2>$null
& sc.exe delete $serviceName 2>$null

Write-Host ""

# 3. Registry cleanup
Write-Host "3. Limpieza de registro..." -ForegroundColor Yellow
$regPaths = @(
    'HKLM:\SYSTEM\CurrentControlSet\Services\SistemaProveedores',
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\SistemaProveedores'
)

foreach ($regPath in $regPaths) {
    try {
        if (Test-Path $regPath) {
            Remove-Item -Path $regPath -Recurse -Force -ErrorAction Stop
            Write-Host "   Registro limpiado: $regPath" -ForegroundColor Green
        }
    } catch {
        Write-Host "   Error limpiando registro: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

Write-Host ""

# 4. Final verification
Write-Host "4. Verificacion final..." -ForegroundColor Yellow
Start-Sleep -Seconds 2

$service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($service) {
    Write-Host "   [ADVERTENCIA] Servicio aun existe: $($service.Status)" -ForegroundColor Yellow
} else {
    Write-Host "   [OK] Servicio completamente removido" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== LIMPIEZA COMPLETADA ===" -ForegroundColor Green
Write-Host ""
Write-Host "Si aun ves la aplicacion en la barra de tareas:" -ForegroundColor Cyan
Write-Host "1. Presiona Ctrl+Shift+Esc para abrir el Administrador de Tareas" -ForegroundColor White
Write-Host "2. Ve a la pestaña Procesos" -ForegroundColor White
Write-Host "3. Busca procesos de Python o CMD relacionados" -ForegroundColor White
Write-Host "4. Finalizalos manualmente" -ForegroundColor White
Write-Host "5. Reinicia el Explorador de Windows si es necesario" -ForegroundColor White
Write-Host ""
Write-Host "Si el problema persiste:" -ForegroundColor Yellow
Write-Host "1. Reinicia tu computadora" -ForegroundColor White
Write-Host "2. Vuelve a ejecutar el instalador" -ForegroundColor White
Write-Host ""

if (-not $Force) {
    Read-Host "Presiona Enter para salir"
}
# Service Management Scripts

## kill-service.bat / kill-service.ps1

**Purpose:** Forcefully stop and remove the Sistema de Proveedores Windows service and related processes.

**Usage:**
- Double-click `kill-service.bat` (recommended for most users)
- Or run `powershell.exe -ExecutionPolicy Bypass -File "utilities\kill-service.ps1"`

**What it does:**
1. Stops the service gracefully (if running)
2. Terminates all related Python processes
3. Removes the service from Windows Service Manager
4. Verifies complete cleanup

**When to use:**
- Service fails to start/stop normally
- Need to clean up after failed installations
- Emergency service termination

**Note:** Requires administrator privileges (will request elevation automatically)

## service.ps1

**Purpose:** Full service management (install, start, stop, remove)

**Usage:**
```powershell
# Install service
.\service.ps1 -Action install

# Start service
.\service.ps1 -Action start

# Stop service
.\service.ps1 -Action stop

# Remove service
.\service.ps1 -Action remove

# Check status
.\service.ps1 -Action status
```

**Note:** Requires administrator privileges for install/remove operations
#Requires -Version 5.1
#Requires -RunAsAdministrator

<#
.SYNOPSIS
    Complete uninstall script for Proveedores application
.DESCRIPTION
    This script performs a total cleanup of the Proveedores installation:
    - Optionally backs up data and config
    - Stops and removes Windows service
    - Removes startup registry entries
    - Kills related processes
    - Removes all files and folders
.PARAMETER BackupData
    Switch to automatically backup data without prompting
.PARAMETER InstallPath
    Path to the installation directory (defaults to current directory)
#>

param(
    [switch]$BackupData,
    [string]$InstallPath = (Get-Location).Path,
    [switch]$CleanupOnly
)

Write-Host ""
Write-Host "============================================================" -ForegroundColor Red
Write-Host "  PROVEEDORES - COMPLETE UNINSTALL" -ForegroundColor Red
Write-Host "============================================================" -ForegroundColor Red
Write-Host ""

# Detect installation root directory
function Get-InstallationRoot {
    param([string]$StartPath)
    
    $currentPath = $StartPath
    
    # Check if we're already in the root (has api/, data/, config/ directories)
    if ((Test-Path (Join-Path $currentPath "api")) -and 
        (Test-Path (Join-Path $currentPath "data")) -and 
        (Test-Path (Join-Path $currentPath "config"))) {
        return $currentPath
    }
    
    # Try parent directories
    $parentPath = Split-Path $currentPath -Parent
    if ($parentPath -and (Test-Path $parentPath)) {
        # Check if parent has the expected structure
        if ((Test-Path (Join-Path $parentPath "api")) -and 
            (Test-Path (Join-Path $parentPath "data")) -and 
            (Test-Path (Join-Path $parentPath "config"))) {
            return $parentPath
        }
    }
    
    # If not found, return the original path
    return $StartPath
}

# Auto-detect installation path only if not explicitly provided
if (-not $PSBoundParameters.ContainsKey('InstallPath')) {
    $InstallPath = Get-InstallationRoot -StartPath (Get-Location).Path
}

# If cleanup only, just delete the folder
if ($CleanupOnly) {
    Write-Host "[INFO] Performing cleanup of: $InstallPath" -ForegroundColor Yellow
    try {
        Remove-Item -Path $InstallPath -Recurse -Force
        Write-Host "[SUCCESS] Installation folder removed" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] Failed to remove folder: $($_.Exception.Message)" -ForegroundColor Red
    }
    exit 0
}

Write-Host "[INFO] Uninstalling from: $InstallPath" -ForegroundColor Yellow
Write-Host ""

# Determine backup choice
$backup = $false
if ($BackupData) {
    $backup = $true
} else {
    $backupChoice = Read-Host "Do you want to backup data and config before uninstalling? (y/n)"
    if ($backupChoice -eq 'y' -or $backupChoice -eq 'Y') {
        $backup = $true
    }
}

# Backup data and config if requested
if ($backup) {
    Write-Host "[INFO] Creating backup..." -ForegroundColor Cyan
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupPath = "$env:USERPROFILE\Proveedores_Backup_$timestamp"

    try {
        New-Item -ItemType Directory -Path $backupPath -Force | Out-Null

        if (Test-Path "$InstallPath\data") {
            Copy-Item -Path "$InstallPath\data" -Destination "$backupPath\data" -Recurse -Force
            Write-Host "  Backed up data folder" -ForegroundColor Green
        }

        if (Test-Path "$InstallPath\config") {
            Copy-Item -Path "$InstallPath\config" -Destination "$backupPath\config" -Recurse -Force
            Write-Host "  Backed up config folder" -ForegroundColor Green
        }

        Write-Host "[SUCCESS] Backup created at: $backupPath" -ForegroundColor Green
        Write-Host ""
    } catch {
        Write-Host "[ERROR] Failed to create backup: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

# Service name
$serviceName = "SistemaProveedores"

# Stop and delete service
Write-Host "[INFO] Stopping and removing Windows service..." -ForegroundColor Cyan
try {
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
        Write-Host "  Service stopped" -ForegroundColor Green
    }

    $scResult = sc.exe delete $serviceName 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  Service deleted successfully" -ForegroundColor Green
    } else {
        Write-Host "  Warning: Service deletion result: $scResult" -ForegroundColor Yellow
    }
} catch {
    Write-Host "  Warning: Error managing service: $($_.Exception.Message)" -ForegroundColor Yellow
}

# Kill related processes
Write-Host "[INFO] Killing related processes..." -ForegroundColor Cyan
$processesKilled = 0

# Kill Python processes
$pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue
foreach ($proc in $pythonProcesses) {
    try {
        $procPath = $proc.Path
        if ($procPath -and ($procPath.StartsWith($InstallPath, [StringComparison]::OrdinalIgnoreCase) -or $procPath -like "*proveedores*")) {
            $proc.Kill()
            $processesKilled++
        }
    } catch {
        # Ignore errors
    }
}

# Kill CMD processes
$cmdProcesses = Get-Process -Name "cmd" -ErrorAction SilentlyContinue
foreach ($proc in $cmdProcesses) {
    try {
        $cmdLine = $proc.CommandLine
        if ($cmdLine -and ($cmdLine -like "*run.bat*" -or $cmdLine -like "*SistemaProveedores*")) {
            $proc.Kill()
            $processesKilled++
        }
    } catch {
        # Ignore errors
    }
}

if ($processesKilled -gt 0) {
    Write-Host "  Killed $processesKilled related processes" -ForegroundColor Green
} else {
    Write-Host "  No related processes found" -ForegroundColor Gray
}

# Remove registry entries
Write-Host "[INFO] Removing registry entries..." -ForegroundColor Cyan
$regPaths = @(
    "HKLM:\SYSTEM\CurrentControlSet\Services\$serviceName",
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\$serviceName",
    "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\$serviceName"
)

$regRemoved = 0
foreach ($regPath in $regPaths) {
    try {
        if (Test-Path $regPath) {
            Remove-Item -Path $regPath -Recurse -Force
            Write-Host "  Removed: $regPath" -ForegroundColor Green
            $regRemoved++
        }
    } catch {
        Write-Host "  Warning: Failed to remove $regPath : $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

if ($regRemoved -eq 0) {
    Write-Host "  No registry entries found to remove" -ForegroundColor Gray
}

# Remove files and folders
Write-Host "[INFO] Removing files and folders..." -ForegroundColor Cyan

# Since this script is inside the folder, we need to handle deletion carefully
# Copy this script to temp and run it from there for complete cleanup

# File removal - manual step required due to Windows limitations
Write-Host "[INFO] Removing files and folders..." -ForegroundColor Cyan
Write-Host "  Note: Automatic file deletion is not possible while running from within the installation folder." -ForegroundColor Yellow
Write-Host "  Please manually delete the installation folder after the uninstall completes:" -ForegroundColor Yellow
Write-Host "  $InstallPath" -ForegroundColor White
Write-Host ""

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  UNINSTALL COMPLETED" -ForegroundColor Green
if ($backup) {
    Write-Host "  Backup available at: $backupPath" -ForegroundColor Green
}
Write-Host "============================================================" -ForegroundColor Green

# This should not be reached if cleanup succeeded, but just in case
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  UNINSTALL COMPLETED" -ForegroundColor Green
if ($backup) {
    Write-Host "  Backup available at: $backupPath" -ForegroundColor Green
}
Write-Host "============================================================" -ForegroundColor Green
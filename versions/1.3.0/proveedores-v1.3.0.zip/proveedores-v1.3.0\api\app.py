# -*- coding: utf-8 -*-
from flask import Flask, jsonify, request, send_file, render_template, redirect, url_for, session, Response
from flask_cors import CORS
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
import os
import pandas as pd
from datetime import datetime
from io import BytesIO
import base64
from database import init_db, SessionLocal, get_database_url
from models import Supplier, Order, Item, supplier_items, User, SupplierContact
from sqlalchemy import select
from functools import wraps
from zipfile import ZipFile
import tempfile

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Por favor inicie sesión para acceder a esta página.'

@login_manager.user_loader
def load_user(user_id):
    """Load user by ID for Flask-Login"""
    if user_id is None:
        return None
    db = SessionLocal()
    user = db.query(User).filter(User.id == int(user_id)).first()
    if user:
        # Detach from session to avoid issues when session closes
        db.expunge(user)
    db.close()
    return user

@login_manager.unauthorized_handler
def unauthorized():
    """Handle unauthorized access"""
    if request.path.startswith('/api/'):
        return jsonify({'error': 'Authentication required'}), 401
    return redirect(url_for('login'))

def permission_required(permission):
    """Decorator to check if user has required permission"""
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            if not current_user.has_permission(permission):
                return jsonify({'error': 'Acceso denegado. Permisos insuficientes.'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def role_required(*roles):
    """Decorator to check if user has one of the required roles"""
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            if current_user.rol not in roles:
                return jsonify({'error': 'Acceso denegado. Rol insuficiente.'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Initialize database
init_db()


# === FULL EXPORT/IMPORT ENDPOINTS ===

@app.route('/api/export/full', methods=['GET'])
@permission_required('export')
def export_full():
    """Export all data (suppliers, items, contacts, supplier_items, orders) as Excel (multi-sheet) or CSV (zip)"""
    db = SessionLocal()
    try:
        fmt = request.args.get('format', 'excel').lower()  # excel or csv
        # Query all data
        suppliers = db.query(Supplier).all()
        items = db.query(Item).all()
        contacts = db.query(SupplierContact).all()
        orders = db.query(Order).all()
        # supplier_items is a link table, use raw SQL
        supplier_items_rows = db.execute(select(supplier_items)).fetchall()

        # Convert to DataFrames
        df_suppliers = pd.DataFrame([s.to_dict(include_items=False, include_contacts=False) for s in suppliers])
        df_items = pd.DataFrame([i.to_dict(include_suppliers=False) for i in items])
        df_contacts = pd.DataFrame([c.to_dict() for c in contacts])
        df_orders = pd.DataFrame([o.to_dict() for o in orders])
        # supplier_items: convert RowProxy to dict
        df_supplier_items = pd.DataFrame([dict(row._mapping) for row in supplier_items_rows])

        if fmt == 'excel':
            output = BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df_suppliers.to_excel(writer, sheet_name='suppliers', index=False)
                df_items.to_excel(writer, sheet_name='items', index=False)
                df_contacts.to_excel(writer, sheet_name='contacts', index=False)
                df_supplier_items.to_excel(writer, sheet_name='supplier_items', index=False)
                df_orders.to_excel(writer, sheet_name='orders', index=False)
            output.seek(0)
            return send_file(
                output,
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                as_attachment=True,
                download_name=f'proveedores_full_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
            )
        elif fmt == 'csv':
            # Write each DataFrame to a temp CSV, zip them
            with tempfile.TemporaryDirectory() as tmpdir:
                paths = {}
                for name, df in [('suppliers', df_suppliers), ('items', df_items), ('contacts', df_contacts), ('supplier_items', df_supplier_items), ('orders', df_orders)]:
                    path = os.path.join(tmpdir, f'{name}.csv')
                    df.to_csv(path, index=False)
                    paths[name] = path
                zip_path = os.path.join(tmpdir, f'proveedores_full_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.zip')
                with ZipFile(zip_path, 'w') as zipf:
                    for name, path in paths.items():
                        zipf.write(path, arcname=os.path.basename(path))
                with open(zip_path, 'rb') as f:
                    data = f.read()
                return send_file(
                    BytesIO(data),
                    mimetype='application/zip',
                    as_attachment=True,
                    download_name=os.path.basename(zip_path)
                )
        else:
            return jsonify({'error': 'Invalid format. Use excel or csv.'}), 400
    finally:
        db.close()


@app.route('/api/import/full', methods=['POST'])
@permission_required('import')
def import_full():
    """Import all data (suppliers, items, contacts, supplier_items, orders) from Excel (multi-sheet) or CSV zip"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    db = SessionLocal()
    try:
        filename = file.filename.lower()
        if filename.endswith('.xlsx') or filename.endswith('.xls'):
            excel = pd.ExcelFile(file)
            dfs = {sheet: excel.parse(sheet) for sheet in excel.sheet_names}
        elif filename.endswith('.zip'):
            with tempfile.TemporaryDirectory() as tmpdir:
                zip_path = os.path.join(tmpdir, file.filename)
                file.save(zip_path)
                with ZipFile(zip_path, 'r') as zipf:
                    dfs = {}
                    for name in ['suppliers', 'items', 'contacts', 'supplier_items', 'orders']:
                        fname = f'{name}.csv'
                        if fname in zipf.namelist():
                            with zipf.open(fname) as f:
                                dfs[name] = pd.read_csv(f)
        else:
            return jsonify({'error': 'Unsupported file type'}), 400

        # Import order: suppliers, items, contacts, orders, supplier_items
        # Clear existing data? (optional, not done here)
        # 1. Suppliers
        supplier_map = {}  # old_id -> new_id
        if 'suppliers' in dfs:
            for _, row in dfs['suppliers'].iterrows():
                # Try to find by tax_id or name
                supplier = None
                tax_id = row.get('tax_id')
                if pd.notna(tax_id) and str(tax_id).strip():
                    supplier = db.query(Supplier).filter(Supplier.tax_id == str(tax_id).strip()).first()
                if not supplier:
                    supplier = db.query(Supplier).filter(Supplier.name == str(row.get('name')).strip()).first()
                if not supplier:
                    supplier = Supplier()
                for col in row.index:
                    if hasattr(supplier, col):
                        setattr(supplier, col, row[col])
                db.add(supplier)
                db.flush()
                supplier_map[row['id']] = supplier.id
        # 2. Items
        item_map = {}
        if 'items' in dfs:
            for _, row in dfs['items'].iterrows():
                item = db.query(Item).filter(Item.item_code == str(row.get('item_code')).strip()).first()
                if not item:
                    item = Item()
                for col in row.index:
                    if hasattr(item, col):
                        setattr(item, col, row[col])
                db.add(item)
                db.flush()
                item_map[row['id']] = item.id
        # 3. Contacts
        if 'contacts' in dfs:
            for _, row in dfs['contacts'].iterrows():
                contact = SupplierContact()
                for col in row.index:
                    if hasattr(contact, col):
                        setattr(contact, col, row[col])
                # Remap supplier_id
                if 'supplier_id' in row and row['supplier_id'] in supplier_map:
                    contact.supplier_id = supplier_map[row['supplier_id']]
                db.add(contact)
        # 4. Orders
        if 'orders' in dfs:
            for _, row in dfs['orders'].iterrows():
                order = Order()
                for col in row.index:
                    if hasattr(order, col):
                        setattr(order, col, row[col])
                # Remap supplier_id
                if 'supplier_id' in row and row['supplier_id'] in supplier_map:
                    order.supplier_id = supplier_map[row['supplier_id']]
                db.add(order)
        # 5. supplier_items
        if 'supplier_items' in dfs:
            for _, row in dfs['supplier_items'].iterrows():
                # Remap supplier_id and item_id
                sid = supplier_map.get(row['supplier_id'], row['supplier_id'])
                iid = item_map.get(row['item_id'], row['item_id'])
                # Check if exists
                stmt = select(supplier_items).where(
                    supplier_items.c.supplier_id == sid,
                    supplier_items.c.item_id == iid
                )
                existing = db.execute(stmt).first()
                if not existing:
                    ins = supplier_items.insert().values(
                        supplier_id=sid,
                        item_id=iid,
                        price=row.get('price'),
                        supplier_item_code=row.get('supplier_item_code'),
                        lead_time_days=row.get('lead_time_days'),
                        minimum_order_quantity=row.get('minimum_order_quantity'),
                        notes=row.get('notes'),
                        created_at=row.get('created_at'),
                        updated_at=row.get('updated_at')
                    )
                    db.execute(ins)
        db.commit()
        return jsonify({'success': True, 'message': 'Full import completed.'})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

# Print registered routes for debugging
print("\n=== REGISTERING AUTHENTICATION ROUTES ===")

# Authentication Routes
@app.route('/login')
def login():
    """Serve the login page"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    return render_template('login.html')

@app.route('/api/auth/login', methods=['POST'])
def api_login():
    """Authenticate user and create session"""
    data = request.get_json()
    email = data.get('email', '').strip()
    password = data.get('password', '')
    
    if not email or not password:
        return jsonify({'error': 'Email y contraseña son requeridos'}), 400
    
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.email == email).first()
        
        if not user:
            return jsonify({'error': 'Credenciales inválidas'}), 401
        
        if not user.check_password(password):
            return jsonify({'error': 'Credenciales inválidas'}), 401
        
        if not user.is_active:
            return jsonify({'error': 'Usuario inactivo. Contacte al administrador.'}), 403
        
        login_user(user, remember=True)
        
        return jsonify({
            'success': True,
            'message': 'Inicio de sesión exitoso',
            'user': user.to_dict()
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/auth/logout', methods=['POST'])
@login_required
def api_logout():
    """Logout current user"""
    logout_user()
    return jsonify({
        'success': True,
        'message': 'Sesión cerrada exitosamente'
    })

@app.route('/api/auth/me', methods=['GET'])
@login_required
def api_current_user():
    """Get current authenticated user info"""
    return jsonify({
        'success': True,
        'user': current_user.to_dict()
    })

@app.route('/api/auth/check', methods=['GET'])
def api_check_auth():
    """Check if user is authenticated"""
    if current_user.is_authenticated:
        return jsonify({
            'authenticated': True,
            'user': current_user.to_dict()
        })
    return jsonify({'authenticated': False})

# Routes
@app.route('/')
@login_required
def index():
    """Serve the main UI"""
    return render_template('index.html')

@app.route('/api/suppliers', methods=['GET'])
@permission_required('search')
def get_suppliers():
    """Get all suppliers with optional search and filter"""
    db = SessionLocal()
    try:
        query = db.query(Supplier)
        
        # Search by name, email, or category
        search = request.args.get('search', '')
        if search:
            search_pattern = f'%{search}%'
            query = query.filter(
                (Supplier.name.ilike(search_pattern)) |
                (Supplier.email.ilike(search_pattern)) |
                (Supplier.category.ilike(search_pattern)) |
                (Supplier.city.ilike(search_pattern))
            )
        
        # Filter by category
        category = request.args.get('category', '')
        if category:
            query = query.filter(Supplier.category == category)
        
        # Filter by active status
        active = request.args.get('active', '')
        if active:
            query = query.filter(Supplier.active == int(active))
        
        # Filter by country
        country = request.args.get('country', '')
        if country:
            query = query.filter(Supplier.country == country)
        
        suppliers = query.all()
        return jsonify([s.to_dict() for s in suppliers])
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>', methods=['GET'])
def get_supplier(supplier_id):
    """Get a specific supplier"""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        return jsonify(supplier.to_dict())
    finally:
        db.close()

@app.route('/api/suppliers', methods=['POST'])
@permission_required('create')
def create_supplier():
    """Create a new supplier"""
    db = SessionLocal()
    try:
        data = request.json
        supplier = Supplier(
            name=data.get('name'),
            contact_person=data.get('contact_person'),
            email=data.get('email'),
            phone=data.get('phone'),
            address=data.get('address'),
            city=data.get('city'),
            country=data.get('country'),
            tax_id=data.get('tax_id'),
            category=data.get('category'),
            rating=data.get('rating', 0.0),
            payment_terms=data.get('payment_terms'),
            notes=data.get('notes'),
            active=data.get('active', 1),
            created_by=session.get('user_id')
        )
        db.add(supplier)
        db.commit()
        db.refresh(supplier)
        return jsonify(supplier.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>', methods=['PUT'])
@permission_required('modify')
def update_supplier(supplier_id):
    """Update a supplier"""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        data = request.json
        for key, value in data.items():
            if hasattr(supplier, key):
                setattr(supplier, key, value)
        
        supplier.updated_at = datetime.utcnow()
        supplier.updated_by = session.get('user_id')
        db.commit()
        db.refresh(supplier)
        return jsonify(supplier.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>', methods=['DELETE'])
@permission_required('modify')
def delete_supplier(supplier_id):
    """Delete a supplier"""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        db.delete(supplier)
        db.commit()
        return jsonify({'message': 'Supplier deleted successfully'})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

# Supplier Contacts routes
@app.route('/api/suppliers/<int:supplier_id>/contacts', methods=['GET'])
@login_required
def get_supplier_contacts(supplier_id):
    """Get all contacts for a supplier"""
    db = SessionLocal()
    try:
        contacts = db.query(SupplierContact).filter(
            SupplierContact.supplier_id == supplier_id
        ).order_by(SupplierContact.is_primary.desc(), SupplierContact.id).all()
        return jsonify([c.to_dict() for c in contacts])
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>/contacts', methods=['POST'])
@permission_required('modify')
def create_supplier_contact(supplier_id):
    """Create a new contact for a supplier"""
    db = SessionLocal()
    try:
        # Verify supplier exists
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        data = request.json
        
        # If this is set as primary, unset other primary contacts
        if data.get('is_primary'):
            db.query(SupplierContact).filter(
                SupplierContact.supplier_id == supplier_id,
                SupplierContact.is_primary == 1
            ).update({'is_primary': 0})
        
        contact = SupplierContact(
            supplier_id=supplier_id,
            contact_name=data.get('contact_name', ''),
            position=data.get('position', ''),
            phone=data.get('phone', ''),
            email=data.get('email', ''),
            is_primary=1 if data.get('is_primary') else 0,
            contact_type=data.get('contact_type', 'general'),
            notes=data.get('notes', ''),
            created_by=session.get('user_id')
        )
        
        db.add(contact)
        db.commit()
        db.refresh(contact)
        return jsonify(contact.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>/contacts/<int:contact_id>', methods=['PUT'])
@permission_required('modify')
def update_supplier_contact(supplier_id, contact_id):
    """Update a supplier contact"""
    db = SessionLocal()
    try:
        contact = db.query(SupplierContact).filter(
            SupplierContact.id == contact_id,
            SupplierContact.supplier_id == supplier_id
        ).first()
        
        if not contact:
            return jsonify({'error': 'Contact not found'}), 404
        
        data = request.json
        
        # If setting as primary, unset other primary contacts
        if data.get('is_primary') and not contact.is_primary:
            db.query(SupplierContact).filter(
                SupplierContact.supplier_id == supplier_id,
                SupplierContact.is_primary == 1
            ).update({'is_primary': 0})
        
        # Update fields
        for key, value in data.items():
            if hasattr(contact, key):
                if key == 'is_primary':
                    setattr(contact, key, 1 if value else 0)
                else:
                    setattr(contact, key, value)
        
        contact.updated_at = datetime.utcnow()
        contact.updated_by = session.get('user_id')
        db.commit()
        db.refresh(contact)
        return jsonify(contact.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>/contacts/<int:contact_id>', methods=['DELETE'])
@permission_required('modify')
def delete_supplier_contact(supplier_id, contact_id):
    """Delete a supplier contact"""
    db = SessionLocal()
    try:
        contact = db.query(SupplierContact).filter(
            SupplierContact.id == contact_id,
            SupplierContact.supplier_id == supplier_id
        ).first()
        
        if not contact:
            return jsonify({'error': 'Contact not found'}), 404
        
        # Check if this is the last contact
        contact_count = db.query(SupplierContact).filter(
            SupplierContact.supplier_id == supplier_id
        ).count()
        
        if contact_count <= 1:
            return jsonify({'error': 'Cannot delete the last contact. At least one contact is required.'}), 400
        
        # If deleting primary contact, make another one primary
        if contact.is_primary:
            next_contact = db.query(SupplierContact).filter(
                SupplierContact.supplier_id == supplier_id,
                SupplierContact.id != contact_id
            ).first()
            if next_contact:
                next_contact.is_primary = 1
        
        db.delete(contact)
        db.commit()
        return jsonify({'message': 'Contact deleted successfully'})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/categories', methods=['GET'])
def get_categories():
    """Get all unique categories"""
    db = SessionLocal()
    try:
        categories = db.query(Supplier.category).distinct().all()
        return jsonify([c[0] for c in categories if c[0]])
    finally:
        db.close()

@app.route('/api/suppliers/countries', methods=['GET'])
def get_countries():
    """Get all unique countries"""
    db = SessionLocal()
    try:
        countries = db.query(Supplier.country).distinct().all()
        return jsonify([c[0] for c in countries if c[0]])
    finally:
        db.close()

@app.route('/api/suppliers/import/csv', methods=['POST'])
def import_csv():
    """Import suppliers from CSV file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    db = SessionLocal()
    try:
        df = pd.read_csv(file)
        count = 0
        errors = []
        
        for index, row in df.iterrows():
            try:
                name = row.get('name')
                if pd.isna(name) or not str(name).strip():
                    continue
                
                supplier = Supplier(
                    name=str(name).strip(),
                    contact_person=str(row.get('contact_person')).strip() if pd.notna(row.get('contact_person')) else None,
                    email=str(row.get('email')).strip() if pd.notna(row.get('email')) else None,
                    phone=str(row.get('phone')).strip() if pd.notna(row.get('phone')) else None,
                    address=str(row.get('address')).strip() if pd.notna(row.get('address')) else None,
                    city=str(row.get('city')).strip() if pd.notna(row.get('city')) else None,
                    country=str(row.get('country')).strip() if pd.notna(row.get('country')) else None,
                    tax_id=str(row.get('tax_id')).strip() if pd.notna(row.get('tax_id')) else None,
                    category=str(row.get('category')).strip() if pd.notna(row.get('category')) else None,
                    rating=float(row.get('rating', 0.0)) if pd.notna(row.get('rating')) else 0.0,
                    payment_terms=str(row.get('payment_terms')).strip() if pd.notna(row.get('payment_terms')) else None,
                    notes=str(row.get('notes')).strip() if pd.notna(row.get('notes')) else None,
                    active=int(row.get('active', 1))
                )
                db.add(supplier)
                count += 1
            except Exception as e:
                errors.append(f'Row {index + 2}: {str(e)}')
        
        db.commit()
        result = {'message': f'{count} suppliers imported successfully', 'count': count}
        if errors:
            result['errors'] = errors
        return jsonify(result)
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/import/excel', methods=['POST'])
@app.route('/api/suppliers/import/csv', methods=['POST'])
@permission_required('import')
def import_excel():
    """Import suppliers from Excel or CSV file with de-duplication and contact updates"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    db = SessionLocal()
    try:
        # Read CSV or Excel file
        if file.filename.endswith('.csv'):
            df = pd.read_csv(file)
        else:
            df = pd.read_excel(file)
            
        created_count = 0
        updated_count = 0
        errors = []
        
        for index, row in df.iterrows():
            try:
                name = row.get('name')
                if pd.isna(name) or not str(name).strip():
                    continue
                
                name = str(name).strip()
                
                # Check if supplier already exists (by name, tax_id, or email)
                existing_supplier = None
                
                # Try to find by tax_id first (most reliable)
                tax_id = row.get('tax_id')
                if pd.notna(tax_id) and str(tax_id).strip():
                    existing_supplier = db.query(Supplier).filter(Supplier.tax_id == str(tax_id).strip()).first()
                
                # If not found by tax_id, try by name
                if not existing_supplier:
                    existing_supplier = db.query(Supplier).filter(Supplier.name == name).first()
                
                # If not found by name, try by email
                if not existing_supplier:
                    email = row.get('email')
                    if pd.notna(email) and str(email).strip():
                        existing_supplier = db.query(Supplier).filter(Supplier.email == str(email).strip()).first()
                
                if existing_supplier:
                    # Update existing supplier with new contact information
                    updated = False
                    
                    # Update contact_person if provided and different
                    contact_person = row.get('contact_person')
                    if pd.notna(contact_person) and str(contact_person).strip():
                        new_contact = str(contact_person).strip()
                        if existing_supplier.contact_person != new_contact:
                            existing_supplier.contact_person = new_contact
                            updated = True
                    
                    # Update email if provided and different
                    if pd.notna(email) and str(email).strip():
                        new_email = str(email).strip()
                        if existing_supplier.email != new_email:
                            existing_supplier.email = new_email
                            updated = True
                    
                    # Update phone if provided and different
                    phone = row.get('phone')
                    if pd.notna(phone) and str(phone).strip():
                        new_phone = str(phone).strip()
                        if existing_supplier.phone != new_phone:
                            existing_supplier.phone = new_phone
                            updated = True
                    
                    # Update other fields if provided
                    address = row.get('address')
                    if pd.notna(address) and str(address).strip():
                        new_address = str(address).strip()
                        if existing_supplier.address != new_address:
                            existing_supplier.address = new_address
                            updated = True
                    
                    city = row.get('city')
                    if pd.notna(city) and str(city).strip():
                        new_city = str(city).strip()
                        if existing_supplier.city != new_city:
                            existing_supplier.city = new_city
                            updated = True
                    
                    country = row.get('country')
                    if pd.notna(country) and str(country).strip():
                        new_country = str(country).strip()
                        if existing_supplier.country != new_country:
                            existing_supplier.country = new_country
                            updated = True
                    
                    category = row.get('category')
                    if pd.notna(category) and str(category).strip():
                        new_category = str(category).strip()
                        if existing_supplier.category != new_category:
                            existing_supplier.category = new_category
                            updated = True
                    
                    rating = row.get('rating')
                    if pd.notna(rating):
                        new_rating = float(rating)
                        if existing_supplier.rating != new_rating:
                            existing_supplier.rating = new_rating
                            updated = True
                    
                    payment_terms = row.get('payment_terms')
                    if pd.notna(payment_terms) and str(payment_terms).strip():
                        new_terms = str(payment_terms).strip()
                        if existing_supplier.payment_terms != new_terms:
                            existing_supplier.payment_terms = new_terms
                            updated = True
                    
                    notes = row.get('notes')
                    if pd.notna(notes) and str(notes).strip():
                        new_notes = str(notes).strip()
                        if existing_supplier.notes != new_notes:
                            existing_supplier.notes = new_notes
                            updated = True
                    
                    # Update active status if provided
                    active = row.get('active')
                    if pd.notna(active):
                        new_active = int(active)
                        if existing_supplier.active != new_active:
                            existing_supplier.active = new_active
                            updated = True
                    
                    existing_supplier.updated_at = datetime.utcnow()
                    existing_supplier.updated_by = session.get('user_id')
                    
                    if updated:
                        updated_count += 1
                else:
                    # Create new supplier
                    supplier = Supplier(
                        name=name,
                        contact_person=str(contact_person).strip() if pd.notna(contact_person) else None,
                        email=str(email).strip() if pd.notna(email) else None,
                        phone=str(phone).strip() if pd.notna(phone) else None,
                        address=str(address).strip() if pd.notna(address) else None,
                        city=str(city).strip() if pd.notna(city) else None,
                        country=str(country).strip() if pd.notna(country) else None,
                        tax_id=str(tax_id).strip() if pd.notna(tax_id) else None,
                        category=str(category).strip() if pd.notna(category) else None,
                        rating=float(rating) if pd.notna(rating) else 0.0,
                        payment_terms=str(payment_terms).strip() if pd.notna(payment_terms) else None,
                        notes=str(notes).strip() if pd.notna(notes) else None,
                        active=int(active) if pd.notna(active) else 1,
                        created_by=session.get('user_id')
                    )
                    db.add(supplier)
                    created_count += 1
                    
            except Exception as e:
                errors.append(f'Row {index + 2}: {str(e)}')
        
        db.commit()
        result = {
            'message': f'Import completed: {created_count} suppliers created, {updated_count} suppliers updated',
            'created': created_count,
            'updated': updated_count
        }
        if errors:
            result['errors'] = errors
        return jsonify(result)
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/export/csv', methods=['GET'])
def export_csv():
    """Export suppliers to CSV file"""
    db = SessionLocal()
    try:
        suppliers = db.query(Supplier).all()
        data = [s.to_dict() for s in suppliers]
        df = pd.DataFrame(data)
        
        output = BytesIO()
        df.to_csv(output, index=False)
        output.seek(0)
        
        return send_file(
            output,
            mimetype='text/csv',
            as_attachment=True,
            download_name=f'suppliers_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        )
    finally:
        db.close()

@app.route('/api/suppliers/export/excel', methods=['GET'])
@permission_required('export')
def export_excel():
    """Export suppliers to Excel file"""
    db = SessionLocal()
    try:
        suppliers = db.query(Supplier).all()
        data = [s.to_dict() for s in suppliers]
        df = pd.DataFrame(data)
        
        # output = BytesIO()
        filename = f'suppliers_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        export_dir = os.path.join(os.path.dirname(__file__), '..', 'exports')
        os.makedirs(export_dir, exist_ok=True)
        file_path = os.path.abspath(os.path.join(export_dir, filename))

        df.to_excel(file_path, index=False, engine='openpyxl')
        # output.seek(0)
        
        # return jsonify({
        #     'success': True,
        #     'file_path': file_path,
        #     'filename': filename
        # })
        # return send_file(
        #     output,
        #     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        #     as_attachment=True,
        #     download_name=f'suppliers_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        # )
    finally:
        db.close()

@app.route('/api/orders', methods=['GET'])
@permission_required('view_orders')
def get_orders():
    """Get all orders with optional filters"""
    db = SessionLocal()
    try:
        query = db.query(Order)
        
        # Filter by status
        status = request.args.get('status', '')
        if status:
            query = query.filter(Order.status == status)
        
        # Filter by supplier
        supplier_id = request.args.get('supplier_id', '')
        if supplier_id:
            query = query.filter(Order.supplier_id == int(supplier_id))
        
        orders = query.all()
        return jsonify([o.to_dict() for o in orders])
    finally:
        db.close()

@app.route('/api/orders', methods=['POST'])
@permission_required('create_orders')
def create_order():
    """Create a new order"""
    db = SessionLocal()
    try:
        data = request.json
        
        # Get supplier name
        supplier = db.query(Supplier).filter(Supplier.id == data.get('supplier_id')).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        # Generate order number
        last_order = db.query(Order).order_by(Order.id.desc()).first()
        order_number = f"ORD-{(last_order.id + 1 if last_order else 1):06d}"
        
        order = Order(
            order_number=order_number,
            supplier_id=data.get('supplier_id'),
            supplier_name=supplier.name,
            delivery_date=datetime.fromisoformat(data.get('delivery_date')) if data.get('delivery_date') else None,
            status=data.get('status', 'pending'),
            total_amount=data.get('total_amount', 0.0),
            items=data.get('items', ''),
            notes=data.get('notes', ''),
            created_by=session.get('user_id')
        )
        db.add(order)
        db.commit()
        db.refresh(order)
        return jsonify(order.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    """Get a single order by ID"""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        return jsonify(order.to_dict())
    finally:
        db.close()

@app.route('/api/orders/<int:order_id>/items-parsed', methods=['GET'])
@login_required
def get_order_items_parsed(order_id):
    """Get order items with SKU information parsed"""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        
        # Get supplier
        supplier = db.query(Supplier).filter(Supplier.id == order.supplier_id).first()
        
        # Parse items
        parsed_items = []
        items_text = order.items or ''
        
        for line in items_text.strip().split('\n'):
            if not line.strip():
                continue
            
            item_data = {
                'internal_sku': '-',
                'vendor_sku': '-',
                'name': '',
                'qty': '',
                'price': ''
            }
            
            if '|' in line:
                # Pipe-separated format
                parts = [p.strip() for p in line.split('|')]
                if len(parts) >= 3:
                    item_data['internal_sku'] = parts[0]
                    item_data['name'] = parts[1]
                    item_data['qty'] = parts[2]
                    item_data['price'] = parts[3] if len(parts) > 3 else ''
            else:
                # Try "qty x name @ price" format
                import re
                match = re.match(r'(\d+)\s*x\s*(.+?)(?:\s*@\s*(.+))?$', line.strip(), re.IGNORECASE)
                if match:
                    item_data['qty'] = match.group(1)
                    item_data['name'] = match.group(2).strip()
                    item_data['price'] = match.group(3).strip() if match.group(3) else ''
                    
                    # Try to find item in database
                    db_item = db.query(Item).filter(Item.name.ilike(f'%{item_data["name"]}%')).first()
                    if db_item:
                        item_data['internal_sku'] = db_item.item_code
                        # Try to get vendor-specific SKU
                        if supplier:
                            supplier_item_link = db.execute(
                                select(supplier_items).where(
                                    supplier_items.c.supplier_id == supplier.id,
                                    supplier_items.c.item_id == db_item.id
                                )
                            ).first()
                            if supplier_item_link and supplier_item_link.supplier_item_code:
                                item_data['vendor_sku'] = supplier_item_link.supplier_item_code
                else:
                    # Fallback: raw line
                    item_data['name'] = line.strip()
            
            parsed_items.append(item_data)
        
        return jsonify({
            'success': True,
            'items': parsed_items
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/orders/<int:order_id>/status', methods=['PUT'])
@permission_required('update_orders')
def update_order_status(order_id):
    """Update order status"""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        
        data = request.json
        new_status = data.get('status')
        
        valid_statuses = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled']
        if new_status not in valid_statuses:
            return jsonify({'error': f'Invalid status. Must be one of: {", ".join(valid_statuses)}'}), 400
        
        order.status = new_status
        order.updated_by = session.get('user_id')
        db.commit()
        
        return jsonify(order.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

# Item routes
@app.route('/api/items/search', methods=['GET'])
@permission_required('search')
def search_items():
    """Search items by name or code and get suppliers that sell them"""
    db = SessionLocal()
    try:
        search = request.args.get('search', '')
        if not search:
            return jsonify({'error': 'Search parameter required'}), 400
        
        # Search for items
        items = db.query(Item).filter(
            (Item.name.ilike(f'%{search}%')) |
            (Item.item_code.ilike(f'%{search}%'))
        ).all()
        
        results = []
        for item in items:
            # Get suppliers for this item with their prices
            stmt = select(supplier_items).where(supplier_items.c.item_id == item.id)
            supplier_item_data = db.execute(stmt).fetchall()
            
            suppliers_info = []
            for si in supplier_item_data:
                supplier = db.query(Supplier).filter(Supplier.id == si.supplier_id).first()
                if supplier:
                    suppliers_info.append({
                        'supplier_id': supplier.id,
                        'supplier_name': supplier.name,
                        'email': supplier.email,
                        'phone': supplier.phone,
                        'price': si.price,
                        'supplier_item_code': si.supplier_item_code,
                        'lead_time_days': si.lead_time_days,
                        'minimum_order_quantity': si.minimum_order_quantity,
                        'notes': si.notes
                    })
            
            results.append({
                'item': item.to_dict(),
                'suppliers': suppliers_info
            })
        
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items', methods=['GET'])
@permission_required('view')
def get_items():
    """Get all items"""
    db = SessionLocal()
    try:
        items = db.query(Item).all()
        return jsonify([item.to_dict() for item in items])
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items', methods=['POST'])
@permission_required('create')
def create_item():
    """Create a new item"""
    db = SessionLocal()
    try:
        data = request.json
        
        # Validate required fields
        if not data.get('item_code') or not data.get('name'):
            return jsonify({'error': 'item_code and name are required'}), 400
        
        # Check if item code already exists
        existing = db.query(Item).filter(Item.item_code == data['item_code']).first()
        if existing:
            return jsonify({'error': 'Item code already exists'}), 400
        
        # Create new item
        new_item = Item(
            item_code=data['item_code'],
            name=data['name'],
            description=data.get('description', ''),
            category=data.get('category', ''),
            unit=data.get('unit', ''),
            created_by=session.get('user_id')
        )
        
        db.add(new_item)
        db.commit()
        db.refresh(new_item)
        
        return jsonify(new_item.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items/<int:item_id>', methods=['GET'])
def get_item(item_id):
    """Get a specific item"""
    db = SessionLocal()
    try:
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404
        return jsonify(item.to_dict(include_suppliers=True))
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items/<int:item_id>', methods=['PUT'])
@permission_required('modify')
def update_item(item_id):
    """Update an item (non-key fields only)"""
    db = SessionLocal()
    try:
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404
        
        data = request.json
        
        # Update only non-key fields
        if 'name' in data:
            item.name = data['name']
        if 'description' in data:
            item.description = data['description']
        if 'category' in data:
            item.category = data['category']
        if 'unit' in data:
            item.unit = data['unit']
        
        item.updated_at = datetime.utcnow()
        item.updated_by = session.get('user_id')
        db.commit()
        db.refresh(item)
        
        return jsonify(item.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items/<int:item_id>/suppliers', methods=['GET', 'POST'])
@permission_required('view')
def manage_item_suppliers(item_id):
    """Get all suppliers for an item (GET) or add a supplier to an item (POST)"""
    db = SessionLocal()
    try:
        # Verify item exists
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404
        
        if request.method == 'GET':
            # Get suppliers with their pricing info
            stmt = select(supplier_items).where(supplier_items.c.item_id == item_id)
            item_supplier_data = db.execute(stmt).fetchall()
            
            suppliers_info = []
            for si in item_supplier_data:
                supplier = db.query(Supplier).filter(Supplier.id == si.supplier_id).first()
                if supplier:
                    supplier_dict = supplier.to_dict()
                    supplier_dict['price'] = si.price
                    supplier_dict['supplier_item_code'] = si.supplier_item_code
                    supplier_dict['lead_time_days'] = si.lead_time_days
                    supplier_dict['minimum_order_quantity'] = si.minimum_order_quantity
                    supplier_dict['notes'] = si.notes
                    suppliers_info.append(supplier_dict)
            
            return jsonify(suppliers_info)
        
        elif request.method == 'POST':
            # Add a supplier to an item
            data = request.json
            supplier_id = data.get('supplier_id')
            
            if not supplier_id:
                return jsonify({'error': 'supplier_id is required'}), 400
            
            # Verify supplier exists
            supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
            if not supplier:
                return jsonify({'error': 'Supplier not found'}), 404
            
            # Check if relationship already exists
            stmt = select(supplier_items).where(
                (supplier_items.c.supplier_id == supplier_id) &
                (supplier_items.c.item_id == item_id)
            )
            existing = db.execute(stmt).fetchone()
            
            if existing:
                return jsonify({'error': 'This supplier is already associated with this item'}), 400
            
            # Insert new supplier-item relationship
            ins = supplier_items.insert().values(
                supplier_id=supplier_id,
                item_id=item_id,
                price=data.get('price'),
                supplier_item_code=data.get('supplier_item_code', ''),
                lead_time_days=data.get('lead_time_days'),
                minimum_order_quantity=data.get('minimum_order_quantity'),
                notes=data.get('notes', '')
            )
            db.execute(ins)
            db.commit()
            
            return jsonify({'message': 'Supplier added to item successfully'}), 201
            
    except Exception as e:
        if request.method == 'POST':
            db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items/<int:item_id>/suppliers/<int:supplier_id>', methods=['PUT', 'DELETE'])
def manage_item_supplier_relationship(item_id, supplier_id):
    """Update (PUT) or delete (DELETE) a supplier-item relationship"""
    db = SessionLocal()
    try:
        # Verify item exists
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404
        
        # Verify supplier exists
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        # Check if relationship exists
        stmt = select(supplier_items).where(
            (supplier_items.c.supplier_id == supplier_id) &
            (supplier_items.c.item_id == item_id)
        )
        existing = db.execute(stmt).fetchone()
        
        if not existing:
            return jsonify({'error': 'Relationship not found'}), 404
        
        if request.method == 'PUT':
            # Update the relationship
            data = request.json
            
            upd = supplier_items.update().where(
                (supplier_items.c.supplier_id == supplier_id) &
                (supplier_items.c.item_id == item_id)
            ).values(
                price=data.get('price'),
                supplier_item_code=data.get('supplier_item_code', ''),
                lead_time_days=data.get('lead_time_days'),
                minimum_order_quantity=data.get('minimum_order_quantity'),
                notes=data.get('notes', ''),
                updated_at=datetime.utcnow()
            )
            db.execute(upd)
            db.commit()
            
            return jsonify({'message': 'Supplier relationship updated successfully'}), 200
        
        elif request.method == 'DELETE':
            # Delete the relationship
            dlt = supplier_items.delete().where(
                (supplier_items.c.supplier_id == supplier_id) &
                (supplier_items.c.item_id == item_id)
            )
            db.execute(dlt)
            db.commit()
            
            return jsonify({'message': 'Supplier relationship deleted successfully'}), 200
            
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>/items', methods=['GET'])
def get_supplier_items(supplier_id):
    """Get all items sold by a specific supplier"""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        # Get items with their pricing info
        stmt = select(supplier_items).where(supplier_items.c.supplier_id == supplier_id)
        supplier_item_data = db.execute(stmt).fetchall()
        
        items_info = []
        for si in supplier_item_data:
            item = db.query(Item).filter(Item.id == si.item_id).first()
            if item:
                item_dict = item.to_dict()
                item_dict['price'] = si.price
                item_dict['supplier_item_code'] = si.supplier_item_code
                item_dict['lead_time_days'] = si.lead_time_days
                item_dict['minimum_order_quantity'] = si.minimum_order_quantity
                item_dict['notes'] = si.notes
                items_info.append(item_dict)
        
        return jsonify({
            'supplier': supplier.to_dict(),
            'items': items_info
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items/common-suppliers', methods=['POST'])
def get_common_suppliers():
    """Find suppliers that sell all specified items or group items by available suppliers"""
    db = SessionLocal()
    try:
        data = request.json
        item_ids = data.get('item_ids', [])
        
        if not item_ids:
            return jsonify({'error': 'No item IDs provided'}), 400
        
        # Get all suppliers for each item
        items_suppliers = {}
        for item_id in item_ids:
            stmt = select(supplier_items).where(supplier_items.c.item_id == item_id)
            supplier_data = db.execute(stmt).fetchall()
            items_suppliers[item_id] = [
                {
                    'supplier_id': sd.supplier_id,
                    'item_id': sd.item_id,
                    'price': sd.price,
                    'supplier_item_code': sd.supplier_item_code,
                    'lead_time_days': sd.lead_time_days
                }
                for sd in supplier_data
            ]
        
        # Find common suppliers (suppliers that have ALL items)
        if len(item_ids) == 1:
            # Single item - return all suppliers
            common_supplier_ids = set(s['supplier_id'] for s in items_suppliers[item_ids[0]])
        else:
            # Multiple items - find intersection
            supplier_sets = [
                set(s['supplier_id'] for s in items_suppliers[item_id])
                for item_id in item_ids
            ]
            common_supplier_ids = set.intersection(*supplier_sets) if supplier_sets else set()
        
        common_suppliers = []
        if common_supplier_ids:
            # Build details for common suppliers
            for supplier_id in common_supplier_ids:
                supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
                if not supplier:
                    continue
                
                supplier_items_list = []
                total_cost = 0
                
                for item_id in item_ids:
                    # Find this supplier's data for this item
                    item_data = next(
                        (s for s in items_suppliers[item_id] if s['supplier_id'] == supplier_id),
                        None
                    )
                    if item_data:
                        supplier_items_list.append({
                            'item_id': item_id,
                            'price': item_data['price'],
                            'supplier_item_code': item_data['supplier_item_code']
                        })
                        if item_data['price']:
                            total_cost += item_data['price']
                
                common_suppliers.append({
                    'supplier_id': supplier_id,
                    'supplier_name': supplier.name,
                    'email': supplier.email,
                    'phone': supplier.phone,
                    'items': supplier_items_list,
                    'total_cost': total_cost
                })
        
        # If no common suppliers, group items by best available suppliers
        supplier_groups = []
        if not common_supplier_ids:
            # For each item, find cheapest supplier
            used_suppliers = {}  # supplier_id -> [items]
            
            for item_id in item_ids:
                item = db.query(Item).filter(Item.id == item_id).first()
                suppliers_for_item = items_suppliers.get(item_id, [])
                
                if not suppliers_for_item:
                    continue
                
                # Find cheapest supplier for this item
                cheapest = min(
                    suppliers_for_item,
                    key=lambda x: x['price'] if x['price'] else float('inf')
                )
                
                supplier_id = cheapest['supplier_id']
                if supplier_id not in used_suppliers:
                    used_suppliers[supplier_id] = []
                
                used_suppliers[supplier_id].append({
                    'item_id': item_id,
                    'item_name': item.name if item else 'Unknown',
                    'price': cheapest['price'],
                    'supplier_item_code': cheapest['supplier_item_code']
                })
            
            # Build groups
            for supplier_id, items_list in used_suppliers.items():
                supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
                if not supplier:
                    continue
                
                total = sum(item['price'] for item in items_list if item['price'])
                
                supplier_groups.append({
                    'supplier_id': supplier_id,
                    'supplier_name': supplier.name,
                    'items': items_list,
                    'total_cost': total
                })
        
        return jsonify({
            'common_suppliers': common_suppliers,
            'supplier_groups': supplier_groups,
            'has_common_supplier': len(common_supplier_ids) > 0
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/suppliers/import/items-excel', methods=['POST'])
@app.route('/api/suppliers/import/with-items', methods=['POST'])
@permission_required('import')
def import_suppliers_with_items():
    """Import suppliers and their items from CSV or Excel file
    Expected CSV/Excel columns:
    - Required: supplier_name, item_code, item_name, price
    - Optional: supplier_email, supplier_phone, supplier_city, supplier_country,
                item_description, item_category, unit, supplier_item_code,
                lead_time_days, minimum_order_quantity, notes
    """
    db = SessionLocal()
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Read CSV or Excel file
        if file.filename.endswith('.csv'):
            df = pd.read_csv(file)
        else:
            df = pd.read_excel(file)
        
        # Expected columns: supplier_name, item_code, item_name, item_description, item_category, unit, price, supplier_item_code, lead_time_days, minimum_order_quantity, notes
        required_columns = ['supplier_name', 'item_code', 'item_name']
        if not all(col in df.columns for col in required_columns):
            return jsonify({'error': f'Excel must contain columns: {", ".join(required_columns)}'}), 400
        
        imported_count = 0
        errors = []
        
        for index, row in df.iterrows():
            try:
                # Get or create/update supplier
                supplier = db.query(Supplier).filter(Supplier.name == row['supplier_name']).first()
                if not supplier:
                    supplier = Supplier(
                        name=row['supplier_name'],
                        email=row.get('supplier_email'),
                        phone=row.get('supplier_phone'),
                        address=row.get('supplier_address'),
                        city=row.get('supplier_city'),
                        country=row.get('supplier_country'),
                        tax_id=row.get('supplier_tax_id'),
                        created_by=session.get('user_id')
                    )
                    db.add(supplier)
                    db.flush()  # Get the supplier ID
                else:
                    # Update existing supplier with new contact information
                    updated = False
                    
                    supplier_email = row.get('supplier_email')
                    if pd.notna(supplier_email) and str(supplier_email).strip():
                        new_email = str(supplier_email).strip()
                        if supplier.email != new_email:
                            supplier.email = new_email
                            updated = True
                    
                    supplier_phone = row.get('supplier_phone')
                    if pd.notna(supplier_phone) and str(supplier_phone).strip():
                        new_phone = str(supplier_phone).strip()
                        if supplier.phone != new_phone:
                            supplier.phone = new_phone
                            updated = True
                    
                    supplier_address = row.get('supplier_address')
                    if pd.notna(supplier_address) and str(supplier_address).strip():
                        new_address = str(supplier_address).strip()
                        if supplier.address != new_address:
                            supplier.address = new_address
                            updated = True
                    
                    supplier_city = row.get('supplier_city')
                    if pd.notna(supplier_city) and str(supplier_city).strip():
                        new_city = str(supplier_city).strip()
                        if supplier.city != new_city:
                            supplier.city = new_city
                            updated = True
                    
                    supplier_country = row.get('supplier_country')
                    if pd.notna(supplier_country) and str(supplier_country).strip():
                        new_country = str(supplier_country).strip()
                        if supplier.country != new_country:
                            supplier.country = new_country
                            updated = True
                    
                    supplier_tax_id = row.get('supplier_tax_id')
                    if pd.notna(supplier_tax_id) and str(supplier_tax_id).strip():
                        new_tax_id = str(supplier_tax_id).strip()
                        if supplier.tax_id != new_tax_id:
                            supplier.tax_id = new_tax_id
                            updated = True
                    
                    if updated:
                        supplier.updated_at = datetime.utcnow()
                        supplier.updated_by = session.get('user_id')
                
                # Get or create item
                item = db.query(Item).filter(Item.item_code == row['item_code']).first()
                if not item:
                    item = Item(
                        item_code=row['item_code'],
                        name=row['item_name'],
                        description=row.get('item_description'),
                        category=row.get('item_category'),
                        unit=row.get('unit')
                    )
                    db.add(item)
                    db.flush()  # Get the item ID
                
                # Check if relationship already exists
                stmt = select(supplier_items).where(
                    (supplier_items.c.supplier_id == supplier.id) &
                    (supplier_items.c.item_id == item.id)
                )
                existing = db.execute(stmt).first()
                
                if not existing:
                    # Create supplier-item relationship
                    ins = supplier_items.insert().values(
                        supplier_id=supplier.id,
                        item_id=item.id,
                        price=float(row['price']) if pd.notna(row.get('price')) else None,
                        supplier_item_code=row.get('supplier_item_code'),
                        lead_time_days=int(row['lead_time_days']) if pd.notna(row.get('lead_time_days')) else None,
                        minimum_order_quantity=int(row['minimum_order_quantity']) if pd.notna(row.get('minimum_order_quantity')) else None,
                        notes=row.get('notes')
                    )
                    db.execute(ins)
                
                imported_count += 1
            except Exception as e:
                errors.append(f'Row {index + 2}: {str(e)}')
        
        db.commit()
        
        return jsonify({
            'message': f'Successfully imported {imported_count} supplier-item relationships',
            'errors': errors if errors else None
        })
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/suppliers/import/custom-excel', methods=['POST'])
def import_custom_excel():
    """Import suppliers and items from custom Excel format with multiple sheets
    Expected sheets:
    - Materials sheet (e.g., Hoja4): No., item/Material, Proveedor, Costo
    - Suppliers sheet (e.g., Hoja2): Proveedor, Tipo de proveedor, Telefonos, Correo, Direccion
    """
    db = SessionLocal()
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Get sheet names from request or use defaults
        materials_sheet = request.form.get('materials_sheet', 'Hoja4')
        suppliers_sheet = request.form.get('suppliers_sheet', 'Hoja2')
        
        # Read Excel file with multiple sheets
        excel_file = pd.ExcelFile(file)
        
        # Check which sheets exist
        available_sheets = excel_file.sheet_names
        
        # Find materials sheet (try specified name first, then look for keywords)
        mat_sheet = None
        if materials_sheet in available_sheets:
            mat_sheet = materials_sheet
        else:
            for sheet in available_sheets:
                if 'hoja' in sheet.lower() or 'material' in sheet.lower() or 'item' in sheet.lower():
                    mat_sheet = sheet
                    break
        
        if not mat_sheet:
            return jsonify({'error': f'Materials sheet not found. Available sheets: {", ".join(available_sheets)}'}), 400
        
        # Find suppliers sheet (optional)
        sup_sheet = None
        if suppliers_sheet in available_sheets:
            sup_sheet = suppliers_sheet
        else:
            for sheet in available_sheets:
                if 'proveedor' in sheet.lower() and 'hoja' in sheet.lower():
                    sup_sheet = sheet
                    break
        
        imported_suppliers = 0
        imported_items = 0
        errors = []
        
        # Import suppliers first if sheet exists
        if sup_sheet:
            try:
                df_suppliers = pd.read_excel(excel_file, sheet_name=sup_sheet)
                
                for index, row in df_suppliers.iterrows():
                    try:
                        supplier_name = row.get('Proveedor')
                        
                        # Skip rows with missing or empty supplier name
                        if supplier_name is None or pd.isna(supplier_name) or str(supplier_name).strip() == '':
                            continue
                        
                        supplier_name = str(supplier_name).strip()
                        
                        # Check if supplier already exists
                        existing = db.query(Supplier).filter(Supplier.name == supplier_name).first()
                        if not existing:
                            supplier = Supplier(
                                name=supplier_name,
                                category=str(row.get('Tipo de proveedor')).strip() if pd.notna(row.get('Tipo de proveedor')) else None,
                                phone=str(row.get('Telefonos')).strip() if pd.notna(row.get('Telefonos')) else None,
                                email=str(row.get('Correo')).strip() if pd.notna(row.get('Correo')) else None,
                                address=str(row.get('Direccion')).strip() if pd.notna(row.get('Direccion')) else None,
                                notes=str(row.get('Relacion Comercial')).strip() if pd.notna(row.get('Relacion Comercial')) else None,
                                active=1,
                                created_by=session.get('user_id')
                            )
                            db.add(supplier)
                            imported_suppliers += 1
                        else:
                            # Update existing supplier with new contact information
                            updated = False
                            
                            phone = row.get('Telefonos')
                            if pd.notna(phone) and str(phone).strip():
                                new_phone = str(phone).strip()
                                if existing.phone != new_phone:
                                    existing.phone = new_phone
                                    updated = True
                            
                            email = row.get('Correo')
                            if pd.notna(email) and str(email).strip():
                                new_email = str(email).strip()
                                if existing.email != new_email:
                                    existing.email = new_email
                                    updated = True
                            
                            address = row.get('Direccion')
                            if pd.notna(address) and str(address).strip():
                                new_address = str(address).strip()
                                if existing.address != new_address:
                                    existing.address = new_address
                                    updated = True
                            
                            category = row.get('Tipo de proveedor')
                            if pd.notna(category) and str(category).strip():
                                new_category = str(category).strip()
                                if existing.category != new_category:
                                    existing.category = new_category
                                    updated = True
                            
                            relacion = row.get('Relacion Comercial')
                            if pd.notna(relacion) and str(relacion).strip():
                                new_notes = str(relacion).strip()
                                if existing.notes != new_notes:
                                    existing.notes = new_notes
                                    updated = True
                            
                            if updated:
                                existing.updated_at = datetime.utcnow()
                                existing.updated_by = session.get('user_id')
                    except Exception as e:
                        errors.append(f'Supplier row {index + 2}: {str(e)}')
                
                db.commit()
            except Exception as e:
                errors.append(f'Error reading suppliers sheet: {str(e)}')
        
        # Import materials/items
        try:
            df_materials = pd.read_excel(excel_file, sheet_name=mat_sheet)
            
            for index, row in df_materials.iterrows():
                try:
                    # Get item details
                    item_no = row.get('No.')
                    item_name = row.get('item/Material') or row.get('Material') or row.get('Item')
                    supplier_name = row.get('Proveedor')
                    price_str = row.get('Costo')
                    
                    # Skip rows with missing required data
                    if item_name is None or pd.isna(item_name) or str(item_name).strip() == '':
                        continue
                    if supplier_name is None or pd.isna(supplier_name) or str(supplier_name).strip() == '':
                        continue
                    
                    # Clean the names
                    item_name = str(item_name).strip()
                    supplier_name = str(supplier_name).strip()
                    
                    # Clean price (remove $, commas, spaces)
                    price = None
                    if pd.notna(price_str):
                        try:
                            price_clean = str(price_str).replace('$', '').replace(',', '').replace(' ', '').strip()
                            if price_clean:
                                price = float(price_clean)
                        except:
                            pass
                    
                    # Get or create supplier
                    supplier = db.query(Supplier).filter(Supplier.name == supplier_name).first()
                    if not supplier:
                        supplier = Supplier(
                            name=supplier_name,
                            active=1
                        )
                        db.add(supplier)
                        db.flush()
                        imported_suppliers += 1
                    
                    # Create item_code from No. or generate one
                    item_code = f"ITEM-{int(item_no)}" if pd.notna(item_no) else f"ITEM-{index+1}"
                    
                    # Get or create item
                    item = db.query(Item).filter(Item.item_code == item_code).first()
                    if not item:
                        item = Item(
                            item_code=item_code,
                            name=item_name,
                            description=row.get('Descripciòn/codigo') or row.get('Descripcion'),
                            category=row.get('Categoria') or 'General',
                            unit=row.get('Unidad') or 'pza'
                        )
                        db.add(item)
                        db.flush()
                        imported_items += 1
                    
                    # Check if relationship already exists
                    stmt = select(supplier_items).where(
                        (supplier_items.c.supplier_id == supplier.id) &
                        (supplier_items.c.item_id == item.id)
                    )
                    existing = db.execute(stmt).first()
                    
                    if not existing:
                        # Create supplier-item relationship
                        ins = supplier_items.insert().values(
                            supplier_id=supplier.id,
                            item_id=item.id,
                            price=price,
                            supplier_item_code=None,
                            lead_time_days=None,
                            minimum_order_quantity=None,
                            notes=None
                        )
                        db.execute(ins)
                
                except Exception as e:
                    errors.append(f'Material row {index + 2}: {str(e)}')
            
            db.commit()
            
        except Exception as e:
            return jsonify({'error': f'Error reading materials sheet: {str(e)}'}), 400
        
        return jsonify({
            'message': f'Import complete: {imported_suppliers} suppliers, {imported_items} items',
            'suppliers_imported': imported_suppliers,
            'items_imported': imported_items,
            'sheets_used': {
                'materials': mat_sheet,
                'suppliers': sup_sheet
            },
            'available_sheets': available_sheets,
            'errors': errors if errors else None
        })
    
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/database/info', methods=['GET'])
def get_database_info():
    """Get database connection information"""
    try:
        db_url = get_database_url()
        db_type = os.getenv('DATABASE_TYPE', 'sqlite')
        return jsonify({
            'type': db_type,
            'url': db_url.split('@')[-1] if '@' in db_url else db_url
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/config', methods=['GET'])
def get_config():
    """Get configuration (company details, logo, etc.)"""
    try:
        config = _load_config_map()
        
        return jsonify({
            'companyName': config.get('COMPANY_NAME', ''),
            'companyAddress': config.get('COMPANY_ADDRESS', ''),
            'companyPhone': config.get('COMPANY_PHONE', ''),
            'companyEmail': config.get('COMPANY_EMAIL', ''),
            'companyWebsite': config.get('COMPANY_WEBSITE', ''),
            'logoPath': config.get('LOGO_PATH', ''),
            'debug': config.get('DEBUG', 'false').lower() == 'true'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/config', methods=['POST'])
def save_config():
    """Save configuration (company details, logo, etc.)"""
    try:
        data = request.json
        company_name = data.get('companyName', '')
        company_address = data.get('companyAddress', '')
        company_phone = data.get('companyPhone', '')
        company_email = data.get('companyEmail', '')
        company_website = data.get('companyWebsite', '')
        logo_path = data.get('logoPath', '')
        debug = data.get('debug', False)

        config = _load_config_map()
        if not config.get('VERSION'):
            config['VERSION'] = _read_version_file()
        config['COMPANY_NAME'] = company_name
        config['COMPANY_ADDRESS'] = company_address
        config['COMPANY_PHONE'] = company_phone
        config['COMPANY_EMAIL'] = company_email
        config['COMPANY_WEBSITE'] = company_website
        config['LOGO_PATH'] = logo_path
        config['DEBUG'] = 'true' if debug else 'false'

        _write_config_map(config)
        
        return jsonify({
            'success': True,
            'message': 'Configuration saved successfully'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def _config_path():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    return os.path.join(base_dir, 'config', 'config.ini')

def _load_config_map():
    config = {}
    config_path = _config_path()
    if os.path.exists(config_path):
        import configparser
        cfg = configparser.ConfigParser()
        cfg.read(config_path, encoding='utf-8')
        
        # If sections exist, read from sections
        if cfg.sections():
            # Read COMPANY section
            if cfg.has_section('COMPANY'):
                for key in cfg.options('COMPANY'):
                    config[key.upper()] = cfg.get('COMPANY', key)
            # Read SERVER section
            if cfg.has_section('SERVER'):
                for key in cfg.options('SERVER'):
                    config[key.upper()] = cfg.get('SERVER', key)
        else:
            # Flat format: read from default section or no sections
            for section_name in cfg.sections() or [None]:
                if section_name is None:
                    # No sections, read from the parser's defaults or all
                    for key, value in cfg.defaults().items():
                        config[key.upper()] = value
                else:
                    for key in cfg.options(section_name):
                        config[key.upper()] = cfg.get(section_name, key)
    
    # Backward compatibility: map old keys to new keys
    old_to_new = {
        'NAME': 'COMPANY_NAME',
        'ADDRESS': 'COMPANY_ADDRESS', 
        'PHONE': 'COMPANY_PHONE',
        'EMAIL': 'COMPANY_EMAIL',
        'WEBSITE': 'COMPANY_WEBSITE',
        'COMPANY': 'COMPANY_NAME',  # if any
        'URL': 'URL'  # already correct
    }
    
    for old_key, new_key in old_to_new.items():
        if old_key in config and new_key not in config:
            config[new_key] = config[old_key]
    
    return config

def _write_config_map(config):
    config_path = _config_path()
    config_dir = os.path.dirname(config_path)
    if config_dir and not os.path.exists(config_dir):
        os.makedirs(config_dir, exist_ok=True)
    
    # Write in sectioned format compatible with installer
    import configparser
    cfg = configparser.ConfigParser()
    
    # COMPANY section
    cfg.add_section('COMPANY')
    cfg.set('COMPANY', 'company_name', config.get('COMPANY_NAME', ''))
    cfg.set('COMPANY', 'company_address', config.get('COMPANY_ADDRESS', ''))
    cfg.set('COMPANY', 'company_phone', config.get('COMPANY_PHONE', ''))
    cfg.set('COMPANY', 'company_email', config.get('COMPANY_EMAIL', ''))
    cfg.set('COMPANY', 'company_website', config.get('COMPANY_WEBSITE', ''))
    cfg.set('COMPANY', 'logo_path', config.get('LOGO_PATH', ''))
    cfg.set('COMPANY', 'version', config.get('VERSION', '1.3.0'))
    cfg.set('COMPANY', 'order_template_esp', config.get('ORDER_TEMPLATE_ESP', 'config/order_template_esp.html'))
    cfg.set('COMPANY', 'order_template_eng', config.get('ORDER_TEMPLATE_ENG', 'config/order_template_eng.html'))
    cfg.set('COMPANY', 'zoom', config.get('ZOOM', '1.0'))
    cfg.set('COMPANY', 'debug', config.get('DEBUG', 'false'))
    
    # SERVER section
    cfg.add_section('SERVER')
    cfg.set('SERVER', 'url', config.get('URL', 'http://127.0.0.0:5000'))
    
    with open(config_path, 'w', encoding='utf-8') as configfile:
        cfg.write(configfile)

def _read_version_file():
    local_version = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'VERSION'))
    if os.path.exists(local_version):
        return _safe_read_text(local_version).strip()
    return 'unknown'

def _get_release_repo_path():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    candidate = os.path.join(base_dir, 'Release', 'proveedores_versiones')
    return candidate if os.path.exists(candidate) else None

def _release_base_url():
    return 'https://raw.githubusercontent.com/unnombrechido/proveedores_versiones/main'

def _safe_read_text(path, max_bytes=512_000):
    try:
        with open(path, 'rb') as f:
            data = f.read(max_bytes)
        return data.decode('utf-8', errors='replace')
    except Exception:
        return ''

def _get_app_version():
    config = _load_config_map()
    if config.get('VERSION'):
        return config.get('VERSION').strip()
    return _read_version_file()

def _get_release_notes_path(version):
    release_repo = _get_release_repo_path()
    if release_repo:
        candidate = os.path.join(release_repo, 'versions', version, 'RELEASE_NOTES.md')
        if os.path.exists(candidate):
            return candidate
    return None

def _get_release_license_path():
    release_repo = _get_release_repo_path()
    if release_repo:
        candidate = os.path.join(release_repo, 'LICENSE')
        if os.path.exists(candidate):
            return candidate
    return None

@app.route('/api/about', methods=['GET'])
def get_about_info():
    """Get about/version information"""
    version = _get_app_version()
    developer = 'Sistema de Gestión de Proveedores - Equipo de Desarrollo'
    release_base = _release_base_url()
    release_notes_url = f"{release_base}/versions/{version}/RELEASE_NOTES.md"
    license_url = f"{release_base}/LICENSE"

    return jsonify({
        'version': version,
        'developer': developer,
        'releaseNotesUrl': release_notes_url,
        'licenseUrl': license_url,
        'hasReleaseNotes': True,
        'hasLicense': True
    })

def _resolve_logo_path():
    config = _load_config_map()
    logo_path = (config.get('LOGO_PATH') or '').strip()
    if not logo_path:
        logo_path = 'logo.png'

    if logo_path.startswith('http://') or logo_path.startswith('https://'):
        return {'type': 'url', 'value': logo_path}

    # Absolute path
    if os.path.isabs(logo_path) and os.path.exists(logo_path):
        return {'type': 'file', 'value': logo_path}

    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    static_path = os.path.join(base_dir, 'api', 'static', logo_path)
    if os.path.exists(static_path):
        return {'type': 'file', 'value': static_path}

    config_path = os.path.join(base_dir, 'config', logo_path)
    if os.path.exists(config_path):
        return {'type': 'file', 'value': config_path}

    # Fallback to default logo if present
    fallback_logo = os.path.join(base_dir, 'api', 'static', 'logo.png')
    if os.path.exists(fallback_logo):
        return {'type': 'file', 'value': fallback_logo}

    return None

def _allowed_file(filename, allowed_extensions):
    """Check if file has allowed extension"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

@app.route('/api/logo', methods=['GET'])
def get_logo():
    resolved = _resolve_logo_path()
    if not resolved:
        return Response('Logo not found', status=404)
    if resolved['type'] == 'url':
        return redirect(resolved['value'])
    return send_file(resolved['value'])

@app.route('/api/logo', methods=['POST'])
def upload_logo():
    """Upload company logo"""
    try:
        if 'logo' not in request.files:
            return jsonify({'error': 'No logo file provided'}), 400
        
        file = request.files['logo']
        if file.filename == '':
            return jsonify({'error': 'No logo file selected'}), 400
        
        if file and _allowed_file(file.filename, {'png', 'jpg', 'jpeg', 'gif', 'ico'}):
            # Ensure static directory exists
            static_dir = os.path.join(app.root_path, 'static')
            os.makedirs(static_dir, exist_ok=True)
            
            # Save the file
            filename = 'company_logo.' + file.filename.rsplit('.', 1)[1].lower()
            filepath = os.path.join(static_dir, filename)
            file.save(filepath)
            
            # Update config
            config = _load_config_map()
            config['LOGO_PATH'] = filename
            _write_config_map(config)
            
            return jsonify({'success': True, 'filename': filename})
        else:
            return jsonify({'error': 'Invalid file type. Allowed: png, jpg, jpeg, gif, ico'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/favicon.ico')
def favicon():
    resolved = _resolve_logo_path()
    if not resolved:
        return Response(status=204)
    if resolved['type'] == 'url':
        return redirect(resolved['value'])
    return send_file(resolved['value'])

@app.route('/release/notes/<version>', methods=['GET'])
def get_release_notes(version):
    """Return release notes content from release repository if available"""
    notes_path = _get_release_notes_path(version)
    if not notes_path or not os.path.exists(notes_path):
        return Response('Release notes not found', status=404)
    content = _safe_read_text(notes_path)
    return Response(content, mimetype='text/plain; charset=utf-8')

@app.route('/release/license/<version>', methods=['GET'])
def get_release_license(version):
    """Return license content from release repository if available"""
    license_path = _get_release_license_path()
    if not license_path or not os.path.exists(license_path):
        return Response('License not found', status=404)
    content = _safe_read_text(license_path)
    return Response(content, mimetype='text/plain; charset=utf-8')

# User Management Routes
@app.route('/api/users', methods=['GET'])
@role_required('sysadmin')
def get_users():
    """Get all users (sysadmin only)"""
    db = SessionLocal()
    try:
        query = db.query(User)
        
        # Search filter
        search = request.args.get('search', '')
        if search:
            query = query.filter(
                (User.email.ilike(f'%{search}%')) |
                (User.nombre.ilike(f'%{search}%')) |
                (User.apellido.ilike(f'%{search}%'))
            )
        
        # Role filter
        rol = request.args.get('rol', '')
        if rol:
            query = query.filter(User.rol == rol)
        
        # Status filter
        status = request.args.get('status', '')
        if status:
            query = query.filter(User.status == status)
        
        users = query.all()
        return jsonify({
            'success': True,
            'users': [user.to_dict() for user in users],
            'total': len(users)
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/users/<int:user_id>', methods=['GET'])
@role_required('sysadmin')
def get_user(user_id):
    """Get specific user by ID (sysadmin only)"""
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'error': 'Usuario no encontrado'}), 404
        
        return jsonify({
            'success': True,
            'user': user.to_dict()
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/users', methods=['POST'])
@role_required('sysadmin')
def create_user():
    """Create new user (sysadmin only)"""
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['email', 'password', 'nombre', 'apellido', 'rol']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'error': f'Campo requerido: {field}'}), 400
    
    # Validate role
    valid_roles = ['sysadmin', 'admin', 'compras']
    if data['rol'] not in valid_roles:
        return jsonify({'error': f'Rol inválido. Use: {", ".join(valid_roles)}'}), 400
    
    db = SessionLocal()
    try:
        # Check if email already exists
        existing = db.query(User).filter(User.email == data['email']).first()
        if existing:
            return jsonify({'error': 'El email ya está registrado'}), 409
        
        # Create new user
        user = User(
            email=data['email'].strip().lower(),
            nombre=data['nombre'].strip(),
            apellido=data['apellido'].strip(),
            telefono=data.get('telefono', '').strip(),
            rol=data['rol'],
            status=data.get('status', 'activo')
        )
        user.set_password(data['password'])
        
        db.add(user)
        db.commit()
        db.refresh(user)
        
        return jsonify({
            'success': True,
            'message': 'Usuario creado exitosamente',
            'user': user.to_dict()
        }), 201
    
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/users/<int:user_id>', methods=['PUT'])
@role_required('sysadmin')
def update_user(user_id):
    """Update user (sysadmin only)"""
    data = request.get_json()
    
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'error': 'Usuario no encontrado'}), 404
        
        # Update fields if provided
        if 'email' in data:
            # Check if new email is already taken
            existing = db.query(User).filter(
                User.email == data['email'], 
                User.id != user_id
            ).first()
            if existing:
                return jsonify({'error': 'El email ya está registrado'}), 409
            user.email = data['email'].strip().lower()
        
        if 'nombre' in data:
            user.nombre = data['nombre'].strip()
        
        if 'apellido' in data:
            user.apellido = data['apellido'].strip()
        
        if 'telefono' in data:
            user.telefono = data['telefono'].strip()
        
        if 'rol' in data:
            valid_roles = ['sysadmin', 'admin', 'compras']
            if data['rol'] not in valid_roles:
                return jsonify({'error': f'Rol inválido. Use: {", ".join(valid_roles)}'}), 400
            user.rol = data['rol']
        
        if 'status' in data:
            valid_statuses = ['activo', 'inactivo']
            if data['status'] not in valid_statuses:
                return jsonify({'error': f'Estado inválido. Use: {", ".join(valid_statuses)}'}), 400
            user.status = data['status']
        
        db.commit()
        db.refresh(user)
        
        return jsonify({
            'success': True,
            'message': 'Usuario actualizado exitosamente',
            'user': user.to_dict()
        })
    
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/users/<int:user_id>/password', methods=['PUT'])
@login_required
def change_password(user_id):
    """Change user password (sysadmin can change any, users can change own)"""
    data = request.get_json()
    
    # Check permissions
    if user_id != current_user.id and not current_user.is_sysadmin:
        return jsonify({'error': 'Acceso denegado'}), 403
    
    if not data.get('new_password'):
        return jsonify({'error': 'Nueva contraseña requerida'}), 400
    
    # If user is changing their own password, require current password
    if user_id == current_user.id and not current_user.is_sysadmin:
        if not data.get('current_password'):
            return jsonify({'error': 'Contraseña actual requerida'}), 400
        if not current_user.check_password(data['current_password']):
            return jsonify({'error': 'Contraseña actual incorrecta'}), 401
    
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'error': 'Usuario no encontrado'}), 404
        
        user.set_password(data['new_password'])
        db.commit()
        
        return jsonify({
            'success': True,
            'message': 'Contraseña actualizada exitosamente'
        })
    
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/users/<int:user_id>', methods=['DELETE'])
@role_required('sysadmin')
def delete_user(user_id):
    """Delete user (sysadmin only)"""
    if user_id == current_user.id:
        return jsonify({'error': 'No puede eliminar su propia cuenta'}), 400
    
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'error': 'Usuario no encontrado'}), 404
        
        db.delete(user)
        db.commit()
        
        return jsonify({
            'success': True,
            'message': 'Usuario eliminado exitosamente'
        })
    
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/orders/<int:order_id>/print', methods=['GET'])
def print_order(order_id):
    """Render order using HTML template with placeholders"""
    db = SessionLocal()
    try:
        # Get order
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        
        # Get supplier to fetch payment_terms
        supplier = db.query(Supplier).filter(Supplier.id == order.supplier_id).first()
        payment_terms = supplier.payment_terms if supplier else 'N/A'
        
        # Get parameters
        lang = request.args.get('lang', 'esp').lower()  # esp or eng
        mode = request.args.get('mode', 'internal')  # internal or vendor
        
        # Load config
        config_map = _load_config_map()
        template_key = f'ORDER_TEMPLATE_{lang.upper()}'
        template_name = f'order_template_{lang.lower()}.html'
        template_path = config_map.get(template_key, f'config/{template_name}')
        
        # Resolve template path (relative to project root)
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        full_template_path = os.path.join(base_dir, template_path)
        
        if not os.path.exists(full_template_path):
            return jsonify({'error': f'Template not found: {template_path}'}), 404
        
        # Read template
        with open(full_template_path, 'r', encoding='utf-8') as f:
            template_html = f.read()
        
        # Build letterhead HTML
        company_name = config_map.get('COMPANY_NAME', 'Mi Empresa')
        logo_path = config_map.get('LOGO_PATH', '')
        
        letterhead_html = ''
        if logo_path and os.path.exists(logo_path):
            # Use data URI for logo
            import base64
            with open(logo_path, 'rb') as logo_file:
                logo_data = base64.b64encode(logo_file.read()).decode('utf-8')
                logo_ext = os.path.splitext(logo_path)[1].lower().replace('.', '')
                if logo_ext == 'jpg':
                    logo_ext = 'jpeg'
                letterhead_html += f'<img src="data:image/{logo_ext};base64,{logo_data}" class="letterhead-logo" alt="Logo">'
        letterhead_html += f'<div class="letterhead-text"><h1>{company_name}</h1></div>'
        
        # Parse items (support multiple formats)
        items_rows_html = ''
        items_text = order.items or ''
        
        for line in items_text.strip().split('\n'):
            if not line.strip():
                continue
            
            # Try to parse different formats
            # Format 1: "1 x CUADRADO 3/4 CAL.18 @ $103.19"
            # Format 2: "ID|Name|Qty|Price"
            # Format 3: "10 x Item A"
            
            if '|' in line:
                # Pipe-separated format
                parts = [p.strip() for p in line.split('|')]
                if len(parts) >= 3:
                    item_id = parts[0]
                    item_name = parts[1]
                    qty = parts[2]
                    price = parts[3] if len(parts) > 3 else ''
                    
                    if mode == 'vendor':
                        items_rows_html += f'<tr><td>{item_id}</td><td>{item_name}</td><td>{qty}</td></tr>'
                    else:
                        items_rows_html += f'<tr><td>{item_id}</td><td>{item_name}</td><td>{qty}</td><td>{price}</td></tr>'
            else:
                # Try "qty x name @ price" format
                import re
                match = re.match(r'(\d+)\s*x\s*(.+?)(?:\s*@\s*(.+))?$', line.strip(), re.IGNORECASE)
                if match:
                    qty = match.group(1)
                    item_name = match.group(2).strip()
                    price = match.group(3).strip() if match.group(3) else ''
                    
                    # Try to find item in database to get SKU
                    item_sku = '-'
                    vendor_sku = '-'
                    db_item = db.query(Item).filter(Item.name.ilike(f'%{item_name}%')).first()
                    if db_item:
                        item_sku = db_item.item_code
                        # Try to get vendor-specific SKU from supplier_items
                        if supplier:
                            supplier_item_link = db.execute(
                                select(supplier_items).where(
                                    supplier_items.c.supplier_id == supplier.id,
                                    supplier_items.c.item_id == db_item.id
                                )
                            ).first()
                            if supplier_item_link and supplier_item_link.supplier_item_code:
                                vendor_sku = supplier_item_link.supplier_item_code
                    
                    # Use internal SKU for internal mode, vendor SKU for vendor mode
                    sku_to_show = vendor_sku if mode == 'vendor' else item_sku
                    
                    if mode == 'vendor':
                        items_rows_html += f'<tr><td>{sku_to_show}</td><td>{item_name}</td><td>{qty}</td></tr>'
                    else:
                        items_rows_html += f'<tr><td>{sku_to_show}</td><td>{item_name}</td><td>{qty}</td><td>{price}</td></tr>'
                else:
                    # Fallback: just display the line as-is
                    if mode == 'vendor':
                        items_rows_html += f'<tr><td colspan="3">{line.strip()}</td></tr>'
                    else:
                        items_rows_html += f'<tr><td colspan="4">{line.strip()}</td></tr>'
        
        # Status label translation
        status_labels = {
            'esp': {
                'pending': 'Pendiente',
                'confirmed': 'Confirmada',
                'shipped': 'Enviada',
                'delivered': 'Entregada',
                'cancelled': 'Cancelada'
            },
            'eng': {
                'pending': 'Pending',
                'confirmed': 'Confirmed',
                'shipped': 'Shipped',
                'delivered': 'Delivered',
                'cancelled': 'Cancelled'
            }
        }
        status_label = status_labels.get(lang, status_labels['esp']).get(order.status, order.status.title())
        
        # SKU header based on mode and language
        if mode == 'vendor':
            sku_header = 'SKU Proveedor' if lang == 'esp' else 'Vendor SKU'
        else:
            sku_header = 'SKU Interno' if lang == 'esp' else 'Internal SKU'
        
        # Conditionally show price header and total
        if mode == 'vendor':
            price_header = ''
            total_section = ''
        else:
            price_header = '<th>Precio</th>' if lang == 'esp' else '<th>Price</th>'
            total_label = 'Total' if lang == 'esp' else 'Total'
            total_section = f'<div class="total">{total_label}: ${order.total_amount or 0:.2f}</div>'
        
        # Build notes section
        notes_section = ''
        if order.notes:
            notes_label = 'Notas' if lang == 'esp' else 'Notes'
            notes_section = f'''
            <div class="notes-section">
                <h3>{notes_label}</h3>
                <div>{order.notes}</div>
            </div>
            '''
        
        # Replace placeholders
        replacements = {
            '##letterhead##': letterhead_html,
            '##order_number##': order.order_number or '',
            '##status##': order.status or 'pending',
            '##status_label##': status_label,
            '##supplier_name##': order.supplier_name or '',
            '##order_date##': order.order_date.strftime('%Y-%m-%d') if order.order_date else '',
            '##delivery_date##': order.delivery_date.strftime('%Y-%m-%d') if order.delivery_date else 'N/A',
            '##payment_terms##': payment_terms or 'N/A',
            '##items_rows##': items_rows_html,
            '##sku_header##': sku_header,
            '##price_header##': price_header,
            '##total_section##': total_section,
            '##notes_section##': notes_section
        }
        
        for placeholder, value in replacements.items():
            template_html = template_html.replace(placeholder, str(value))
        
        return Response(template_html, mimetype='text/html')
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/orders/<int:order_id>/email-html', methods=['GET'])
@login_required
def get_order_email_html(order_id):
    """Get the HTML content for embedding in email"""
    db = SessionLocal()
    try:
        # Get order
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        
        # Get supplier to fetch payment_terms
        supplier = db.query(Supplier).filter(Supplier.id == order.supplier_id).first()
        payment_terms = supplier.payment_terms if supplier else 'N/A'
        
        # Get parameters
        lang = request.args.get('lang', 'esp').lower()
        mode = request.args.get('mode', 'vendor')
        
        # Load config
        config_map = _load_config_map()
        template_key = f'ORDER_TEMPLATE_{lang.upper()}'
        template_path = config_map.get(template_key, 'config/order_template_esp.html')
        
        # Resolve template path
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        full_template_path = os.path.join(base_dir, template_path)
        
        if not os.path.exists(full_template_path):
            return jsonify({'error': f'Template not found'}), 404
        
        # Read template
        with open(full_template_path, 'r', encoding='utf-8') as f:
            template_html = f.read()
        
        # Build letterhead with embedded logo
        company_name = config_map.get('COMPANY_NAME', 'Mi Empresa')
        logo_path = config_map.get('LOGO_PATH', '')
        
        letterhead_html = ''
        if logo_path and os.path.exists(logo_path):
            import base64
            with open(logo_path, 'rb') as logo_file:
                logo_data = base64.b64encode(logo_file.read()).decode('utf-8')
                logo_ext = os.path.splitext(logo_path)[1].lower().replace('.', '')
                if logo_ext == 'jpg':
                    logo_ext = 'jpeg'
                letterhead_html += f'<img src="data:image/{logo_ext};base64,{logo_data}" class="letterhead-logo" alt="Logo">'
        letterhead_html += f'<div class="letterhead-text"><h1>{company_name}</h1></div>'
        
        # Parse items
        items_rows_html = ''
        items_text = order.items or ''
        
        for line in items_text.strip().split('\n'):
            if not line.strip():
                continue
            
            if '|' in line:
                parts = [p.strip() for p in line.split('|')]
                if len(parts) >= 3:
                    item_id = parts[0]
                    item_name = parts[1]
                    qty = parts[2]
                    price = parts[3] if len(parts) > 3 else ''
                    
                    if mode == 'vendor':
                        items_rows_html += f'<tr><td>{item_id}</td><td>{item_name}</td><td>{qty}</td></tr>'
                    else:
                        items_rows_html += f'<tr><td>{item_id}</td><td>{item_name}</td><td>{qty}</td><td>{price}</td></tr>'
            else:
                import re
                match = re.match(r'(\d+)\s*x\s*(.+?)(?:\s*@\s*(.+))?$', line.strip(), re.IGNORECASE)
                if match:
                    qty = match.group(1)
                    item_name = match.group(2).strip()
                    price = match.group(3).strip() if match.group(3) else ''
                    
                    item_sku = '-'
                    vendor_sku = '-'
                    db_item = db.query(Item).filter(Item.name.ilike(f'%{item_name}%')).first()
                    if db_item:
                        item_sku = db_item.item_code
                        if supplier:
                            supplier_item_link = db.execute(
                                select(supplier_items).where(
                                    supplier_items.c.supplier_id == supplier.id,
                                    supplier_items.c.item_id == db_item.id
                                )
                            ).first()
                            if supplier_item_link and supplier_item_link.supplier_item_code:
                                vendor_sku = supplier_item_link.supplier_item_code
                    
                    sku_to_show = vendor_sku if mode == 'vendor' else item_sku
                    
                    if mode == 'vendor':
                        items_rows_html += f'<tr><td>{sku_to_show}</td><td>{item_name}</td><td>{qty}</td></tr>'
                    else:
                        items_rows_html += f'<tr><td>{sku_to_show}</td><td>{item_name}</td><td>{qty}</td><td>{price}</td></tr>'
                else:
                    if mode == 'vendor':
                        items_rows_html += f'<tr><td colspan="3">{line.strip()}</td></tr>'
                    else:
                        items_rows_html += f'<tr><td colspan="4">{line.strip()}</td></tr>'
        
        # Status translation
        status_labels = {
            'esp': {'pending': 'Pendiente', 'confirmed': 'Confirmada', 'shipped': 'Enviada', 'delivered': 'Entregada', 'cancelled': 'Cancelada'},
            'eng': {'pending': 'Pending', 'confirmed': 'Confirmed', 'shipped': 'Shipped', 'delivered': 'Delivered', 'cancelled': 'Cancelled'}
        }
        status_label = status_labels.get(lang, status_labels['esp']).get(order.status, order.status.title())
        
        # Headers
        sku_header = 'SKU Proveedor' if (lang == 'esp' and mode == 'vendor') else ('Vendor SKU' if mode == 'vendor' else ('SKU Interno' if lang == 'esp' else 'Internal SKU'))
        
        if mode == 'vendor':
            price_header = ''
            total_section = ''
        else:
            price_header = '<th>Precio</th>' if lang == 'esp' else '<th>Price</th>'
            total_label = 'Total' if lang == 'esp' else 'Total'
            total_section = f'<div class="total">{total_label}: ${order.total_amount or 0:.2f}</div>'
        
        notes_section = ''
        if order.notes:
            notes_label = 'Notas' if lang == 'esp' else 'Notes'
            notes_section = f'<div class="notes-section"><h3>{notes_label}</h3><div>{order.notes}</div></div>'
        
        # Replace placeholders
        replacements = {
            '##letterhead##': letterhead_html,
            '##order_number##': order.order_number or '',
            '##status##': order.status or 'pending',
            '##status_label##': status_label,
            '##supplier_name##': order.supplier_name or '',
            '##order_date##': order.order_date.strftime('%Y-%m-%d') if order.order_date else '',
            '##delivery_date##': order.delivery_date.strftime('%Y-%m-%d') if order.delivery_date else 'N/A',
            '##payment_terms##': payment_terms or 'N/A',
            '##items_rows##': items_rows_html,
            '##sku_header##': sku_header,
            '##price_header##': price_header,
            '##total_section##': total_section,
            '##notes_section##': notes_section
        }
        
        for placeholder, value in replacements.items():
            template_html = template_html.replace(placeholder, str(value))
        
        # Return JSON with HTML content for embedding
        return jsonify({
            'success': True,
            'html': template_html,
            'subject': f'Orden de Compra {order.order_number}' if lang == 'esp' else f'Purchase Order {order.order_number}'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

# Settings Routes
@app.route('/api/settings/company', methods=['GET'])
@login_required
def get_company_settings():
    """Get company settings"""
    try:
        # For now, return default settings. In a real app, you'd store these in the database
        settings = {
            'name': '',
            'address': '',
            'phone': '',
            'email': '',
            'website': '',
            'logo': None
        }
        
        # Load from config file in sectioned format
        config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'config.ini')
        if os.path.exists(config_path):
            import configparser
            config = configparser.ConfigParser()
            config.read(config_path)
            
            # Load from COMPANY section
            if 'COMPANY' in config:
                settings.update({
                    'name': config['COMPANY'].get('company_name', settings['name']),
                    'address': config['COMPANY'].get('company_address', settings['address']),
                    'phone': config['COMPANY'].get('company_phone', settings['phone']),
                    'email': config['COMPANY'].get('company_email', settings['email']),
                    'website': config['COMPANY'].get('company_website', settings['website'])
                })
                logo_path = config['COMPANY'].get('logo_path', '')
            
            # Check for logo
            if logo_path and os.path.exists(logo_path):
                # Return logo as data URL
                import base64
                with open(logo_path, 'rb') as logo_file:
                    logo_data = base64.b64encode(logo_file.read()).decode('utf-8')
                    logo_ext = os.path.splitext(logo_path)[1].lower().replace('.', '')
                    if logo_ext == 'jpg':
                        logo_ext = 'jpeg'
                    settings['logo'] = f'data:image/{logo_ext};base64,{logo_data}'
        
        return jsonify({'success': True, 'settings': settings})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/settings/company', methods=['POST'])
def save_company_settings():
    """Save company settings or update zoom (all users)"""
    try:
        data = request.get_json()
        config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'config.ini')
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        import configparser
        config = configparser.ConfigParser()
        if os.path.exists(config_path):
            config.read(config_path)

        # Allow all users to update zoom
        if 'zoom' in data:
            if 'COMPANY' not in config:
                config.add_section('COMPANY')
            config['COMPANY']['zoom'] = str(data['zoom'])
            with open(config_path, 'w', encoding='utf-8') as configfile:
                config.write(configfile)
            return jsonify({'success': True, 'message': 'Zoom actualizado'})

        # Only admin/sysadmin can update company info
        if not getattr(current_user, 'is_admin', False) and not getattr(current_user, 'is_sysadmin', False):
            return jsonify({'error': 'Acceso denegado. Permisos insuficientes.'}), 403

        if 'COMPANY' not in config:
            config.add_section('COMPANY')
        config['COMPANY']['company_name'] = data.get('name', '')
        config['COMPANY']['company_address'] = data.get('address', '')
        config['COMPANY']['company_phone'] = data.get('phone', '')
        config['COMPANY']['company_email'] = data.get('email', '')
        config['COMPANY']['company_website'] = data.get('website', '')
        with open(config_path, 'w', encoding='utf-8') as configfile:
            config.write(configfile)
        return jsonify({'success': True, 'message': 'Configuración guardada exitosamente'})
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        print("[ERROR] save_company_settings:", tb)
        return jsonify({'error': str(e), 'traceback': tb}), 500

if __name__ == '__main__':
    # Check if running as a Windows service
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == '--service':
        # Running as a service - use a more robust server configuration
        from werkzeug.serving import make_server
        import threading
        import logging
        import time

        # Set up logging for service mode
        log_dir = Path(__file__).parent.parent / 'logs'
        log_dir.mkdir(exist_ok=True)
        logging.basicConfig(
            filename=str(log_dir / 'service_startup.log'),
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        logger = logging.getLogger(__name__)

        logger.info("Starting Flask server in service mode")

        port = int(os.getenv('PORT', 5000))
        server = make_server('0.0.0.0', port, app, threaded=True)

        logger.info(f"Server created on port {port}")

        # Give the server a moment to initialize
        time.sleep(2)

        logger.info("Calling server.serve_forever()")

        server.serve_forever()
    else:
        # Normal development mode
        port = int(os.getenv('PORT', 5000))
        debug = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
        app.run(host='0.0.0.0', port=port, debug=debug)
@app.route('/api/items/export', methods=['GET'])
@permission_required('export')
def export_items():
    """"Export items to Excel file"""
    db = SessionLocal()
    try:
        items = db.query(Item).all()
        data = [i.to_dict(include_suppliers=False) for i in items]
        df = pd.DataFrame(data)
        
        filename = f'items_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        export_dir = os.path.join(os.path.dirname(__file__), '..', 'exports')
        os.makedirs(export_dir, exist_ok=True)
        file_path = os.path.abspath(os.path.join(export_dir, filename))
        df.to_excel(file_path, index=False, engine='openpyxl')
        # return jsonify({
        #     'success': True,
        #     'file_path': file_path,
        #     'filename': filename
        # })
        # output = BytesIO()
        # df.to_excel(output, index=False, engine='openpyxl')
        # output.seek(0)
        
        # return send_file(
        #     output,
        #     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        #     as_attachment=True,
        #     download_name=f'items_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        # )
    finally:
        db.close()

@app.route('/api/orders/export', methods=['GET'])
@permission_required('export')
def export_orders():
    """"Export orders to Excel file"""
    db = SessionLocal()
    try:
        orders = db.query(Order).all()
        data = [o.to_dict() for o in orders]
        df = pd.DataFrame(data)
        
        filename = f'orders_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        export_dir = os.path.join(os.path.dirname(__file__), '..', 'exports')
        os.makedirs(export_dir, exist_ok=True)
        file_path = os.path.abspath(os.path.join(export_dir, filename))
        df.to_excel(file_path, index=False, engine='openpyxl')
        # return jsonify({
        #     'success': True,
        #     'file_path': file_path,
        #     'filename': filename
        # })
    finally:
        db.close()

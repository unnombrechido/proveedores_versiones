"""
Database Migration Utility
Migrates data from old database structure to new structure
Handles schema differences intelligently
"""
import sqlite3
import os
import sys
from pathlib import Path
from datetime import datetime

def get_table_schema(cursor, table_name):
    """Get column names and types for a table"""
    cursor.execute(f"PRAGMA table_info({table_name})")
    return {row[1]: row[2] for row in cursor.fetchall()}

def table_exists(cursor, table_name):
    """Check if table exists"""
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
    return cursor.fetchone() is not None

def migrate_table_data(source_cursor, dest_cursor, table_name):
    """Migrate data from source table to destination table"""
    if not table_exists(source_cursor, table_name):
        print(f"  [SKIP] Table '{table_name}' not found in source database")
        return 0
    
    if not table_exists(dest_cursor, table_name):
        print(f"  [SKIP] Table '{table_name}' not found in destination database")
        return 0
    
    # Get schemas
    source_schema = get_table_schema(source_cursor, table_name)
    dest_schema = get_table_schema(dest_cursor, table_name)
    
    # Find common columns
    common_columns = [col for col in source_schema.keys() if col in dest_schema.keys()]
    
    if not common_columns:
        print(f"  [WARN] No common columns between source and destination for table '{table_name}'")
        return 0
    
    # Get data from source
    columns_str = ", ".join(common_columns)
    source_cursor.execute(f"SELECT {columns_str} FROM {table_name}")
    rows = source_cursor.fetchall()
    
    if not rows:
        print(f"  [INFO] Table '{table_name}' is empty")
        return 0
    
    # Clear destination table
    dest_cursor.execute(f"DELETE FROM {table_name}")
    
    # Insert into destination
    placeholders = ", ".join(["?" for _ in common_columns])
    insert_sql = f"INSERT INTO {table_name} ({columns_str}) VALUES ({placeholders})"
    
    dest_cursor.executemany(insert_sql, rows)
    
    print(f"  [OK] Migrated {len(rows)} rows from '{table_name}'")
    print(f"       Columns: {', '.join(common_columns)}")
    
    return len(rows)

def parse_multi_value_field(field_value, separator_pattern=r'[/,;]'):
    """
    Parse multi-value fields like "phone1 / phone2" or "email1, email2"
    Returns list of cleaned values
    """
    import re
    if not field_value or not field_value.strip():
        return []
    values = re.split(separator_pattern, field_value)
    cleaned = [val.strip() for val in values if val.strip()]
    return cleaned

def migrate_supplier_contacts(source_cursor, dest_cursor):
    """Migrate supplier contact data from old suppliers table to new supplier_contacts table, splitting multi-value fields"""
    print("  Migrating supplier contacts (with multi-value split)...")
    # Check if supplier_contacts table exists in destination
    if not table_exists(dest_cursor, 'supplier_contacts'):
        print("  [SKIP] supplier_contacts table not found in destination")
        return 0
    # Get suppliers from source
    source_cursor.execute("SELECT id, contact_person, email, phone FROM suppliers")
    suppliers = source_cursor.fetchall()
    contacts_created = 0
    for supplier_id, contact_person, email, phone in suppliers:
        phones = parse_multi_value_field(phone)
        emails = parse_multi_value_field(email)
        contact_names = parse_multi_value_field(contact_person)
        max_contacts = max(len(phones), len(emails), len(contact_names))
        if max_contacts == 0:
            # No contact info, create a placeholder
            dest_cursor.execute("""
                INSERT INTO supplier_contacts
                (supplier_id, contact_name, position, phone, email, is_primary, contact_type, notes)
                VALUES (?, ?, ?, ?, ?, 1, 'general', ?)
            """, (supplier_id, 'Contacto Principal', '', '', '', 'Migrado automáticamente - sin información de contacto'))
            contacts_created += 1
        else:
            for i in range(max_contacts):
                contact_name = contact_names[i] if i < len(contact_names) else f'Contacto {i+1}'
                phone_val = phones[i] if i < len(phones) else ''
                email_val = emails[i] if i < len(emails) else ''
                if not contact_name and not phone_val and not email_val:
                    continue
                position = ''
                contact_type = 'general'
                if i == 0:
                    position = 'Principal'
                    contact_type = 'general'
                elif 'compra' in contact_name.lower():
                    position = 'Compras'
                    contact_type = 'purchasing'
                elif 'venta' in contact_name.lower():
                    position = 'Ventas'
                    contact_type = 'sales'
                elif 'contab' in contact_name.lower():
                    position = 'Contabilidad'
                    contact_type = 'accounting'
                dest_cursor.execute("""
                    INSERT INTO supplier_contacts
                    (supplier_id, contact_name, position, phone, email, is_primary, contact_type, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    supplier_id,
                    contact_name,
                    position,
                    phone_val,
                    email_val,
                    1 if i == 0 else 0,
                    contact_type,
                    'Migrado automáticamente desde campos legacy'
                ))
                contacts_created += 1
    print(f"  [OK] Created {contacts_created} supplier contacts (split)")
    return contacts_created

def migrate_database(source_db_path, dest_db_path, preserve_users=True):
    """
    Migrate data from source database to destination database
    
    Args:
        source_db_path: Path to old database
        dest_db_path: Path to new database
        preserve_users: If True, don't overwrite users table in destination
    """
    print("")
    print("=" * 70)
    print("  DATABASE MIGRATION UTILITY")
    print("=" * 70)
    print("")
    
    # Verify source exists
    if not os.path.exists(source_db_path):
        print(f"[ERROR] Source database not found: {source_db_path}")
        return False
    
    # Verify destination exists
    if not os.path.exists(dest_db_path):
        print(f"[ERROR] Destination database not found: {dest_db_path}")
        return False
    
    print(f"[INFO] Source:      {source_db_path}")
    print(f"[INFO] Destination: {dest_db_path}")
    print("")
    
    try:
        # Connect to both databases
        source_conn = sqlite3.connect(source_db_path)
        dest_conn = sqlite3.connect(dest_db_path)
        
        source_cursor = source_conn.cursor()
        dest_cursor = dest_conn.cursor()
        
        # Get list of tables from source
        source_cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        source_tables = [row[0] for row in source_cursor.fetchall()]
        
        print(f"[INFO] Found {len(source_tables)} tables in source database")
        print("")
        
        # Migrate each table
        total_migrated = 0
        
        for table_name in source_tables:
            # Skip users table if preserve_users is True
            if preserve_users and table_name == 'users':
                print(f"  [SKIP] Table 'users' (preserving existing users)")
                continue
            
            # Skip sqlite internal tables
            if table_name.startswith('sqlite_'):
                continue
            
            rows_migrated = migrate_table_data(source_cursor, dest_cursor, table_name)
            total_migrated += rows_migrated
        
        # Migrate supplier contacts from old structure
        contacts_migrated = migrate_supplier_contacts(source_cursor, dest_cursor)
        total_migrated += contacts_migrated
        
        # Commit changes
        dest_conn.commit()
        
        print("")
        print("-" * 70)
        print(f"[SUCCESS] Migration complete: {total_migrated} total rows migrated")
        print("-" * 70)
        print("")
        
        # Close connections
        source_conn.close()
        dest_conn.close()
        
        return True
        
    except Exception as e:
        print("")
        print(f"[ERROR] Migration failed: {str(e)}")
        print("")
        return False

def create_backup(db_path):
    """Create a timestamped backup of a database"""
    if not os.path.exists(db_path):
        return None
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{db_path}.backup_{timestamp}"
    
    try:
        import shutil
        shutil.copy2(db_path, backup_path)
        print(f"[OK] Backup created: {backup_path}")
        return backup_path
    except Exception as e:
        print(f"[ERROR] Failed to create backup: {str(e)}")
        return None

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("")
        print("Usage: python migrate_database.py <source_db> <dest_db> [--no-preserve-users]")
        print("")
        print("Example:")
        print("  python migrate_database.py suppliers.db data/suppliers.db")
        print("  python migrate_database.py ../old_install/suppliers.db data/suppliers.db")
        print("")
        sys.exit(1)
    
    source_db = sys.argv[1]
    dest_db = sys.argv[2]
    preserve_users = "--no-preserve-users" not in sys.argv
    
    # Create backup of destination before migration
    print("")
    print("[INFO] Creating backup of destination database...")
    backup_path = create_backup(dest_db)
    print("")
    
    # Run migration
    success = migrate_database(source_db, dest_db, preserve_users)
    
    sys.exit(0 if success else 1)

# Initialize-System.ps1
# Initializes Python environment and database

function Initialize-PythonEnvironment {
    param(
        [string]$InstallPath,
        [string]$PythonCmd
    )
    
    $result = @{
        Success = $false
        VenvCreated = $false
        DependenciesInstalled = $false
        Errors = @()
    }
    
    Push-Location $InstallPath
    
    try {
        # Create virtual environment
        if (Test-Path "venv") {
            Remove-Item -Recurse -Force venv -ErrorAction SilentlyContinue
        }
        
        & $PythonCmd -m venv venv 2>&1 | Out-Null
        
        if ($LASTEXITCODE -eq 0) {
            $result.VenvCreated = $true
        } else {
            $result.Errors += "Failed to create virtual environment"
            Pop-Location
            return $result
        }
        
        # Install dependencies
        if (Test-Path "requirements.txt") {
            $pipPath = "venv\Scripts\pip.exe"
            
            # Upgrade pip
            & $pipPath install --upgrade pip --quiet 2>&1 | Out-Null
            
            # Install requirements
            & $pipPath install -r requirements.txt --quiet 2>&1 | Out-Null
            
            if ($LASTEXITCODE -eq 0) {
                $result.DependenciesInstalled = $true
                $result.Success = $true
            } else {
                $result.Errors += "Failed to install dependencies"
            }
        } else {
            $result.Errors += "requirements.txt not found"
        }
        
    } catch {
        $result.Errors += $_.Exception.Message
    }
    
    Pop-Location
    return $result
}

function Initialize-Database {
    param(
        [string]$InstallPath,
        [bool]$CreateDefaultAdmin = $true
    )
    
    $result = @{
        Success = $false
        DatabaseCreated = $false
        AdminCreated = $false
        Errors = @()
    }
    
    Push-Location $InstallPath
    
    try {
        $pythonExe = "venv\Scripts\python.exe"
        
        # Check if database already exists
        $dbPath = "data\suppliers.db"
        $dbExists = Test-Path $dbPath
        
        if (-not $dbExists) {
            # Run app briefly to create database structure
            $process = Start-Process -FilePath $pythonExe -ArgumentList "api\app.py" -PassThru -WindowStyle Hidden
            Start-Sleep -Seconds 3
            $process | Stop-Process -Force -ErrorAction SilentlyContinue
            
            if (Test-Path $dbPath) {
                $result.DatabaseCreated = $true
            }
        } else {
            $result.DatabaseCreated = $true
        }
        
        # Create default admin user if requested
        if ($CreateDefaultAdmin) {
            if (Test-Path "api\init_users.py") {
                $output = & $pythonExe "api\init_users.py" 2>&1
                if ($LASTEXITCODE -eq 0) {
                    $result.AdminCreated = $true
                }
            }
        }
        
        $result.Success = $result.DatabaseCreated
        
    } catch {
        $result.Errors += $_.Exception.Message
    }
    
    Pop-Location
    return $result
}

Export-ModuleMember -Function Initialize-PythonEnvironment, Initialize-Database

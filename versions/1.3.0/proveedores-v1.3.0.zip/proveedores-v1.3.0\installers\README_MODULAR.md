# Instalador Modular v1.0

## Arquitectura

El instalador ahora es **completamente modular** y requiere **mínima intervención del usuario**.

### Estructura

```
installers/
├── INSTALAR.bat                    ← Punto de entrada principal
├── setup-auto.ps1                  ← Orquestador automático
├── setup-complete.ps1              ← Instalador completo (legacy)
├── install-auto.bat                ← Wrapper alternativo
└── modules/                        ← Módulos reutilizables
    ├── Detect-Installation.ps1     ← Detecta versión instalada
    ├── Backup-Installation.ps1     ← Crea backups automáticos
    ├── Migrate-Database.ps1        ← Migra datos inteligentemente
    ├── Install-NewStructure.ps1    ← Instala estructura modular
    └── Initialize-System.ps1       ← Inicializa Python y BD
```

## Características

### ✨ Cero Intervención del Usuario

- ✅ Detección automática de instalaciones previas
- ✅ Backup automático sin confirmación
- ✅ Migración automática de datos
- ✅ Instalación completa desatendida
- ✅ Auto-continúa después de 5 segundos

### 🔒 Seguridad de Datos

- ✅ Backup obligatorio antes de cambios
- ✅ Migración inteligente de esquemas
- ✅ Preservación de configuración
- ✅ No elimina datos originales

### 🚀 Proceso Rápido

1. **Verificar Python** (< 1 seg)
2. **Detectar instalación** (< 1 seg)
3. **Crear backup** (< 2 seg)
4. **Instalar estructura** (< 5 seg)
5. **Inicializar sistema** (30-60 seg)
6. **Migrar datos** (< 5 seg)

**Tiempo total:** ~1-2 minutos

## Uso

### Instalación Simple

```batch
INSTALAR.bat
```

Eso es todo. El instalador:
- Detecta Python automáticamente
- Detecta instalaciones previas automáticamente
- Crea backups automáticamente
- Migra datos automáticamente
- Configura todo automáticamente

### Instalación en Ubicación Específica

El instalador pregunta una sola vez por la ubicación:

```
Ubicación por defecto: C:\Users\TuUsuario\SistemaProveedores

Presiona ENTER para usar por defecto, o escribe una nueva ruta:
```

Solo presiona ENTER para continuar automáticamente.

## Módulos

### Detect-Installation.ps1

**Función:** `Get-InstallationInfo`

Detecta:
- ✓ Si existe instalación
- ✓ Versión (v0.1 o v1.0)
- ✓ Estructura (flat o modular)
- ✓ Ubicación de base de datos
- ✓ Tamaño de base de datos
- ✓ Ubicación de configuración
- ✓ Si hay datos reales (no vacía)

**Retorna:**
```powershell
@{
    Exists = $true/$false
    Version = "0.1"/"1.0"/"none"
    Structure = "flat"/"modular"/"none"
    DatabasePath = "path/to/db"
    DatabaseSize = 12345
    ConfigPath = "path/to/config"
    HasData = $true/$false
}
```

### Backup-Installation.ps1

**Función:** `New-InstallationBackup`

Crea backup de:
- ✓ Base de datos completa
- ✓ Archivos de configuración
- ✓ Carpeta config/ (v1.0)
- ✓ README.txt con instrucciones

**Retorna:**
```powershell
@{
    Success = $true/$false
    Path = "backup_20260204_143022_v0.1"
    Files = @("Database: suppliers.db (45.3 KB)", ...)
    TotalSize = 46234
    Error = "mensaje de error"
}
```

### Migrate-Database.ps1

**Función:** `Invoke-DatabaseMigration`

Migra datos usando `scripts/migrate_database.py`:
- ✓ Detecta esquemas automáticamente
- ✓ Copia solo columnas compatibles
- ✓ Maneja diferencias de esquema
- ✓ Preserva tabla users
- ✓ Reporta progreso detallado

**Retorna:**
```powershell
@{
    Success = $true/$false
    RowsMigrated = 165
    TablesProcessed = @("items (61 rows)", "suppliers (15 rows)", ...)
    Errors = @()
}
```

### Install-NewStructure.ps1

**Función:** `Install-ModularStructure`

Crea estructura v1.0:
- ✓ Directorios: api/, bin/, data/, scripts/, docs/, etc.
- ✓ Copia archivos desde distribución
- ✓ Mantiene backups intactos
- ✓ No sobrescribe datos existentes

**Retorna:**
```powershell
@{
    Success = $true/$false
    DirectoriesCreated = @("api", "bin", ...)
    FilesCopied = 127
    Errors = @()
}
```

### Initialize-System.ps1

**Funciones:** `Initialize-PythonEnvironment`, `Initialize-Database`

**PythonEnvironment:**
- ✓ Crea entorno virtual
- ✓ Instala pip actualizado
- ✓ Instala requirements.txt
- ✓ Silencioso (sin spam de output)

**Database:**
- ✓ Crea estructura de BD (si no existe)
- ✓ Crea usuario admin por defecto
- ✓ Ejecuta init_users.py automáticamente

## Flujo de Ejecución

```
┌────────────────────────────────────────────┐
│ INSTALAR.bat                               │
│ - Verifica PowerShell disponible           │
│ - Muestra banner                           │
│ - Ejecuta setup-auto.ps1                   │
└──────────────────┬─────────────────────────┘
                   ↓
┌────────────────────────────────────────────┐
│ setup-auto.ps1 (Orquestador)               │
│ - Importa todos los módulos                │
│ - Ejecuta pasos secuencialmente            │
│ - Maneja errores globalmente               │
└──────────────────┬─────────────────────────┘
                   ↓
┌────────────────────────────────────────────┐
│ PASO 1: Verificar Python                   │
│ → Detecta python3/python                   │
│ → Verifica versión >= 3.8                  │
└──────────────────┬─────────────────────────┘
                   ↓
┌────────────────────────────────────────────┐
│ PASO 2: Obtener Ruta de Instalación        │
│ → Sugiere ruta por defecto                 │
│ → Usuario presiona ENTER (auto)            │
└──────────────────┬─────────────────────────┘
                   ↓
┌────────────────────────────────────────────┐
│ PASO 3: Detectar Instalación Existente     │
│ → modules/Detect-Installation.ps1          │
│ → Detecta v0.1/v1.0/none                   │
│ → Muestra info de lo encontrado            │
│ → Auto-continúa en 5 segundos              │
└──────────────────┬─────────────────────────┘
                   ↓
┌────────────────────────────────────────────┐
│ PASO 4: Crear Backup (si existe previa)    │
│ → modules/Backup-Installation.ps1          │
│ → Crea backup_YYYYMMDD_HHMMSS_vX.X/        │
│ → Copia BD, config, todo                   │
└──────────────────┬─────────────────────────┘
                   ↓
┌────────────────────────────────────────────┐
│ PASO 5: Instalar Nueva Estructura          │
│ → modules/Install-NewStructure.ps1         │
│ → Crea api/, bin/, data/, etc.             │
│ → Copia archivos de distribución           │
└──────────────────┬─────────────────────────┘
                   ↓
┌────────────────────────────────────────────┐
│ PASO 6: Inicializar Sistema                │
│ → modules/Initialize-System.ps1            │
│ → Crea venv                                │
│ → Instala dependencias                     │
│ → Inicializa BD                            │
│ → Crea usuario admin                       │
│ → Migra datos (si hay upgrade)             │
└──────────────────┬─────────────────────────┘
                   ↓
┌────────────────────────────────────────────┐
│ ✓ INSTALACIÓN COMPLETADA                   │
│ → Muestra credenciales admin               │
│ → Muestra comando para iniciar             │
│ → Muestra ubicación de backup             │
└────────────────────────────────────────────┘
```

## Ventajas del Diseño Modular

### 1. Mantenibilidad
Cada módulo es independiente y testeable.

### 2. Reusabilidad
Los módulos se pueden usar en otros scripts:

```powershell
# Desde otro script
Import-Module "modules\Detect-Installation.ps1"
$info = Get-InstallationInfo -Path "C:\MiInstalacion"
```

### 3. Extensibilidad
Agregar nuevas funcionalidades es fácil:

```powershell
# Nuevo módulo: Configure-CustomSettings.ps1
function Set-CompanyBranding {
    param([string]$CompanyName, [string]$LogoPath)
    # ... lógica ...
}
```

### 4. Testing
Cada módulo se puede probar independientemente:

```powershell
# Test de detección
$result = Get-InstallationInfo -Path "C:\TestPath"
if ($result.Version -eq "0.1") { Write-Host "✓ Test passed" }
```

### 5. Debugging
Errores aislados a módulos específicos.

## Configuración

### Variables en setup-auto.ps1

```powershell
$VERSION = "1.0"                    # Versión a instalar
$MIN_PYTHON_VERSION = @(3, 8)       # Python mínimo requerido
```

### Personalización

Para personalizar el instalador, edita:

1. **Ruta por defecto:** `$defaultPath` en setup-auto.ps1
2. **Directorios creados:** `$directories` en Install-NewStructure.ps1
3. **Archivos copiados:** `$filesToCopy` en Install-NewStructure.ps1
4. **Timeout de auto-continuar:** `$timeout = 5` en setup-auto.ps1

## Troubleshooting

### El instalador no encuentra Python

**Síntoma:** "Python 3.8+ no encontrado"

**Solución:**
```batch
python --version
# Si muestra Python 2.x o no encuentra comando
# Descargar e instalar Python 3.8+ desde python.org
```

### Error al crear backup

**Síntoma:** "Fallo al crear backup"

**Causa común:** Permisos insuficientes

**Solución:**
```powershell
# Ejecutar como administrador
Right-click INSTALAR.bat → "Ejecutar como administrador"
```

### Migración falla pero instalación completa

**Síntoma:** "Advertencia en migración"

**Causa:** Script de migración no encontrado o error en Python

**Solución:**
```batch
# Migrar manualmente después
cd C:\SistemaProveedores
utilities\migrate_database.bat C:\backup\suppliers.db
```

## Testing

### Test Manual del Instalador

```powershell
# 1. Test de detección
Import-Module "modules\Detect-Installation.ps1"
Get-InstallationInfo -Path "C:\SistemaProveedores"

# 2. Test de backup (en instalación de prueba)
Import-Module "modules\Backup-Installation.ps1"
$info = Get-InstallationInfo -Path "C:\Test"
New-InstallationBackup -InstallPath "C:\Test" -InstallInfo $info

# 3. Test de instalación (en carpeta temporal)
Import-Module "modules\Install-NewStructure.ps1"
Install-ModularStructure -SourcePath "." -DestPath "C:\TestInstall"
```

## Logs

El instalador no genera logs por defecto (para ser rápido), pero puedes activarlos:

```powershell
# En setup-auto.ps1, agregar al inicio:
Start-Transcript -Path "$env:TEMP\installer_log.txt"
# ... resto del script ...
Stop-Transcript
```

## Contribuir

Para agregar nuevos módulos:

1. Crear archivo en `installers/modules/`
2. Definir función con Export-ModuleMember
3. Importar en setup-auto.ps1
4. Llamar en el paso apropiado

## Conclusión

El instalador modular v1.0:

- ✅ Es completamente automático
- ✅ Requiere mínima intervención
- ✅ Es seguro (backups automáticos)
- ✅ Es inteligente (migración automática)
- ✅ Es rápido (~1-2 minutos)
- ✅ Es mantenible (código modular)
- ✅ Es extensible (fácil agregar features)

**Simplemente ejecuta `INSTALAR.bat` y relájate.** ☕

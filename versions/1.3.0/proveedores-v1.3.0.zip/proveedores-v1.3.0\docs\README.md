# Sistema de Gestión de Proveedores e Inventario v1.3.0

Sistema web profesional para la gestión integral de proveedores, materiales/items y órdenes de compra. Interfaz moderna con búsqueda inteligente, gestión de precios, tracking de órdenes y soporte para importación/exportación de datos.

**Versión:** 1.3.0  
**Fecha:** Febrero 2026  
**Licencia:** Ver [LICENSE](LICENSE)

---

## 📑 Tabla de Contenidos

- [Características Principales](#-características-principales)
- [Novedades v1.3.0](#-novedades-v130)
- [Capturas de Pantalla](#-capturas-de-pantalla)
- [Requisitos](#-requisitos)
- [Instalación Rápida](#-instalación-rápida)
- [Arquitectura y Acceso](#-arquitectura-y-acceso)
- [Guía de Uso](#-guía-de-uso)
- [Importación de Datos](#-importación-de-datos)
- [API REST](#-api-rest)
- [Despliegue en Internet](#-despliegue-en-internet)
- [Base de Datos](#-base-de-datos)
- [Estructura del Proyecto](#-estructura-del-proyecto)
- [Troubleshooting](#-troubleshooting)

---

## 🆕 Novedades v1.3.0

### 🔧 Arquitectura de Servicio
- **Servidor independiente**: El servidor web ahora se ejecuta como servicio de Windows, permitiendo acceso continuo
- **Prevención de instancias múltiples**: Solo una instancia de la aplicación puede ejecutarse simultáneamente
- **Acceso remoto**: Posibilidad de acceder desde múltiples dispositivos en la misma red (PC, móviles, tablets)

### 🌐 Acceso Multi-Dispositivo
- **Cliente web**: Acceso desde cualquier navegador web en la red local
- **Configuración flexible**: Soporte para URLs de servidor personalizadas
- **Aplicación de escritorio**: Interfaz nativa que se conecta al servidor de servicio
- **Móviles y tablets**: Acceso completo desde dispositivos móviles

### ⚙️ Mejoras de Instalación
- **Instalador inteligente**: Detecta instalaciones previas y migra datos automáticamente
- **Servicio automático**: Configuración automática del servicio de Windows
- **Configuración centralizada**: Archivo `config.ini` con secciones para empresa y servidor

---

### 📦 Gestión de Inventario
- **Catálogo completo** de items/materiales con búsqueda instantánea
- **Múltiples proveedores** por item con precios individuales
- **Códigos SKU/SDK** con consolidación automática
- **Categorías organizadas**: Alimentos, Herramientas, Vehículos, etc.
- **Unidades de medida**: Kilogramos, Litros, Piezas, Metros, etc.
- **Edición inline** con modales intuitivos

### 👥 Gestión de Proveedores
- **CRUD completo**: Crear, Editar, Eliminar proveedores
- **Información detallada**: Contacto, dirección, calificación (1-5 estrellas)
- **Búsqueda avanzada** por nombre, categoría, ciudad, país
- **Vista de catálogo** para cada proveedor con todos sus items
- **Sistema de calificación** para evaluar proveedores

### 💰 Gestión de Precios (Precio-Item-Proveedor)
- **Página dedicada** para gestionar relaciones proveedor-item
- **Filtros avanzados**:
  - Por estado de relación (Activas / Disponibles)
  - Por categoría de item
  - Por ciudad del proveedor
- **Vista consolidada** de todos los proveedores y sus precios
- **Agregar/Editar/Eliminar** precios fácilmente
- **Comparación visual** para identificar mejor precio

### 🔍 Búsqueda Inteligente de Items
- **Selección múltiple** con checkboxes
- **Identificación automática** de proveedores comunes
- **Badge "Mejor Precio"** para identificar la opción más económica
- **Creación de órdenes optimizadas** desde búsqueda
- **División inteligente** cuando se requieren múltiples proveedores

### 📋 Gestión de Órdenes
- **Creación desde múltiples puntos**: Búsqueda de items, proveedores, u órdenes
- **Modal avanzado** con selección de items y búsqueda integrada
- **Cálculo automático** de subtotales y total general
- **Estados de orden**: Pendiente, Confirmada, Enviada, Entregada, Cancelada
- **Vista detallada** con modal read-only
- **Edición de estado** con dropdown
- **Impresión/Exportación**:
  - Versión imprimible en escritorio
  - Botón compartir en móviles (WhatsApp, Email, etc.)
  - Formato profesional con logo y detalles completos

### 📊 Importación y Exportación
- **Importar proveedores**: CSV, Excel (.xlsx, .xls, .xlsm)
- **Importar items**: CSV, Excel con relación proveedor-precio
- **Exportar proveedores**: CSV, Excel
- **Exportar items**: CSV, Excel
- **Validación robusta** con manejo de errores
- **Prevención de duplicados** automática

### 🎨 Interfaz Moderna
- **Diseño responsive** para escritorio, tablet y móvil
- **Iconos intuitivos** con tooltips informativos
- **Notificaciones toast** personalizadas (no alerts del navegador)
- **Modales de confirmación** profesionales
- **Sidebar con navegación** clara y organizada
- **Tema morado profesional** (#667eea)

---

## 📸 Capturas de Pantalla

### Pantalla Principal - Buscar Items
![Buscar Items](https://via.placeholder.com/800x500/667eea/ffffff?text=Buscar+Items+-+Selección+Múltiple)
*Búsqueda de items con selección múltiple y creación de órdenes optimizadas*

### Gestión de Proveedores
![Proveedores](https://via.placeholder.com/800x500/667eea/ffffff?text=Gestión+de+Proveedores)
*Lista completa de proveedores con búsqueda y filtros avanzados*

### Gestión de Precios
![Precios](https://via.placeholder.com/800x500/667eea/ffffff?text=Gestión+de+Precios)
*Página dedicada para gestionar relaciones proveedor-item-precio*

### Vista de Orden
![Ver Orden](https://via.placeholder.com/800x500/667eea/ffffff?text=Vista+de+Orden)
*Modal con detalles completos de la orden y opciones de impresión*

---

## 📋 Requisitos

- **Python**: 3.8 o superior (probado con 3.13.9)
- **Sistema operativo**: Windows, Linux, macOS
- **Navegador web**: Chrome, Firefox, Edge, Safari (versiones recientes)
- **Memoria RAM**: Mínimo 512MB disponible
- **Espacio en disco**: 50MB (base de datos crece según datos)

---

## 🏗️ Arquitectura y Acceso

### Arquitectura Cliente-Servidor
El sistema utiliza una arquitectura cliente-servidor moderna:

- **Servidor**: Servicio de Windows que ejecuta la aplicación Flask (puerto 5000)
- **Cliente de Escritorio**: Aplicación nativa que se conecta al servidor
- **Cliente Web**: Acceso desde cualquier navegador en la red local

### Modos de Acceso

#### 1. Aplicación de Escritorio (Recomendado)
- Ejecuta `bin/run.bat` para iniciar la interfaz nativa
- Se conecta automáticamente al servidor local
- Prevención automática de múltiples instancias

#### 2. Acceso Web Directo
- Abre `http://localhost:5000` en cualquier navegador
- Acceso desde PCs, tablets y móviles en la misma red
- No requiere instalación adicional en otros dispositivos

#### 3. Servidor Remoto
- Configura la URL del servidor en `config/config.ini`
- Permite acceso desde múltiples ubicaciones
- Ideal para redes empresariales

### Configuración del Servidor
Edita `config/config.ini` para configurar el acceso:

```ini
[SERVER]
url = http://192.168.1.100:5000  # Cambia la IP según tu servidor
```

### Servicio de Windows
- El servidor se instala como servicio de Windows
- Inicio automático al encender el PC
- Se mantiene ejecutando incluso al cerrar la aplicación de escritorio

---

## ⚡ Instalación Automática

### 🪟 Windows

**Método Recomendado: Doble clic en INSTALAR.bat**

Simplemente **doble clic** en el archivo:
```
INSTALAR.bat
```

Este archivo:
- ✅ **No requiere permisos especiales** (funciona sin ser administrador)
- ✅ **Evita problemas de execution policy** de PowerShell
- ✅ Ejecuta automáticamente el instalador completo
- ✅ Muestra el progreso en tiempo real

**Alternativa (si prefieres línea de comandos):**
```powershell
# Si no tienes problemas de execution policy:
.\setup-complete.ps1

# O usa el wrapper:
.\INSTALAR.bat
```

El instalador completo incluye:
- 🔍 **Auto-instalación de Python** si no está instalado (usando winget - requiere admin)
- 📂 Selección de directorio de instalación
- 🏢 Personalización con nombre de empresa
- 🖼️ Logo personalizado (opcional)
- ✅ Instalación completa de todas las dependencias
- 🗄️ Inicialización de base de datos
- 🚀 Creación de acceso directo en escritorio (opcional)
- 📊 Barra de progreso visual

**Opción 2: Instalador Rápido**
```cmd
install.bat
```

**Opción 3: Instalador PowerShell**
```powershell
.\install.ps1
```

Todos los instaladores automáticamente:
- ✅ Verifican Python y su versión
- ✅ Crean el entorno virtual
- ✅ Instalan todas las dependencias
- ✅ Inicializan la base de datos
- ✅ Crean script de inicio rápido (`start.bat`)

### 🔄 Actualización a Nueva Versión

**IMPORTANTE:** Al actualizar, tus datos se preservan automáticamente.

```powershell
# Extrae la nueva versión sobre la instalación existente
# Ejecuta el instalador
.\setup-complete.ps1
```

El instalador detectará la instalación existente y:
- 🔒 **Preservará tu base de datos** (proveedores, items, órdenes)
- 🔒 **Mantendrá tu configuración** (nombre empresa, logo)
- 📦 Creará un **respaldo automático** antes de actualizar
- ⚡ Actualizará solo los archivos del sistema
- ✅ Actualizará dependencias si es necesario

**Tus datos NUNCA se borran durante una actualización.**

### 🐧 Linux / 🍎 macOS

```bash
chmod +x install.sh
./install.sh
```

El instalador automáticamente:
- ✅ Verifica Python3 y su versión
- ✅ Crea el entorno virtual
- ✅ Instala todas las dependencias
- ✅ Inicializa la base de datos
- ✅ Crea script de inicio rápido (`start.sh`)

### 🐍 ¿Qué pasa si no tengo Python?

**Windows 10/11:** El instalador `setup-complete.ps1` intentará instalar Python automáticamente usando winget.

**⚠️ IMPORTANTE:** Para instalar Python automáticamente:
- Clic derecho en `setup-complete.ps1`
- Selecciona **"Ejecutar con PowerShell como Administrador"**
- Esto permite que winget instale Python en el sistema

**Sin permisos de administrador:**
- El instalador te dará la opción de continuar
- Te redirigirá a la instalación manual de Python

**Instalación manual:** Si prefieres o la auto-instalación falla:
1. Visita [python.org/downloads](https://www.python.org/downloads/)
2. Descarga Python 3.13.9 o superior
3. Durante la instalación, marca: **☑ Add Python to PATH**
4. Completa la instalación
5. Ejecuta el instalador nuevamente (sin necesidad de permisos de admin)

### 🚀 Iniciar la Aplicación

Después de la instalación:

**Windows:**
```cmd
# Ejecuta el acceso directo del escritorio
# O manualmente:
bin\run.bat
```

**Linux/Mac:**
```bash
./start.sh
```

**O manualmente:**
```bash
# Activar entorno virtual
# Windows
.\venv\Scripts\Activate.ps1

# Linux/Mac
source venv/bin/activate

# Iniciar aplicación de escritorio
pythonw desktop_app.py
```

La aplicación se abre en una **ventana de escritorio nativa** sin artefactos del navegador.

### 🔧 Opción: Ejecutar como Servicio Windows

Para una experiencia más profesional, puedes instalar la aplicación como un **servicio de Windows** que se ejecuta en segundo plano automáticamente:

**Ventajas:**
- 🚀 **Ejecución invisible** - Sin ventana de consola o ícono en la barra de tareas
- 🔄 **Auto-inicio** - Se inicia automáticamente al encender el sistema
- 💤 **Wake-from-sleep** - Se reinicia automáticamente al despertar el sistema
- 🛡️ **Protección contra paradas accidentales** - Los usuarios no pueden detenerlo fácilmente mientras trabajan

**Instalación del servicio:**
1. Ejecuta `setup-complete.ps1` (el instalador completo incluye esta opción)
2. Selecciona "Sí" cuando te pregunte si quieres instalar como servicio
3. O instala manualmente: Ejecuta `utilities\service\setup-service.bat` como administrador

**Gestión del servicio:**
```batch
# Verificar estado
utilities\service\service.bat status

# Detener servicio
utilities\service\service.bat stop

# Iniciar servicio
utilities\service\service.bat start

# Desinstalar servicio
utilities\service\service.bat remove
```

**Nota:** El servicio usa NSSM (incluido localmente) para una gestión confiable y reinicio automático en caso de fallos.

---

## 🛠️ Instalación Manual (Avanzada)

Si prefieres instalar manualmente o los instaladores automáticos no funcionan:

### 1️⃣ Descargar el Proyecto

```bash
# Clonar desde Git (si aplica)
git clone https://github.com/tu-usuario/proveedores.git
cd proveedores

# O descargar y extraer el ZIP
```

### 2️⃣ Crear Entorno Virtual

```bash
# Windows PowerShell
python -m venv venv
.\venv\Scripts\Activate.ps1

# Windows CMD
python -m venv venv
venv\Scripts\activate.bat

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

### 3️⃣ Instalar Dependencias

```bash
pip install -r requirements.txt
```

**Dependencias principales:**
- Flask 3.0.0 - Framework web
- SQLAlchemy 2.0.46 - ORM para base de datos
- pandas 3.0.0 - Procesamiento de CSV/Excel
- openpyxl 3.1.5 - Lectura de archivos Excel
- pymysql 1.1.1 - Conector MySQL (opcional)

### 4️⃣ Iniciar la Aplicación

```bash
python app.py
```

**Salida esperada:**
```
 * Running on http://127.0.0.1:5000
 * Running on http://192.168.1.100:5000
Press CTRL+C to quit
```

Abre tu navegador en: **http://localhost:5000**

---

## 📖 Guía de Uso

### Navegación Principal

El sistema tiene 5 secciones principales accesibles desde el sidebar:

#### 1. 🔍 Buscar Items
**Propósito**: Búsqueda inteligente de items para crear órdenes optimizadas

**Cómo usar**:
1. Escribe en el buscador para filtrar items
2. Usa los filtros de categoría y ordenamiento
3. Selecciona items con checkboxes
4. El sistema muestra proveedores comunes y mejor precio
5. Haz clic en "Crear Orden" para generar automáticamente
6. Si no hay proveedor común, se crean órdenes múltiples

**Funciones**:
- ✅ Selección múltiple de items
- 🏆 Identificación de mejor precio
- 👥 Proveedores que tienen todos los items
- 📝 Creación automática de órdenes optimizadas

#### 2. 👤 Buscar Proveedores
**Propósito**: Búsqueda y consulta de proveedores con sus catálogos

**Cómo usar**:
1. Busca por nombre del proveedor
2. Filtra por categoría o ciudad
3. Ordena por calificación, nombre, etc.
4. Haz clic en "Ver Items" (👁️) para ver su catálogo
5. Haz clic en "Crear Orden" (➕) para hacer pedido

**Funciones**:
- 🔎 Búsqueda en tiempo real
- 🏷️ Filtros por categoría y ciudad
- ⭐ Ordenamiento por calificación
- 📦 Vista de catálogo completo

#### 3. 📦 Gestionar Inventario
**Propósito**: Ver y administrar todo el catálogo de items

**Cómo usar**:
1. Visualiza lista completa de items
2. Busca items específicos
3. Haz clic en "Editar" (✏️) para modificar
4. Haz clic en "Eliminar" (🗑️) para borrar
5. Usa "Nuevo Item" para agregar
6. Usa "Gestionar Precios" para ir a gestión de relaciones

**Funciones**:
- ➕ Crear nuevos items
- ✏️ Editar items existentes
- 🗑️ Eliminar items (previo confirmar)
- 💰 Acceso a gestión de precios
- 📤 Exportar a CSV/Excel
- 📥 Importar desde CSV/Excel

#### 4. 👥 Gestionar Proveedores
**Propósito**: CRUD completo de proveedores

**Cómo usar**:
1. Visualiza lista de todos los proveedores
2. Haz clic en "Nuevo Proveedor" para agregar
3. Completa el formulario con datos del proveedor
4. Usa "Editar" (✏️) para modificar información
5. Usa "Ver Items" (👁️) para ver su catálogo
6. Usa "Crear Orden" (➕) para hacer pedido
7. Usa "Eliminar" (🗑️) para borrar (previo confirmar)

**Campos del proveedor**:
- Nombre completo (requerido)
- Email de contacto
- Teléfono
- Dirección completa
- Ciudad, País
- Categoría (tipo de proveedor)
- Calificación (1-5 estrellas)
- Términos de pago (ej: "30 días neto")

#### 5. 📋 Gestionar Órdenes
**Propósito**: Crear, ver y gestionar órdenes de compra

**Cómo usar**:
1. Haz clic en "Nueva Orden" para crear
2. Selecciona proveedor del dropdown
3. Usa el buscador para filtrar items
4. Selecciona items con checkboxes
5. Ajusta cantidades si es necesario
6. Agrega notas adicionales
7. El total se calcula automáticamente
8. Guarda la orden

**Gestión de órdenes existentes**:
- 👁️ **Ver**: Abre modal con todos los detalles
- 🖨️ **Imprimir**: 
  - En escritorio: Abre ventana de impresión
  - En móvil: Botón para compartir (WhatsApp, Email, etc.)
- **Editar estado**: Dropdown en modal de vista
  - Pendiente (amarillo)
  - Confirmada (cyan)
  - Enviada (azul)
  - Entregada (verde)
  - Cancelada (rojo)

#### 6. 💰 Gestión de Precios (Precio-Item-Proveedor)
**Propósito**: Administrar relaciones entre proveedores e items con precios

**Cómo acceder**:
- Desde "Gestionar Inventario" → Botón "Gestionar Precios"
- Se abre una página dedicada full-screen

**Filtros disponibles**:
- **Estado de Relación**:
  - `Activas`: Items que ya tienen precio con proveedores
  - `Disponibles`: Items sin relación aún (para agregar nuevos)
- **Categoría**: Filtra por tipo de item
- **Ciudad**: Filtra proveedores por ubicación

**Cómo agregar precio**:
1. Filtra por "Disponibles"
2. Encuentra el item que quieres agregar
3. Haz clic en "Agregar Proveedor" (➕)
4. Selecciona proveedor del dropdown
5. Ingresa el precio
6. Guarda

**Cómo editar precio**:
1. Filtra por "Activas"
2. Encuentra la relación existente
3. Haz clic en el precio (se hace editable)
4. Modifica el valor
5. Haz clic en "Actualizar" (💾)

**Cómo eliminar relación**:
1. Encuentra la relación a eliminar
2. Haz clic en "Eliminar" (🗑️)
3. Confirma en el diálogo

---

## 📥 Importación de Datos

### Importar Proveedores

**Formatos soportados**: `.csv`, `.xlsx`, `.xls`, `.xlsm`

**Estructura CSV/Excel estándar**:
```csv
name,email,phone,address,city,country,category,rating,payment_terms
Proveedor SA,contacto@proveedor.com,555-1234,Calle 123,Lima,Perú,Alimentos,5,30 días
Empresa XYZ,ventas@xyz.com,555-5678,Av. Principal 456,Bogotá,Colombia,Herramientas,4,15 días
```

**Columnas requeridas**:
- `name` (obligatorio)
- Todas las demás son opcionales

**Pasos**:
1. Ve a "Gestionar Proveedores"
2. Haz clic en "Importar Proveedores"
3. Selecciona archivo CSV o Excel
4. El sistema valida y muestra resultado
5. Confirma importación

### Importar Items

**Formatos soportados**: `.csv`, `.xlsx`, `.xls`, `.xlsm`

**Estructura CSV con proveedores**:
```csv
name,description,category,unit_of_measure,supplier_name,price
Arroz Premium,Arroz grano largo,Alimentos,Kilogramos,Proveedor SA,2.50
Martillo,Martillo de acero,Herramientas,Piezas,Empresa XYZ,15.00
```

**Columnas para items**:
- `name` (obligatorio)
- `category` (recomendado)
- `unit_of_measure` (recomendado)
- `description` (opcional)

**Columnas para relación con proveedor**:
- `supplier_name` (nombre exacto del proveedor)
- `price` (precio del item con ese proveedor)

**Nota importante**: Si incluyes `supplier_name` y `price`, el sistema creará automáticamente la relación proveedor-item.

**Pasos**:
1. Ve a "Gestionar Inventario"
2. Haz clic en "Importar Items"
3. Selecciona archivo
4. El sistema:
   - Crea los items
   - Busca los proveedores por nombre
   - Crea las relaciones con precios
5. Muestra resumen de importación

---

## 🌐 API REST

El sistema expone una API REST completa para integración con otros sistemas.

**Base URL**: `http://localhost:5000/api`

### Endpoints - Proveedores

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/suppliers` | Listar todos los proveedores |
| GET | `/suppliers/:id` | Obtener un proveedor específico |
| POST | `/suppliers` | Crear nuevo proveedor |
| PUT | `/suppliers/:id` | Actualizar proveedor |
| DELETE | `/suppliers/:id` | Eliminar proveedor |
| GET | `/suppliers/:id/items` | Items de un proveedor |

### Endpoints - Items

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/items` | Listar todos los items |
| GET | `/items/:id` | Obtener un item específico |
| POST | `/items` | Crear nuevo item |
| PUT | `/items/:id` | Actualizar item |
| DELETE | `/items/:id` | Eliminar item |
| GET | `/items/:id/suppliers` | Proveedores de un item |

### Endpoints - Relaciones (Supplier-Item)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/supplier-items` | Todas las relaciones proveedor-item |
| POST | `/supplier-items` | Crear relación con precio |
| PUT | `/supplier-items/:supplier_id/:item_id` | Actualizar precio |
| DELETE | `/supplier-items/:supplier_id/:item_id` | Eliminar relación |

### Endpoints - Órdenes

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/orders` | Listar todas las órdenes |
| GET | `/orders/:id` | Obtener orden específica |
| POST | `/orders` | Crear nueva orden |
| PUT | `/orders/:id` | Actualizar orden completa |
| PUT | `/orders/:id/status` | Actualizar solo el estado |
| DELETE | `/orders/:id` | Eliminar orden |

### Ejemplo de Uso - API

**Crear un proveedor**:
```javascript
fetch('http://localhost:5000/api/suppliers', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    name: "Proveedor Nuevo",
    email: "contacto@nuevo.com",
    phone: "555-9999",
    city: "Lima",
    country: "Perú",
    category: "Alimentos",
    rating: 4
  })
})
.then(response => response.json())
.then(data => console.log(data));
```

**Actualizar estado de orden**:
```javascript
fetch('http://localhost:5000/api/orders/123/status', {
  method: 'PUT',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    status: "delivered"
  })
})
.then(response => response.json())
.then(data => console.log(data));
```

---

## 🌍 Despliegue en Internet

### Opción 1: Cloudflare Tunnel (Recomendado)

**Ventajas**:
- ✅ **HTTPS automático** (SSL/TLS incluido)
- ✅ **Sin configuración de router** ni port forwarding
- ✅ **Sin IP pública requerida**
- ✅ **URL personalizable** (subdominio .trycloudflare.com)
- ✅ **Gratuito** para uso básico
- ✅ **Funciona detrás de NAT/firewalls**

**Instalación**:

1. Descarga Cloudflare Tunnel (cloudflared):
   - Windows: https://github.com/cloudflare/cloudflared/releases
   - Descarga `cloudflared-windows-amd64.exe`
   - Renombra a `cloudflared.exe`

2. Inicia tu aplicación Flask:
   ```bash
   python app.py
   ```

3. En otra terminal, ejecuta cloudflared:
   ```bash
   cloudflared tunnel --url http://localhost:5000
   ```

4. Cloudflared te dará una URL pública como:
   ```
   https://random-name-1234.trycloudflare.com
   ```

5. Comparte esa URL para acceso remoto

**Notas importantes**:
- La URL cambia cada vez que reinicias cloudflared
- Para URL permanente, necesitas cuenta de Cloudflare (también gratis)
- Ideal para demos, pruebas y acceso temporal

### Opción 2: ngrok

Similar a Cloudflare, pero con algunas limitaciones:

```bash
# Instalar ngrok
# Descargar de: https://ngrok.com/download

# Ejecutar
ngrok http 5000
```

**Nota**: ngrok puede tener problemas con HSTS en algunos navegadores. Cloudflare Tunnel es más confiable.

### Opción 3: Servidor VPS (Producción)

Para despliegue en producción:

1. **Servicios recomendados**:
   - DigitalOcean
   - AWS EC2
   - Google Cloud
   - Azure
   - Heroku

2. **Configuración básica**:
   - Servidor Ubuntu/Linux
   - Nginx como reverse proxy
   - Gunicorn como servidor WSGI
   - SSL con Let's Encrypt
   - Base de datos MySQL en servidor

3. **Ejemplo con Gunicorn**:
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5000 app:app
   ```

---

## 💾 Base de Datos

### SQLite (Por Defecto)

**Ubicación**: `suppliers.db` en el directorio raíz del proyecto

**Ventajas**:
- No requiere instalación
- Cero configuración
- Portátil (un solo archivo)
- Perfecto para desarrollo y pequeñas empresas

**Límites prácticos**:
- Hasta ~1,000 proveedores: Excelente
- Hasta ~10,000 items: Muy bueno
- Hasta ~50,000 órdenes: Aceptable

**Respaldo**:
```bash
# Simplemente copia el archivo
copy suppliers.db suppliers_backup.db
```

### MySQL (Opcional)

**Cuándo usar MySQL**:
- Múltiples usuarios simultáneos (>5)
- Más de 1,000 proveedores
- Acceso desde múltiples ubicaciones
- Requerimientos empresariales

**Configuración**:

1. Instalar MySQL/MariaDB
2. Crear base de datos:
   ```sql
   CREATE DATABASE proveedores CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'proveedores_user'@'localhost' IDENTIFIED BY 'password_seguro';
   GRANT ALL PRIVILEGES ON proveedores.* TO 'proveedores_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

3. Crear archivo `.env`:
   ```env
   DATABASE_TYPE=mysql
   DATABASE_HOST=localhost
   DATABASE_PORT=3306
   DATABASE_USER=proveedores_user
   DATABASE_PASSWORD=password_seguro
   DATABASE_NAME=proveedores
   ```

4. Reiniciar aplicación - las tablas se crean automáticamente

### Esquema de Base de Datos

**Tablas principales**:

1. **suppliers** - Proveedores
   - id (PK)
   - name, email, phone
   - address, city, country
   - category, rating
   - payment_terms
   - created_at, updated_at

2. **items** - Items/Materiales
   - id (PK)
   - name, description
   - sku_code, sdk_code
   - category, unit_of_measure
   - created_at, updated_at

3. **supplier_items** - Relación M:N con precios
   - supplier_id (FK)
   - item_id (FK)
   - price
   - is_active
   - created_at, updated_at

4. **orders** - Órdenes de compra
   - id (PK)
   - order_number (único)
   - supplier_id (FK)
   - order_date, delivery_date
   - items (texto)
   - total_amount
   - status
   - notes
   - created_at, updated_at

---

## 📁 Estructura del Proyecto

```
proveedores/
│
├── app.py                      # Aplicación Flask principal (API REST)
├── database.py                 # Configuración de base de datos
├── models.py                   # Modelos SQLAlchemy (ORM)
├── requirements.txt            # Dependencias Python
├── README.md                   # Este archivo
├── QUICKSTART.md              # Guía rápida de inicio
├── LICENSE                    # Licencia del proyecto
│
├── suppliers.db               # Base de datos SQLite (generada)
├── example_suppliers.csv      # Archivo de ejemplo para importar
│
├── templates/                 # Plantillas HTML
│   └── index.html            # Página principal (SPA)
│
└── static/                    # Archivos estáticos
    ├── style.css             # Estilos CSS (1069 líneas)
    └── script.js             # Lógica JavaScript (3000+ líneas)
```

### Archivos Principales

**app.py** (1155 líneas)
- API REST completa con 30+ endpoints
- Importación/Exportación CSV/Excel
- Validación y manejo de errores
- CORS habilitado para desarrollo

**models.py** (177 líneas)
- 4 modelos SQLAlchemy
- Relaciones many-to-many
- Métodos de serialización
- Validación de datos

**database.py** (80 líneas)
- Configuración de SQLAlchemy
- Soporte SQLite y MySQL
- Manejo de sesiones
- Variables de entorno

**script.js** (3000+ líneas)
- SPA completa con vanilla JavaScript
- Gestión de estado sin framework
- AJAX para todas las operaciones
- Notificaciones toast personalizadas
- Modales de confirmación
- Funciones de importación/exportación

**style.css** (1069 líneas)
- Diseño responsive
- Tema morado profesional
- Animaciones y transiciones
- Media queries para móvil

---

## 🎥 Video Tutorial

_(Espacio reservado para video tutorial futuro)_

**Temas a cubrir en video**:
1. ✅ Instalación paso a paso
2. ✅ Tour de la interfaz
3. ✅ Importación de datos
4. ✅ Gestión de proveedores
5. ✅ Gestión de items y precios
6. ✅ Búsqueda inteligente
7. ✅ Creación de órdenes
8. ✅ Impresión y exportación
9. ✅ Despliegue en internet

---

## 🔧 Troubleshooting

### Problema: "ModuleNotFoundError"

**Solución**: Instalar dependencias
```bash
pip install -r requirements.txt
```

### Problema: "Port 5000 is already in use"

**Solución**: Cambiar puerto en app.py
```python
# Línea final de app.py
app.run(host='0.0.0.0', port=5001, debug=False)
```

### Problema: Error al importar archivos Excel

**Solución**: Verificar que openpyxl esté instalado
```bash
pip install openpyxl
```

### Problema: No se pueden ver otros dispositivos en la red

**Solución Windows**: Configurar Firewall
```powershell
# PowerShell como Administrador
New-NetFirewallRule -DisplayName "Flask App" -Direction Inbound -Protocol TCP -LocalPort 5000 -Action Allow
```

### Problema: Cloudflare Tunnel no funciona

**Solución**: Verificar que Flask esté en 0.0.0.0
```python
# app.py debe tener:
app.run(host='0.0.0.0', port=5000, debug=False)
```

### Problema: Datos duplicados al importar

**Solución**: El sistema detecta automáticamente duplicados por nombre. Si deseas reimportar, elimina los registros existentes primero.

---

## 📝 Changelog

### Versión 0.1 (Febrero 2026) - Release Inicial

**🎉 Características principales**:
- ✅ Sistema completo de gestión de proveedores (CRUD)
- ✅ Sistema completo de gestión de items/inventario (CRUD)
- ✅ Gestión de precios con página dedicada
- ✅ Gestión de órdenes con estados y tracking
- ✅ Búsqueda inteligente de items con selección múltiple
- ✅ Búsqueda avanzada de proveedores con filtros
- ✅ Identificación automática de proveedores comunes
- ✅ Badge de "Mejor Precio" en búsquedas
- ✅ Importación/Exportación CSV y Excel
- ✅ API REST completa (30+ endpoints)

**🎨 Interfaz y UX**:
- ✅ Diseño responsive (escritorio, tablet, móvil)
- ✅ Notificaciones toast personalizadas
- ✅ Modales de confirmación profesionales
- ✅ Iconos con tooltips en todos los botones
- ✅ Tema morado moderno (#667eea)
- ✅ Sidebar con navegación intuitiva

**📱 Funciones móviles**:
- ✅ Impresión optimizada para escritorio
- ✅ Botón compartir en móviles (Web Share API)
- ✅ Interfaz táctil optimizada

**💾 Base de datos**:
- ✅ SQLite por defecto (sin configuración)
- ✅ Soporte opcional para MySQL
- ✅ Auto-migraciones y esquema completo
- ✅ 4 tablas: suppliers, items, supplier_items, orders

**🚀 Despliegue**:
- ✅ Instaladores automáticos (Windows, Linux, Mac)
- ✅ Scripts de inicio rápido generados automáticamente
- ✅ Soporte para Cloudflare Tunnel
- ✅ Configuración para servidores VPS

**🔧 Mejoras técnicas**:
- ✅ Validación robusta de datos
- ✅ Prevención de duplicados
- ✅ Manejo de errores mejorado
- ✅ Cierre automático de modales
- ✅ Cálculo en tiempo real de totales

**📦 Archivos del release**:
- `install.bat` - Instalador automático para Windows (CMD)
- `install.ps1` - Instalador automático para Windows (PowerShell)
- `install.sh` - Instalador automático para Linux/Mac
- `start.bat` / `start.sh` - Scripts de inicio rápido (generados por instalador)
- `VERSION` - Archivo de versión

**🐛 Problemas conocidos**:
- Ninguno reportado en esta versión inicial

**📚 Documentación**:
- README completo con guías paso a paso
- Documentación de API REST
- Guía de troubleshooting
- Ejemplos de importación de datos

---

## 🤝 Contribuir

Si deseas contribuir al proyecto:

1. Fork el repositorio
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add: AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

---

## 📄 Licencia

Este proyecto está bajo la licencia especificada en el archivo [LICENSE](LICENSE).

---

## 📞 Soporte

¿Necesitas ayuda?

- 📧 Email: support@example.com
- 📚 Documentación: Este README
- 🐛 Reportar bugs: Issues en GitHub
- 💬 Preguntas: Discussions en GitHub

---

## ⭐ Agradecimientos

- Flask Framework
- SQLAlchemy ORM
- Pandas Library
- OpenPyXL
- Cloudflare Tunnel
- Comunidad Open Source

---

**Desarrollado con ❤️ para gestión eficiente de proveedores e inventario**

**Versión 0.1** - Febrero 2026

---

## 🚀 Quick Start (Resumen)

### Instalación Automática (Recomendado)

**Windows:**
```cmd
install.bat
start.bat
```

**Linux/Mac:**
```bash
chmod +x install.sh
./install.sh
./start.sh
```

### Instalación Manual

```bash
# 1. Descargar proyecto
cd proveedores

# 2. Crear entorno virtual
python -m venv venv

# 3. Activar entorno
.\venv\Scripts\Activate.ps1  # Windows
source venv/bin/activate      # Linux/Mac

# 4. Instalar dependencias
pip install -r requirements.txt

# 5. Iniciar aplicación
python app.py
```

Abre tu navegador en: **http://localhost:5000**

**¡Listo para usar!** 🎉

# ============================================================
#  Sistema de Gestión de Proveedores e Inventario v0.1
#  Instalador Automático para Windows (PowerShell)
# ============================================================

$Host.UI.RawUI.WindowTitle = "Instalador - Sistema de Proveedores v0.1"

function Read-HostDefault {
    param(
        [string]$Prompt,
        [string]$Default = ""
    )

    $suffix = if ([string]::IsNullOrWhiteSpace($Default)) { "" } else { " [$Default]" }
    $value = Read-Host "$Prompt$suffix"
    if ([string]::IsNullOrWhiteSpace($value)) {
        return $Default
    }
    return $value
}

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  INSTALADOR - Sistema de Gestion de Proveedores v0.1" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# Check if Python is installed
try {
    $pythonVersion = python --version 2>&1
    Write-Host "[OK] Python detectado: $pythonVersion" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "[ERROR] Python no esta instalado en el sistema." -ForegroundColor Red
    Write-Host ""
    Write-Host "Por favor descarga e instala Python 3.8 o superior desde:"
    Write-Host "https://www.python.org/downloads/" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Asegurate de marcar 'Add Python to PATH' durante la instalacion."
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}

# Check Python version
$versionCheck = python -c "import sys; exit(0 if sys.version_info >= (3, 8) else 1)" 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Se requiere Python 3.8 o superior." -ForegroundColor Red
    Write-Host "Por favor actualiza tu version de Python."
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}

Write-Host "[1/5] Verificando entorno virtual..." -ForegroundColor Yellow
if (Test-Path "venv") {
    Write-Host "[INFO] Entorno virtual existente detectado. Se eliminara y recreara." -ForegroundColor Yellow
    Remove-Item -Recurse -Force venv
}

Write-Host "[2/5] Creando entorno virtual..." -ForegroundColor Yellow
python -m venv venv
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] No se pudo crear el entorno virtual." -ForegroundColor Red
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}
Write-Host "[OK] Entorno virtual creado exitosamente." -ForegroundColor Green
Write-Host ""

Write-Host "[3/5] Activando entorno virtual..." -ForegroundColor Yellow
& .\venv\Scripts\Activate.ps1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] No se pudo activar el entorno virtual." -ForegroundColor Red
    Write-Host "[INFO] Esto puede ser debido a la politica de ejecucion de PowerShell." -ForegroundColor Yellow
    Write-Host "Ejecuta como Administrador: Set-ExecutionPolicy RemoteSigned" -ForegroundColor Yellow
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}
Write-Host "[OK] Entorno virtual activado." -ForegroundColor Green
Write-Host ""

$pythonCmd = ".\venv\Scripts\python.exe"

Write-Host "[4/5] Instalando dependencias..." -ForegroundColor Yellow
Write-Host "Este proceso puede tardar algunos minutos..." -ForegroundColor Gray
Write-Host ""
& $pythonCmd -m pip install --upgrade pip --quiet
& $pythonCmd -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Fallo la instalacion de dependencias." -ForegroundColor Red
    Write-Host "Verifica tu conexion a internet e intenta nuevamente."
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}
Write-Host ""
Write-Host "[OK] Dependencias instaladas correctamente." -ForegroundColor Green
Write-Host ""

Write-Host "[5/5] Verificando instalacion..." -ForegroundColor Yellow
python -c "import flask, sqlalchemy, pandas, openpyxl" 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] La verificacion de modulos fallo." -ForegroundColor Red
    Read-Host "Presiona Enter para salir"
    exit 1
}
Write-Host "[OK] Todos los modulos fueron instalados correctamente." -ForegroundColor Green
Write-Host ""

# Create launch script
Write-Host "[EXTRA] Creando script de inicio rapido..." -ForegroundColor Yellow
@"
@echo off
cd /d "%~dp0"
call venv\Scripts\activate.bat
python app.py
pause
"@ | Out-File -FilePath "start.bat" -Encoding ASCII
Write-Host "[OK] Script 'start.bat' creado." -ForegroundColor Green
Write-Host ""

# Create database if not exists
if (-not (Test-Path "suppliers.db")) {
    Write-Host "[SETUP] Inicializando base de datos..." -ForegroundColor Yellow
    python -c "from database import init_db; init_db(); print('Base de datos creada exitosamente.')"
    Write-Host ""
}

Write-Host "========================================================" -ForegroundColor Green
Write-Host "  INSTALACION COMPLETADA EXITOSAMENTE!" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host ""
Write-Host "El sistema esta listo para usar." -ForegroundColor Cyan
Write-Host ""
Write-Host "Para iniciar la aplicacion:" -ForegroundColor White
Write-Host "  1. Ejecuta 'start.bat' en esta carpeta, o" -ForegroundColor Gray
Write-Host "  2. Ejecuta manualmente:" -ForegroundColor Gray
Write-Host "     .\venv\Scripts\Activate.ps1" -ForegroundColor Gray
Write-Host "     python app.py" -ForegroundColor Gray
Write-Host ""
Write-Host "Luego abre tu navegador en: " -NoNewline
Write-Host "http://localhost:5000" -ForegroundColor Yellow
Write-Host ""
Write-Host "Documentacion completa: README.md" -ForegroundColor Gray
Write-Host ""
Read-HostDefault "Presiona Enter para salir" ""

# Windows Service Setup for Sistema de Proveedores
# This script sets up the application as a Windows service using sc.exe

param(
    [string]$Action = "install",
    [string]$ServiceName = "SistemaProveedores",
    [string]$ProjectRoot,
    [switch]$ForceReinstall = $false
)

$ErrorActionPreference = "Stop"

# Check for administrator privileges
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Request administrator privileges if not running as admin
if (-not (Test-Administrator)) {
    Write-Host "This script requires administrator privileges to manage Windows services." -ForegroundColor Yellow
    Write-Host "Requesting elevation..." -ForegroundColor Yellow

    $scriptPath = $MyInvocation.MyCommand.Path
    $arguments = ""
    if ($Action) { $arguments += " -Action $Action" }
    if ($ServiceName) { $arguments += " -ServiceName $ServiceName" }
    if ($ProjectRoot) { $arguments += " -ProjectRoot `"$ProjectRoot`"" }
    if ($ForceReinstall) { $arguments += " -ForceReinstall" }

    Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$scriptPath`" $arguments" -Verb RunAs -Wait
    exit $LASTEXITCODE
}

# Get the script directory and project root
# Use provided ProjectRoot parameter, or fall back to working directory
if ($ProjectRoot) {
    $ProjectRoot = $ProjectRoot
} else {
    $ProjectRoot = $PWD.Path
}
$ScriptDir = Join-Path $ProjectRoot "utilities\service"

$LogDir = Join-Path $ProjectRoot "logs"
$ServiceLog = Join-Path $LogDir "service.log"

# Ensure log directory exists
if (!(Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $LogMessage = "[$Level] $Timestamp - $Message"
    $LogMessage | Out-File -FilePath $ServiceLog -Append -Encoding UTF8
    Write-Host $LogMessage
}

Write-Log "=== Service Management Script Started ===" "INFO"
Write-Log "Log file: $ServiceLog" "INFO"
Write-Log "Action: $Action" "INFO"
Write-Log "Service Name: $ServiceName" "INFO"
Write-Log "Using sc.exe for service management" "INFO"

function Install-Service {
    Write-Log "Installing Windows service: $ServiceName"

    # Get paths
    $pythonExe = Join-Path $ProjectRoot "venv\Scripts\python.exe"
    $serviceWrapper = Join-Path $ProjectRoot "api\service_wrapper.py"
    $appPath = Join-Path $ProjectRoot "api\app.py"

    # Check if service wrapper exists
    if (!(Test-Path $serviceWrapper)) {
        Write-Log "ERROR: Service wrapper not found at $serviceWrapper"
        exit 1
    }

    # Check if app.py exists
    if (!(Test-Path $appPath)) {
        Write-Log "ERROR: Flask app not found at $appPath"
        exit 1
    }

    # Check if Python executable exists
    if (!(Test-Path $pythonExe)) {
        Write-Log "ERROR: Python executable not found at $pythonExe"
        exit 1
    }

    # Always remove any existing service first for clean installation
    Write-Log "Ensuring clean installation by removing any existing service..."

    # Stop the service if it exists
    $existingService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($existingService) {
        Write-Log "Stopping existing service..."
        try {
            Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
            Write-Log "Stopped existing service"
        } catch {
            Write-Log "Warning: Could not stop existing service: $($_.Exception.Message)"
        }
    }

    # Kill any orphaned Python processes
    Write-Log "Checking for orphaned Python processes..."
    $pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
        $_.CommandLine -like "*app.py*" -or $_.CommandLine -like "*service_wrapper.py*" -or $_.CommandLine -like "*SistemaProveedores*"
    }
    if ($pythonProcesses) {
        Write-Log "Found $($pythonProcesses.Count) orphaned Python processes, terminating..."
        foreach ($process in $pythonProcesses) {
            try {
                Stop-Process -Id $process.Id -Force -ErrorAction Stop
                Write-Log "Terminated orphaned process PID: $($process.Id)"
            } catch {
                Write-Log "Failed to terminate process $($process.Id): $($_.Exception.Message)"
            }
        }
        Start-Sleep -Seconds 2
    } else {
        Write-Log "No orphaned Python processes found"
    }

    # Remove the service using sc.exe
    Write-Log "Removing existing service configuration..."
    try {
        $scResult = sc.exe delete $ServiceName 2>&1
        if ($LASTEXITCODE -eq 0 -or $scResult -match "service does not exist") {
            Write-Log "Service removed using sc.exe"
        } else {
            Write-Log "sc.exe delete result: $scResult"
        }
    } catch {
        Write-Log "Warning: sc.exe delete failed: $($_.Exception.Message)"
    }

    # Wait for cleanup to complete
    Start-Sleep -Seconds 5

    # Install the service using sc.exe
    Write-Log "Installing service with sc.exe..."

    # Create a batch file for the service to ensure correct working directory
    $serviceBatPath = Join-Path $ProjectRoot "service.bat"
    $batContent = @"
@echo off
echo Starting service at %DATE% %TIME% >> "$ProjectRoot\logs\service_debug.log"
cd /d "$ProjectRoot" >> "$ProjectRoot\logs\service_debug.log" 2>&1
echo Changed to $ProjectRoot >> "$ProjectRoot\logs\service_debug.log"
call "$ProjectRoot\venv\Scripts\activate.bat" >> "$ProjectRoot\logs\service_debug.log" 2>&1
if %errorlevel% neq 0 (
    echo Venv activation failed with %errorlevel% >> "$ProjectRoot\logs\service_debug.log"
    exit /b %errorlevel%
)
echo Venv activated >> "$ProjectRoot\logs\service_debug.log"
"$ProjectRoot\venv\Scripts\python.exe" -c "print('Python test successful')" >> "$ProjectRoot\logs\service_debug.log" 2>&1
if %errorlevel% neq 0 (
    echo Python test failed with %errorlevel% >> "$ProjectRoot\logs\service_debug.log"
    exit /b %errorlevel%
)
echo Python test passed >> "$ProjectRoot\logs\service_debug.log"
"$ProjectRoot\venv\Scripts\python.exe" "$appPath" --service >> "$ProjectRoot\logs\service_debug.log" 2>&1
echo Service exited with errorlevel %errorlevel% >> "$ProjectRoot\logs\service_debug.log"
"@
    $batContent | Out-File -FilePath $serviceBatPath -Encoding ASCII -Force
    Write-Log "Created service batch file: $serviceBatPath"

    $serviceCommand = "`"$serviceBatPath`""
    Write-Log "Service command: $serviceCommand"
    $binPath = "`"$serviceBatPath`""
    $scCreateResult = sc.exe create $ServiceName binPath= "$binPath" start= auto "DisplayName=Sistema de Proveedores" 2>&1
    Write-Log "sc.exe create result: $scCreateResult"
    Write-Log "LASTEXITCODE: $LASTEXITCODE"

    if ($LASTEXITCODE -eq 0) {
        Write-Log "Service created successfully with sc.exe"

        # Configure service failure actions to restart on failure
        $failureResult = sc.exe failure $ServiceName reset= 86400 actions= restart/5000/restart/10000/restart/60000 2>&1
        Write-Log "Service failure config result: $failureResult"

        # Set description
        $descResult = sc.exe description $ServiceName "Sistema de Gestion de Proveedores - Web Service" 2>&1
        Write-Log "Service description result: $descResult"

        Write-Log "Service installed and configured successfully"
        
        # Clean up the temporary service batch file since it's no longer needed
        if (Test-Path $serviceBatPath) {
            Remove-Item $serviceBatPath -Force
            Write-Log "Cleaned up temporary service batch file: $serviceBatPath"
        }
    } else {
        Write-Log "ERROR: Failed to create service with sc.exe: $scCreateResult"
        exit 1
    }
}

function Remove-Service {
    Write-Log "Removing Windows service: $ServiceName"

    if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
        Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue

        # Use sc.exe to delete the service
        $scDeleteResult = sc.exe delete $ServiceName 2>&1
        Write-Log "sc.exe delete result: $scDeleteResult"

        # Wait a bit for deletion to complete
        Start-Sleep -Seconds 3

        # Check if service is gone
        $stillExists = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if ($stillExists) {
            Write-Log "Warning: Service still exists after sc.exe delete"
        } else {
            Write-Log "Service removed successfully"
        }
    } else {
        Write-Log "Service $ServiceName not found"
    }

    # Remove the service batch file
    $serviceBatPath = Join-Path $ProjectRoot "service.bat"
    if (Test-Path $serviceBatPath) {
        Remove-Item $serviceBatPath -Force
        Write-Log "Removed service batch file: $serviceBatPath"
    }
}

function Start-Service-Manual {
    Write-Log "Starting service: $ServiceName" "INFO"

    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if (-not $service) {
        Write-Log "Service $ServiceName not found" "ERROR"
        exit 1
    }

    Write-Log "Current service status: $($service.Status)" "INFO"

    if ($service.Status -eq "Running") {
        Write-Log "Service is already running"
        return
    }

    # Kill any orphaned Python processes first
    Write-Log "Checking for and killing any orphaned Python processes..." "INFO"
    $pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
        $_.CommandLine -like "*app.py*" -or $_.CommandLine -like "*service_wrapper.py*" -or $_.CommandLine -like "*SistemaProveedores*"
    }

    if ($pythonProcesses) {
        Write-Log "Found $($pythonProcesses.Count) Python processes, terminating..." "WARNING"
        foreach ($process in $pythonProcesses) {
            try {
                Write-Log "Terminating PID: $($process.Id)" "DEBUG"
                Stop-Process -Id $process.Id -Force -ErrorAction Stop
                Write-Log "Terminated Python process PID: $($process.Id)" "SUCCESS"
            } catch {
                Write-Log "Failed to terminate process $($process.Id): $($_.Exception.Message)" "ERROR"
            }
        }
        Start-Sleep -Seconds 2
    }

    # Start the service
    Write-Log "Starting service..." "INFO"
    try {
        Start-Service -Name $ServiceName
        Start-Sleep -Seconds 5
        $service.Refresh()
        Write-Log "Service status after start: $($service.Status)" "INFO"
        if ($service.Status -eq "Running") {
            Write-Log "Service started successfully" "SUCCESS"
        } else {
            Write-Log "Service start completed but status is: $($service.Status)" "WARNING"
        }
    } catch {
        Write-Log "Service start failed: $($_.Exception.Message)" "ERROR"
        exit 1
    }
}

function Stop-Service-Manual {
    Write-Log "Stopping service: $ServiceName"
    Stop-Service -Name $ServiceName -Force
    Write-Log "Service stopped"
}

function Get-Service-Status {
    Write-Log "=== Service Status Check ==="

    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($service) {
        Write-Log "Windows Service Status: $($service.Status)"
        Write-Log "Service Name: $($service.Name)"
        Write-Log "Display Name: $($service.DisplayName)"
        Write-Log "Start Type: $($service.StartType)"

        # Check if process is running
        $processes = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
            $_.CommandLine -like "*service_wrapper.py*" -or $_.CommandLine -like "*SistemaProveedores*"
        }
        if ($processes) {
            foreach ($proc in $processes) {
                Write-Log "Python process found: PID $($proc.Id), CPU: $($proc.CPU), Memory: $([math]::Round($proc.WorkingSet64 / 1MB, 2)) MB"
            }

            # Check if web service is responding
            Write-Log "Checking web service health..."
            try {
                $webResponse = Invoke-WebRequest -Uri "http://localhost:5000" -TimeoutSec 5 -ErrorAction Stop
                if ($webResponse.StatusCode -eq 200) {
                    Write-Host "Web service is responding (HTTP $($webResponse.StatusCode))"
                } else {
                    Write-Host "Web service responded with HTTP $($webResponse.StatusCode)"
                }
            } catch {
                Write-Host "Web service is not responding: $($_.Exception.Message)"
                Write-Host "The Python process is running but the web server may have failed to start"
            }
        } else {
            Write-Host "No Python process found"
        }

        # Determine overall status
        if ($service.Status -eq "Running") {
            Write-Host "Service confirmed running via Windows Services"
        } else {
            Write-Host "Service status: $($service.Status)"
        }

    } else {
        Write-Host "Service $ServiceName not found"
    }

    Write-Host "=== Status check completed ==="
}

# Main execution
Write-Log "=== Service Management Script ==="
Write-Log "Action: $Action"
Write-Log "Service Name: $ServiceName"

switch ($Action.ToLower()) {
    "install" { Install-Service }
    "remove" { Remove-Service }
    "uninstall" { Remove-Service }
    "start" { Start-Service-Manual }
    "stop" { Stop-Service-Manual }
    "status" { Get-Service-Status }
    "restart" {
        Stop-Service-Manual
        Start-Sleep -Seconds 2
        Start-Service-Manual
    }
    default {
        Write-Log "Usage: service.ps1 -Action install|remove|start|stop|status|restart [-ServiceName name]"
        exit 1
    }
}

Write-Log "=== Operation completed ===" "INFO"
Write-Log "Log file location: $ServiceLog" "INFO"
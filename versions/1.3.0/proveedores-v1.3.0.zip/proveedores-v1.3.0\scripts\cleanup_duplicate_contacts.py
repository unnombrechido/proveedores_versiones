# -*- coding: utf-8 -*-
"""
Cleanup Script: Remove Duplicate Supplier Contacts
Version: 1.0.0
Date: 2026-02-10

This script:
1. Identifies duplicate contacts within the same supplier
2. Merges duplicate contacts, preserving the most complete information
3. Removes duplicate records
4. Maintains primary contact designation
5. Can be run standalone or as part of maintenance
"""

import sys
import os
from datetime import datetime
import argparse

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'api')))

from database import SessionLocal, engine
from models import SupplierContact
from sqlalchemy import text, and_, or_, func

def find_duplicate_contacts():
    """Find duplicate contacts within the same supplier based on name, phone, email combination"""
    db = SessionLocal()
    try:
        print("Searching for duplicate contacts...")

        # Find duplicates by grouping contacts with same supplier_id and similar contact info
        duplicates_query = db.execute(text("""
            SELECT supplier_id,
                   LOWER(TRIM(contact_name)) as name_key,
                   LOWER(TRIM(phone)) as phone_key,
                   LOWER(TRIM(email)) as email_key,
                   COUNT(*) as duplicate_count,
                   GROUP_CONCAT(id) as contact_ids,
                   GROUP_CONCAT(is_primary) as primary_flags
            FROM supplier_contacts
            GROUP BY supplier_id, LOWER(TRIM(contact_name)), LOWER(TRIM(phone)), LOWER(TRIM(email))
            HAVING COUNT(*) > 1
            ORDER BY supplier_id, duplicate_count DESC
        """))

        duplicates = duplicates_query.fetchall()
        print(f"Found {len(duplicates)} groups of duplicate contacts")

        return duplicates

    except Exception as e:
        print(f"Error finding duplicates: {str(e)}")
        return []
    finally:
        db.close()

def merge_duplicate_contacts(duplicate_group):
    """Merge a group of duplicate contacts, keeping the most complete one"""
    db = SessionLocal()
    try:
        supplier_id = duplicate_group[0]
        name_key = duplicate_group[1]
        phone_key = duplicate_group[2]
        email_key = duplicate_group[3]
        duplicate_count = duplicate_group[4]
        contact_ids_str = duplicate_group[5]
        primary_flags_str = duplicate_group[6]

        contact_ids = [int(id) for id in contact_ids_str.split(',')]
        primary_flags = [int(flag) for flag in primary_flags_str.split(',')]

        print(f"  Processing supplier {supplier_id}: {duplicate_count} duplicates")

        # Get all duplicate contacts
        contacts = db.query(SupplierContact).filter(SupplierContact.id.in_(contact_ids)).all()

        if not contacts:
            return 0

        # Find the "best" contact to keep (most complete information)
        best_contact = None
        best_score = -1

        for contact in contacts:
            score = 0
            if contact.contact_name and contact.contact_name.strip():
                score += 3
            if contact.phone and contact.phone.strip():
                score += 2
            if contact.email and contact.email.strip():
                score += 2
            if contact.position and contact.position.strip():
                score += 1
            if contact.notes and contact.notes.strip():
                score += 1

            # Prefer primary contacts
            if contact.is_primary:
                score += 5

            if score > best_score:
                best_score = score
                best_contact = contact

        if not best_contact:
            print("    Warning: Could not determine best contact to keep")
            return 0

        # Ensure the best contact is marked as primary if any of the duplicates were primary
        if any(primary_flags) and not best_contact.is_primary:
            best_contact.is_primary = True
            best_contact.notes = (best_contact.notes or "") + " [Merged from duplicates - marked as primary]"

        # Update best contact with any missing information from other contacts
        for contact in contacts:
            if contact.id == best_contact.id:
                continue

            # Merge position if missing
            if not best_contact.position and contact.position:
                best_contact.position = contact.position

            # Merge contact_type if missing
            if not best_contact.contact_type and contact.contact_type:
                best_contact.contact_type = contact.contact_type

            # Append notes
            if contact.notes and contact.notes.strip():
                if best_contact.notes:
                    best_contact.notes += f"; {contact.notes}"
                else:
                    best_contact.notes = contact.notes

        # Update timestamp
        best_contact.updated_at = datetime.utcnow()

        # Delete duplicate contacts
        duplicate_ids = [c.id for c in contacts if c.id != best_contact.id]
        if duplicate_ids:
            db.query(SupplierContact).filter(SupplierContact.id.in_(duplicate_ids)).delete(synchronize_session=False)
            db.commit()

            print(f"    Kept contact ID {best_contact.id}, removed {len(duplicate_ids)} duplicates")
            return len(duplicate_ids)

        return 0

    except Exception as e:
        db.rollback()
        print(f"    Error merging duplicates for supplier {supplier_id}: {str(e)}")
        return 0
    finally:
        db.close()

def cleanup_duplicate_contacts(dry_run=True):
    """Main function to cleanup duplicate contacts"""
    print("=" * 70)
    print("LIMPIEZA: Eliminar Contactos Duplicados de Proveedores")
    print("Versión: 1.0.0")
    print("=" * 70)
    print()

    if dry_run:
        print("🔍 MODO SIMULACIÓN - No se realizarán cambios")
        print("Ejecuta con dry_run=False para aplicar los cambios")
    else:
        print("⚠️  MODO REAL - Se eliminarán contactos duplicados")
        confirm = input("¿Continuar? (sí/no): ").lower().strip()
        if confirm not in ['sí', 'si', 's', 'yes', 'y']:
            print("Operación cancelada.")
            return

    print()

    # Find duplicates
    duplicate_groups = find_duplicate_contacts()

    if not duplicate_groups:
        print("✅ No se encontraron contactos duplicados.")
        return

    total_duplicates_removed = 0
    total_groups_processed = 0

    print(f"\nProcesando {len(duplicate_groups)} grupos de duplicados...")
    print()

    for group in duplicate_groups:
        if not dry_run:
            removed = merge_duplicate_contacts(group)
            total_duplicates_removed += removed
        else:
            duplicate_count = group[4]
            supplier_id = group[0]
            print(f"  Supplier {supplier_id}: {duplicate_count} duplicados encontrados")

        total_groups_processed += 1

    print()
    print("=" * 70)
    if dry_run:
        print("RESUMEN DE SIMULACIÓN:")
        print(f"  Grupos de duplicados encontrados: {len(duplicate_groups)}")
        print("  Para aplicar los cambios, ejecuta con dry_run=False")
    else:
        print("RESUMEN DE LIMPIEZA:")
        print(f"  Grupos procesados: {total_groups_processed}")
        print(f"  Contactos duplicados eliminados: {total_duplicates_removed}")
        print(f"  Contactos únicos preservados: {total_groups_processed}")

    print("=" * 70)

def verify_cleanup():
    """Verify that cleanup was successful"""
    db = SessionLocal()
    try:
        print("\nVerificando limpieza...")

        # Check for remaining duplicates
        remaining_duplicates = db.execute(text("""
            SELECT COUNT(*) FROM (
                SELECT supplier_id, LOWER(TRIM(contact_name)), LOWER(TRIM(phone)), LOWER(TRIM(email))
                FROM supplier_contacts
                GROUP BY supplier_id, LOWER(TRIM(contact_name)), LOWER(TRIM(phone)), LOWER(TRIM(email))
                HAVING COUNT(*) > 1
            ) as duplicates
        """)).scalar()

        total_contacts = db.query(SupplierContact).count()
        primary_contacts = db.query(SupplierContact).filter(SupplierContact.is_primary == True).count()

        print(f"  Contactos totales: {total_contacts}")
        print(f"  Contactos primarios: {primary_contacts}")
        print(f"  Grupos de duplicados restantes: {remaining_duplicates}")

        if remaining_duplicates == 0:
            print("✅ Verificación exitosa: No quedan duplicados")
            return True
        else:
            print("⚠️  Advertencia: Aún quedan duplicados")
            return False

    except Exception as e:
        print(f"Error durante verificación: {str(e)}")
        return False
    finally:
        db.close()

def main():
    parser = argparse.ArgumentParser(description='Cleanup duplicate supplier contacts')
    parser.add_argument('--apply', action='store_true',
                       help='Apply changes (default is dry run)')
    parser.add_argument('--verify-only', action='store_true',
                       help='Only verify current state, do not cleanup')

    args = parser.parse_args()

    if args.verify_only:
        verify_cleanup()
        return

    # Run cleanup
    cleanup_duplicate_contacts(dry_run=not args.apply)

    # Verify if changes were applied
    if args.apply:
        verify_cleanup()


if __name__ == '__main__':
    main()
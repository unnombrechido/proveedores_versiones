# Windows Service Setup

This directory contains scripts to run the Sistema de Proveedores as a Windows service, making it run invisibly in the background and start automatically on system boot and wake-from-sleep.

## Quick Start

1. **Run as Administrator**: Right-click `utilities\service\setup-service.bat` and select "Run as administrator"
2. **Follow the prompts**: The script will install the service and set up wake-from-sleep handling
3. **Access the app**: The web interface will be available at `http://localhost:5000`

## What Gets Installed

- **Windows Service**: "SistemaProveedores" - runs the Flask app in the background
- **Scheduled Task**: "SistemaProveedores-WakeHandler" - ensures service runs after wake from sleep
- **NSSM**: Non-Sucking Service Manager for reliable service management (included locally)

## Service Management

Use `manage-service.bat` for day-to-day service management:

```batch
# Check service status
manage-service.bat status

# Stop the service
manage-service.bat stop

# Start the service
manage-service.bat start

# Restart the service
manage-service.bat restart

# Remove/uninstall the service
manage-service.bat remove
```

## Files Overview

- `setup-service.bat` - **Main installation script** (run as admin)
- `manage-service.bat` - Service management commands
- `service.ps1` - PowerShell service management script
- `setup-wake-task.ps1` - Scheduled task setup for wake-from-sleep
- `wake-handler.ps1` - Script that runs on system wake
- `nssm.exe` - **NSSM executable (included locally)**

## Benefits

- **Invisible Operation**: No console window or taskbar icon
- **Auto-Start**: Starts automatically on system boot
- **Wake-from-Sleep**: Automatically restarts after system wake
- **Reliability**: NSSM handles crashes and restarts
- **User Protection**: Prevents accidental stopping while working

## Troubleshooting

### Service Won't Start
- Check logs in `logs/service.log`
- Ensure Python virtual environment is set up
- Verify port 5000 is not blocked by firewall

### Web Interface Not Accessible
- Check if service is running: `manage-service.bat status`
- Check logs for errors
- Verify port 5000 is not blocked by firewall

### Wake-from-Sleep Not Working
- Check Task Scheduler for "SistemaProveedores-WakeHandler" task
- Verify task is enabled and set to run on startup
- Check `logs/wake.log` for wake events

## Offline Installation

Since NSSM is included locally in the distribution package, the service setup works completely offline without internet access.

## Removal

To completely remove the service setup:

1. Run `manage-service.bat remove` as administrator
2. Run `setup-wake-task.ps1 -Action remove` as administrator

The application will return to running as a regular console application.

## What Gets Installed

- **Windows Service**: "SistemaProveedores" - runs the Flask app in the background
- **Scheduled Task**: "SistemaProveedores-WakeHandler" - ensures service runs after wake from sleep
- **NSSM**: Non-Sucking Service Manager for reliable service management

## Service Management

Use `manage-service.bat` for day-to-day service management:

```batch
# Check service status
manage-service.bat status

# Stop the service
manage-service.bat stop

# Start the service
manage-service.bat start

# Restart the service
manage-service.bat restart

# Remove/uninstall the service
manage-service.bat remove
```

## Files Overview

- `setup-service.bat` - Main installation script (run as admin)
- `manage-service.bat` - Service management commands
- `service.ps1` - PowerShell service management script
- `setup-wake-task.ps1` - Scheduled task setup for wake-from-sleep
- `wake-handler.ps1` - Script that runs on system wake
- `download-nssm.ps1` - Downloads NSSM if needed

## Benefits

- **Invisible Operation**: No console window or taskbar icon
- **Auto-Start**: Starts automatically on system boot
- **Wake-from-Sleep**: Automatically restarts after system wake
- **Reliability**: NSSM handles crashes and restarts
- **User Protection**: Prevents accidental stopping while working

## Troubleshooting

### Service Won't Start
- Check logs in `logs/service.log`
- Ensure Python virtual environment is set up
- Verify all dependencies are installed

### Web Interface Not Accessible
- Check if service is running: `manage-service.bat status`
- Check logs for errors
- Verify port 5000 is not blocked by firewall

### Wake-from-Sleep Not Working
- Check Task Scheduler for "SistemaProveedores-WakeHandler" task
- Verify task is enabled and set to run on startup
- Check `logs/wake.log` for wake events

## Manual Installation

If automatic setup fails, you can install components manually:

1. Download NSSM from https://nssm.cc/ and place `nssm.exe` in this directory
2. Run `manage-service.bat install` as administrator
3. Run `setup-wake-task.ps1 -Action install` as administrator

## Removal

To completely remove the service setup:

1. Run `manage-service.bat remove` as administrator
2. Run `setup-wake-task.ps1 -Action remove` as administrator
3. Delete the `nssm.exe` file if desired

The application will return to running as a regular console application.
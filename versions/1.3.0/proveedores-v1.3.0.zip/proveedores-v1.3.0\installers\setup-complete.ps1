# Canonical config structure as a hashtable
$CanonicalConfigKeys = @{
    section = '[COMPANY]'
    company_name = $companyName
    company_address = ''
    company_phone = ''
    company_email = ''
    company_website = ''
    logo_path = $logoPath
    version = $currentVersion
    order_template_esp = 'config/order_template_esp.html'
    order_template_eng = 'config/order_template_eng.html'
    zoom = '1.0'
}

# SERVER section
$CanonicalServerKeys = @{
    section = '[SERVER]'
    url = 'http://127.0.0.1:5000'
}

# Function to write canonical config.ini
function Write-CanonicalConfig {
    param(
        [string]$filePath,
        [hashtable]$values
    )
    $lines = @()
    $lines += $values.section
    $lines += "company_name=$($values.company_name)"
    $lines += "company_address=$($values.company_address)"
    $lines += "company_phone=$($values.company_phone)"
    $lines += "company_email=$($values.company_email)"
    $lines += "company_website=$($values.company_website)"
    $lines += "logo_path=$($values.logo_path)"
    $lines += "version=$($values.version)"
    $lines += "order_template_esp=$($values.order_template_esp)"
    $lines += "order_template_eng=$($values.order_template_eng)"
    $lines += "zoom=$($values.zoom)"
    $lines | Out-File -FilePath $filePath -Encoding ASCII
}

# Function to enforce canonical config structure
function Ensure-CanonicalConfig {
    param(
        [string]$filePath,
        [hashtable]$companyDefaults,
        [hashtable]$serverDefaults
    )
    $existingValues = @{}
    $companySection = $false
    $serverSection = $false
    $lines = @()
    if (Test-Path $filePath) {
        $content = Get-Content $filePath -Raw
        $rawLines = $content -split "\r?\n"
        $currentSection = ""
        foreach ($line in $rawLines) {
            if ($line -match '^\[COMPANY\]') { 
                $currentSection = "COMPANY"
                $companySection = $true 
            } elseif ($line -match '^\[SERVER\]') { 
                $currentSection = "SERVER"
                $serverSection = $true 
            }
            # Accept keys with or without spaces, case-insensitive
            if ($line -match '^\s*([\w_]+)\s*=\s*(.*)$') {
                $key = $matches[1].Trim().ToLower()
                $val = $matches[2].Trim()
                $existingValues["$currentSection.$key"] = $val
            }
        }
    }
    # Build new config preserving existing values
    $lines += '[COMPANY]'
    foreach ($key in $companyDefaults.Keys) {
        if ($key -eq 'section') { continue }
        $val = $companyDefaults[$key]
        if ($key -ne 'version' -and $existingValues.ContainsKey("COMPANY.$($key.ToLower())")) {
            $val = $existingValues["COMPANY.$($key.ToLower())"]
        }
        $lines += "$key=$val"
    }
    $lines += ''
    $lines += '[SERVER]'
    foreach ($key in $serverDefaults.Keys) {
        if ($key -eq 'section') { continue }
        $val = $serverDefaults[$key]
        if ($existingValues.ContainsKey("SERVER.$($key.ToLower())")) {
            $val = $existingValues["SERVER.$($key.ToLower())"]
        }
        $lines += "$key=$val"
    }
    $lines | Out-File -FilePath $filePath -Encoding ASCII
    Write-Host "[OK] config.ini actualizado y valores existentes preservados" -ForegroundColor Green
}
# ============================================================
#  Sistema de Gestión de Proveedores v1.3.0
#  Instalador Completo con Migración Inteligente
# ============================================================

$versionPath = Join-Path (Split-Path $PSScriptRoot -Parent) "VERSION"
$VERSION = if (Test-Path $versionPath) { (Get-Content $versionPath -Raw).Trim() } else { "1.3.0" }
$currentVersion = $VERSION
$Host.UI.RawUI.WindowTitle = "Sistema de Proveedores v$VERSION - Instalador Completo"
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "White"
Clear-Host

# Set up logging
$logDir = Join-Path (Split-Path $PSScriptRoot -Parent) "logs"
if (!(Test-Path $logDir)) {
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
}
$logFile = Join-Path $logDir "installer.log"
Start-Transcript -Path $logFile -Append

# Configuration
$GITHUB_RELEASE_URL = "https://github.com/TU_USUARIO/proveedores/releases/download/v$VERSION/proveedores-v$VERSION.zip"
$TEMP_ZIP = "$env:TEMP\proveedores-v$VERSION.zip"

# Progress tracking function
function Show-OverallProgress {
    param(
        [int]$Step,
        [int]$TotalSteps,
        [string]$Description
    )
    
    $percent = [math]::Floor(($Step / $TotalSteps) * 100)
    $progressChars = [math]::Floor($percent / 2)
    $progressBar = "[" + ("=" * $progressChars) + ("-" * (50 - $progressChars)) + "]"
    
    Write-Host ""
    Write-Host "--------------------------------------------------------------" -ForegroundColor DarkCyan
    Write-Host " PROGRESO GENERAL: $progressBar $percent%" -ForegroundColor Cyan
    Write-Host " Paso $Step de ${TotalSteps}: $Description" -ForegroundColor White
    Write-Host "--------------------------------------------------------------" -ForegroundColor DarkCyan
    Write-Host ""
}

# Stop running app instances
function Stop-RunningApp {
    param(
        [string]$InstallPath
    )
    
    Write-Host "[STOP] Verificando aplicaciones en ejecucion..." -ForegroundColor Yellow
    
    $appStopped = $false
    
    # Check if service is installed and running
    $serviceName = "SistemaProveedores"
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        $service = Get-Service -Name $serviceName
        Write-Host "  Servicio `"$serviceName`" encontrado - Estado: $($service.Status)" -ForegroundColor Gray
        
        # Check if service is active (Running or Starting)
        if ($service.Status -eq "Running" -or $service.Status -eq "Starting") {
            Write-Host "  Servicio `"$serviceName`" esta activo. Deteniendo..." -ForegroundColor Cyan
            
            # Try standard Stop-Service first
            try {
                Stop-Service -Name $serviceName -Force -ErrorAction Stop
                Write-Host "  [OK] Servicio detenido correctamente con Stop-Service" -ForegroundColor Green
                $appStopped = $true
            } catch {
                Write-Host "  [ADVERTENCIA] Stop-Service fallo, intentando con NSSM..." -ForegroundColor Yellow
                
                # Try NSSM stop if available
                $nssmPath = Join-Path $InstallPath "utilities\service\nssm.exe"
                if (Test-Path $nssmPath) {
                    try {
                        & $nssmPath stop $serviceName
                        Write-Host "  [OK] Servicio detenido correctamente con NSSM" -ForegroundColor Green
                        $appStopped = $true
                    } catch {
                        Write-Host "  [ERROR] No se pudo detener el servicio: $($_.Exception.Message)" -ForegroundColor Red
                    }
                } else {
                    Write-Host "  [ERROR] NSSM no encontrado para detener servicio" -ForegroundColor Red
                }
            }
        } elseif ($service.Status -eq "Stopping") {
            Write-Host "  Servicio `"$serviceName`" se esta deteniendo. Esperando..." -ForegroundColor Yellow
            Start-Sleep -Seconds 5
            $service.Refresh()
            if ($service.Status -eq "Stopped") {
                Write-Host "  [OK] Servicio se detuvo automaticamente" -ForegroundColor Green
                $appStopped = $true
            }
        } else {
            Write-Host "  Servicio `"$serviceName`" instalado pero detenido" -ForegroundColor Gray
        }
    }
    
    # Check for running Python processes on port 5000 (Flask default)
    $pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
        $_.CommandLine -like "*app.py*" -or $_.CommandLine -like "*api/app.py*"
    }
    
    if ($pythonProcesses) {
        Write-Host "  Encontrados $($pythonProcesses.Count) procesos Python ejecutandose:" -ForegroundColor Cyan
        foreach ($process in $pythonProcesses) {
            Write-Host "    PID $($process.Id): $($process.CommandLine)" -ForegroundColor Gray
        }
        
        try {
            $pythonProcesses | Stop-Process -Force -ErrorAction Stop
            Write-Host "  [OK] Procesos Python detenidos correctamente" -ForegroundColor Green
            $appStopped = $true
        } catch {
            Write-Host "  [ADVERTENCIA] No se pudieron detener algunos procesos Python: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    
    # Check if port 5000 is in use (alternative method)
    $portInUse = Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue
    if ($portInUse) {
        Write-Host "  Puerto 5000 esta en uso. Aplicacion puede estar ejecutandose." -ForegroundColor Yellow
        Write-Host "  [RECOMENDACION] Asegurese de que la aplicacion este completamente detenida" -ForegroundColor Yellow
    }
    
    if ($appStopped) {
        Write-Host "  Aplicacion detenida exitosamente" -ForegroundColor Green
        Start-Sleep -Seconds 2  # Give time for cleanup
    } else {
        Write-Host "  No se encontraron aplicaciones ejecutandose" -ForegroundColor Gray
    }
    
    Write-Host ""
}

# Detect installation structure version
function Get-InstallationStructure {
    param(
        [string]$Path
    )
    
    # Check for v1.0 structure (modular: api/, bin/, data/, scripts/)
    if ((Test-Path "$Path\api\app.py") -and 
        (Test-Path "$Path\bin") -and 
        (Test-Path "$Path\data")) {
        return "v1.0"
    }
    
    # Check for v0.1 structure (old: app/, suppliers.db at root)
    if ((Test-Path "$Path\app\app.py") -or (Test-Path "$Path\app.py")) {
        return "v0.1"
    }
    
    return "unknown"
}

# Backup existing installation
function Backup-Installation {
    param(
        [string]$InstallDir,
        [string]$Structure
    )
    
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupDir = "$InstallDir\backup_${timestamp}_${Structure}"
    
    Write-Host "[INFO] Creando respaldo completo..." -ForegroundColor Yellow
    
    try {
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        
        # Backup database
        if ($Structure -eq "v0.1") {
            if (Test-Path "$InstallDir\suppliers.db") {
                Copy-Item "$InstallDir\suppliers.db" "$backupDir\suppliers.db" -Force
                Write-Host "  [OK] Base de datos respaldada" -ForegroundColor Green
            }
            if (Test-Path "$InstallDir\proveedores.db") {
                Copy-Item "$InstallDir\proveedores.db" "$backupDir\proveedores.db" -Force
                Write-Host "  [OK] Base de datos respaldada" -ForegroundColor Green
            }
        } else {
            if (Test-Path "$InstallDir\data\suppliers.db") {
                Copy-Item "$InstallDir\data\suppliers.db" "$backupDir\suppliers.db" -Force
                Write-Host "  [OK] Base de datos respaldada" -ForegroundColor Green
            }
        }
        
        # Backup config
        if (Test-Path "$InstallDir\config\config.ini") {
            Copy-Item "$InstallDir\config\config.ini" "$backupDir\config.ini" -Force
            Write-Host "  [OK] Configuración respaldada" -ForegroundColor Green
        } elseif (Test-Path "$InstallDir\config.ini") {
            Copy-Item "$InstallDir\config.ini" "$backupDir\config.ini" -Force
            Write-Host "  [OK] Configuración respaldada" -ForegroundColor Green
        }
        
        Write-Host ""
        Write-Host "[OK] Respaldo creado en: $backupDir" -ForegroundColor Green
        return $backupDir
    } catch {
        Write-Host "[ERROR] Fallo al crear respaldo: $_" -ForegroundColor Red
        return $null
    }
}

function New-DesktopShortcut {
    param(
        [string]$Name,
        [string]$TargetPath,
        [string]$WorkingDirectory,
        [string]$Description,
        [int]$WindowStyle = 1
    )

    try {
        $desktop = @([Environment]::GetFolderPath("Desktop"))[0]
        $shortcutPath = Join-Path $desktop "$Name.lnk"

        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut($shortcutPath)
        $Shortcut.TargetPath = $TargetPath
        $Shortcut.WorkingDirectory = $WorkingDirectory
        $Shortcut.Description = $Description
        $Shortcut.WindowStyle = $WindowStyle
        $Shortcut.Save()
        return $true
    }
    catch {
        return $false
    }
}

function New-UtilityShortcut {
    param(
        [string]$ShortcutPath,
        [string]$TargetPath,
        [string]$Arguments = "",
        [string]$WorkingDirectory,
        [string]$Description,
        [int]$WindowStyle = 1
    )

    try {
        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
        $Shortcut.TargetPath = $TargetPath
        if ($Arguments) {
            $Shortcut.Arguments = $Arguments
        }
        $Shortcut.WorkingDirectory = $WorkingDirectory
        $Shortcut.Description = $Description
        $Shortcut.WindowStyle = $WindowStyle
        $Shortcut.Save()
        return $true
    }
    catch {
        return $false
    }
}

function Read-HostDefault {
    param(
        [string]$Prompt,
        [string]$Default = ""
    )

    $suffix = if ([string]::IsNullOrWhiteSpace($Default)) { "" } else { " [$Default]" }
    $value = Read-Host "$Prompt$suffix"
    if ([string]::IsNullOrWhiteSpace($value)) {
        return $Default
    }
    return $value
}

function Convert-PathInput {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $Value }
    return $Value.Trim().Trim('"').Trim("'")
}

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# Banner
Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  SISTEMA DE GESTION DE PROVEEDORES E INVENTARIO v$VERSION" -ForegroundColor Cyan
Write-Host "  Instalador Completo con Migración Inteligente" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

if ($isAdmin) {
    Write-Host "[INFO] Ejecutando con permisos de administrador" -ForegroundColor Green
} else {
    Write-Host "[INFO] Ejecutando como usuario normal" -ForegroundColor Gray
}
Write-Host ""

Show-OverallProgress -Step 1 -TotalSteps 11 -Description "Verificando Python"

# Check Python
Write-Host "[Verificando requisitos...]" -ForegroundColor Yellow
Write-Host ""

$pythonInstalled = $false
$pythonCmd = "python"

# Try python3 first (common on systems with both Python 2 and 3)
try {
    $pythonVersion = python3 --version 2>&1 | Out-String
    if ($pythonVersion -match "Python 3") {
        Write-Host "[OK] Python 3 detectado: $pythonVersion" -ForegroundColor Green
        $pythonCmd = "python3"
        $pythonInstalled = $true
    }
} catch {
    # python3 command not found, try python
}

# If python3 didn't work, try python
if (-not $pythonInstalled) {
    try {
        $pythonVersion = python --version 2>&1 | Out-String
        if ($pythonVersion -match "Python 3") {
            Write-Host "[OK] Python detectado: $pythonVersion" -ForegroundColor Green
            $pythonCmd = "python"
            $pythonInstalled = $true
        } elseif ($pythonVersion -match "Python 2") {
            Write-Host "[ADVERTENCIA] Se detecto Python 2.7: $pythonVersion" -ForegroundColor Yellow
            Write-Host "[INFO] Se requiere Python 3.8+, pero se encontro Python 2.x" -ForegroundColor Yellow
            Write-Host ""
            # Don't set $pythonInstalled = $true, let it try to install Python 3
        }
    } catch {
        Write-Host "[INFO] Python no esta instalado." -ForegroundColor Yellow
        Write-Host ""
    }
}

# Try to install Python automatically if not found
if (-not $pythonInstalled) {
    Write-Host "Intentando instalar Python automaticamente..." -ForegroundColor Cyan
    Write-Host ""
    
    # Check if we need admin rights
    if (-not $isAdmin) {
        Write-Host "[ADVERTENCIA] No se detectaron permisos de administrador." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Para instalar Python automaticamente, necesitas:" -ForegroundColor White
        Write-Host "1. Cerrar esta ventana" -ForegroundColor Gray
        Write-Host "2. Clic derecho en setup-complete.ps1" -ForegroundColor Gray
        Write-Host "3. Seleccionar `"Ejecutar con PowerShell como Administrador`"" -ForegroundColor Gray
        Write-Host ""
        $continueAnyway = Read-HostDefault "Continuar sin instalar Python automaticamente? (S/N)" "N"
        
        if ($continueAnyway -ne "S" -and $continueAnyway -ne "s") {
            Write-Host ""
            Write-Host "Instalacion cancelada. Ejecuta como administrador e intenta de nuevo." -ForegroundColor Yellow
            Read-HostDefault "Presiona Enter para salir" ""
            exit 1
        }
        
        # User chose to continue, skip to manual instructions
        Write-Host ""
        Write-Host "[INFO] Saltando instalacion automatica..." -ForegroundColor Yellow
        Write-Host ""
    }
    
    # Try winget first (Windows 10 1709+ / Windows 11)
    if ($isAdmin) {
        try {
            $wingetCheck = Get-Command winget -ErrorAction SilentlyContinue
            if ($wingetCheck) {
                Write-Host "[INFO] Usando winget para instalar Python 3.13.9..." -ForegroundColor Cyan
                Write-Host "[INFO] Esto puede tardar varios minutos..." -ForegroundColor Gray
                Write-Host ""
                
                # Try to install Python for all users (needs admin)
                $wingetResult = winget install Python.Python.3.13 --silent --scope machine --accept-package-agreements --accept-source-agreements 2>&1
                
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "[OK] Python instalado exitosamente" -ForegroundColor Green
                    Write-Host "[INFO] Reiniciando terminal para actualizar PATH..." -ForegroundColor Yellow
                    Write-Host ""
                    Write-Host "IMPORTANTE: Cierra esta ventana y ejecuta el instalador nuevamente." -ForegroundColor Cyan
                    Write-Host ""
                    Read-HostDefault "Presiona Enter para cerrar" ""
                    exit 0
                } else {
                    Write-Host "[ADVERTENCIA] winget fallo: $wingetResult" -ForegroundColor Yellow
                    Write-Host "[INFO] Intentando instalacion para usuario actual..." -ForegroundColor Cyan
                    
                    # Try user-level install as fallback
                    $wingetResult2 = winget install Python.Python.3.13 --silent --scope user --accept-package-agreements --accept-source-agreements 2>&1
                    
                    if ($LASTEXITCODE -eq 0) {
                        Write-Host "[OK] Python instalado para usuario actual" -ForegroundColor Green
                        Write-Host "[INFO] Reiniciando terminal..." -ForegroundColor Yellow
                        Write-Host ""
                        Write-Host "IMPORTANTE: Cierra esta ventana y ejecuta el instalador nuevamente." -ForegroundColor Cyan
                        Write-Host ""
                        Read-HostDefault "Presiona Enter para cerrar" ""
                        exit 0
                    }
                }
            }
        } catch {
            Write-Host "[INFO] winget no disponible o fallo: $_" -ForegroundColor Gray
        }
    }
    
    # If we get here, automatic installation failed or was skipped
    Write-Host "[INFO] Instalacion automatica no disponible." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Por favor instala Python manualmente:" -ForegroundColor White
    Write-Host ""
    Write-Host "1. Visita: https://www.python.org/downloads/" -ForegroundColor Cyan
    Write-Host "2. Descarga Python 3.13.9 (o superior)" -ForegroundColor Gray
    Write-Host "3. Durante la instalacion, marca:" -ForegroundColor Gray
    Write-Host "   [X] Add Python to PATH" -ForegroundColor Yellow
    Write-Host "4. Completa la instalacion" -ForegroundColor Gray
    Write-Host "5. Ejecuta este instalador nuevamente" -ForegroundColor Gray
    Write-Host ""
    
    $openBrowser = Read-HostDefault "Abrir pagina de descarga ahora? (S/N)" "N"
    if ($openBrowser -eq "S" -or $openBrowser -eq "s") {
        Start-Process "https://www.python.org/downloads/"
    }
    
    Write-Host ""
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}

# Check Python version
$versionOutput = & $pythonCmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Error al verificar version de Python." -ForegroundColor Red
    Write-Host "Salida: $versionOutput" -ForegroundColor Yellow
    exit 1
}

$versionParts = $versionOutput -split "\."
$major = [int]$versionParts[0]
$minor = [int]$versionParts[1]

if ($major -lt 3 -or ($major -eq 3 -and $minor -lt 8)) {
    Write-Host "[ERROR] Se requiere Python 3.8 o superior." -ForegroundColor Red
    Write-Host "La version instalada es: $versionOutput" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Por favor actualiza Python desde: https://www.python.org/downloads/" -ForegroundColor Cyan
    Write-Host ""
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}

Write-Host "[INFO] Usando comando: $pythonCmd" -ForegroundColor Cyan
Write-Host ""

Show-OverallProgress -Step 2 -TotalSteps 11 -Description "Configuracion de Instalacion"

Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  CONFIGURACION DE INSTALACION" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Antes de continuar, asegúrate de cerrar la aplicación si está en ejecución." -ForegroundColor Yellow
Read-HostDefault "Presiona Enter para continuar" ""

# Ask for installation directory
$defaultDir = "C:\SistemaProveedores"
Write-Host "Ubicacion de instalacion por defecto:" -ForegroundColor White
Write-Host "$defaultDir" -ForegroundColor Gray
Write-Host ""
$installDir = Convert-PathInput (Read-HostDefault "Presiona ENTER para usar por defecto, o escribe nueva ruta" $defaultDir)

Write-Host ""
Write-Host "[INFO] Se instalara en: $installDir" -ForegroundColor Cyan
Write-Host ""

# Check for existing installation BEFORE asking for configuration
$isUpgrade = $false
$existingConfig = $null
$existingConfigPath = $null
$existingDbPath = $null
$structure = "unknown"
$companyName = ""
$logoPath = ""

if (Test-Path $installDir) {
    $structure = Get-InstallationStructure -Path $installDir
    if ($structure -ne "unknown") {
        $isUpgrade = $true
        Write-Host "[INFO] Instalacion existente detectada!" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Se encontro una instalacion anterior en:" -ForegroundColor White
        Write-Host "$installDir" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Los siguientes datos se preservaran:" -ForegroundColor Green

        if (Test-Path "$installDir\config\config.ini") {
            $existingConfigPath = "$installDir\config\config.ini"
        } elseif (Test-Path "$installDir\config.ini") {
            $existingConfigPath = "$installDir\config.ini"
        }

        if ($existingConfigPath) {
            Write-Host "  [X] Configuracion (config.ini)" -ForegroundColor Green
            $existingConfig = Get-Content $existingConfigPath -Raw
            
            # Parse existing config to get company name and logo
            $configLines = Get-Content $existingConfigPath
            foreach ($line in $configLines) {
                if ($line -match "^COMPANY_NAME=(.*)$") {
                    $companyName = $matches[1]
                    if ($companyName) {
                        Write-Host "  [X] Nombre de empresa: $companyName" -ForegroundColor Green
                    }
                } elseif ($line -match "^LOGO_PATH=(.*)$") {
                    $logoPath = $matches[1]
                    if ($logoPath) {
                        Write-Host "  [X] Logo personalizado" -ForegroundColor Green
                    }
                }
            }
        } else {
            Write-Host "  [ ] Configuracion (no encontrada)" -ForegroundColor Gray
        }

        if ($structure -eq "v1.0" -and (Test-Path "$installDir\data\suppliers.db")) {
            $existingDbPath = "$installDir\data\suppliers.db"
            $dbSize = (Get-Item $existingDbPath).Length
            $dbSizeKB = [math]::Round($dbSize / 1KB, 2)
            Write-Host "  [X] Base de datos (data\suppliers.db - $dbSizeKB KB)" -ForegroundColor Green
        } elseif (Test-Path "$installDir\proveedores.db") {
            $existingDbPath = "$installDir\proveedores.db"
            $dbSize = (Get-Item $existingDbPath).Length
            $dbSizeKB = [math]::Round($dbSize / 1KB, 2)
            Write-Host "  [X] Base de datos (proveedores.db - $dbSizeKB KB)" -ForegroundColor Green
        } elseif (Test-Path "$installDir\suppliers.db") {
            $existingDbPath = "$installDir\suppliers.db"
            $dbSize = (Get-Item $existingDbPath).Length
            $dbSizeKB = [math]::Round($dbSize / 1KB, 2)
            Write-Host "  [X] Base de datos (suppliers.db - $dbSizeKB KB)" -ForegroundColor Green
        } else {
            Write-Host "  [ ] Base de datos (no encontrada)" -ForegroundColor Gray
        }

        Write-Host ""
        Write-Host "IMPORTANTE: Tus proveedores, productos y pedidos NO se borraran." -ForegroundColor Cyan
        Write-Host ""
        $continueUpgrade = Read-HostDefault "Continuar con la actualizacion? (S/N)" "S"

        if ($continueUpgrade -ne "S" -and $continueUpgrade -ne "s") {
            Write-Host "Actualizacion cancelada." -ForegroundColor Yellow
            Read-HostDefault "Presiona Enter para salir" ""
            exit 0
        }

        Write-Host ""
        Write-Host "[INFO] Creando respaldo de seguridad..." -ForegroundColor Yellow
        $formatted_Date = (Get-Date -Format "yyyyMMdd_HHmmss")
        $backupDir = "$installDir\backup_$formatted_Date"
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

        if ($existingConfigPath) {
            Copy-Item $existingConfigPath "$backupDir\config.ini" -Force
        }
        if ($existingDbPath) {
            Copy-Item $existingDbPath "$backupDir\$([System.IO.Path]::GetFileName($existingDbPath))" -Force
        }

        Write-Host "[OK] Respaldo creado en: $backupDir" -ForegroundColor Green
        Write-Host ""
    } else {
        Write-Host "[OK] Directorio ya existe (vacio)" -ForegroundColor Green
    }
} else {
    try {
        New-Item -ItemType Directory -Path $installDir -Force | Out-Null
        Write-Host "[OK] Directorio creado: $installDir" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] No se pudo crear el directorio." -ForegroundColor Red
        Write-Host "Verifica que tienes permisos o elige otra ubicacion." -ForegroundColor Yellow
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}

# Only ask for company name and logo if this is NOT an upgrade (no existing config)
if (-not $isUpgrade -or -not $existingConfig) {
    # Ask for company name
    $companyName = Read-HostDefault "Nombre de tu empresa (opcional, presiona ENTER para omitir)" ""
    Write-Host ""

    # Ask for logo path
    Write-Host "Logo de la empresa (opcional):" -ForegroundColor White
    Write-Host "Proporciona la ruta a tu logo (PNG/JPG/SVG)" -ForegroundColor Gray
    Write-Host "Si no tienes uno, presiona ENTER para usar el logo por defecto" -ForegroundColor Gray
    Write-Host ""
    $logoPath = Convert-PathInput (Read-HostDefault "Ruta completa al logo (o ENTER para omitir)" "")
    Write-Host ""

    # Validate logo if provided
    if (-not [string]::IsNullOrWhiteSpace($logoPath)) {
        if (-not (Test-Path $logoPath)) {
            Write-Host "[ADVERTENCIA] La ruta del logo no existe. Se usara el logo por defecto." -ForegroundColor Yellow
            $logoPath = ""
            Start-Sleep -Seconds 2
        }
    }
    # Populate $existingValues for summary
    $existingValues = @{}
    $existingValues['company_name'] = $companyName
    $existingValues['logo_path'] = $logoPath
    $existingValues['install_dir'] = $installDir
} else {
    # On upgrade, parse config.ini for summary values
    $existingValues = @{}
    if ($existingConfigPath -and (Test-Path $existingConfigPath)) {
        $configLines = Get-Content $existingConfigPath
        foreach ($line in $configLines) {
            if ($line -match '^\s*([\w_]+)\s*=\s*(.*)$') {
                $key = $matches[1].Trim().ToLower()
                $val = $matches[2].Trim()
                $existingValues[$key] = $val
            }
        }
    }
    # Fallbacks if config values missing
    if (-not $existingValues.ContainsKey('company_name')) { $existingValues['company_name'] = $companyName }
    if (-not $existingValues.ContainsKey('logo_path')) { $existingValues['logo_path'] = $logoPath }
    $existingValues['install_dir'] = $installDir
}

function Get-ConfigValue {
    param(
        [hashtable]$config = @{},
        [string]$key,
        [string]$default = ""
    )
    if ($null -eq $config) { $config = @{} }
    $k = $key.ToLower()
    if ($config.ContainsKey($k) -and -not [string]::IsNullOrWhiteSpace($config[$k])) {
        return $config[$k]
    }
    return $default
}

# Show summary using parsed config values if present
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  RESUMEN DE CONFIGURACION" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Ubicacion:  " -NoNewline -ForegroundColor White
Write-Host "$(Get-ConfigValue $existingValues 'install_dir' $installDir)" -ForegroundColor Yellow

$summaryCompany = Get-ConfigValue $existingValues 'company_name' $companyName
if (-not [string]::IsNullOrWhiteSpace($summaryCompany)) {
    Write-Host "Empresa:    " -NoNewline -ForegroundColor White
    Write-Host "$summaryCompany" -ForegroundColor Yellow
} else {
    Write-Host "Empresa:    " -NoNewline -ForegroundColor White
    Write-Host "[No especificado]" -ForegroundColor Gray
}

$summaryLogo = Get-ConfigValue $existingValues 'logo_path' $logoPath
if (-not [string]::IsNullOrWhiteSpace($summaryLogo)) {
    Write-Host "Logo:       " -NoNewline -ForegroundColor White
    Write-Host "$summaryLogo" -ForegroundColor Yellow
} else {
    Write-Host "Logo:       " -NoNewline -ForegroundColor White
    Write-Host "[Por defecto]" -ForegroundColor Gray
}

Write-Host ""
$confirm = Read-HostDefault "Continuar con la instalacion? (S/N)" "S"

if ($confirm -ne "S" -and $confirm -ne "s") {
    Write-Host "Instalacion cancelada." -ForegroundColor Yellow
    Read-HostDefault "Presiona Enter para salir" ""
    exit 0
}

# Stop any running instances before installation
Stop-RunningApp -InstallPath $installDir

Show-OverallProgress -Step 3 -TotalSteps 11 -Description "Preparando Instalacion"

Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  DESCARGANDO E INSTALANDO SISTEMA" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# Create installation directory (if it doesn't exist)
if (-not (Test-Path $installDir)) {
    try {
        New-Item -ItemType Directory -Path $installDir -Force | Out-Null
        Write-Host "[3.1] Directorio creado: $installDir" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] No se pudo crear el directorio." -ForegroundColor Red
        Write-Host "Verifica que tienes permisos o elige otra ubicacion." -ForegroundColor Yellow
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
} else {
    Write-Host "[3.1] Directorio ya existe" -ForegroundColor Green
}
Write-Host ""

# Check if files are in current directory (automated installation)
$currentDir = Get-Location
write-Host "[INFO] Directorio actual: $currentDir" -ForegroundColor Gray
$parentDir = Split-Path -Parent $currentDir
write-Host "[INFO] Directorio padre: $parentDir" -ForegroundColor Gray

# Check if we're in the installers folder and source files exist in parent directory
$sourceDir = $null
$appDir = $null
$apiDir = $null

# Look for source files in parent directory (where the project root should be)
if (Test-Path "$parentDir\api\app.py") {
    $sourceDir = $parentDir
    $apiDir = "$parentDir\api"
    Write-Host "[INFO] Archivos fuente detectados (estructura v1.0): $sourceDir" -ForegroundColor Cyan
} elseif (Test-Path "$parentDir\app\app.py") {
    $sourceDir = $parentDir
    $appDir = "$parentDir\app"
    Write-Host "[INFO] Archivos fuente detectados (estructura v0.1): $sourceDir" -ForegroundColor Cyan
} elseif (Test-Path "$currentDir\api\app.py") {
    $sourceDir = "$currentDir"
    $apiDir = "$currentDir\api"
    Write-Host "[INFO] Archivos fuente detectados (estructura v1.0): $sourceDir" -ForegroundColor Cyan
} elseif (Test-Path "$currentDir\app\app.py") {
    $sourceDir = "$currentDir"
    $appDir = "$currentDir\app"
    Write-Host "[INFO] Archivos fuente detectados (estructura v0.1): $sourceDir" -ForegroundColor Cyan
} else {
    Write-Host "[ADVERTENCIA] No se encontraron archivos fuente automaticamente" -ForegroundColor Yellow
}

if ($apiDir -or $appDir) {
    $appStructure = if ($apiDir) { "v1.0 (api/)" } else { "v0.1 (app/)" }
    Write-Host "[INFO] Estructura de aplicacion detectada: $appStructure" -ForegroundColor Gray
    
    Show-OverallProgress -Step 4 -TotalSteps 11 -Description "Copiando Archivos del Sistema"
    
    Write-Host "[3.2] Copiando archivos al directorio de instalacion..." -ForegroundColor Yellow
    
    try {
        # Copy application files (handle both v1.0 api/ and v0.1 app/ structures)
        if ($apiDir) {
            # New v1.0 structure with api/ folder
            $appDestDir = Join-Path $installDir "api"
            if (!(Test-Path $appDestDir)) {
                New-Item -ItemType Directory -Path $appDestDir -Force | Out-Null
            }
            Copy-Item -Path "$apiDir\*" -Destination $appDestDir -Recurse -Force
            Write-Host "  [OK] Archivos API (v1.0) copiados a api/" -ForegroundColor Green
            
            # Remove any API files that might have been copied to the root directory
            $apiFiles = @("app.py", "database.py", "models.py", "service_wrapper.py", "init_users.py")
            foreach ($file in $apiFiles) {
                $rootFile = Join-Path $installDir $file
                if (Test-Path $rootFile) {
                    Remove-Item $rootFile -Force -ErrorAction SilentlyContinue
                    Write-Host "  [OK] Archivo $file removido del directorio raiz" -ForegroundColor Green
                }
            }
        } elseif ($appDir) {
            # Old v0.1 structure with app/ folder
            $appDestDir = Join-Path $installDir "app"
            if (!(Test-Path $appDestDir)) {
                New-Item -ItemType Directory -Path $appDestDir -Force | Out-Null
            }
            Copy-Item -Path "$appDir\*" -Destination $appDestDir -Recurse -Force
            Write-Host "  [OK] Archivos APP (v0.1) copiados a app/" -ForegroundColor Green
            
            # For old structure, also copy app.py to root if it exists
            if (Test-Path "$appDir\app.py") {
                Copy-Item -Path "$appDir\app.py" -Destination $installDir -Force
                Write-Host "  [OK] app.py copiado al directorio raiz" -ForegroundColor Green
            }
        }
        
        # Copy root files (requirements.txt, VERSION, LICENSE, etc.)
        $rootFiles = @("requirements.txt", "VERSION", "LICENSE", "LEEME_PRIMERO.txt", "desktop_app.py")
        foreach ($file in $rootFiles) {
            if (Test-Path "$sourceDir\$file") {
                Copy-Item -Path "$sourceDir\$file" -Destination $installDir -Force
                Write-Host "  [OK] $file copiado" -ForegroundColor Green
            }
        }
        
        # Copy additional directories if they exist
        $additionalDirs = @("bin", "config", "scripts", "utilities", "docs", "examples")
        foreach ($dir in $additionalDirs) {
            if (Test-Path "$sourceDir\$dir") {
                Copy-Item -Path "$sourceDir\$dir" -Destination $installDir -Recurse -Force
                Write-Host "  [OK] Directorio $dir copiado" -ForegroundColor Green
            }
        }
        
        Write-Host "[OK] Todos los archivos copiados exitosamente" -ForegroundColor Green
        Write-Host ""
    } catch {
        Write-Host "[ERROR] Error copiando archivos: $($_.Exception.Message)" -ForegroundColor Red
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
} else {
    # Fallback: Try to download from GitHub or show manual instructions
    Write-Host "[INFO] Intentando descarga desde GitHub..." -ForegroundColor Yellow
    Write-Host "[INFO] URL: $GITHUB_RELEASE_URL" -ForegroundColor Gray
    Write-Host ""
    
    try {
        # For now, this will always fail since the URL doesn't exist
        # In the future, uncomment these lines when GitHub releases are set up:
        # Invoke-WebRequest -Uri $GITHUB_RELEASE_URL -OutFile $TEMP_ZIP
        # Expand-Archive -Path $TEMP_ZIP -DestinationPath $installDir -Force
        # Remove-Item $TEMP_ZIP -Force
        
        Write-Host "[ERROR] La descarga automatica aun no esta configurada." -ForegroundColor Red
        Write-Host ""
        Write-Host "Por favor copia manualmente estos archivos a: $installDir" -ForegroundColor Yellow
        Write-Host "  - api/app.py, api/database.py, api/models.py" -ForegroundColor Gray
        Write-Host "  - requirements.txt, VERSION, LICENSE" -ForegroundColor Gray
        Write-Host "  - api/static/ (carpeta completa)" -ForegroundColor Gray
        Write-Host "  - api/templates/ (carpeta completa)" -ForegroundColor Gray
        Write-Host "  - bin/, config/, scripts/, utilities/ (carpetas completas)" -ForegroundColor Gray
        Write-Host ""
        Write-Host "Luego ejecuta este instalador nuevamente." -ForegroundColor Cyan
        Write-Host ""
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    } catch {
        Write-Host "[ERROR] No se pudo descargar: $_" -ForegroundColor Red
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}

# Change to installation directory
Set-Location $installDir

Show-OverallProgress -Step 5 -TotalSteps 11 -Description "Configurando Personalizacion"

# Create or enforce canonical config file
Write-Host "[5.1] Configurando sistema..." -ForegroundColor Yellow

# Always ensure config directory exists
if (-not (Test-Path "config")) {
    New-Item -ItemType Directory -Path "config" -Force | Out-Null
}

# Always enforce canonical config structure
Ensure-CanonicalConfig -filePath "config\config.ini" -companyDefaults $CanonicalConfigKeys -serverDefaults $CanonicalServerKeys
Write-Host ""

# --- PATCH: Robust config migration and DB/migration automation ---
# 1. Parse all config values from previous config.ini and preserve them
function Migrate-ConfigValues {
    param(
        [string]$oldConfigPath,
        [string]$newConfigPath
    )
    if (!(Test-Path $oldConfigPath)) { return }
    $oldLines = Get-Content $oldConfigPath
    $oldValues = @{}
    foreach ($line in $oldLines) {
        if ($line -match '^[\[]') { continue }
        if ($line -match '^(\w+)[ ]*=[ ]*(.*)$') {
            $k = $matches[1].Trim().ToLower()
            $v = $matches[2].Trim()
            $oldValues[$k] = $v
        }
    }
    $newLines = Get-Content $newConfigPath
    $result = @()
    foreach ($line in $newLines) {
        if ($line -match '^(\w+)[ ]*=[ ]*(.*)$') {
            $k = $matches[1].Trim().ToLower()
            if ($oldValues.ContainsKey($k) -and $oldValues[$k] -ne '') {
                $result += "$k=$($oldValues[$k])"
            } else {
                $result += $line
            }
        } else {
            $result += $line
        }
    }
    $result | Out-File -FilePath $newConfigPath -Encoding ASCII
    Write-Host "[OK] Valores de config.ini migrados y preservados" -ForegroundColor Green
}

# If upgrading and previous config exists, migrate values
if ($isUpgrade -and $existingConfigPath -and (Test-Path $existingConfigPath)) {
    Migrate-ConfigValues -oldConfigPath $existingConfigPath -newConfigPath "config\config.ini"
    
    # Remove old config.ini from root directory after successful migration
    if ($existingConfigPath -ne "config\config.ini") {
        Remove-Item $existingConfigPath -Force
        Write-Host "[OK] Configuracion anterior limpiada del directorio raiz" -ForegroundColor Green
    }
}

# If upgrading and previous DB exists, preserve it in the new location
if ($isUpgrade -and $existingDbPath -and (Test-Path $existingDbPath)) {
    $dataDir = "data"
    if (-not (Test-Path $dataDir)) {
        New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
    }
    $newDbPath = "$dataDir\suppliers.db"
    if (-not (Test-Path $newDbPath)) {
        Copy-Item $existingDbPath $newDbPath -Force
        Write-Host "[OK] Base de datos preservada en nueva ubicacion: $newDbPath" -ForegroundColor Green
        
        # Remove old database from root directory after successful migration
        if ($existingDbPath -ne $newDbPath) {
            Remove-Item $existingDbPath -Force
            Write-Host "[OK] Base de datos anterior limpiada del directorio raiz" -ForegroundColor Green
        }
    } else {
        Write-Host "[INFO] Base de datos ya existe en nueva ubicacion" -ForegroundColor Gray
    }
}

# 2. Database operations moved to after dependencies installation
Write-Host "[INFO] Configuracion de personalizacion completada" -ForegroundColor Green
Write-Host ""

# Restore database if upgrading
if ($isUpgrade -and $existingDbPath) {
    Write-Host "[INFO] Restaurando base de datos..." -ForegroundColor Cyan
    # Database file should already be there, just verify
    if (Test-Path $existingDbPath) {
        Write-Host "[OK] Base de datos preservada (sin cambios)" -ForegroundColor Green
    }
    Write-Host ""
}

# Copy logo if provided (only for new installations or if user provided new logo)
if (-not $isUpgrade) {
    if (-not [string]::IsNullOrWhiteSpace($logoPath) -and (Test-Path $logoPath)) {
        Write-Host "[5.2] Copiando logo personalizado..." -ForegroundColor Yellow
        $logoExt = [System.IO.Path]::GetExtension($logoPath)
        Copy-Item -Path $logoPath -Destination "api\static\logo$logoExt" -Force
        Write-Host "[OK] Logo copiado" -ForegroundColor Green
    } else {
        Write-Host "[5.2] Usando logo por defecto..." -ForegroundColor Yellow
        Write-Host "[OK] Logo por defecto configurado" -ForegroundColor Green
    }
} else {
    Write-Host "[5.2] Logo existente preservado..." -ForegroundColor Yellow
    Write-Host "[OK] Logo sin cambios" -ForegroundColor Green
}
Write-Host ""

Show-OverallProgress -Step 6 -TotalSteps 11 -Description "Configurando Entorno Python"

# Create virtual environment
if ($isUpgrade -and (Test-Path "venv")) {
    Write-Host "[6.1] Actualizando entorno virtual..." -ForegroundColor Yellow
    Write-Host "[INFO] Entorno virtual existente detectado" -ForegroundColor Cyan
} else {
    Write-Host "[6.1] Creando entorno virtual..." -ForegroundColor Yellow
    & $pythonCmd -m venv venv
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[ERROR] No se pudo crear el entorno virtual" -ForegroundColor Red
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}
Write-Host "[OK] Entorno virtual creado" -ForegroundColor Green
Write-Host ""

Show-OverallProgress -Step 7 -TotalSteps 11 -Description "Instalando Dependencias"

# Activate and install dependencies
Write-Host "[7.1] Instalando dependencias..." -ForegroundColor Yellow
Write-Host "Este proceso puede tardar 2-5 minutos..." -ForegroundColor Gray
Write-Host ""

& .\venv\Scripts\Activate.ps1

$pythonCmd = Join-Path $installDir "venv\Scripts\python.exe"

Write-Host "[INFO] Actualizando pip..." -ForegroundColor Cyan
& $pythonCmd -m pip install --upgrade pip --quiet 2>&1 | Out-Null
Write-Host "[OK] pip actualizado" -ForegroundColor Green
Write-Host ""

Write-Host "[INFO] Leyendo requirements.txt..." -ForegroundColor Cyan
$requirements = Get-Content (Join-Path $installDir "requirements.txt") | Where-Object { $_ -notmatch "^\s*#" -and $_ -notmatch "^\s*$" }
$totalPackages = $requirements.Count
Write-Host "[INFO] Paquetes a instalar: $totalPackages" -ForegroundColor Cyan
Write-Host ""

# Install packages one by one to show progress
$installedCount = 0
foreach ($package in $requirements) {
    $installedCount++
    $packageName = $package -replace '[>=<].*', ''
    $percent = [math]::Floor(($installedCount / $totalPackages) * 100)
    
    Write-Host "[$installedCount/$totalPackages] Instalando $packageName..." -NoNewline -ForegroundColor Cyan
    
    $result = & $pythonCmd -m pip install $package --quiet 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host " [OK]" -ForegroundColor Green
    } else {
        Write-Host " [ERROR]" -ForegroundColor Red
        Write-Host "Detalles: $result" -ForegroundColor Yellow
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}

Write-Host ""
Write-Host "[OK] Dependencias instaladas" -ForegroundColor Green
Write-Host ""

# Verify installation
Write-Host "[Verificando instalacion...]" -ForegroundColor Yellow

$modulesToVerify = @("flask", "flask_cors", "flask_login", "sqlalchemy", "pandas", "openpyxl", "pymysql", "dotenv", "webview")
$verifiedCount = 0
foreach ($module in $modulesToVerify) {
    $verifiedCount++
    Write-Host "[$verifiedCount/$($modulesToVerify.Count)] Verificando $module..." -NoNewline -ForegroundColor Cyan
    
    $checkResult = & $pythonCmd -c "import $module" 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host " [OK]" -ForegroundColor Green
    } else {
        Write-Host " [ERROR]" -ForegroundColor Red
        Write-Host "Fallo la verificacion de $module" -ForegroundColor Red
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}

Write-Host "[OK] Verificacion completa" -ForegroundColor Green
Write-Host ""

Show-OverallProgress -Step 8 -TotalSteps 11 -Description "Configurando Base de Datos y Datos"

# Run user initialization, data migration, contacts migration, and audit columns in order
Write-Host "[8.1] Ejecutando scripts de migracion y datos..." -ForegroundColor Yellow
# Use absolute path for scripts directory
$scriptsDir = Join-Path $installDir "scripts"
$apiDir = Join-Path $installDir "api"

# Initialize complete database schema first
Write-Host "[INFO] Inicializando esquema completo de base de datos..." -ForegroundColor Gray
Push-Location $apiDir
& $pythonCmd -c "
from database import init_db, engine
from models import Base
init_db()
Base.metadata.create_all(bind=engine)
print('Esquema completo de base de datos inicializado')
"
Pop-Location

# Create users table and default admin
Write-Host "[INFO] Creando tabla de usuarios..." -ForegroundColor Gray
Push-Location $apiDir
& $pythonCmd init_users.py
Pop-Location

# Add audit columns to all tables
Write-Host "[INFO] Agregando columnas de auditoria..." -ForegroundColor Gray
Push-Location $scriptsDir
& $pythonCmd add_who_columns.py
Pop-Location

# Migrate supplier contact data
Write-Host "[INFO] Migrando datos de contactos..." -ForegroundColor Gray
Push-Location $scriptsDir
& $pythonCmd migrate_supplier_contacts.py
Pop-Location

# Clean up any duplicate contacts created during migration
Write-Host "[INFO] Limpiando contactos duplicados..." -ForegroundColor Gray
Push-Location $scriptsDir
& $pythonCmd cleanup_duplicate_contacts.py --apply
Pop-Location

# Run additional migrations for fresh installs
if (-not $isUpgrade) {
    Write-Host "[INFO] Ejecutando migraciones adicionales..." -ForegroundColor Gray
    Push-Location $scriptsDir
    & $pythonCmd migrate_database.py
    Pop-Location
} else {
    Write-Host "[INFO] Saltando migraciones adicionales (upgrade preservando datos)" -ForegroundColor Gray
}

Write-Host "[OK] Migraciones y datos aplicados" -ForegroundColor Green
Write-Host ""

Show-OverallProgress -Step 9 -TotalSteps 11 -Description "Finalizando Instalacion"

# Check if database already exists (from preservation or previous operations)
$dbPath = "data\suppliers.db"
if (Test-Path $dbPath) {
    Write-Host "[INFO] Base de datos existente detectada en $dbPath" -ForegroundColor Cyan
    Write-Host "[OK] Saltando inicializacion (base de datos ya existe)" -ForegroundColor Green
    Write-Host ""
    if ($isUpgrade) {
        Write-Host "IMPORTANTE: Tus proveedores, productos y pedidos estan intactos." -ForegroundColor Green
        Write-Host ""
    }
} else {
    Write-Host "[9.1] Inicializando base de datos..." -ForegroundColor Yellow
    Push-Location (Join-Path $installDir "api")
    & $pythonCmd -c "from database import init_db; init_db(); print('Base de datos creada')"
    Pop-Location
    Write-Host ""
}

# Schema updates handled in Step 8
Write-Host "[INFO] Esquema de base de datos actualizado en paso anterior" -ForegroundColor Gray
Write-Host ""

# Create start script
Write-Host "[9.2] Creando scripts de inicio..." -ForegroundColor Yellow

# Remove unused installer copy in bin
if (Test-Path "bin\INSTALAR.bat") {
    Remove-Item "bin\INSTALAR.bat" -Force -ErrorAction SilentlyContinue
}

# Remove obsolete root start.bat if present
if (Test-Path "start.bat") {
    Remove-Item "start.bat" -Force -ErrorAction SilentlyContinue
}

# Create new start.bat that calls bin\run.bat
@"
@echo off
REM Sistema de Proveedores - Start Script
echo Starting Sistema de Proveedores...
call "%~dp0bin\run.bat"
"@ | Out-File -FilePath "start.bat" -Encoding ASCII
Write-Host "[OK] Script 'start.bat' creado/actualizado" -ForegroundColor Green

# Remove old root run.bat if present
if (Test-Path "run.bat") {
    Remove-Item "run.bat" -Force -ErrorAction SilentlyContinue
}
Write-Host "================================================================" -ForegroundColor Green
if ($isUpgrade) {
    Write-Host "  ACTUALIZACION COMPLETADA EXITOSAMENTE!" -ForegroundColor Green
} else {
    Write-Host "  INSTALACION COMPLETADA EXITOSAMENTE!" -ForegroundColor Green
}
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""

if ($isUpgrade) {
    Write-Host "[ACTUALIZACION COMPLETADA]" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Version actualizada a: " -NoNewline -ForegroundColor White
    Write-Host "$VERSION" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Datos preservados:" -ForegroundColor Green
    Write-Host "  [X] Configuracion de la empresa" -ForegroundColor Green
    Write-Host "  [X] Base de datos (proveedores, productos, pedidos)" -ForegroundColor Green
    Write-Host "  [X] Logo personalizado" -ForegroundColor Green
    Write-Host ""
    if (Test-Path "$installDir\backup_*") {
        $backupFolder = Get-ChildItem "$installDir\backup_*" | Select-Object -Last 1
        Write-Host "Respaldo creado en: " -NoNewline -ForegroundColor White
        Write-Host "$($backupFolder.Name)" -ForegroundColor Gray
        Write-Host ""
    }
}

if (-not [string]::IsNullOrWhiteSpace($companyName)) {
    Write-Host "Instalacion personalizada para: " -NoNewline -ForegroundColor White
    Write-Host "$companyName" -ForegroundColor Cyan
    Write-Host ""
}

Write-Host "Ubicacion: " -NoNewline -ForegroundColor White
Write-Host "$installDir" -ForegroundColor Yellow
Write-Host ""

# Check if auto-start was configured and show appropriate instructions
$startupShortcut = Join-Path ([Environment]::GetFolderPath("Startup")) "Sistema Proveedores.lnk"
$autoStartConfigured = Test-Path $startupShortcut

if ($autoStartConfigured) {
    Write-Host "Modo de ejecucion: " -NoNewline -ForegroundColor White
    Write-Host "Inicio Automatico (Minimizado)" -ForegroundColor Green
    Write-Host ""
    Write-Host "El sistema se inicia automaticamente con Windows." -ForegroundColor Gray
    Write-Host "La aplicacion se ejecuta minimizada en segundo plano." -ForegroundColor Gray
    Write-Host ""
    Write-Host "Para gestionar:" -ForegroundColor White
    Write-Host "  • Usa los accesos directos del escritorio" -ForegroundColor Gray
    Write-Host "  • O accede desde el navegador: http://localhost:5000" -ForegroundColor Gray
    Write-Host "  • La aplicacion de escritorio se conecta automaticamente al servicio" -ForegroundColor Gray
} else {
    Write-Host "Modo de ejecucion: " -NoNewline -ForegroundColor White
    Write-Host "Manual" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Para iniciar el sistema:" -ForegroundColor White
    Write-Host "  1. Ejecuta " -NoNewline -ForegroundColor Gray
    Write-Host "start.bat " -NoNewline -ForegroundColor Yellow
    Write-Host "en: $installDir" -ForegroundColor Gray
    Write-Host "  2. O usa el acceso directo del escritorio (si lo creaste)" -ForegroundColor Gray
}

Write-Host ""
Write-Host "Aplicacion de escritorio disponible." -ForegroundColor White
Write-Host "Tambien puedes acceder via navegador en: " -NoNewline -ForegroundColor Gray
Write-Host "http://localhost:5000" -ForegroundColor Yellow
Write-Host ""
Write-Host "Documentacion completa: README.md" -ForegroundColor Gray
Write-Host ""

# ============================================================
# STEP 10: Automatic Startup Configuration
# ============================================================
Show-OverallProgress -Step 10 -TotalSteps 11 -Description "Configuracion de Inicio Automatico"

Write-Host ""
Write-Host "--------------------------------------------------------------" -ForegroundColor Cyan
Write-Host "  CONFIGURACION DE INICIO AUTOMATICO" -ForegroundColor Cyan
Write-Host "--------------------------------------------------------------" -ForegroundColor Cyan
Write-Host ""

Write-Host "El sistema puede iniciarse automaticamente con Windows:" -ForegroundColor White
Write-Host "  • Se inicia automaticamente al encender la PC" -ForegroundColor Gray
Write-Host "  • Se ejecuta minimizado en segundo plano" -ForegroundColor Gray
Write-Host "  • Puedes acceder desde la bandeja del sistema o navegador" -ForegroundColor Gray
Write-Host ""

$setupAutoStart = (Read-HostDefault "Agregar al inicio automatico de Windows? (S/N): " "S") -in @("S", "s")

if ($setupAutoStart) {
    Write-Host ""
    Write-Host "[9.1] Configurando inicio automatico..." -ForegroundColor Yellow

    try {
        # Create startup shortcut
        $startupFolder = [Environment]::GetFolderPath("Startup")
        $startupShortcut = Join-Path $startupFolder "Sistema Proveedores.lnk"

        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut($startupShortcut)
        $Shortcut.TargetPath = "$installDir\bin\run.bat"
        $Shortcut.WorkingDirectory = $installDir
        $Shortcut.Description = "Sistema de Gestion de Proveedores (Inicio Automatico)"
        $Shortcut.WindowStyle = 7  # Minimized
        $Shortcut.Save()

        Write-Host "[OK] Aplicacion agregada al inicio automatico de Windows" -ForegroundColor Green
        Write-Host "[INFO] La aplicacion se iniciara minimizada al encender la PC" -ForegroundColor Cyan
        Write-Host ""

        # Ask if user wants to start now
        $startNow = (Read-HostDefault "Iniciar la aplicacion ahora? (S/N): " "S") -in @("S", "s")

        if ($startNow) {
            Write-Host "[9.2] Iniciando aplicacion..." -ForegroundColor Yellow
            try {
                # Kill any running Python processes related to the app
                $pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
                    $_.CommandLine -like "*app.py*" -or $_.CommandLine -like "*desktop_app.py*" -or $_.CommandLine -like "*SistemaProveedores*"
                }
                if ($pythonProcesses) {
                    Write-Host "[INFO] Terminando procesos Python existentes..." -ForegroundColor Gray
                    foreach ($process in $pythonProcesses) {
                        try {
                            Stop-Process -Id $process.Id -Force -ErrorAction Stop
                            Write-Host "[INFO] Proceso terminado: $($process.Id)" -ForegroundColor Gray
                        } catch {
                            Write-Host "[ADVERTENCIA] No se pudo terminar proceso $($process.Id): $($_.Exception.Message)" -ForegroundColor Yellow
                        }
                    }
                    Start-Sleep -Seconds 2
                }

                # Remove any existing lock file to allow the app to start
                $lockFile = Join-Path $env:TEMP "proveedores_desktop_app.lock"
                if (Test-Path $lockFile) {
                    Remove-Item $lockFile -Force -ErrorAction SilentlyContinue
                    Write-Host "[INFO] Lock file removido para permitir inicio" -ForegroundColor Gray
                }
                $runBat = Join-Path $installDir "bin\run.bat"
                Start-Process -FilePath $runBat -WorkingDirectory $installDir -WindowStyle Minimized
                
                # Wait a moment for the process to start
                Start-Sleep -Seconds 3
                
                # Verify the application actually started
                $appStarted = $false
                $pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
                    $_.CommandLine -like "*desktop_app.py*"
                }
                
                if ($pythonProcesses) {
                    Write-Host "[OK] Aplicacion iniciada correctamente" -ForegroundColor Green
                    Write-Host "[INFO] La aplicacion esta ejecutandose minimizada" -ForegroundColor Cyan
                    Write-Host "[INFO] Accede desde: http://localhost:5000" -ForegroundColor Cyan
                    $appStarted = $true
                } else {
                    Write-Host "[ADVERTENCIA] La aplicacion no pudo iniciarse correctamente" -ForegroundColor Yellow
                    Write-Host "[INFO] Puedes iniciarla manualmente desde el acceso directo del escritorio" -ForegroundColor Gray
                }
            } catch {
                Write-Host "[ADVERTENCIA] Error al iniciar la aplicacion: $($_.Exception.Message)" -ForegroundColor Yellow
                Write-Host "[INFO] Puedes iniciarla manualmente desde el acceso directo" -ForegroundColor Gray
            }
        } else {
            Write-Host "[INFO] Aplicacion configurada para inicio automatico" -ForegroundColor Gray
            Write-Host "[INFO] Se iniciara automaticamente en el proximo reinicio" -ForegroundColor Gray
        }

    } catch {
        Write-Host "[ADVERTENCIA] No se pudo configurar el inicio automatico: $($_.Exception.Message)" -ForegroundColor Yellow
        Write-Host "[INFO] Puedes configurar el inicio automatico manualmente:" -ForegroundColor Gray
        Write-Host "  1. Presiona Win+R, escribe 'shell:startup'" -ForegroundColor Gray
        Write-Host "  2. Crea un acceso directo a '$installDir\bin\run.bat'" -ForegroundColor Gray
    }
} else {
    Write-Host "[INFO] Inicio automatico no configurado" -ForegroundColor Cyan
    Write-Host "[INFO] La aplicacion se ejecutara solo manualmente" -ForegroundColor Gray
}

# ============================================================
# STEP 11: Windows Service Installation (Optional)
# ============================================================
Show-OverallProgress -Step 11 -TotalSteps 11 -Description "Instalacion de Servicio Windows"

Write-Host ""
Write-Host "--------------------------------------------------------------" -ForegroundColor Cyan
Write-Host "  INSTALACION DE SERVICIO WINDOWS (OPCIONAL)" -ForegroundColor Cyan
Write-Host "--------------------------------------------------------------" -ForegroundColor Cyan
Write-Host ""

Write-Host "El servicio de Windows permite:" -ForegroundColor White
Write-Host "  • Ejecucion invisible en segundo plano" -ForegroundColor Gray
Write-Host "  • Inicio automatico al encender la PC" -ForegroundColor Gray
Write-Host "  • Acceso desde otros dispositivos en la red" -ForegroundColor Gray
Write-Host "  • Mayor estabilidad y recuperacion automatica" -ForegroundColor Gray
Write-Host ""

$installService = (Read-HostDefault "Instalar servicio de Windows? (S/N): " "N") -in @("S", "s")

if ($installService) {
    Write-Host ""
    Write-Host "[10.1] Instalando servicio de Windows..." -ForegroundColor Yellow

    try {
        # Check if running as administrator
        $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

        if (-not $isAdmin) {
            Write-Host "[ADVERTENCIA] Se requieren permisos de administrador para instalar servicios" -ForegroundColor Yellow
            Write-Host "[INFO] El instalador intentara elevar privilegios automaticamente..." -ForegroundColor Gray
        }

        # Run service installation from the target install directory
        $serviceScript = Join-Path $installDir "utilities\service\service.ps1"

        if (Test-Path $serviceScript) {
            Write-Host "[INFO] Ejecutando instalacion de servicio..." -ForegroundColor Gray

            # Run service installation with elevated privileges if needed
            $serviceArgs = "-Action install -ProjectRoot `"$installDir`""
            $process = Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$serviceScript`" $serviceArgs" -Verb RunAs -Wait -PassThru

            if ($process.ExitCode -eq 0) {
                Write-Host "[OK] Servicio de Windows instalado correctamente" -ForegroundColor Green
                Write-Host "[INFO] El servicio se iniciara automaticamente al reiniciar" -ForegroundColor Cyan

                # Ask if user wants to start the service now
                $startServiceNow = (Read-HostDefault "Iniciar el servicio ahora? (S/N): " "S") -in @("S", "s")

                if ($startServiceNow) {
                    Write-Host "[10.2] Iniciando servicio..." -ForegroundColor Yellow
                    try {
                        $startArgs = "-Action start -ProjectRoot `"$installDir`""
                        $startProcess = Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$serviceScript`" $startArgs" -Verb RunAs -Wait -PassThru

                        if ($startProcess.ExitCode -eq 0) {
                            Write-Host "[OK] Servicio iniciado correctamente" -ForegroundColor Green
                            Write-Host "[INFO] Acceso web: http://localhost:5000" -ForegroundColor Cyan
                            Write-Host "[INFO] Acceso red: http://$($env:COMPUTERNAME):5000" -ForegroundColor Cyan
                        } else {
                            Write-Host "[ADVERTENCIA] Error al iniciar servicio (codigo: $($startProcess.ExitCode))" -ForegroundColor Yellow
                        }
                    } catch {
                        Write-Host "[ADVERTENCIA] Error al iniciar servicio: $($_.Exception.Message)" -ForegroundColor Yellow
                    }
                }
            } else {
                Write-Host "[ERROR] Fallo en la instalacion del servicio (codigo: $($process.ExitCode))" -ForegroundColor Red
                Write-Host "[INFO] Puedes intentar instalar el servicio manualmente mas tarde:" -ForegroundColor Gray
                Write-Host "  utilities\service\service.ps1 -Action install" -ForegroundColor Gray
            }
        } else {
            Write-Host "[ERROR] Script de servicio no encontrado: $serviceScript" -ForegroundColor Red
        }

    } catch {
        Write-Host "[ERROR] Error durante instalacion del servicio: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "[INFO] Servicio de Windows no instalado" -ForegroundColor Cyan
    Write-Host "[INFO] La aplicacion funcionara en modo escritorio" -ForegroundColor Gray
}

# Create desktop shortcuts for application and web access
Write-Host ""
Write-Host "Configurando directorios de aplicacion..." -ForegroundColor Yellow

# Ensure logs directory exists for desktop app logging
if (-not (Test-Path "logs")) {
    New-Item -ItemType Directory -Path "logs" -Force | Out-Null
    Write-Host "[OK] Directorio logs creado" -ForegroundColor Green
} else {
    Write-Host "[OK] Directorio logs ya existe" -ForegroundColor Green
}

Write-Host ""
Write-Host "Configurando accesos directos..." -ForegroundColor Yellow

$createAppShortcut = (Read-HostDefault "Deseas crear/actualizar acceso directo de la aplicacion? (S/N): " "S") -in @("S", "s")
if ($createAppShortcut) {
    $desktop = @([Environment]::GetFolderPath("Desktop"))[0]
    $oldLinks = @(
        (Join-Path $desktop "Sistema Proveedores.lnk")
        (Join-Path $desktop "Sistema de Proveedores.lnk")
    )
    foreach ($link in $oldLinks) {
        if (Test-Path $link) { Remove-Item $link -Force -ErrorAction SilentlyContinue }
    }

    if (New-DesktopShortcut -Name "Sistema Proveedores" -TargetPath "$installDir\bin\run.bat" -WorkingDirectory $installDir -Description "Sistema de Gestion de Proveedores (Inicio Manual)" -WindowStyle 7) {
        Write-Host "[OK] Acceso directo de la aplicacion creado/actualizado" -ForegroundColor Green
    } else {
        Write-Host "[ADVERTENCIA] No se pudo crear el acceso directo de la aplicacion" -ForegroundColor Yellow
        Write-Host "[INFO] Puedes crear uno manualmente mas tarde" -ForegroundColor Gray
    }
}

$createWebShortcut = (Read-HostDefault "Deseas crear/actualizar acceso directo de la web? (S/N): " "S") -in @("S", "s")
if ($createWebShortcut) {
    $desktop = @([Environment]::GetFolderPath("Desktop"))[0]
    $webShortcut = Join-Path $desktop "Sistema Proveedores - Web.url"
    @(
        "[InternetShortcut]",
        "URL=http://localhost:5000/login"
    ) | Out-File -FilePath $webShortcut -Encoding ASCII -Force
    Write-Host " [OK] Acceso directo web creado/actualizado" -ForegroundColor Green
}

# Create utility shortcuts in utilities folder
Write-Host ""
Write-Host "Creando accesos directos en carpeta de utilidades..." -ForegroundColor Yellow

$utilitiesDir = Join-Path $installDir "utilities"
if (Test-Path $utilitiesDir) {
    # Service management shortcuts
    $serviceScript = Join-Path $utilitiesDir "service\service.ps1"
    if (Test-Path $serviceScript) {
        # Service status shortcut
        $statusShortcut = Join-Path $utilitiesDir "Servicio - Estado.lnk"
        New-UtilityShortcut -ShortcutPath $statusShortcut -TargetPath "powershell.exe" -Arguments "-ExecutionPolicy Bypass -File `"$serviceScript`" -Action status" -WorkingDirectory $installDir -Description "Ver estado del servicio de Windows"

        # Service start shortcut
        $startShortcut = Join-Path $utilitiesDir "Servicio - Iniciar.lnk"
        New-UtilityShortcut -ShortcutPath $startShortcut -TargetPath "powershell.exe" -Arguments "-ExecutionPolicy Bypass -File `"$serviceScript`" -Action start" -WorkingDirectory $installDir -Description "Iniciar servicio de Windows"

        # Service stop shortcut
        $stopShortcut = Join-Path $utilitiesDir "Servicio - Detener.lnk"
        New-UtilityShortcut -ShortcutPath $stopShortcut -TargetPath "powershell.exe" -Arguments "-ExecutionPolicy Bypass -File `"$serviceScript`" -Action stop" -WorkingDirectory $installDir -Description "Detener servicio de Windows"

        Write-Host "[OK] Accesos directos de gestion de servicio creados" -ForegroundColor Green
    }

    # Database cleanup shortcut
    $cleanupScript = Join-Path $utilitiesDir "cleanup_database.bat"
    if (Test-Path $cleanupScript) {
        $cleanupShortcut = Join-Path $utilitiesDir "Limpiar Base de Datos.lnk"
        New-UtilityShortcut -ShortcutPath $cleanupShortcut -TargetPath $cleanupScript -WorkingDirectory $installDir -Description "Limpiar y optimizar base de datos"
        Write-Host "[OK] Acceso directo de limpieza de BD creado" -ForegroundColor Green
    }

    # Load sample data shortcut
    $sampleScript = Join-Path $utilitiesDir "load_sample_data.bat"
    if (Test-Path $sampleScript) {
        $sampleShortcut = Join-Path $utilitiesDir "Cargar Datos de Muestra.lnk"
        New-UtilityShortcut -ShortcutPath $sampleShortcut -TargetPath $sampleScript -WorkingDirectory $installDir -Description "Cargar datos de muestra en el sistema"
        Write-Host "[OK] Acceso directo de datos de muestra creado" -ForegroundColor Green
    }

    Write-Host "[OK] Accesos directos de utilidades creados en: $utilitiesDir" -ForegroundColor Green
} else {
    Write-Host "[INFO] Carpeta de utilidades no encontrada, omitiendo accesos directos" -ForegroundColor Gray
}

# Copy uninstall scripts to utilities directory for easy access
Write-Host "[INFO] Copiando scripts de desinstalacion..." -ForegroundColor Yellow
$installerDir = Split-Path $MyInvocation.MyCommand.Path -Parent
$uninstallScript = Join-Path $installerDir "uninstall.ps1"
$uninstallBatch = Join-Path $installerDir "uninstall.bat"

# Clean up any old copies in root directory
$oldUninstallBatch = Join-Path $installDir "uninstall.bat"
if (Test-Path $oldUninstallBatch) {
    Remove-Item $oldUninstallBatch -Force
    Write-Host "[OK] Version anterior de uninstall.bat limpiada del directorio raiz" -ForegroundColor Green
}

if (Test-Path $uninstallScript) {
    Copy-Item $uninstallScript $utilitiesDir -Force
    Write-Host "[OK] Script de desinstalacion copiado: uninstall.ps1" -ForegroundColor Green
} else {
    Write-Host "[ADVERTENCIA] Script de desinstalacion no encontrado: $uninstallScript" -ForegroundColor Yellow
}

if (Test-Path $uninstallBatch) {
    Copy-Item $uninstallBatch $utilitiesDir -Force
    Write-Host "[OK] Batch de desinstalacion copiado: uninstall.bat" -ForegroundColor Green
    
    # Create uninstaller shortcut
    $uninstallShortcut = Join-Path $utilitiesDir "Desinstalar Proveedores.lnk"
    New-UtilityShortcut -ShortcutPath $uninstallShortcut -TargetPath (Join-Path $utilitiesDir "uninstall.bat") -WorkingDirectory $installDir -Description "Desinstalar completamente Proveedores"
    Write-Host "[OK] Acceso directo de desinstalacion creado" -ForegroundColor Green
} else {
    Write-Host "[ADVERTENCIA] Batch de desinstalacion no encontrado: $uninstallBatch" -ForegroundColor Yellow
}

Write-Host ""
Write-Host ""

# Stop logging
Stop-Transcript
Write-Host "--------------------------------------------------------------" -ForegroundColor DarkGreen
Write-Host " PROGRESO: [==================================================] 100%" -ForegroundColor Green
Write-Host "--------------------------------------------------------------" -ForegroundColor DarkGreen
Write-Host ""

Write-Host ""
Read-HostDefault "Presiona Enter para finalizar" ""

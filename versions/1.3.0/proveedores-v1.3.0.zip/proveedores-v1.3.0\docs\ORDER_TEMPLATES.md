# Order Template System

## Overview
The order printing system now uses **server-side HTML templates** with placeholder syntax. Templates are stored as HTML files in the `config/` directory and rendered by the backend.

## Template Locations

### Spanish Template
**File:** `proveedores/config/order_template_esp.html`

### English Template  
**File:** `proveedores/config/order_template_eng.html`

## Configuration

Template paths are stored in `config/config.ini`:

```ini
ORDER_TEMPLATE_ESP=config/order_template_esp.html
ORDER_TEMPLATE_ENG=config/order_template_eng.html
```

You can change these paths to point to custom templates anywhere in your project.

## Placeholder Syntax

Templates use `##placeholder##` syntax that gets replaced with actual data:

### Available Placeholders

| Placeholder | Description | Example Output |
|------------|-------------|----------------|
| `##letterhead##` | Company logo + name | `<img src="..."><div><h1>Company Name</h1></div>` |
| `##order_number##` | Order number | `ORD-001` |
| `##status##` | Order status (lowercase) | `pending` |
| `##status_label##` | Translated status label | `Pendiente` / `Pending` |
| `##supplier_name##` | Supplier name | `Acme Corp` |
| `##order_date##` | Order date (YYYY-MM-DD) | `2026-02-05` |
| `##delivery_date##` | Delivery date or "N/A" | `2026-02-15` |
| `##payment_terms##` | Payment terms or "N/A" | `Net 30` |
| `##items_rows##` | Generated table rows for items | `<tr><td>...</td></tr>` |
| `##sku_header##` | SKU column header (changes by mode) | `SKU Interno` / `Vendor SKU` |
| `##price_header##` | Price column header (or empty for vendor) | `<th>Precio</th>` |
| `##total_section##` | Total amount (or empty for vendor) | `<div class="total">Total: $500.00</div>` |
| `##notes_section##` | Notes section with styling (or empty) | `<div class="notes-section">...</div>` |

### Conditional Sections

Some placeholders are conditionally populated based on print mode:

- **Vendor Mode** (`mode=vendor`): Prices are hidden
  - `##price_header##` → empty string
  - `##total_section##` → empty string
  - Items don't include price column

- **Internal Mode** (`mode=internal`): All prices shown
  - `##price_header##` → `<th>Precio</th>` (Spanish) or `<th>Price</th>` (English)
  - `##total_section##` → Full total section with amount
  - Items include price column

## Item Format

The system expects items in the order to be formatted as pipe-separated values:

```
ID|Name|Quantity|Price
```

Example:
```
001|Widget A|10|$5.00
002|Widget B|5|$10.00
```

The backend automatically parses these and generates table rows.

## How to Customize Templates

### 1. Basic Structure
Keep the basic HTML structure:
```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Order ##order_number##</title>
    <style>
        /* Your CSS here */
    </style>
</head>
<body>
    <!-- Your template here -->
</body>
</html>
```

### 2. Add Your Placeholders
Use placeholders anywhere in the HTML:
```html
<div class="header">
    ##letterhead##
</div>

<div class="info">
    <p>Order: ##order_number##</p>
    <p>Supplier: ##supplier_name##</p>
    <p>Date: ##order_date##</p>
</div>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Qty</th>
            ##price_header##
        </tr>
    </thead>
    <tbody>
        ##items_rows##
    </tbody>
</table>

##notes_section##
##total_section##
```

### 3. Custom Styling
All CSS is embedded in the `<style>` section. Modify colors, fonts, layouts as needed.

### 4. Testing Your Template
After editing a template:
1. Save the file
2. Restart the Flask server (or it will auto-reload in debug mode)
3. Print an order to see the changes
4. Use browser dev tools to inspect the generated HTML

## API Endpoint

The print endpoint is:
```
GET /api/orders/<order_id>/print?mode=<mode>&lang=<lang>
```

Parameters:
- `mode`: `internal` (default) or `vendor`
- `lang`: `esp` (default) or `eng`

Example:
```
http://localhost:5000/api/orders/1/print?mode=vendor&lang=eng
```

## Simple Template Example

Here's a minimal template to get you started:

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Order ##order_number##</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .header { border-bottom: 2px solid #333; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
    </style>
</head>
<body>
    <div class="header">
        ##letterhead##
    </div>
    
    <h1>PURCHASE ORDER ##order_number##</h1>
    
    <p><strong>Supplier:</strong> ##supplier_name##</p>
    <p><strong>Date:</strong> ##order_date##</p>
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Item</th>
                <th>Quantity</th>
                ##price_header##
            </tr>
        </thead>
        <tbody>
            ##items_rows##
        </tbody>
    </table>
    
    ##notes_section##
    ##total_section##
</body>
</html>
```

## Notes
- Templates are processed on the server, not the client
- Logo is embedded as base64 data URI for portability
- All paths in config.ini are relative to project root
- The system automatically handles language-specific labels (status, headers, etc.)

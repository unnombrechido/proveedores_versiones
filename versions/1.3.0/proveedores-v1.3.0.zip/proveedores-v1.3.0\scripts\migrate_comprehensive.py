#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comprehensive Database Migration Tool
Migrates from old suppliers.db structure to new v1.3.0 structure

Old structure: suppliers with contact_person, email, phone
New structure: suppliers + separate supplier_contacts table, plus who columns
"""

import sqlite3
import os
import sys
from datetime import datetime
from pathlib import Path

def create_new_database(db_path):
    """Create new database with current schema"""
    print("Creating new database with current schema...")

    # Import here to avoid issues if modules not available
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from api.database import init_db
    from api.models import Base, engine

    # Set the database path
    os.environ['DATABASE_URL'] = f'sqlite:///{db_path}'

    # Initialize database
    init_db()
    print(f"[OK] New database created at {db_path}")

def add_who_columns(db_path):
    """Add created_by and updated_by columns to tables"""
    print("Adding audit columns...")

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    tables = ['items', 'suppliers', 'supplier_items', 'orders', 'users']

    for table in tables:
        # Check existing columns
        cursor.execute(f"PRAGMA table_info({table})")
        columns = [row[1] for row in cursor.fetchall()]

        if 'created_by' not in columns:
            cursor.execute(f"ALTER TABLE {table} ADD COLUMN created_by INTEGER REFERENCES users(id)")
            print(f"  Added created_by to {table}")

        if 'updated_by' not in columns:
            cursor.execute(f"ALTER TABLE {table} ADD COLUMN updated_by INTEGER REFERENCES users(id)")
            print(f"  Added updated_by to {table}")

    conn.commit()
    conn.close()
    print("[OK] Audit columns added")

def create_supplier_contacts_table(db_path):
    """Create supplier_contacts table"""
    print("Creating supplier_contacts table...")

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE supplier_contacts (
            id INTEGER PRIMARY KEY,
            supplier_id INTEGER NOT NULL,
            contact_name VARCHAR(200) NOT NULL,
            position VARCHAR(100),
            phone VARCHAR(50),
            email VARCHAR(200),
            is_primary INTEGER DEFAULT 0,
            contact_type VARCHAR(50) DEFAULT 'general',
            notes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by INTEGER,
            updated_by INTEGER,
            FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
            FOREIGN KEY (created_by) REFERENCES users(id),
            FOREIGN KEY (updated_by) REFERENCES users(id)
        )
    """)

    conn.commit()
    conn.close()
    print("[OK] supplier_contacts table created")

def migrate_supplier_contacts(db_path):
    """Migrate contact data from suppliers to supplier_contacts"""
    print("Migrating supplier contact data...")

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Get all suppliers
    cursor.execute("SELECT id, contact_person, email, phone FROM suppliers")
    suppliers = cursor.fetchall()

    for supplier_id, contact_person, email, phone in suppliers:
        contacts_created = 0

        # Create contact from contact_person (primary)
        if contact_person and contact_person.strip():
            cursor.execute("""
                INSERT INTO supplier_contacts
                (supplier_id, contact_name, position, phone, email, is_primary, contact_type)
                VALUES (?, ?, ?, ?, ?, 1, 'general')
            """, (supplier_id, contact_person.strip(), 'Contacto Principal', phone, email))
            contacts_created += 1

        # If no contact_person but have email/phone, create generic contact
        elif (email and email.strip()) or (phone and phone.strip()):
            cursor.execute("""
                INSERT INTO supplier_contacts
                (supplier_id, contact_name, phone, email, is_primary, contact_type)
                VALUES (?, ?, ?, ?, 1, 'general')
            """, (supplier_id, 'Contacto', phone, email))
            contacts_created += 1

        print(f"  Supplier {supplier_id}: {contacts_created} contacts created")

    conn.commit()
    conn.close()
    print("[OK] Supplier contacts migrated")

def migrate_data(old_db_path, new_db_path):
    """Migrate data from old database to new database"""
    print("Migrating data from old database...")

    if not os.path.exists(old_db_path):
        print(f"[ERROR] Old database not found: {old_db_path}")
        return False

    old_conn = sqlite3.connect(old_db_path)
    new_conn = sqlite3.connect(new_db_path)

    old_cursor = old_conn.cursor()
    new_cursor = new_conn.cursor()

    # Tables to migrate
    tables = ['items', 'suppliers', 'supplier_items', 'orders', 'users']

    total_migrated = 0

    for table in tables:
        print(f"  Migrating {table}...")

        # Get old data
        old_cursor.execute(f"SELECT * FROM {table}")
        old_data = old_cursor.fetchall()

        if not old_data:
            print(f"    No data in {table}")
            continue

        # Get column info
        old_cursor.execute(f"PRAGMA table_info({table})")
        old_columns = [row[1] for row in old_cursor.fetchall()]

        new_cursor.execute(f"PRAGMA table_info({table})")
        new_columns = [row[1] for row in new_cursor.fetchall()]

        # Find common columns
        common_columns = [col for col in old_columns if col in new_columns]

        if not common_columns:
            print(f"    No common columns for {table}")
            continue

        # Clear new table
        new_cursor.execute(f"DELETE FROM {table}")

        # Insert data
        placeholders = ', '.join(['?' for _ in common_columns])
        columns_str = ', '.join(common_columns)

        for row in old_data:
            # Create dict of old data
            old_row_dict = dict(zip(old_columns, row))
            # Extract values for common columns
            values = [old_row_dict[col] for col in common_columns]

            new_cursor.execute(f"INSERT INTO {table} ({columns_str}) VALUES ({placeholders})", values)

        print(f"    Migrated {len(old_data)} rows")
        total_migrated += len(old_data)

    new_conn.commit()
    old_conn.close()
    new_conn.close()

    print(f"[OK] Data migration complete: {total_migrated} total rows")
    return True

def main():
    if len(sys.argv) < 2:
        print("Usage: python migrate_comprehensive.py <old_db_path>")
        print("Example: python migrate_comprehensive.py proveedores/backup_20260208_113738/suppliers.db")
        sys.exit(1)

    old_db_path = sys.argv[1]

    # Create new DB path
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    new_db_path = f"data/suppliers_migrated_{timestamp}.db"

    print("=" * 70)
    print("COMPREHENSIVE DATABASE MIGRATION")
    print("=" * 70)
    print(f"Old DB: {old_db_path}")
    print(f"New DB: {new_db_path}")
    print()

    try:
        # Step 1: Create new database
        create_new_database(new_db_path)

        # Step 2: Add audit columns
        add_who_columns(new_db_path)

        # Step 3: Create contacts table
        create_supplier_contacts_table(new_db_path)

        # Step 4: Migrate data
        if not migrate_data(old_db_path, new_db_path):
            print("[ERROR] Data migration failed")
            return False

        # Step 5: Migrate contacts
        migrate_supplier_contacts(new_db_path)

        print()
        print("=" * 70)
        print("MIGRATION COMPLETED SUCCESSFULLY")
        print("=" * 70)
        print(f"New database: {new_db_path}")
        print()
        print("Next steps:")
        print("1. Backup your old database")
        print("2. Replace the old suppliers.db with the new one")
        print("3. Test the application")

        return True

    except Exception as e:
        print(f"[ERROR] Migration failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
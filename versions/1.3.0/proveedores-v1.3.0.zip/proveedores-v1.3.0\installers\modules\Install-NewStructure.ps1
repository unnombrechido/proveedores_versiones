# Install-NewStructure.ps1
# Installs new modular structure

function Install-ModularStructure {
    param(
        [string]$SourcePath,
        [string]$DestPath,
        [bool]$IsUpgrade = $false
    )
    
    $result = @{
        Success = $false
        DirectoriesCreated = @()
        FilesCopied = 0
        Errors = @()
    }
    
    try {
        # Define required directories for v1.0
        $directories = @(
            "api",
            "api\static",
            "api\templates",
            "bin",
            "data",
            "scripts",
            "docs",
            "examples",
            "config",
            "logs",
            "utilities",
            "installers"
        )
        
        # Create directories
        foreach ($dir in $directories) {
            $dirPath = Join-Path $DestPath $dir
            if (-not (Test-Path $dirPath)) {
                New-Item -ItemType Directory -Path $dirPath -Force | Out-Null
                $result.DirectoriesCreated += $dir
            }
        }
        
        # Copy files from source (if running from distribution)
        if (Test-Path $SourcePath) {
            $filesToCopy = @{
                "api\*" = "api\"
                "bin\*" = "bin\"
                "scripts\*" = "scripts\"
                "docs\*" = "docs\"
                "examples\*" = "examples\"
                "utilities\*" = "utilities\"
                "installers\*" = "installers\"
                "requirements.txt" = ""
                "VERSION" = ""
                "LICENSE" = ""
                "README.md" = ""
            }
            
            foreach ($source in $filesToCopy.Keys) {
                $dest = $filesToCopy[$source]
                $sourcePath = Join-Path $SourcePath $source
                $destPath = if ($dest) { Join-Path $DestPath $dest } else { $DestPath }
                
                if (Test-Path $sourcePath) {
                    Copy-Item -Path $sourcePath -Destination $destPath -Recurse -Force -ErrorAction SilentlyContinue
                    
                    # Count files copied
                    if ($source -like "*\*") {
                        $count = (Get-ChildItem -Path $sourcePath -Recurse -File).Count
                        $result.FilesCopied += $count
                    } else {
                        $result.FilesCopied++
                    }
                }
            }
        }
        
        $result.Success = $true
        return $result
        
    } catch {
        $result.Errors += $_.Exception.Message
        return $result
    }
}

Export-ModuleMember -Function Install-ModularStructure

# -*- coding: utf-8 -*-
"""
Migration Script: Add Audit "Who" Columns
Version: 1.3.0
Date: 2026-02-05

This script adds created_by and updated_by columns to track who creates and modifies records.
Adds columns to: items, suppliers, supplier_contacts, orders
"""

import sys
import os
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from api.database import SessionLocal, engine
from sqlalchemy import text

def add_who_columns():
    """Add created_by and updated_by columns to all main tables"""
    print("="*60)
    print("MIGRACION: Agregar Columnas de Auditoria (Who)")
    print("Version: 1.3.0")
    print("="*60)
    print()
    
    db = SessionLocal()
    
    try:
        tables = ['items', 'suppliers', 'supplier_contacts', 'orders']
        
        for table in tables:
            print(f"Procesando tabla: {table}")
            
            # Check if columns already exist
            result = db.execute(text(f"PRAGMA table_info({table})")).fetchall()
            columns = [row[1] for row in result]
            
            if 'created_by' in columns and 'updated_by' in columns:
                print(f"  [SKIP] Columnas ya existen en {table}")
                continue
            
            # Add created_by column
            if 'created_by' not in columns:
                print(f"  Agregando created_by a {table}...")
                db.execute(text(f"""
                    ALTER TABLE {table}
                    ADD COLUMN created_by INTEGER
                    REFERENCES users(id)
                """))
                print(f"  [OK] created_by agregado")
            
            # Add updated_by column
            if 'updated_by' not in columns:
                print(f"  Agregando updated_by a {table}...")
                db.execute(text(f"""
                    ALTER TABLE {table}
                    ADD COLUMN updated_by INTEGER
                    REFERENCES users(id)
                """))
                print(f"  [OK] updated_by agregado")
            
            print()
        
        db.commit()
        print("="*60)
        print("[OK] MIGRACION COMPLETADA EXITOSAMENTE")
        print("="*60)
        print()
        print("NOTAS:")
        print("- Las columnas created_by y updated_by estan disponibles")
        print("- Los registros existentes tienen NULL en estas columnas")
        print("- Los nuevos registros deben incluir el user_id apropiado")
        print()
        
        # Verification
        print("Verificacion:")
        for table in tables:
            result = db.execute(text(f"PRAGMA table_info({table})")).fetchall()
            columns = [row[1] for row in result]
            has_created = 'created_by' in columns
            has_updated = 'updated_by' in columns
            status = "[OK]" if has_created and has_updated else "[ERROR]"
            print(f"  {status} {table}: created_by={has_created}, updated_by={has_updated}")
        
    except Exception as e:
        db.rollback()
        print(f"\n[ERROR] Migracion fallida: {str(e)}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    add_who_columns()

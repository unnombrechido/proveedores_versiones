# TODO - Próxima versión (v1.3.0)

## Instalación y servicio
- [X] Make app a service to run in the background
- [X] Add an option to start automatically after install and on system restart
- [X] Add an icon to the app file
- [X] Use company logo as icon for the web app
- [X] Remove browser artifacts
- [X] Make it run on a separate window
- [X] Move initial config from install to admin UI
- [X] Add company details: address, contact info, etc to the config
- [X] Add a zoom option to change font-zise and button size
- [X] app run should check for an active session so it doesn't open the app twice
- [X] CLient on local and remote pc, mobile client (keep server running when closing the UI)



- [ ] Stop the app if running during installation
- [ ] Uninstaller
- [ ] Separate clean installer vs upgrade/repair installer

## Pedidos y plantillas
- [X] User templates for orders
- [X] Separate order versions for user and for sending to vendors (user's must have prices for estimates, vendor's must not)
- [ ] Share button [email, whatsapp, others?]

## Catálogo y datos
- [ ] Add remove/deactivate vendors/items process
- [X] Add who columns
- [ ] Add inventory and inventory management (different from items list)
- [X] Add company letterhead to vendor sending orders

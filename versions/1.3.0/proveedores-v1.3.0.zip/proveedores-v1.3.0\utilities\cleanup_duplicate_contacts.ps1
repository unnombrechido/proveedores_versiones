# Cleanup Duplicate Contacts Script - Interactive Menu
# Version: 1.0.0
# Date: 2026-02-10

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  LIMPIEZA DE CONTACTOS DUPLICADOS" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Determine Python command
$pythonCmd = "python"
if (Test-Path "..\venv\Scripts\python.exe") {
    $pythonCmd = "..\venv\Scripts\python.exe"
    Write-Host "[INFO] Usando Python del entorno virtual" -ForegroundColor Green
} elseif (Test-Path "..\venv\bin\python") {
    $pythonCmd = "..\venv\bin\python"
    Write-Host "[INFO] Usando Python del entorno virtual (Linux)" -ForegroundColor Green
} else {
    # Check if Python is available
    try {
        $null = Get-Command python -ErrorAction Stop
        Write-Host "[INFO] Usando Python del sistema" -ForegroundColor Gray
    } catch {
        Write-Host "[ERROR] Python no esta disponible" -ForegroundColor Red
        Write-Host ""
        Write-Host "Por favor instala Python o ejecuta desde el entorno virtual:" -ForegroundColor Yellow
        Write-Host "  ..\venv\Scripts\python.exe ..\scripts\cleanup_duplicate_contacts.py" -ForegroundColor Gray
        Read-Host "Presiona Enter para salir"
        exit 1
    }
}
Write-Host ""

# Show menu
Write-Host "Selecciona una opcion:" -ForegroundColor White
Write-Host ""
Write-Host "  1. Verificar estado actual (buscar duplicados)" -ForegroundColor Gray
Write-Host "  2. Simulacion (mostrar duplicados sin eliminar)" -ForegroundColor Gray
Write-Host "  3. Aplicar limpieza (eliminar duplicados)" -ForegroundColor Yellow
Write-Host "  4. Salir" -ForegroundColor Gray
Write-Host ""

$choice = Read-Host "Opcion (1-4)"

switch ($choice) {
    "1" {
        Write-Host ""
        Write-Host "[INFO] Verificando estado actual..." -ForegroundColor Cyan
        Write-Host ""

        try {
            $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
            $parentDir = Split-Path -Parent $scriptDir
            $cleanupScript = Join-Path $parentDir "scripts\cleanup_duplicate_contacts.py"

            & $pythonCmd $cleanupScript --verify-only
        } catch {
            Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
        }

        Write-Host ""
        Read-Host "Presiona Enter para continuar"
    }

    "2" {
        Write-Host ""
        Write-Host "[INFO] Ejecutando simulacion (no se eliminan datos)..." -ForegroundColor Cyan
        Write-Host ""

        try {
            $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
            $parentDir = Split-Path -Parent $scriptDir
            $cleanupScript = Join-Path $parentDir "scripts\cleanup_duplicate_contacts.py"

            & $pythonCmd $cleanupScript
        } catch {
            Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
        }

        Write-Host ""
        Read-Host "Presiona Enter para continuar"
    }

    "3" {
        Write-Host ""
        Write-Host "[ADVERTENCIA] Esta opcion ELIMINARA contactos duplicados permanentemente" -ForegroundColor Red
        Write-Host ""

        $confirm = Read-Host "¿Estas seguro? (si/no)"
        if ($confirm -eq "si" -or $confirm -eq "sí") {
            Write-Host ""
            Write-Host "[INFO] Aplicando limpieza de duplicados..." -ForegroundColor Yellow
            Write-Host ""

            try {
                $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
                $parentDir = Split-Path -Parent $scriptDir
                $cleanupScript = Join-Path $parentDir "scripts\cleanup_duplicate_contacts.py"

                & $pythonCmd $cleanupScript --apply
            } catch {
                Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
            }
        } else {
            Write-Host ""
            Write-Host "Operacion cancelada." -ForegroundColor Gray
        }

        Write-Host ""
        Read-Host "Presiona Enter para continuar"
    }

    "4" {
        Write-Host ""
        Write-Host "Saliendo..." -ForegroundColor Gray
        exit 0
    }

    default {
        Write-Host ""
        Write-Host "Opcion invalida" -ForegroundColor Red
        Read-Host "Presiona Enter para continuar"
    }
}
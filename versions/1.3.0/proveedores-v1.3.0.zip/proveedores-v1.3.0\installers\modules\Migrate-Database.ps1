# Migrate-Database.ps1
# Migrates database from old structure to new

function Invoke-DatabaseMigration {
    param(
        [string]$SourceDb,
        [string]$DestDb,
        [string]$PythonCmd = "python"
    )
    
    $result = @{
        Success = $false
        RowsMigrated = 0
        TablesProcessed = @()
        Errors = @()
    }
    
    # Verify source exists
    if (-not (Test-Path $SourceDb)) {
        $result.Errors += "Source database not found: $SourceDb"
        return $result
    }
    
    # Verify destination exists
    if (-not (Test-Path $DestDb)) {
        $result.Errors += "Destination database not found: $DestDb"
        return $result
    }
    
    # Find migration script
    $scriptPath = "scripts\migrate_database.py"
    if (-not (Test-Path $scriptPath)) {
        $result.Errors += "Migration script not found: $scriptPath"
        return $result
    }
    
    try {
        # Run migration script
        $output = & $PythonCmd $scriptPath $SourceDb $DestDb 2>&1
        
        # Parse output for results
        $success = $LASTEXITCODE -eq 0
        $result.Success = $success
        
        # Extract information from output
        foreach ($line in $output) {
            $lineStr = $line.ToString()
            
            # Count migrated rows
            if ($lineStr -match "Migrated (\d+) rows from '(\w+)'") {
                $count = [int]$Matches[1]
                $table = $Matches[2]
                $result.RowsMigrated += $count
                $result.TablesProcessed += "$table ($count rows)"
            }
            
            # Capture errors
            if ($lineStr -match "\[ERROR\]") {
                $result.Errors += $lineStr
            }
        }
        
        return $result
        
    } catch {
        $result.Errors += $_.Exception.Message
        return $result
    }
}

Export-ModuleMember -Function Invoke-DatabaseMigration

# Sistema de Autenticación y Gestión de Usuarios

## Resumen

Se ha implementado un sistema completo de autenticación y autorización con gestión de usuarios y tres roles diferentes:

## 🔐 Roles y Permisos

### Sysadmin (Administrador del Sistema)
**Acceso completo y sin restricciones:**
- ✅ Ver, buscar, crear y modificar items
- ✅ Ver, buscar, crear y modificar proveedores  
- ✅ Importar y exportar datos (CSV/Excel)
- ✅ Ver, crear y actualizar órdenes de compra
- ✅ **Gestión de usuarios** (crear, editar, eliminar usuarios)
- ✅ **Cambiar contraseñas** de cualquier usuario
- ✅ Acceso a todas las funcionalidades del sistema

### Admin (Administrador)
**Gestión de datos sin administración de usuarios:**
- ✅ Ver, buscar, crear y modificar items
- ✅ Ver, buscar, crear y modificar proveedores
- ✅ Importar y exportar datos (CSV/Excel)
- ✅ Gestión de precios e items
- ❌ **NO** puede gestionar usuarios
- ❌ **NO** puede ver/crear órdenes de compra

### Compras (Usuario de Compras)
**Solo consulta y gestión de órdenes:**
- ✅ Buscar items y proveedores
- ✅ Ver información de items y proveedores
- ✅ Ver, crear y actualizar órdenes de compra
- ❌ **NO** puede crear/modificar items o proveedores
- ❌ **NO** puede importar/exportar datos
- ❌ **NO** puede gestionar usuarios

## 👤 Gestión de Usuarios

### Usuario Predeterminado

Al inicializar el sistema, se crea automáticamente un usuario sysadmin:

```
Email: admin@proveedores.com
Password: admin123
Rol: sysadmin
```

**⚠️ IMPORTANTE:** Cambie esta contraseña inmediatamente después del primer inicio de sesión.

### Crear Nuevos Usuarios

Solo los usuarios con rol **sysadmin** pueden crear y gestionar usuarios:

1. Iniciar sesión como sysadmin
2. Ir a "Gestión de Usuarios" en el menú lateral
3. Hacer clic en "+ Nuevo Usuario"
4. Completar el formulario:
   - **Email** * (usado como identificador único)
   - **Contraseña** * (mínimo 6 caracteres)
   - **Nombre** *
   - **Apellido** *
   - **Teléfono** (opcional)
   - **Rol** * (sysadmin, admin, o compras)
   - **Estado** * (activo o inactivo)
5. Guardar

### Editar Usuarios

- Click en "✏️ Editar" en la tabla de usuarios
- Modificar campos necesarios
- La contraseña se puede dejar vacía para mantener la actual
- Guardar cambios

### Cambiar Contraseñas

**Sysadmin puede cambiar cualquier contraseña:**
- Click en "🔑 Cambiar Contraseña" en la tabla de usuarios
- Ingresar nueva contraseña (mínimo 6 caracteres)
- Confirmar

**Los usuarios pueden cambiar su propia contraseña:**
- En el perfil del usuario actual
- Requerirá la contraseña actual para confirmar

### Eliminar Usuarios

- Solo sysadmin puede eliminar usuarios
- No se puede eliminar la propia cuenta
- Click en "🗑️ Eliminar" en la tabla de usuarios
- Confirmar acción

## 🚀 Inicialización

### Primera Vez

Si es una instalación nueva, ejecute:

```bash
# Windows
utilities\init_users.bat

# O directamente con Python
python app\init_users.py
```

Esto creará:
- La tabla `users` en la base de datos
- El usuario sysadmin predeterminado

### Sistema Existente

Si ya tiene datos y solo necesita agregar usuarios:

```bash
python app\init_users.py
```

El script detectará si ya existen usuarios y no creará duplicados.

## 🔒 Seguridad

### Contraseñas

- Las contraseñas se almacenan hasheadas usando `werkzeug.security`
- Algoritmo: scrypt (seguro y recomendado)
- Las contraseñas nunca se almacenan en texto plano
- Longitud mínima requerida: 6 caracteres

### Sesiones

- Sistema de sesiones con Flask-Login
- Cookies seguras con secret key
- Timeout automático de sesión
- Logout limpia todas las sesiones

### Autorización

- Decoradores `@permission_required` y `@role_required`
- Verificación automática en cada ruta
- Redirección a login si no está autenticado
- Error 403 si no tiene permisos suficientes

## 📋 Campos de Usuario

| Campo | Tipo | Requerido | Descripción |
|-------|------|-----------|-------------|
| email | string | ✅ | Identificador único, usado para login |
| password | string | ✅ | Mínimo 6 caracteres, hasheado |
| nombre | string | ✅ | Nombre del usuario |
| apellido | string | ✅ | Apellido del usuario |
| telefono | string | ❌ | Número de teléfono |
| rol | string | ✅ | sysadmin, admin, o compras |
| status | string | ✅ | activo o inactivo |
| fecha_registro | datetime | Auto | Fecha de creación |
| fecha_actualizacion | datetime | Auto | Última modificación |

## 🛠️ Archivos Modificados/Creados

### Backend
- `app/models.py` - Nuevo modelo `User` con métodos de autenticación
- `app/app.py` - Rutas de autenticación y gestión de usuarios
- `app/database.py` - Sin cambios, compatible
- `app/init_users.py` - **Nuevo:** Script de inicialización

### Frontend  
- `templates/login.html` - **Nueva:** Página de inicio de sesión
- `templates/index.html` - Actualizada con gestión de usuarios
- `static/script.js` - Funciones de autenticación y usuarios

### Utilidades
- `utilities/init_users.bat` - **Nuevo:** Script de inicialización Windows
- `requirements.txt` - Agregado `Flask-Login==0.6.3`

## 🔧 API Endpoints

### Autenticación
```
POST   /api/auth/login          - Iniciar sesión
POST   /api/auth/logout         - Cerrar sesión
GET    /api/auth/me             - Información del usuario actual
GET    /api/auth/check          - Verificar autenticación
```

### Gestión de Usuarios (Solo Sysadmin)
```
GET    /api/users               - Listar todos los usuarios
POST   /api/users               - Crear nuevo usuario
GET    /api/users/:id           - Obtener usuario específico
PUT    /api/users/:id           - Actualizar usuario
DELETE /api/users/:id           - Eliminar usuario
PUT    /api/users/:id/password  - Cambiar contraseña
```

## 🎯 Próximos Pasos Recomendados

1. **Cambiar contraseña del admin predeterminado**
2. **Crear usuarios para su equipo** con los roles apropiados
3. **Configurar SECRET_KEY** en producción (variable de entorno)
4. **Revisar permisos** de cada rol según necesidades
5. **Considerar autenticación de 2 factores** para mayor seguridad (futuro)

## 📝 Notas

- Los usuarios inactivos no pueden iniciar sesión
- Las sesiones persisten con "Remember Me" activado
- El primer sysadmin siempre debe existir
- Se recomienda tener al menos 2 sysadmins activos

## 🐛 Solución de Problemas

**No puedo iniciar sesión:**
- Verificar que el usuario esté activo
- Confirmar email y contraseña correctos
- Revisar logs del servidor

**Olvidé la contraseña del sysadmin:**
- Ejecutar `init_users.py` recreará el admin predeterminado
- O usar consola SQL para actualizar password_hash

**Error 403 Forbidden:**
- Su rol no tiene permisos para esa acción
- Contacte a un sysadmin para cambiar su rol

## 📞 Soporte

Para más información o problemas, contacte al equipo de desarrollo.

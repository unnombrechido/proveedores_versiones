# -*- coding: utf-8 -*-
"""
Migration Script: Add Supplier Contacts Table
Version: 1.3.1
Date: 2026-02-10

This script:
1. Creates the supplier_contacts table
2. Migrates existing contact data from suppliers table to supplier_contacts
3. Handles multi-value phone/email fields (splits on '/', ',', ';')
4. Sets the first contact as primary
5. Includes deduplication logic to prevent duplicate contacts
"""

import sys
import os
import re
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'api')))

from database import SessionLocal, engine
from models import Base, Supplier, SupplierContact
from sqlalchemy import text

def create_contacts_table():
    """Create the supplier_contacts table"""
    print("Creating supplier_contacts table...")
    Base.metadata.create_all(bind=engine, tables=[SupplierContact.__table__])
    print("[OK] Table created successfully")

def parse_multi_value_field(field_value, separator_pattern=r'[/,;]'):
    """
    Parse multi-value fields like "phone1 / phone2" or "email1, email2"
    Returns list of cleaned values
    """
    if not field_value or not field_value.strip():
        return []
    
    # Split by common separators
    values = re.split(separator_pattern, field_value)
    
    # Clean and filter
    cleaned = []
    for val in values:
        val = val.strip()
        if val:
            cleaned.append(val)
    
    return cleaned

def migrate_supplier_contacts():
    """Migrate existing supplier contact data to supplier_contacts table"""
    db = SessionLocal()
    try:
        # Use raw SQL to query suppliers to avoid ORM issues with missing audit columns
        result = db.execute(text("""
            SELECT id, name, contact_person, email, phone, address, city, country, 
                   tax_id, category, rating, payment_terms, notes, active, 
                   created_at, updated_at
            FROM suppliers
        """))
        suppliers_data = result.fetchall()
        total = len(suppliers_data)
        migrated = 0
        
        print(f"\nMigrating contact data for {total} suppliers...")
        
        for supplier_row in suppliers_data:
            supplier_id = supplier_row[0]
            supplier_name = supplier_row[1]
            contact_person = supplier_row[2]
            email = supplier_row[3]
            phone = supplier_row[4]
            
            contacts_created = 0
            
            # Parse multi-value fields
            phones = parse_multi_value_field(phone)
            emails = parse_multi_value_field(email)
            contact_names = parse_multi_value_field(contact_person)
            
            # Collect unique contacts to avoid duplicates
            unique_contacts = {}
            
            # Process contacts from contact_person field
            for i, name in enumerate(contact_names):
                if not name.strip():
                    continue
                    
                # Create a unique key based on name, phone, and email combination
                phone_val = phones[i] if i < len(phones) else ''
                email_val = emails[i] if i < len(emails) else ''
                contact_key = f"{name.strip().lower()}|{phone_val.strip().lower()}|{email_val.strip().lower()}"
                
                if contact_key not in unique_contacts:
                    unique_contacts[contact_key] = {
                        'name': name.strip(),
                        'phone': phone_val.strip(),
                        'email': email_val.strip(),
                        'index': i
                    }
            
            # Process any remaining phones/emails that don't have corresponding names
            max_len = max(len(phones), len(emails))
            for i in range(max_len):
                if i < len(contact_names):
                    continue  # Already processed above
                    
                name_val = f'Contacto {i+1}' if i >= len(contact_names) else contact_names[i]
                phone_val = phones[i] if i < len(phones) else ''
                email_val = emails[i] if i < len(emails) else ''
                
                if not name_val.strip() and not phone_val.strip() and not email_val.strip():
                    continue
                    
                contact_key = f"{name_val.strip().lower()}|{phone_val.strip().lower()}|{email_val.strip().lower()}"
                
                if contact_key not in unique_contacts:
                    unique_contacts[contact_key] = {
                        'name': name_val.strip(),
                        'phone': phone_val.strip(),
                        'email': email_val.strip(),
                        'index': i
                    }
            
            # If no contacts found, create a placeholder
            if not unique_contacts:
                contact = SupplierContact(
                    supplier_id=supplier_id,
                    contact_name='Contacto Principal',
                    position='',
                    phone='',
                    email='',
                    is_primary=1,
                    contact_type='general',
                    notes='Migrado automáticamente - sin información de contacto'
                )
                db.add(contact)
                contacts_created += 1
            else:
                # Create contacts from unique list
                sorted_contacts = sorted(unique_contacts.values(), key=lambda x: x['index'])
                
                for i, contact_data in enumerate(sorted_contacts):
                    contact_name = contact_data['name']
                    phone = contact_data['phone']
                    email = contact_data['email']
                    
                    # Skip if completely empty
                    if not contact_name and not phone and not email:
                        continue
                    
                    # Determine position/type
                    position = ''
                    contact_type = 'general'
                    if i == 0:
                        position = 'Principal'
                        contact_type = 'general'
                    elif 'compra' in contact_name.lower():
                        position = 'Compras'
                        contact_type = 'purchasing'
                    elif 'venta' in contact_name.lower():
                        position = 'Ventas'
                        contact_type = 'sales'
                    elif 'contab' in contact_name.lower():
                        position = 'Contabilidad'
                        contact_type = 'accounting'
                    
                    contact = SupplierContact(
                        supplier_id=supplier_id,
                        contact_name=contact_name,
                        position=position,
                        phone=phone,
                        email=email,
                        is_primary=(1 if i == 0 else 0),
                        contact_type=contact_type,
                        notes='Migrado automáticamente desde campos legacy'
                    )
                    db.add(contact)
                    contacts_created += 1
            
            if contacts_created > 0:
                migrated += 1
            
            # Commit every 50 suppliers
            if migrated % 50 == 0:
                db.commit()
                print(f"  Progreso: {migrated}/{total} proveedores migrados...")
        
        db.commit()
        print(f"[OK] Migracion completada: {migrated}/{total} proveedores procesados")
        
        # Print summary
        contact_count = db.query(SupplierContact).count()
        primary_count = db.query(SupplierContact).filter(SupplierContact.is_primary == 1).count()
        print(f"[OK] Total de contactos creados: {contact_count}")
        print(f"[OK] Contactos primarios: {primary_count}")
        
    except Exception as e:
        db.rollback()
        print(f"✗ Error durante la migración: {str(e)}")
        raise
    finally:
        db.close()

def verify_migration():
    """Verify the migration was successful"""
    db = SessionLocal()
    try:
        print("\nVerificando migración...")
        
        # Check table exists
        result = db.execute(text("SELECT name FROM sqlite_master WHERE type='table' AND name='supplier_contacts'"))
        if not result.fetchone():
            print("✗ Tabla supplier_contacts no existe")
            return False
        
        # Check contacts created
        supplier_count = db.query(Supplier).count()
        contact_count = db.query(SupplierContact).count()
        
        print(f"  Proveedores: {supplier_count}")
        print(f"  Contactos: {contact_count}")
        
        # Check each supplier has at least one contact
        suppliers_without_contacts = db.execute(text("""
            SELECT COUNT(*) FROM suppliers s
            LEFT JOIN supplier_contacts sc ON s.id = sc.supplier_id
            WHERE sc.id IS NULL
        """)).scalar()
        
        if suppliers_without_contacts > 0:
            print(f"⚠ Advertencia: {suppliers_without_contacts} proveedores sin contactos")
        
        # Check primary contacts
        suppliers_without_primary = db.execute(text("""
            SELECT COUNT(*) FROM suppliers s
            WHERE NOT EXISTS (
                SELECT 1 FROM supplier_contacts sc 
                WHERE sc.supplier_id = s.id AND sc.is_primary = 1
            )
        """)).scalar()
        
        if suppliers_without_primary > 0:
            print(f"⚠ Advertencia: {suppliers_without_primary} proveedores sin contacto primario")
        
        print("[OK] Verificacion completada")
        return True
        
    except Exception as e:
        print(f"✗ Error durante verificación: {str(e)}")
        return False
    finally:
        db.close()

def main():
    print("=" * 60)
    print("MIGRACIÓN: Agregar Tabla de Contactos de Proveedores")
    print("Versión: 1.3.1")
    print("=" * 60)
    print()
    
    try:
        # Step 1: Create table
        create_contacts_table()
        
        # Step 2: Migrate data
        migrate_supplier_contacts()
        
        # Step 3: Verify
        verify_migration()
        
        print()
        print("=" * 60)
        print("[OK] MIGRACION COMPLETADA EXITOSAMENTE")
        print("=" * 60)
        print()
        print("NOTAS:")
        print("- Los campos legacy (contact_person, email, phone) en suppliers")
        print("  permanecen intactos por compatibilidad")
        print("- Use la nueva tabla supplier_contacts para gestionar contactos")
        print("- El primer contacto está marcado como primario (is_primary=1)")
        print()
        
    except Exception as e:
        print()
        print("=" * 60)
        print("✗ MIGRACIÓN FALLÓ")
        print("=" * 60)
        print(f"Error: {str(e)}")
        print()
        sys.exit(1)

if __name__ == '__main__':
    main()

```python
# In app.py: Add these imports at the top
from fpdf import FPDF
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from flask import request, make_response, jsonify

# In app.py: Add this function to generate PDF (can be standalone or inside endpoint)
def generate_order_pdf(order):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt=f"Orden #{order.order_number}", ln=1, align='C')
    pdf.cell(200, 10, txt=f"Proveedor: {order.supplier.name}", ln=1)
    pdf.cell(200, 10, txt=f"Fecha: {order.order_date}", ln=1)
    pdf.cell(200, 10, txt="Items:", ln=1)
    # Assuming order.items is a list or JSON; adjust parsing as needed
    items = json.loads(order.items) if isinstance(order.items, str) else order.items
    for item in items:
        pdf.cell(200, 10, txt=f"- {item['name']} x {item['quantity']} = {item['subtotal']}", ln=1)
    pdf.cell(200, 10, txt=f"Total: {order.total_amount}", ln=1)
    return pdf.output(dest='S').encode('latin-1')

# In app.py: Add this endpoint for PDF download
@app.route('/api/orders/<int:order_id>/pdf', methods=['GET'])
def get_order_pdf(order_id):
    order = Order.query.get_or_404(order_id)
    pdf_bytes = generate_order_pdf(order)
    response = make_response(pdf_bytes)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename=orden_{order_id}.pdf'
    return response

# In app.py: Add this endpoint for server-side email with attachment
# Configure SMTP details (use env vars in production: os.getenv('SMTP_USER'), etc.)
@app.route('/api/orders/<int:order_id>/email', methods=['POST'])
def send_order_email(order_id):
    order = Order.query.get_or_404(order_id)
    data = request.json
    recipient = data.get('email')
    if not recipient:
        return jsonify({'error': 'Email requerido'}), 400
    
    pdf_bytes = generate_order_pdf(order)
    
    msg = MIMEMultipart()
    msg['From'] = 'tuemail@example.com'  # Cambia a tu email
    msg['To'] = recipient
    msg['Subject'] = f"Orden #{order.order_number}"
    
    body = "Adjunto encontrarás los detalles de la orden."
    msg.attach(MIMEText(body, 'plain'))
    
    attachment = MIMEApplication(pdf_bytes, _subtype="pdf")
    attachment.add_header('Content-Disposition', 'attachment', filename=f"orden_{order_id}.pdf")
    msg.attach(attachment)
    
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)  # Ejemplo Gmail; ajusta según proveedor
        server.starttls()
        server.login('tuemail@example.com', 'tupassword')  # Usa app password para Gmail
        server.send_message(msg)
        server.quit()
        return jsonify({'message': 'Email enviado'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
```

```html
<!-- In templates/index.html: Add this script tag in <head> for jsPDF (client-side WhatsApp) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
```

```javascript
// In static/script.js: Add this function for client-side sharing (WhatsApp/email fallback)
async function shareOrder(orderId, orderData) {  // orderData from existing fetch
    if (navigator.canShare && navigator.canShare({ files: [] })) {
        // Generar PDF client-side para WhatsApp
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        doc.text(`Orden #${orderData.order_number}`, 10, 10);
        doc.text(`Proveedor: ${orderData.supplier.name}`, 10, 20);
        doc.text(`Fecha: ${orderData.order_date}`, 10, 30);
        doc.text("Items:", 10, 40);
        let y = 50;
        orderData.items.forEach(item => {  // Ajusta si orderData.items es string/JSON
            doc.text(`- ${item.name} x ${item.quantity} = ${item.subtotal}`, 10, y);
            y += 10;
        });
        doc.text(`Total: ${orderData.total_amount}`, 10, y);
        const pdfBlob = doc.output('blob');
        const pdfFile = new File([pdfBlob], `orden_${orderId}.pdf`, { type: 'application/pdf' });

        try {
            await navigator.share({
                title: 'Detalles de Orden',
                text: 'Revisa esta orden del sistema de proveedores.',
                files: [pdfFile]
            });
        } catch (err) {
            console.error('Compartir falló:', err);
            // Fallback a email si WhatsApp falla
            promptEmailShare(orderId);
        }
    } else {
        // Fallback para desktops: descarga PDF o mailto
        window.open(`/api/orders/${orderId}/pdf`, '_blank');
    }
}

// In static/script.js: Add this for email prompt (client-side trigger to server)
function promptEmailShare(orderId) {
    const email = prompt('Ingresa el email del destinatario:');
    if (email) {
        fetch(`/api/orders/${orderId}/email`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        })
        .then(res => res.json())
        .then(data => {
            if (data.message) alert('Email enviado');
            else alert('Error: ' + data.error);
        });
    }
}

// In static/script.js: Integrate into order view modal (find existing code for 'Ver Orden' modal)
// Example: In the function that opens the view modal, add buttons
// Assuming a variable like viewModalContent
viewModalContent += `<button onclick="shareOrder(${order.id}, ${JSON.stringify(order)})">Compartir (WhatsApp/Email)</button>`;
```
# Migrate-Database.psm1
# Migrates database from old structure to new

function Invoke-DatabaseMigration {
    param(
        [string]$SourceDb,
        [string]$DestDb,
        [string]$PythonCmd = "python"
    )
    
    $result = @{
        Success = $false
        RowsMigrated = 0
        TablesProcessed = @()
        Errors = @()
    }
    
    # Verify source exists
    if (-not (Test-Path $SourceDb)) {
        $result.Errors += "Source database not found: $SourceDb"
        return $result
    }
    
    # Verify destination exists
    if (-not (Test-Path $DestDb)) {
        $result.Errors += "Destination database not found: $DestDb"
        return $result
    }
    
    # Find migration script
    $scriptPath = "scripts\migrate_database.py"
    if (-not (Test-Path $scriptPath)) {
        $result.Errors += "Migration script not found: $scriptPath"
        return $result
    }
    
    try {
        # Run migration script
        $output = & $PythonCmd $scriptPath $SourceDb $DestDb 2>&1
    }
    catch {
        Write-Error "An error occurred during the database migration: $_"
        $result.Success = $false
        $result.Errors += $_.Exception.Message
    }
}

Export-ModuleMember -Function Invoke-DatabaseMigration
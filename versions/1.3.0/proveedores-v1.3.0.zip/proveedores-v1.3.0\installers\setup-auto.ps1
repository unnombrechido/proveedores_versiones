﻿# ============================================================
#  Sistema de Gestion de Proveedores v1.0
#  Instalador Automatico Modular
# ============================================================

param(
    [switch]$ServiceInstallOnly,
    [string]$InstallPath
)

$Host.UI.RawUI.WindowTitle = "Sistema de Proveedores v1.3.0 - Instalacion Automatica"
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "White"
Clear-Host

# Ensure execution policy allows script execution
$currentPolicy = Get-ExecutionPolicy -Scope Process
if ($currentPolicy -eq 'Restricted' -or $currentPolicy -eq 'Undefined') {
    try {
        Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned -Force -ErrorAction Stop
    } catch {
        Write-Host "Error: No se pudo configurar la politica de ejecucion." -ForegroundColor Red
        Write-Host "Ejecuta este comando manualmente como administrador:" -ForegroundColor Yellow
        Write-Host "Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned -Force" -ForegroundColor Yellow
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}

# Import modules
$moduleDir = Join-Path $PSScriptRoot "modules"
Import-Module (Join-Path $moduleDir "Detect-Installation/Detect-Installation.psm1") -Force
Import-Module (Join-Path $moduleDir "Backup-Installation/Backup-Installation.psm1") -Force
Import-Module (Join-Path $moduleDir "Migrate-Database/Migrate-Database.psm1") -Force
Import-Module (Join-Path $moduleDir "Install-NewStructure/Install-NewStructure.psm1") -Force
Import-Module (Join-Path $moduleDir "Initialize-System/Initialize-System.psm1") -Force

# Check if this is a service-only installation
if ($ServiceInstallOnly) {
    Write-Host "Modo de instalacion: Solo Servicio" -ForegroundColor Cyan
    Write-Host ""
    
    # Get installation path from parameter
    if (-not $InstallPath -or -not (Test-Path $InstallPath)) {
        Write-Host "Ruta de instalacion no especificada o no encontrada" -ForegroundColor Red
        exit 1
    }
    
    # Install service
    $serviceInstalled = Install-Service -InstallPath $InstallPath
    
    if ($serviceInstalled) {
        Write-Host "Servicio instalado correctamente" -ForegroundColor Green
        exit 0
    } else {
        Write-Host "Fallo al instalar el servicio" -ForegroundColor Red
        exit 1
    }
}

# Configuration
$versionPath = Join-Path (Split-Path $PSScriptRoot -Parent) "VERSION"
$VERSION = if (Test-Path $versionPath) { (Get-Content $versionPath -Raw).Trim() } else { "1.3.0" }
$MIN_PYTHON_VERSION = @(3, 8)

# Track changes for rollback
$script:installationChanges = @{
    DirectoriesCreated = @()
    FilesCreated = @()
    BackupPath = $null
    OldFilesPreserved = @()
}

# Stop running app instances
function Stop-RunningApp {
    param(
        [string]$InstallPath
    )
    
    Write-Host "[STOP] Verificando aplicaciones en ejecucion..." -ForegroundColor Yellow
    
    $appStopped = $false
    
    # Check if service is installed and running
    $serviceName = "SistemaProveedores"
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        $service = Get-Service -Name $serviceName
        Write-Host "  Servicio '$serviceName' encontrado - Estado: $($service.Status)" -ForegroundColor Gray
        
        # Check if service is active (Running or Starting)
        if ($service.Status -eq "Running" -or $service.Status -eq "Starting") {
            Write-Host "  Servicio '$serviceName' esta activo. Deteniendo..." -ForegroundColor Cyan
            
            # Try standard Stop-Service first
            try {
                Stop-Service -Name $serviceName -Force -ErrorAction Stop
                Write-Host "  [OK] Servicio detenido correctamente con Stop-Service" -ForegroundColor Green
                $appStopped = $true
            } catch {
                Write-Host "  [ADVERTENCIA] Stop-Service fallo, intentando con sc.exe..." -ForegroundColor Yellow

                # Try sc.exe stop as fallback
                try {
                    $scResult = sc.exe stop $serviceName 2>&1
                    if ($LASTEXITCODE -eq 0) {
                        Write-Host "  [OK] Servicio detenido correctamente con sc.exe" -ForegroundColor Green
                        $appStopped = $true
                    } else {
                        Write-Host "  [ERROR] No se pudo detener el servicio: sc.exe returned $LASTEXITCODE" -ForegroundColor Red
                    }
                } catch {
                    Write-Host "  [ERROR] No se pudo detener el servicio: $($_.Exception.Message)" -ForegroundColor Red
                }
            }
        } elseif ($service.Status -eq "Stopping") {
            Write-Host "  Servicio '$serviceName' se esta deteniendo. Esperando..." -ForegroundColor Yellow
            Start-Sleep -Seconds 5
            $service.Refresh()
            if ($service.Status -eq "Stopped") {
                Write-Host "  [OK] Servicio se detuvo automaticamente" -ForegroundColor Green
                $appStopped = $true
            }
        } else {
            Write-Host "  Servicio '$serviceName' instalado pero detenido" -ForegroundColor Gray
        }
    }
    
    # Check for running Python processes on port 5000 (Flask default)
    $pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
        $_.CommandLine -like "*app.py*" -or $_.CommandLine -like "*api/app.py*"
    }
    
    if ($pythonProcesses) {
        Write-Host "  Encontrados $($pythonProcesses.Count) procesos Python ejecutandose:" -ForegroundColor Cyan
        foreach ($process in $pythonProcesses) {
            Write-Host "    PID $($process.Id): $($process.CommandLine)" -ForegroundColor Gray
        }
        
        try {
            $pythonProcesses | Stop-Process -Force -ErrorAction Stop
            Write-Host "  [OK] Procesos Python detenidos correctamente" -ForegroundColor Green
            $appStopped = $true
        } catch {
            Write-Host "  [ADVERTENCIA] No se pudieron detener algunos procesos Python: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    
    # Check if port 5000 is in use (alternative method)
    $portInUse = Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue
    if ($portInUse) {
        Write-Host "  Puerto 5000 esta en uso. Aplicacion puede estar ejecutandose." -ForegroundColor Yellow
        Write-Host "  [RECOMENDACION] Asegurese de que la aplicacion este completamente detenida" -ForegroundColor Yellow
    }
    
    if ($appStopped) {
        Write-Host "  Aplicacion detenida exitosamente" -ForegroundColor Green
        Start-Sleep -Seconds 2  # Give time for cleanup
    } else {
        Write-Host "  No se encontraron aplicaciones ejecutandose" -ForegroundColor Gray
    }
    
    Write-Host ""
}

# Rollback function
function Invoke-Rollback {
    param([string]$Reason)
    
    Write-Host ""
    Write-Host "=========================================" -ForegroundColor Red
    Write-Host "  INSTALACION FALLIDA - REVERTIENDO" -ForegroundColor Red
    Write-Host "=========================================" -ForegroundColor Red
    Write-Host ""
    Show-Error "Razon: $Reason"
    Write-Host ""
    Show-Info "Revirtiendo cambios..."
    
    # Remove created files
    foreach ($file in $script:installationChanges.FilesCreated) {
        if (Test-Path $file) {
            Remove-Item $file -Force -ErrorAction SilentlyContinue
            Show-Info "Eliminado: $file"
        }
    }
    
    # Remove created directories (in reverse order)
    $script:installationChanges.DirectoriesCreated | Sort-Object -Descending | ForEach-Object {
        if (Test-Path $_) {
            Remove-Item $_ -Recurse -Force -ErrorAction SilentlyContinue
            Show-Info "Eliminado: $_"
        }
    }
    
    if ($script:installationChanges.BackupPath) {
        Write-Host ""
        Show-Success "Backup preservado en: $($script:installationChanges.BackupPath)"
    }
    
    Write-Host ""
    Write-Host "Sistema revertido al estado anterior" -ForegroundColor Yellow
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}

# Helper function for progress
function Show-Step {
    param([int]$Step, [int]$Total, [string]$Message)
    
    $percent = [math]::Round(($Step / $Total) * 100)
    $completed = [math]::Floor($percent / 10)
    $remaining = 10 - $completed
    
    $progressBar = "[" + ("=" * $completed) + ("." * $remaining) + "]"
    
    Write-Host ""
    Write-Host "$progressBar $percent% " -NoNewline -ForegroundColor Cyan
    Write-Host "[$Step/$Total] $Message" -ForegroundColor Cyan
}

function Show-Success {
    param([string]$Message)
    Write-Host "  " -NoNewline
    Write-Host "[OK]" -NoNewline -ForegroundColor Green
    Write-Host " $Message" -ForegroundColor White
}

function Show-Error {
    param([string]$Message)
    Write-Host "  " -NoNewline
    Write-Host "[X]" -NoNewline -ForegroundColor Red
    Write-Host " $Message" -ForegroundColor White
}

function Show-Warning {
    param([string]$Message)
    Write-Host "  " -NoNewline
    Write-Host "[!]" -NoNewline -ForegroundColor Yellow
    Write-Host " $Message" -ForegroundColor White
}

function Show-Info {
    param([string]$Message)
    Write-Host "  " -NoNewline
    Write-Host "[-]" -NoNewline -ForegroundColor Gray
    Write-Host " $Message" -ForegroundColor Gray
}

function Read-HostDefault {
    param(
        [string]$Prompt,
        [string]$Default = ""
    )

    $suffix = if ([string]::IsNullOrWhiteSpace($Default)) { "" } else { " [$Default]" }
    $value = Read-Host "$Prompt$suffix"
    if ([string]::IsNullOrWhiteSpace($value)) {
        return $Default
    }
    return $value
}

function Normalize-PathInput {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $Value }
    return $Value.Trim().Trim('"').Trim("'")
}

function Read-ConfigFile {
    param([string]$Path)

    $config = @{
        CompanyName = ""
        LogoPath = ""
    }

    if (-not (Test-Path $Path)) {
        return $config
    }

    foreach ($line in (Get-Content $Path)) {
        $trim = $line.Trim()
        if ($trim -and -not $trim.StartsWith('#') -and $trim.Contains('=')) {
            $parts = $trim.Split('=', 2)
            $key = $parts[0].Trim()
            $value = $parts[1].Trim()
            switch ($key) {
                "company_name" { $config.CompanyName = $value }
                "logo_path" { $config.LogoPath = $value }
            }
        }
    }

    return $config
}

function Write-ConfigFile {
    param(
        [string]$InstallPath,
        [string]$CompanyName,
        [string]$LogoPath
    )

    $versionValue = ""
    $versionPath = Join-Path $PSScriptRoot "..\VERSION"
    if (Test-Path $versionPath) {
        $versionValue = (Get-Content $versionPath -Raw).Trim()
    }

    $configContent = @"
# Configuration file for Sistema de Proveedores
# Generated by installer
COMPANY_NAME=$CompanyName
LOGO_PATH=$LogoPath
VERSION=$versionValue
"@

    $configDir = Join-Path $InstallPath "config"
    if (-not (Test-Path $configDir)) {
        New-Item -ItemType Directory -Path $configDir -Force | Out-Null
    }
    $configPath = Join-Path $configDir "config.ini"
    $configContent | Out-File -FilePath $configPath -Encoding UTF8
}

function Copy-LogoIfProvided {
    param(
        [string]$InstallPath,
        [string]$LogoPath,
        [string]$BasePath = $null
    )

    if ([string]::IsNullOrWhiteSpace($LogoPath)) {
        return ""
    }

    if ($LogoPath -match '^https?://') {
        return $LogoPath
    }

    $resolvedPath = $LogoPath
    if (-not [string]::IsNullOrWhiteSpace($BasePath) -and -not [System.IO.Path]::IsPathRooted($LogoPath)) {
        $candidate = Join-Path $BasePath $LogoPath
        if (Test-Path $candidate) {
            $resolvedPath = $candidate
        }
    }

    if (Test-Path $resolvedPath) {
        $logoExt = [System.IO.Path]::GetExtension($resolvedPath)
        if ([string]::IsNullOrWhiteSpace($logoExt)) {
            $logoExt = ".png"
        }
        $destName = "logo$logoExt"
        $destPath = Join-Path $InstallPath "api\static\$destName"
        Copy-Item -Path $resolvedPath -Destination $destPath -Force -ErrorAction SilentlyContinue
        return $destName
    }

    return ""
}

function Test-InstallIntegrity {
    param([string]$InstallPath)

    $requiredItems = @(
        "api\app.py",
        "api\database.py",
        "api\models.py",
        "api\init_users.py",
        "api\templates\index.html",
        "api\templates\login.html",
        "api\static\script.js",
        "api\static\style.css",
        "requirements.txt",
        "VERSION",
        "LICENSE",
        "bin\run.bat",
        "utilities\cleanup_installation.ps1",
        "scripts\cleanup_database.py",
        "config\config.ini"
    )

    $missing = @()
    foreach ($item in $requiredItems) {
        $path = Join-Path $InstallPath $item
        if (-not (Test-Path $path)) {
            $missing += $item
        }
    }

    return $missing
}

function Create-DesktopShortcut {
    param(
        [string]$Name,
        [string]$TargetPath,
        [string]$WorkingDirectory,
        [string]$Description
    )

    try {
        $desktop = [Environment]::GetFolderPath('Desktop')
        $shortcutPath = Join-Path $desktop "$Name.lnk"

        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut($shortcutPath)
        $Shortcut.TargetPath = $TargetPath
        $Shortcut.WorkingDirectory = $WorkingDirectory
        $Shortcut.Description = $Description
        $Shortcut.Save()
        return $true
    }
    catch {
        return $false
    }
}

# Create desktop shortcuts for service management
function Create-ServiceShortcuts {
    param(
        [string]$InstallDir
    )
    
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $serviceScript = Join-Path $InstallDir "utilities\service\service.bat"
    
    $shortcuts = @(
        @{
            Name = "Sistema Proveedores - Iniciar Servicio"
            Arguments = "start"
            Description = "Inicia el servicio de Sistema Proveedores"
        },
        @{
            Name = "Sistema Proveedores - Detener Servicio"
            Arguments = "stop"
            Description = "Detiene el servicio de Sistema Proveedores"
        },
        @{
            Name = "Sistema Proveedores - Reiniciar Servicio"
            Arguments = "restart"
            Description = "Reinicia el servicio de Sistema Proveedores"
        },
        @{
            Name = "Sistema Proveedores - Estado del Servicio"
            Arguments = "status"
            Description = "Muestra el estado del servicio de Sistema Proveedores"
        }
    )
    
    $shell = New-Object -ComObject WScript.Shell
    
    foreach ($shortcut in $shortcuts) {
        $shortcutPath = Join-Path $desktopPath "$($shortcut.Name).lnk"
        
        try {
            $shortcutObj = $shell.CreateShortcut($shortcutPath)
            $shortcutObj.TargetPath = $serviceScript
            $shortcutObj.Arguments = $shortcut.Arguments
            $shortcutObj.WorkingDirectory = $InstallDir
            $shortcutObj.Description = $shortcut.Description
            $shortcutObj.IconLocation = "shell32.dll,1"  # Default icon
            $shortcutObj.Save()
            
            Write-Host "  ✓ $($shortcut.Name)" -ForegroundColor Green
        } catch {
            Write-Host "  ✗ $($shortcut.Name) - Error: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
}

function Create-ManualShortcut {
    param(
        [string]$InstallDir
    )
    
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $runScript = Join-Path $InstallDir "run.bat"
    
    $shortcutPath = Join-Path $desktopPath "Sistema Proveedores - Ejecutar Manual.lnk"
    
    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcutObj = $shell.CreateShortcut($shortcutPath)
        $shortcutObj.TargetPath = $runScript
        $shortcutObj.WorkingDirectory = $InstallDir
        $shortcutObj.Description = "Ejecuta el Sistema de Proveedores manualmente"
        $shortcutObj.IconLocation = "shell32.dll,1"  # Default icon
        $shortcutObj.Save()
        
        Write-Host "  ✓ Sistema Proveedores - Ejecutar Manual" -ForegroundColor Green
    } catch {
        Write-Host "  ✗ Sistema Proveedores - Ejecutar Manual - Error: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

function Install-Service {
    param(
        [string]$InstallPath
    )
    
    Write-Host "Instalando servicio de Windows..." -ForegroundColor Gray
    
    $serviceScript = Join-Path $InstallPath "utilities\service\service.ps1"
    if (Test-Path $serviceScript) {
        try {
            # First, try to remove any existing service
            Write-Host "Verificando y removiendo servicio existente..." -ForegroundColor Gray
            $serviceName = "SistemaProveedores"
            
            # Try to stop and remove with sc.exe (with elevation)
            try {
                Start-Process -FilePath "sc.exe" -ArgumentList "stop $serviceName" -Wait -Verb RunAs 2>$null
                Start-Sleep -Seconds 2
                Start-Process -FilePath "sc.exe" -ArgumentList "delete $serviceName" -Wait -Verb RunAs 2>$null
                Write-Host "Servicio existente removido con sc.exe" -ForegroundColor Gray
            } catch {
                # Ignore errors
            }
            
            Start-Sleep -Seconds 2
            
            Write-Host "Ejecutando instalacion del servicio..." -ForegroundColor Gray
            # Run service installation with admin privileges
            # Note: Cannot combine -Verb RunAs with output redirection, so we rely on service script's internal logging
            $serviceResult = Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$serviceScript`" -Action install -ProjectRoot `"$InstallPath`"" -WorkingDirectory $InstallPath -Wait -PassThru -Verb RunAs
            if ($serviceResult.ExitCode -eq 0) {
                Write-Host "Servicio instalado correctamente" -ForegroundColor Green
                $installLog = Join-Path $InstallPath "utilities\logs\service.log"
                if (Test-Path $installLog) {
                    Write-Host "  Log: $installLog" -ForegroundColor Gray
                }
                
                # Start the service with admin privileges
                Write-Host "Iniciando servicio..." -ForegroundColor Gray
                $startResult = Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$serviceScript`" -Action start -ProjectRoot `"$InstallPath`"" -WorkingDirectory $InstallPath -Wait -PassThru -Verb RunAs
                if ($startResult.ExitCode -eq 0) {
                    Write-Host "Servicio iniciado correctamente" -ForegroundColor Green
                    $startLog = Join-Path $InstallPath "utilities\logs\service.log"
                    if (Test-Path $startLog) {
                        Write-Host "  Log: $startLog" -ForegroundColor Gray
                    }
                    
                    # Verify the service is actually running
                    Write-Host "Verificando que el servicio este ejecutandose..." -ForegroundColor Gray
                    Start-Sleep -Seconds 5
                    
                    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
                    if ($service -and $service.Status -eq "Running") {
                        Write-Host "Servicio confirmado ejecutandose" -ForegroundColor Green
                        
                        # Test web service health
                        Write-Host "Verificando conectividad web..." -ForegroundColor Gray
                        try {
                            $webResponse = Invoke-WebRequest -Uri "http://localhost:5000" -TimeoutSec 10 -ErrorAction Stop
                            if ($webResponse.StatusCode -eq 200) {
                                Write-Host "Aplicacion web respondiendo correctamente" -ForegroundColor Green
                                
                                # Create desktop shortcuts
                                Write-Host "Creando accesos directos..." -ForegroundColor Gray
                                Create-ServiceShortcuts -InstallDir $InstallPath
                                
                                return $true
                            } else {
                                Write-Host "Aplicacion web respondio con codigo $($webResponse.StatusCode)" -ForegroundColor Yellow
                                return $false
                            }
                        } catch {
                            Write-Host "Aplicacion web no responde: $($_.Exception.Message)" -ForegroundColor Red
                            return $false
                        }
                    } else {
                        Write-Host "Servicio no esta ejecutandose despues del inicio" -ForegroundColor Red
                        return $false
                    }
                } else {
                    Write-Host "Fallo al iniciar el servicio (codigo: $($startResult.ExitCode))" -ForegroundColor Red
                    Write-Host "  Log: $startLog" -ForegroundColor Yellow
                    return $false
                }
            } else {
                Write-Host "Fallo al instalar el servicio (codigo: $($serviceResult.ExitCode))" -ForegroundColor Red
                # Show the service log contents to help with debugging
                $installLog = Join-Path $InstallPath "utilities\logs\service.log"
                if (Test-Path $installLog) {
                    Write-Host "  Contenido del log de servicio:" -ForegroundColor Yellow
                    Write-Host "  --------------------------------" -ForegroundColor Yellow
                    try {
                        $logContent = Get-Content $installLog -Tail 20  # Show last 20 lines
                        foreach ($line in $logContent) {
                            Write-Host "  $line" -ForegroundColor Gray
                        }
                    } catch {
                        Write-Host "  No se pudo leer el log: $($_.Exception.Message)" -ForegroundColor Red
                    }
                    Write-Host "  --------------------------------" -ForegroundColor Yellow
                    Write-Host "  Log completo: $installLog" -ForegroundColor Yellow
                } else {
                    Write-Host "  Log de servicio no encontrado en: $installLog" -ForegroundColor Red
                }
                return $false
            }
        } catch {
            Write-Host "Error al instalar el servicio: $($_.Exception.Message)" -ForegroundColor Red
            return $false
        }
    } else {
        Write-Host "Script de servicio no encontrado: $serviceScript" -ForegroundColor Red
        return $false
    }
}

# Banner
Write-Host ""
Write-Host "===========================================================" -ForegroundColor Cyan
Write-Host "  SISTEMA DE PROVEEDORES E INVENTARIO v$VERSION" -ForegroundColor Cyan
Write-Host "  Instalacion Automatica con Migracion Inteligente" -ForegroundColor Cyan
Write-Host "===========================================================" -ForegroundColor Cyan
Write-Host ""

# ============================================================
# STEP 1: Verify Python
# ============================================================
Show-Step 1 7 "Verificando Python"

$pythonCmd = $null
$pythonVersions = @("python3", "python")

foreach ($cmd in $pythonVersions) {
    try {
        $versionOutput = & $cmd --version 2>&1
        if ($versionOutput -match "Python 3\.(\d+)\.(\d+)") {
            $major = [int]$Matches[1]
            if ($major -ge $MIN_PYTHON_VERSION[1]) {
                $pythonCmd = $cmd
                Show-Success "Python encontrado: $versionOutput"
                break
            }
        }
    } catch {
        continue
    }
}

if (-not $pythonCmd) {
    Show-Error "Python 3.8+ no encontrado"
    Write-Host ""
    Write-Host "Descarga Python desde: https://www.python.org/downloads/" -ForegroundColor Yellow
    Write-Host "Asegurate de marcar 'Add Python to PATH' durante la instalacion" -ForegroundColor Yellow
    Write-Host ""
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}

# ============================================================
# STEP 2: Get Installation Path
# ============================================================
Show-Step 2 7 "Configuración de Instalación"

# Installation will automatically stop any running instances
Write-Host ""

$defaultPath = "C:\SistemaProveedores"
Write-Host ""
Write-Host "  Ubicacion por defecto: $defaultPath" -ForegroundColor Gray
Write-Host ""
Write-Host "  Presiona ENTER para usar por defecto, o escribe una nueva ruta:" -ForegroundColor White
$installPath = Normalize-PathInput (Read-HostDefault "  " $defaultPath)

# Stop any running instances before installation
Stop-RunningApp -InstallPath $installPath

Show-Info "Instalando en: $installPath"

# ============================================================
# STEP 3: Detect Existing Installation
# ============================================================
Show-Step 3 7 "Detectando Instalación Existente"

$installInfo = Get-InstallationInfo -Path $installPath

if ($installInfo.Exists) {
    Write-Host ""
    Write-Host "  |==================================================|" -ForegroundColor Yellow
    Write-Host "  |  INSTALACION EXISTENTE DETECTADA                 |" -ForegroundColor Yellow
    Write-Host "  |==================================================|" -ForegroundColor Yellow
    Write-Host ""
    Show-Info "Versión detectada: v$($installInfo.Version)"
    Show-Info "Estructura: $($installInfo.Structure)"
    
    if ($installInfo.HasData) {
        $dbSizeKB = [math]::Round($installInfo.DatabaseSize / 1KB, 2)
        $msg = "Base de datos encontrada ($dbSizeKB KB)"
        Show-Success $msg
    }
    
    if ($installInfo.ConfigPath) {
        Show-Success "Configuracion encontrada"
    }
    
    Write-Host ""
    Write-Host "  Se realizara:" -ForegroundColor White
    Show-Info "1. Backup completo automatico"
    Show-Info "2. Instalacion de nueva estructura v$VERSION"
    Show-Info "3. Migracion inteligente de datos"
    Show-Info "4. Inicializacion del sistema"
    Write-Host ""
    Write-Host "  ATENCION: Tus datos NO se perderan - se creara backup" -ForegroundColor Cyan
    Write-Host ""
    
    # Auto-continue after 5 seconds or user input
    Write-Host "  Continuando en 5 segundos (presiona cualquier tecla para continuar ahora)..." -ForegroundColor Gray
    $timeout = 5
    $startTime = Get-Date
    while (((Get-Date) - $startTime).TotalSeconds -lt $timeout) {
        if ([Console]::KeyAvailable) {
            [Console]::ReadKey($true) | Out-Null
            break
        }
        Start-Sleep -Milliseconds 100
    }
    
    # ============================================================
    # STEP 4: Create Backup
    # ============================================================
    Show-Step 4 7 "Creando Backup de Seguridad"
    
    $backup = New-InstallationBackup -InstallPath $installPath -InstallInfo $installInfo
    
    if ($backup.Success) {
        $script:installationChanges.BackupPath = $backup.Path
        Show-Success ("Backup creado: " + (Split-Path $backup.Path -Leaf))
        foreach ($file in $backup.Files) {
            Show-Info $file
        }
    } else {
        Invoke-Rollback "Fallo al crear backup: $($backup.Error)"
    }
    
} else {
    # ============================================================
    # STEP 4: New Installation
    # ============================================================
    Show-Step 4 7 "Preparando Instalación Nueva"
    
    Show-Info "Instalacion nueva (no se encontro instalacion previa)"
    
    # Create directory
    if (-not (Test-Path $installPath)) {
        New-Item -ItemType Directory -Path $installPath -Force | Out-Null
        $script:installationChanges.DirectoriesCreated += $installPath
        Show-Success "Directorio creado: $installPath"
    } else {
        Show-Info "Directorio ya existe"
    }
}

# ============================================================
# Company & Logo Configuration
# ============================================================
$companyName = ""
$logoPath = ""
$useExistingConfig = $false
$existingConfigPath = $null

if ($installInfo.Exists -and $installInfo.ConfigPath) {
    $existingConfigPath = $installInfo.ConfigPath
}

Write-Host ""
Show-Info "Configuracion de empresa"

if ($existingConfigPath -and (Test-Path $existingConfigPath)) {
    $existingConfig = Read-ConfigFile -Path $existingConfigPath
    $existingCompany = $existingConfig.CompanyName
    $existingLogo = $existingConfig.LogoPath

    Write-Host "Se detecto configuracion existente:" -ForegroundColor Yellow
    Write-Host "  Empresa: " -NoNewline -ForegroundColor White
    Write-Host ($(if ($existingCompany) { $existingCompany } else { "(vacio)" })) -ForegroundColor Gray
    Write-Host "  Logo:    " -NoNewline -ForegroundColor White
    Write-Host ($(if ($existingLogo) { $existingLogo } else { "(vacio)" })) -ForegroundColor Gray

    $keepConfig = (Read-HostDefault "Deseas conservarla? (S/N): " "S") -in @('S', 's')

    if ($keepConfig) {
        $companyName = $existingCompany
        $logoPath = $existingLogo
        $useExistingConfig = $true
    }
}

if (-not $useExistingConfig) {
    $companyName = Read-HostDefault "Nombre de tu empresa (opcional, ENTER para omitir)" ""
    Write-Host "Logo de la empresa (opcional):" -ForegroundColor White
    Write-Host "Proporciona la ruta a tu logo (PNG/JPG/SVG)" -ForegroundColor Gray
    Write-Host "Si no tienes uno, presiona ENTER para omitir" -ForegroundColor Gray
    $logoPath = Normalize-PathInput (Read-HostDefault "Ruta completa al logo (o ENTER para omitir)" "")

    if (-not [string]::IsNullOrWhiteSpace($logoPath)) {
        if ($logoPath -match '^https?://') {
            # Keep URL as-is
        } elseif (-not (Test-Path $logoPath)) {
            Write-Host "[ADVERTENCIA] La ruta del logo no existe. Se usara el logo por defecto." -ForegroundColor Yellow
            $logoPath = ""
        }
    }
}

# ============================================================
# STEP 5: Install New Structure
# ============================================================
Show-Step 5 7 "Instalando Estructura Modular"

# Determine source path (current directory or parent)
$currentDir = Get-Location
$parentDir = Split-Path -Parent $PSScriptRoot

$sourcePath = if (Test-Path "$parentDir\api\app.py") {
    $parentDir
} elseif (Test-Path "$currentDir\api\app.py") {
    $currentDir
} else {
    Show-Error "No se encontraron archivos de instalacion"
    Write-Host ""
    Write-Host "Asegurate de ejecutar desde el directorio correcto" -ForegroundColor Yellow
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}

Show-Info "Fuente: $sourcePath"

# Install modular structure
$isUpgrade = [bool]$installInfo.Exists
$install = Install-ModularStructure -SourcePath $sourcePath -DestPath $installPath -IsUpgrade $isUpgrade

if ($install.Success) {
    # Track created directories
    foreach ($dir in $install.DirectoriesCreated) {
        $script:installationChanges.DirectoriesCreated += (Join-Path $installPath $dir)
    }
    Show-Success "$($install.DirectoriesCreated.Count) directorios creados"
    Show-Success "$($install.FilesCopied) archivos copiados"
} else {
    $errors = ($install.Errors -join ", ")
    Invoke-Rollback "Fallo al instalar estructura: $errors"
}

# Configure company name and logo
if ($useExistingConfig -and $existingConfigPath -and (Test-Path $existingConfigPath)) {
    $existingConfig = Read-ConfigFile -Path $existingConfigPath
    $companyName = $existingConfig.CompanyName
    $logoPath = $existingConfig.LogoPath
    $basePath = Split-Path $existingConfigPath -Parent
    $finalLogoPath = Copy-LogoIfProvided -InstallPath $installPath -LogoPath $logoPath -BasePath $basePath
    Write-ConfigFile -InstallPath $installPath -CompanyName $companyName -LogoPath $finalLogoPath
} else {
    $finalLogoPath = Copy-LogoIfProvided -InstallPath $installPath -LogoPath $logoPath
    Write-ConfigFile -InstallPath $installPath -CompanyName $companyName -LogoPath $finalLogoPath
}

# Integrity check
$missingItems = Test-InstallIntegrity -InstallPath $installPath
if ($missingItems.Count -gt 0) {
    Show-Error "Faltan archivos esenciales en la instalacion:"
    foreach ($item in $missingItems) {
        Show-Info $item
    }
    Invoke-Rollback "Instalacion incompleta. Faltan archivos esenciales."
}

# ============================================================
# STEP 6: Initialize System
# ============================================================
Show-Step 6 7 "Inicializando Sistema"
Show-Info "Creando entorno virtual Python..."
$pyEnv = Initialize-PythonEnvironment -InstallPath $installPath -PythonCmd $pythonCmd

if ($pyEnv.Success) {
    Show-Success "Entorno virtual creado"
    Show-Success "Dependencias instaladas"
} else {
    $errors = ($pyEnv.Errors -join ", ")
    Invoke-Rollback "Fallo al crear entorno Python: $errors"
}
Show-Info "Inicializando base de datos..."
$dbInit = Initialize-Database -InstallPath $installPath -CreateDefaultAdmin $true

if ($dbInit.Success) {
    Show-Success "Base de datos inicializada"
    
    if ($dbInit.AdminCreated) {
        Show-Success "Usuario administrador creado"
    }
} else {
    $errors = ($dbInit.Errors -join ", ")
    Invoke-Rollback "Fallo al inicializar base de datos: $errors"
}

# ============================================================
# STEP 7: Migrate Data (if upgrading)
# ============================================================
if ($installInfo.Exists -and $installInfo.HasData) {
    Show-Step 7 7 "Migrando Datos"
    
    Show-Info "Migrando datos desde v$($installInfo.Version)..."
    
    $sourceDb = $installInfo.DatabasePath
    $destDb = Join-Path $installPath "data\suppliers.db"
    
    $pythonExe = Join-Path $installPath "venv\Scripts\python.exe"
    $migration = Invoke-DatabaseMigration -SourceDb $sourceDb -DestDb $destDb -PythonCmd $pythonExe
    
    if ($migration.Success) {
        Show-Success "$($migration.RowsMigrated) registros migrados"
        foreach ($table in $migration.TablesProcessed) {
            Show-Info $table
        }
    } else {
        $errors=($migration.Errors -join ", ")
        Show-Error "Advertencia en migracion: $($errors)"
        Show-Info "Los datos del backup siguen disponibles"
    }
}

# ============================================================
# Installation Complete
# ============================================================

# Cleanup old structure files if this was an upgrade
if ($installInfo.Exists) {
    Write-Host ""
    Show-Info "Se detecto una instalacion previa."

    $doCleanup = (Read-HostDefault "Deseas ejecutar la limpieza de archivos antiguos? (S/N): " "S") -in @('S', 's')

    if ($doCleanup) {
        $removeBackups = (Read-HostDefault "Eliminar respaldos antiguos tambien? (S/N): " "S") -in @('S', 's')

        $cleanupScript = Join-Path (Split-Path $PSScriptRoot -Parent) "utilities\cleanup_installation.ps1"
        if (Test-Path $cleanupScript) {
            Write-Host ""
            Show-Info "Ejecutando utilidad de limpieza..."
            $args = @('-ExecutionPolicy', 'Bypass', '-File', $cleanupScript, '-InstallPath', $installPath, '-SkipSizeScan')
            if ($removeBackups) { $args += '-RemoveBackups' }
            & powershell @args
        }
        else {
            Show-Error "No se encontro la utilidad de limpieza: $cleanupScript"
        }
    }
}

Write-Host ""
Write-Host "===========================================================" -ForegroundColor Green
Write-Host "  OK INSTALACION COMPLETADA EXITOSAMENTE" -ForegroundColor Green
Write-Host "===========================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Ubicacion: $installPath" -ForegroundColor White
Write-Host ""

# ============================================================
# SERVICE SETUP (Optional)
# ============================================================
Write-Host "•••••••••••••••••••••••••••••••••••••••••••••••••••••••••••" -ForegroundColor Cyan
Write-Host "  CONFIGURACION DE SERVICIO WINDOWS (OPCIONAL)" -ForegroundColor Cyan
Write-Host "•••••••••••••••••••••••••••••••••••••••••••••••••••••••••••" -ForegroundColor Cyan
Write-Host ""

Write-Host "El sistema puede ejecutarse como un servicio de Windows que:" -ForegroundColor White
Write-Host "  €¢ Se inicia automaticamente al encender la PC" -ForegroundColor Gray
Write-Host "  €¢ Se reinicia automaticamente si falla" -ForegroundColor Gray
Write-Host "  €¢ Maneja el despertar del modo suspension" -ForegroundColor Gray
Write-Host "  €¢ Se ejecuta de forma invisible en segundo plano" -ForegroundColor Gray
Write-Host ""

$setupService = (Read-HostDefault "Instalar como servicio de Windows? (S/N): " "S") -in @('S', 's')

if ($setupService) {
    Write-Host ""
    Show-Info "Instalando servicio de Windows..."
    
    # Check if running as administrator
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    
    if (-not $isAdmin) {
        Show-Warning "Se requieren permisos de administrador para instalar el servicio"
        Write-Host ""
        $elevate = (Read-HostDefault "Elevar privilegios ahora? (S/N): " "S") -in @('S', 's')
        
        if ($elevate) {
            Write-Host "Solicitando permisos de administrador..." -ForegroundColor Yellow
            
            # Get the current script path and arguments
            $scriptPath = $MyInvocation.MyCommand.Path
            $scriptArgs = "-ServiceInstallOnly -InstallPath `"$installPath`""
            
            try {
                # Restart the script with elevation
                $process = Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$scriptPath`" $scriptArgs" -Verb RunAs -Wait -PassThru
                
                if ($process.ExitCode -eq 0) {
                    Show-Success "Servicio instalado correctamente"
                    $serviceInstalled = $true
                } else {
                    Show-Error "Fallo al instalar el servicio (codigo: $($process.ExitCode))"
                    Show-Info "El resto de la instalacion continuara sin el servicio"
                    $serviceInstalled = $false
                }
            } catch {
                Show-Error "Error al solicitar elevacion: $($_.Exception.Message)"
                Show-Info "El resto de la instalacion continuara sin el servicio"
                $serviceInstalled = $false
            }
        } else {
            Show-Info "Continuando sin instalar el servicio"
            $serviceInstalled = $false
        }
    } else {
        # Already running as admin, install service directly
        $serviceInstalled = Install-Service -InstallPath $installPath
    }

Write-Host ""

# Check if service was installed and show appropriate instructions
$serviceExists = Get-Service -Name "SistemaProveedores" -ErrorAction SilentlyContinue

if ($serviceExists) {
    Write-Host "  Modo de ejecucion: " -NoNewline -ForegroundColor White
    Write-Host "Servicio Windows (Automatico)" -ForegroundColor Green
    Write-Host ""
    Write-Host "  El sistema se ejecuta automaticamente como servicio." -ForegroundColor Gray
    Write-Host "  Usa los accesos directos del escritorio para gestionar el servicio." -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Accesos directos creados:" -ForegroundColor White
    Write-Host "    €¢ Sistema Proveedores - Iniciar Servicio" -ForegroundColor Cyan
    Write-Host "    €¢ Sistema Proveedores - Detener Servicio" -ForegroundColor Cyan
    Write-Host "    €¢ Sistema Proveedores - Reiniciar Servicio" -ForegroundColor Cyan
    Write-Host "    €¢ Sistema Proveedores - Estado del Servicio" -ForegroundColor Cyan
} else {
    Write-Host "  Modo de ejecucion: " -NoNewline -ForegroundColor White
    Write-Host "Manual" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Para iniciar el servicio (manual):" -ForegroundColor White
    Write-Host "    1. Ejecuta: " -NoNewline -ForegroundColor Gray
    Write-Host "run.bat" -ForegroundColor Yellow
    Write-Host "    2. (Opcional) Usa el acceso directo del escritorio" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Creando acceso directo para ejecucion manual..." -ForegroundColor Yellow
    try {
        Create-ManualShortcut -InstallDir $installPath
        Show-Success "Acceso directo creado"
    } catch {
        Show-Warning "No se pudo crear el acceso directo: $($_.Exception.Message)"
    }
}
}

Write-Host "    3. Abre: " -NoNewline -ForegroundColor Gray
Write-Host "http://localhost:5000/login" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Credenciales por defecto:" -ForegroundColor White
Write-Host "    Email:    " -NoNewline -ForegroundColor Gray
Write-Host "admin@proveedores.com" -ForegroundColor Yellow
Write-Host "    Password: " -NoNewline -ForegroundColor Gray
Write-Host "admin123" -ForegroundColor Yellow
Write-Host ""
Write-Host "  ATENCION: Cambia la contrasena despues del primer login" -ForegroundColor Cyan
Write-Host ""

if ($installInfo.Exists) {
    Write-Host "  Backup disponible en:" -ForegroundColor White
    Write-Host ("    " + (Split-Path $backup.Path -Leaf)) -ForegroundColor Gray
    Write-Host ""
}

# Remove obsolete root start.bat if present
$rootStartBat = Join-Path $installPath "start.bat"
if (Test-Path $rootStartBat) {
    Remove-Item $rootStartBat -Force -ErrorAction SilentlyContinue
}

# Remove unused installer copy in bin
$binInstaller = Join-Path $installPath "bin\INSTALAR.bat"
if (Test-Path $binInstaller) {
    Remove-Item $binInstaller -Force -ErrorAction SilentlyContinue
}

# Remove old root run.bat if present
$rootRunBat = Join-Path $installPath "run.bat"
if (Test-Path $rootRunBat) {
    Remove-Item $rootRunBat -Force -ErrorAction SilentlyContinue
}

$createAppShortcut = (Read-HostDefault "Deseas crear/actualizar acceso directo de la aplicacion? (S/N): " "S") -in @('S', 's')
if ($createAppShortcut) {
    $shortcutTarget = Join-Path $installPath "bin\run.bat"
    $desktop = @([Environment]::GetFolderPath('Desktop'))[0]
    $oldLinks = @(
        (Join-Path $desktop "Sistema Proveedores.lnk")
        (Join-Path $desktop "Sistema de Proveedores.lnk")
    )
    foreach ($link in $oldLinks) {
        if (Test-Path $link) { Remove-Item $link -Force -ErrorAction SilentlyContinue }
    }

    if (Create-DesktopShortcut -Name "Sistema Proveedores" -TargetPath $shortcutTarget -WorkingDirectory $installPath -Description "Sistema de Gestion de Proveedores") {
        Show-Success "Acceso directo de la aplicacion creado/actualizado"
    } else {
        Show-Error "No se pudo crear el acceso directo de la aplicacion"
    }
    Write-Host ""
}

$createWebShortcut = (Read-HostDefault "Deseas crear/actualizar acceso directo de la web? (S/N): " "S") -in @('S', 's')
if ($createWebShortcut) {
    $desktop = @([Environment]::GetFolderPath('Desktop'))[0]
    $webShortcut = Join-Path $desktop "Sistema Proveedores Web.url"
    @(
        '[InternetShortcut]',
        'URL=http://localhost:5000/login'
    ) | Out-File -FilePath $webShortcut -Encoding ASCII -Force
    Show-Success "Acceso directo web creado/actualizado"
    Write-Host ""
}

Write-Host "•••••••••••••••••••••••••••••••••••••••••••••••••••••••••••" -ForegroundColor Green
Write-Host ""
Read-HostDefault "Presiona Enter para salir" ""


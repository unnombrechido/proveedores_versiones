# Carga de Datos de Ejemplo

Esta utilidad permite cargar los archivos CSV de ejemplo en la base de datos automáticamente, sin necesidad de usar la interfaz web.

## Archivos Incluidos

- **`load_sample_data.py`** - Script principal de Python
- **`load_sample_data.bat`** - Interfaz interactiva para Windows

## Datos de Ejemplo Disponibles

### 1. Proveedores (`examples/import_proveedores.csv`)
- **9 proveedores** con información completa:
  - ACEROS VELA
  - FERRETERIA Y MATERIALES GONZALEZ
  - PERFILES Y LAMINAS
  - ASH
  - GASES INDUSTRIALES RAFE
  - ELECTRICOS Y LAMPARAS
  - GRUPO FERRETERO
  - TELECOMUNICACIONES Y SEÑALIZACIONES
  - VALVULAS Y CONEXIONES INDUSTRIALES

### 2. Items con Proveedores y Precios (`examples/import_lista_materiales.csv`)
- **58 items/materiales** con códigos MAT-001 a MAT-058
- **Categorías:** Metales, Ferretería, Electricidad, Soldadura, Seguridad, Herramientas
- **Precios** asociados por proveedor
- **7 proveedores únicos** con información de contacto

## Uso

### Opción 1: Interfaz Interactiva (Recomendado)

```batch
cd utilities
load_sample_data.bat
```

Menú interactivo:
1. Cargar TODOS los datos de ejemplo
2. Cargar solo Proveedores (9 proveedores)
3. Cargar solo Items con precios (58 items)
4. LIMPIAR base de datos y cargar todo
5. Salir

### Opción 2: Línea de Comandos

**Cargar todos los datos:**
```bash
python load_sample_data.py
```

**Cargar solo proveedores:**
```bash
python load_sample_data.py --suppliers-only
```

**Cargar solo items con precios:**
```bash
python load_sample_data.py --items-only
```

**Limpiar base de datos y cargar todo:**
```bash
python load_sample_data.py --clean
```

## Comportamiento

### Duplicados
El script **no creará duplicados**:
- Proveedores: Se verifica por nombre
- Items: Se verifica por código de item
- Relaciones proveedor-item: Se verifica si ya existe la relación

Si un proveedor o item ya existe, se omite pero se crea la relación de precio si no existe.

### Limpieza con `--clean`
Cuando se usa la opción `--clean`:
1. Elimina todas las relaciones proveedor-item (precios)
2. Elimina todos los items
3. Elimina todos los proveedores
4. Carga los datos de ejemplo desde cero

⚠️ **ADVERTENCIA:** Esta operación es irreversible. Todos los datos existentes serán eliminados.

## Ejemplos de Salida

### Carga Exitosa
```
============================================================
  CARGA DE DATOS DE EJEMPLO
============================================================

Fecha: 2026-02-04 15:30:00

============================================================
CARGANDO PROVEEDORES
============================================================

Archivo: C:\SistemaProveedores\examples\import_proveedores.csv
Registros encontrados: 9

✓ Proveedores importados: 9

============================================================
CARGANDO ITEMS CON PROVEEDORES Y PRECIOS
============================================================

Archivo: C:\SistemaProveedores\examples\import_lista_materiales.csv
Registros encontrados: 58

✓ Proveedores creados: 7
✓ Items creados: 58
✓ Relaciones proveedor-item creadas: 58

============================================================
RESUMEN FINAL
============================================================

Proveedores totales: 16
Items totales: 58

✓ Carga completada exitosamente!
```

### Con Duplicados
```
✓ Proveedores importados: 3
⊘ Proveedores omitidos (ya existen): 6
```

## Casos de Uso

### 1. Instalación Nueva
Después de instalar el sistema por primera vez:
```bash
cd utilities
load_sample_data.bat
# Seleccionar opción 1: Cargar TODOS los datos
```

### 2. Demo o Pruebas
Para restaurar datos de ejemplo durante demos:
```bash
python load_sample_data.py --clean
```

### 3. Agregar Solo Proveedores
Si solo necesitas los proveedores base:
```bash
python load_sample_data.py --suppliers-only
```

### 4. Agregar Items a Proveedores Existentes
Si ya tienes proveedores y solo quieres agregar items:
```bash
python load_sample_data.py --items-only
```

## Notas Técnicas

### Estructura de Archivos
El script espera encontrar los archivos CSV en:
- `examples/import_proveedores.csv`
- `examples/import_lista_materiales.csv`

### Requisitos
- Python 3.6+
- Entorno virtual activado (recomendado)
- Paquetes: pandas, sqlalchemy (instalados con requirements.txt)

### Compatibilidad
- Funciona tanto con estructura `app/database.py` como con `database.py` directo
- Cambia automáticamente al directorio raíz del proyecto para encontrar `config.ini` y la base de datos
- Compatible con instalaciones de desarrollo y producción

## Solución de Problemas

### Error: "No se pudo encontrar database.py"
- Asegúrate de ejecutar el script desde la carpeta `utilities/`
- Verifica que exista `app/database.py` o `database.py` en el directorio padre

### Error: "No module named 'pandas'"
```bash
# Activa el entorno virtual
venv\Scripts\activate
# O usa el ejecutable del venv directamente
..\venv\Scripts\python.exe load_sample_data.py
```

### Error: "Archivo no encontrado"
- Verifica que existan los archivos en la carpeta `examples/`
- Usa rutas absolutas si es necesario

## Ver También

- [Plantillas CSV](../examples/README.md) - Información sobre formatos de importación
- [Limpieza de Base de Datos](DATABASE_CLEANUP.md) - Utilidad de limpieza
- [Guía de Inicio Rápido](../QUICKSTART.md) - Configuración inicial del sistema

import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

load_dotenv()

Base = declarative_base()

def get_database_url():
    """Generate database URL based on configuration"""
    db_type = os.getenv('DATABASE_TYPE', 'sqlite')
    
    if db_type == 'sqlite':
        # Database is in data/ folder at project root
        api_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(api_dir)
        data_dir = os.path.join(project_root, 'data')
        
        # Ensure data directory exists
        os.makedirs(data_dir, exist_ok=True)
        
        db_name = os.getenv('DATABASE_PATH', 'suppliers.db')
        db_path = os.path.join(data_dir, db_name)
        return f'sqlite:///{db_path}'
    
    elif db_type == 'mysql':
        host = os.getenv('DATABASE_HOST', 'localhost')
        port = os.getenv('DATABASE_PORT', '3306')
        user = os.getenv('DATABASE_USER', 'root')
        password = os.getenv('DATABASE_PASSWORD', '')
        database = os.getenv('DATABASE_NAME', 'proveedores')
        return f'mysql+pymysql://{user}:{password}@{host}:{port}/{database}'
    
    else:
        raise ValueError(f'Unsupported database type: {db_type}')

# Create engine and session
engine = create_engine(get_database_url(), echo=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def init_db():
    """Initialize database tables"""
    # Import models to ensure they're registered with Base
    try:
        import models
    except ImportError:
        # Try relative import if direct import fails
        from . import models
    
    # Get the actual database path for logging
    db_url = get_database_url()
    if db_url.startswith('sqlite:///'):
        db_path = db_url.replace('sqlite:///', '')
        print(f"Creating database at: {db_path}")
    
    # Create all tables
    Base.metadata.create_all(bind=engine)
    
    # Ensure database file is written to disk
    engine.dispose()
    
    # Verify file was created (for SQLite)
    if db_url.startswith('sqlite:///'):
        if os.path.exists(db_path):
            print(f"Database file confirmed at: {db_path}")
            print(f"File size: {os.path.getsize(db_path)} bytes")
        else:
            raise FileNotFoundError(f"Database file was not created at expected path: {db_path}")

def get_db():
    """Get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

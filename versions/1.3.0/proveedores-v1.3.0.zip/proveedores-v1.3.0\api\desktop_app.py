import threading
import time
import os
import sys
import socket
import tempfile
import logging
from logging.handlers import RotatingFileHandler
import configparser

# Add the api directory to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from api.app import app
import webview

def _check_config_debug():
    """Check if debug is enabled in config file"""
    try:
        config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'config.ini')
        if os.path.exists(config_path):
            config = configparser.ConfigParser()
            config.read(config_path)
            if 'COMPANY' in config and config['COMPANY'].get('debug', '').lower() == 'true':
                return True
    except:
        pass
    return False

# Set up logging
DEBUG_MODE = ('--debug' in sys.argv or 
              os.getenv('PROVEEDORES_DEBUG', '').lower() == 'true' or
              _check_config_debug())

log_level = logging.DEBUG if DEBUG_MODE else logging.INFO

# Create logs directory if it doesn't exist
log_dir = os.path.join(os.path.dirname(__file__), '..', 'logs')
os.makedirs(log_dir, exist_ok=True)

# Rotating file handler to prevent logs from growing indefinitely
log_file = os.path.join(log_dir, 'desktop_app.log')
file_handler = RotatingFileHandler(
    log_file,
    maxBytes=5*1024*1024,  # 5MB
    backupCount=3  # Keep 3 backup files
)

logging.basicConfig(
    level=log_level,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        file_handler,
        logging.StreamHandler()
    ] if DEBUG_MODE else [
        file_handler
    ]
)
logger = logging.getLogger(__name__)

def is_port_open(host, port):
    """Check if a port is open on the given host."""
    logger.debug(f"Checking if port {port} is open on {host}")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(1)
        result = sock.connect_ex((host, port))
        is_open = result == 0
        logger.debug(f"Port {port} on {host} is {'open' if is_open else 'closed'}")
        return is_open

def is_app_already_running():
    """Check if another instance of the desktop app is already running using a lock file."""
    lock_file = os.path.join(tempfile.gettempdir(), 'proveedores_desktop_app.lock')
    logger.debug(f"Checking lock file: {lock_file}")

    try:
        # Try to create/open the lock file exclusively
        lock_handle = os.open(lock_file, os.O_CREAT | os.O_EXCL | os.O_RDWR)
        # Write our PID to the lock file
        os.write(lock_handle, str(os.getpid()).encode())
        # Keep the file handle open to maintain the lock
        # Note: We don't close it, so the lock persists until process exit
        logger.info("No other instance running, created lock file")
        return False  # Not already running
    except OSError:
        # Lock file already exists - check if the process is still running
        logger.debug("Lock file exists, checking if process is still running")
        try:
            with open(lock_file, 'r') as f:
                pid_str = f.read().strip()
                if pid_str:
                    try:
                        pid = int(pid_str)
                        # Check if process is running
                        os.kill(pid, 0)  # Signal 0 just checks if process exists
                        logger.info(f"Another instance is running with PID {pid}")
                        return True  # Process is running
                    except (ValueError, OSError):
                        # PID is invalid or process not running
                        logger.debug("PID invalid or process not running, removing stale lock file")
                        pass
            # Remove stale lock file
            os.remove(lock_file)
            logger.info("Removed stale lock file")
        except OSError:
            logger.warning("Could not read or remove lock file")
        # Try again to create the lock file
        try:
            lock_handle = os.open(lock_file, os.O_CREAT | os.O_EXCL | os.O_RDWR)
            os.write(lock_handle, str(os.getpid()).encode())
            logger.info("Created lock file after cleanup")
            return False
        except OSError:
            logger.error("Failed to create lock file even after cleanup")
            return True

def cleanup_lock_file():
    """Clean up the lock file on exit."""
    lock_file = os.path.join(tempfile.gettempdir(), 'proveedores_desktop_app.lock')
    try:
        os.remove(lock_file)
    except OSError:
        pass

def get_server_url():
    """Get the server URL from config or environment variable."""
    # Check environment variable first
    server_url = os.getenv('PROVEEDORES_SERVER_URL')
    if server_url:
        logger.debug(f"Using server URL from environment: {server_url}")
        return server_url

    # Check config file
    config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'config.ini')
    if os.path.exists(config_path):
        logger.debug(f"Reading config from: {config_path}")
        config = configparser.ConfigParser()
        config.read(config_path)
        if 'SERVER' in config and 'url' in config['SERVER']:
            server_url = config['SERVER']['url']
            logger.debug(f"Using server URL from config: {server_url}")
            return server_url
        else:
            logger.debug("No SERVER/url found in config")

    # Default to localhost
    logger.debug("Using default server URL: http://127.0.0.1:5000")
    return 'http://127.0.0.1:5000'

def start_server():
    """Start the Flask server in a separate thread"""
    logger.info("Starting Flask server on 127.0.0.1:5000")
    try:
        app.run(host='127.0.0.1', port=5000, debug=False, use_reloader=False, threaded=True)
    except Exception as e:
        logger.error(f"Failed to start server: {e}")
        raise

def main():
    logger.info("Starting desktop application")
    logger.debug(f"Debug mode: {DEBUG_MODE}")

    # Check if another instance is already running
    if is_app_already_running():
        logger.warning("Another instance of the application is already running")
        print("Another instance of the application is already running.")
        sys.exit(1)

    try:
        server_thread = None
        server_url = get_server_url()
        logger.info(f"Using server URL: {server_url}")

        # Parse server URL to check if it's localhost
        if server_url.startswith('http://127.0.0.1:') or server_url.startswith('http://localhost:'):
            # For localhost, check if server is running
            port = 5000  # Default port
            if ':' in server_url:
                try:
                    port = int(server_url.split(':')[-1])
                except ValueError:
                    pass

            if not is_port_open('127.0.0.1', port):
                logger.info(f"Server not running on localhost:{port}. Starting local server...")
                print(f"Server not running on localhost:{port}. Starting local server...")
                server_thread = threading.Thread(target=start_server, daemon=True)
                server_thread.start()
                # Wait a bit for server to start
                time.sleep(3)
                if not is_port_open('127.0.0.1', port):
                    logger.error("Failed to start local server")
                    print("Failed to start local server.")
                else:
                    logger.info(f"Local server started on localhost:{port}")
                    print(f"Local server started on localhost:{port}")
            else:
                logger.info(f"Server is already running on localhost:{port}")
                print(f"Server is already running on localhost:{port}")
        else:
            logger.info(f"Connecting to remote server: {server_url}")
            print(f"Connecting to remote server: {server_url}")

        # Create the webview window
        logger.info("Creating webview window")
        window = webview.create_window(
            title='Sistema de Gestión de Proveedores',
            url=server_url,
            width=1200,
            height=800,
            resizable=True,
            fullscreen=False,
            frameless=False,  # Keep window borders for minimize/maximize/close buttons
        )

        # Start the webview
        logger.info("Starting webview")
        webview.start()
        logger.info("Webview closed, shutting down")
    except Exception as e:
        logger.error(f"Error in main: {e}")
        raise
    finally:
        # Clean up lock file on exit
        logger.debug("Cleaning up lock file")
        cleanup_lock_file()

if __name__ == '__main__':
    main()
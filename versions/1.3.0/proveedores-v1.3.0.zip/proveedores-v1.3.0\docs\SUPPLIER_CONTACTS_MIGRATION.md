# Supplier Contacts Migration Guide

## Overview
Version 1.3.0 introduces a new `supplier_contacts` table to properly manage multiple contacts per supplier, replacing the single-value legacy fields.

## What Changed

### Before (v1.2.x):
```
suppliers table:
- contact_person: "Juan Pérez"
- phone: "8183518378 / 8183518379"  ❌ Multiple values in one field
- email: "juan@example.com, ventas@example.com"  ❌ Multiple values
```

### After (v1.3.0):
```
supplier_contacts table:
- id: 1
- supplier_id: 1
- contact_name: "Juan Pérez"
- phone: "8183518378"
- is_primary: 1  ✓ Primary contact
- contact_type: "general"

- id: 2
- supplier_id: 1
- contact_name: "Contacto 2"
- phone: "8183518379"
- is_primary: 0
- contact_type: "general"
```

## Migration Process

### Step 1: Backup Database
```powershell
cd C:\Projects\Proveedores\proveedores
copy data\suppliers.db data\suppliers.db.backup_before_contacts_migration
```

### Step 2: Run Migration
```powershell
cd utilities
.\migrate_supplier_contacts.bat
```

Or directly with Python:
```powershell
cd C:\Projects\Proveedores\proveedores
python scripts\migrate_supplier_contacts.py
```

### Step 3: Verify Migration
The script automatically verifies:
- Table created
- All suppliers have at least one contact
- Each supplier has a primary contact
- Multi-value fields properly split

## What the Migration Does

### 1. Creates Table
Creates `supplier_contacts` with columns:
- id, supplier_id, contact_name, position
- phone, email, is_primary, contact_type
- notes, created_at, updated_at

### 2. Parses Multi-Value Fields
Automatically splits fields containing:
- `/` - slash separator
- `,` - comma separator  
- `;` - semicolon separator

Example:
- Input: `"8183518378 / 8183518379"`
- Output: Two separate contact records

### 3. Assigns Contact Types
Intelligently detects contact types from names:
- "compra" → `purchasing` type
- "venta" → `sales` type
- "contab" → `accounting` type
- Default → `general` type

### 4. Sets Primary Contact
First contact is automatically marked as primary (`is_primary = 1`)

### 5. Preserves Legacy Fields
Original fields remain intact for backwards compatibility:
- `suppliers.contact_person`
- `suppliers.phone`
- `suppliers.email`

## New API Endpoints

### Get Supplier Contacts
```
GET /api/suppliers/{supplier_id}/contacts
```

### Create Contact
```
POST /api/suppliers/{supplier_id}/contacts
{
  "contact_name": "María López",
  "position": "Gerente de Ventas",
  "phone": "8183518380",
  "email": "maria@supplier.com",
  "is_primary": false,
  "contact_type": "sales",
  "notes": ""
}
```

### Update Contact
```
PUT /api/suppliers/{supplier_id}/contacts/{contact_id}
{
  "phone": "8183518381",
  "is_primary": true
}
```

### Delete Contact
```
DELETE /api/suppliers/{supplier_id}/contacts/{contact_id}
```
Note: Cannot delete last contact. At least one required.

## UI Changes

### Supplier Edit Form
New "Contacts" section with:
- List of all contacts
- Add/Edit/Delete buttons
- Primary contact indicator (⭐)
- Contact type badges

### Share Order
Contact selection dropdown:
```
Select Contact:
⭐ Juan Pérez (Principal) - 8183518378 - juan@example.com
   María López (Ventas) - 8183518380 - maria@supplier.com
```

## Contact Types
- `general` - General/main contact
- `purchasing` - Purchasing department
- `sales` - Sales representative
- `accounting` - Accounting/billing
- `technical` - Technical support

## Rollback (If Needed)

If migration fails or you need to rollback:

1. Stop the application
2. Restore backup:
```powershell
copy data\suppliers.db.backup_before_contacts_migration data\suppliers.db
```
3. Remove SupplierContact model from code
4. Restart application

## Troubleshooting

### "Table already exists"
If you run migration twice:
```python
# Safe to run - checks if table exists
python scripts\migrate_supplier_contacts.py
```

### "No contacts created"
Check if suppliers table is empty:
```sql
SELECT COUNT(*) FROM suppliers;
```

### "Primary contact missing"
Manually fix:
```sql
UPDATE supplier_contacts 
SET is_primary = 1 
WHERE id = (
    SELECT MIN(id) FROM supplier_contacts 
    WHERE supplier_id = <supplier_id>
);
```

## Testing

After migration, verify:
1. View a supplier - should show contacts tab
2. Create new contact - should appear in list
3. Set different contact as primary - star moves
4. Share order - dropdown shows all contacts
5. Delete non-primary contact - works
6. Try delete last contact - blocked with error

## Notes

- Migration is **idempotent** - safe to run multiple times
- Legacy fields kept for compatibility
- UI automatically uses contacts table
- No code changes needed in other parts
- Minimal downtime (< 10 seconds for 1000 suppliers)

## Support

Issues? Check:
1. Database file path correct
2. Python has write permissions
3. No active database connections
4. Backup exists before migration

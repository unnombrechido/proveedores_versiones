# ============================================================
#  Installation Cleanup Utility
#  Removes old v0.1 files and old backups from v1.0 installation
# ============================================================

param(
    [string]$InstallPath = "C:\SistemaProveedores",
    [switch]$RemoveBackups = $false,
    [switch]$DryRun = $false,
    [switch]$Force = $false,
    [switch]$SkipSizeScan = $false,
    [switch]$CleanupService = $true
)

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  LIMPIEZA DE INSTALACION" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path $InstallPath)) {
    Write-Host "[ERROR] Ruta de instalacion no encontrada: $InstallPath" -ForegroundColor Red
    exit 1
}

Write-Host "[INFO] Analizando: $InstallPath" -ForegroundColor Yellow
Write-Host ""

function Get-FolderSizeSafe {
    param(
        [string]$Path,
        [switch]$Skip
    )

    if ($Skip) {
        return 0
    }

    try {
        $sum = (Get-ChildItem $Path -Recurse -File -Force -Attributes !ReparsePoint -ErrorAction SilentlyContinue |
            Measure-Object -Property Length -Sum).Sum
        if ($null -eq $sum) { $sum = 0 }
        return $sum
    }
    catch {
        return 0
    }
}

# Define old v0.1 files/folders in root that should be removed
$oldFilesToRemove = @(
    "app.py",           # Should be in api/
    "database.py",      # Should be in api/
    "models.py",        # Should be in api/
    "suppliers.db",     # Should be in data/
    "start.bat",        # Old v0.1 launcher
    "config.ini"        # Old v0.1 config
)

$oldFoldersToRemove = @(
    "static",           # Should be in api/
    "templates",        # Should be in api/
    "__pycache__"       # Old Python cache
)

$itemsToRemove = @()
$backupsToRemove = @()
$totalSize = 0

# Service and Process Cleanup
if ($CleanupService) {
    Write-Host "Verificando servicios y procesos en ejecucion..." -ForegroundColor Yellow
    
    # Stop and remove Windows service aggressively
    $serviceName = "SistemaProveedores"
    $serviceFound = $false
    
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        $serviceFound = $true
        Write-Host "  Servicio '$serviceName' encontrado. Deteniendo y removiendo..." -ForegroundColor Cyan
        try {
            Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
            Write-Host "  Servicio detenido normalmente" -ForegroundColor Green
        } catch {
            Write-Host "  Error deteniendo normalmente: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    } else {
        Write-Host "  Servicio '$serviceName' no encontrado en el administrador de servicios" -ForegroundColor Gray
    }
    
    # Try SC delete
    Write-Host "  Intentando remover con SC..." -ForegroundColor Gray
    & sc.exe delete $serviceName 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  [OK] Servicio removido con SC" -ForegroundColor Green
        $serviceFound = $true
    } else {
        Write-Host "  SC delete fallo" -ForegroundColor Yellow
    }
    }
    
    # Kill any stuck Python processes related to the app
    Write-Host "  Buscando procesos Python relacionados..." -ForegroundColor Cyan
    $pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue
    $killedCount = 0
    foreach ($proc in $pythonProcesses) {
        try {
            # Check if the process is running from our install path or has proveedores in path
            $procPath = $proc.Path
            if ($procPath -and ($procPath.StartsWith($InstallPath, [StringComparison]::OrdinalIgnoreCase) -or $procPath -like "*proveedores*")) {
                Write-Host "    Matando proceso Python (PID: $($proc.Id), Path: $($procPath))" -ForegroundColor Yellow
                $proc.Kill()
                $killedCount++
            }
        } catch {
            Write-Host "    [ADVERTENCIA] No se pudo matar proceso $($proc.Id): $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    
    # Also kill CMD processes that might be running the service
    $cmdProcesses = Get-Process -Name "cmd" -ErrorAction SilentlyContinue
    foreach ($proc in $cmdProcesses) {
        try {
            $cmdLine = $proc.CommandLine
            if ($cmdLine -and ($cmdLine -like "*run.bat*" -or $cmdLine -like "*SistemaProveedores*")) {
                Write-Host "    Matando proceso CMD (PID: $($proc.Id))" -ForegroundColor Yellow
                $proc.Kill()
                $killedCount++
            }
        } catch {
            Write-Host "    [ADVERTENCIA] No se pudo matar proceso CMD $($proc.Id): $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    
    if ($killedCount -gt 0) {
        Write-Host "  [OK] $killedCount procesos relacionados terminados" -ForegroundColor Green
    } else {
        Write-Host "  No se encontraron procesos relacionados activos" -ForegroundColor Gray
    }
    
    # Registry cleanup for stubborn services
    Write-Host "  Limpiando entradas de registro..." -ForegroundColor Cyan
    $regPaths = @(
        "HKLM:\SYSTEM\CurrentControlSet\Services\$serviceName",
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\$serviceName"
    )
    
    $regCleaned = 0
    foreach ($regPath in $regPaths) {
        try {
            if (Test-Path $regPath) {
                Remove-Item -Path $regPath -Recurse -Force -ErrorAction Stop
                Write-Host "    [OK] Entrada de registro eliminada: $regPath" -ForegroundColor Green
                $regCleaned++
            }
        } catch {
            Write-Host "    [ADVERTENCIA] No se pudo eliminar entrada de registro $regPath" -ForegroundColor Yellow
        }
    }
    
    if ($regCleaned -eq 0) {
        Write-Host "  No se encontraron entradas de registro problematicas" -ForegroundColor Gray
    }
    
    Write-Host ""
}

# Check for old files
Write-Host "Buscando archivos antiguos de v0.1..." -ForegroundColor Yellow
foreach ($file in $oldFilesToRemove) {
    $filePath = Join-Path $InstallPath $file
    if (Test-Path $filePath) {
        $item = Get-Item $filePath
        $size = $item.Length
        $totalSize += $size
        $itemsToRemove += @{
            Path = $filePath
            Type = "Archivo"
            Name = $file
            Size = $size
        }
        Write-Host "  [X] $file ($([math]::Round($size/1KB, 2)) KB)" -ForegroundColor Red
    }
}

# Check for old folders
foreach ($folder in $oldFoldersToRemove) {
    $folderPath = Join-Path $InstallPath $folder
    if (Test-Path $folderPath) {
        $size = Get-FolderSizeSafe -Path $folderPath -Skip:$SkipSizeScan
        $totalSize += $size
        $itemsToRemove += @{
            Path = $folderPath
            Type = "Carpeta"
            Name = $folder
            Size = $size
        }
        Write-Host "  [X] $folder\ ($([math]::Round($size/1KB, 2)) KB)" -ForegroundColor Red
    }
}

# Check for backup folders
Write-Host ""
Write-Host "Buscando respaldos antiguos..." -ForegroundColor Yellow
$backups = Get-ChildItem $InstallPath -Directory -Filter "backup_*" -ErrorAction SilentlyContinue
$backupSize = 0
foreach ($backup in $backups) {
    $size = Get-FolderSizeSafe -Path $backup.FullName -Skip:$SkipSizeScan
    $backupSize += $size
    $backupsToRemove += @{
        Path = $backup.FullName
        Name = $backup.Name
        Size = $size
        Created = $backup.LastWriteTime
    }
    Write-Host "  [!] $($backup.Name) ($([math]::Round($size/1MB, 2)) MB) - $($backup.LastWriteTime)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan

if ($itemsToRemove.Count -eq 0 -and $backupsToRemove.Count -eq 0) {
    Write-Host "[OK] No se encontraron archivos antiguos para eliminar" -ForegroundColor Green
    Write-Host ""
    exit 0
}

# Summary
Write-Host ""
Write-Host "RESUMEN:" -ForegroundColor Cyan
Write-Host "  Archivos/carpetas antiguos: $($itemsToRemove.Count) ($([math]::Round($totalSize/1KB, 2)) KB)" -ForegroundColor White
Write-Host "  Respaldos: $($backupsToRemove.Count) ($([math]::Round($backupSize/1MB, 2)) MB)" -ForegroundColor White
Write-Host "  Espacio total a liberar: $([math]::Round(($totalSize + $backupSize)/1MB, 2)) MB" -ForegroundColor White
if ($CleanupService) {
    Write-Host "  Limpieza de servicios: Activada" -ForegroundColor White
} else {
    Write-Host "  Limpieza de servicios: Desactivada" -ForegroundColor White
}
Write-Host ""

if ($DryRun) {
    Write-Host "[DRY RUN] No se eliminara nada. Usa -DryRun:`$false para ejecutar." -ForegroundColor Yellow
    Write-Host ""
    exit 0
}

# Confirm
$confirmOld = $false
$confirmBackups = $false

if ($Force) {
    $confirmOld = $itemsToRemove.Count -gt 0
    $confirmBackups = $RemoveBackups -and $backupsToRemove.Count -gt 0
}
else {
    if ($itemsToRemove.Count -gt 0) {
        Write-Host "Deseas eliminar los archivos antiguos de v0.1? (S/N): " -NoNewline -ForegroundColor Yellow
        $response = Read-Host
        $confirmOld = $response -eq 'S' -or $response -eq 's'
    }

    if ($RemoveBackups -and $backupsToRemove.Count -gt 0) {
        Write-Host "Deseas eliminar los respaldos antiguos? (S/N): " -NoNewline -ForegroundColor Yellow
        $response = Read-Host
        $confirmBackups = $response -eq 'S' -or $response -eq 's'
    }
}

Write-Host ""

# Remove old files
if ($confirmOld) {
    Write-Host "Eliminando archivos antiguos..." -ForegroundColor Yellow
    $removed = 0
    foreach ($item in $itemsToRemove) {
        try {
            if (Test-Path $item.Path) {
                Remove-Item $item.Path -Recurse -Force -ErrorAction Stop
                Write-Host "  [OK] Eliminado: $($item.Name)" -ForegroundColor Green
                $removed++
            }
        }
        catch {
            Write-Host "  [ERROR] No se pudo eliminar $($item.Name): $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    Write-Host ""
    Write-Host "[OK] $removed archivos/carpetas eliminados" -ForegroundColor Green
}

# Remove backups
if ($confirmBackups) {
    Write-Host "Eliminando respaldos..." -ForegroundColor Yellow
    $removed = 0
    foreach ($backup in $backupsToRemove) {
        try {
            if (Test-Path $backup.Path) {
                Remove-Item $backup.Path -Recurse -Force -ErrorAction Stop
                Write-Host "  [OK] Eliminado: $($backup.Name)" -ForegroundColor Green
                $removed++
            }
        }
        catch {
            Write-Host "  [ERROR] No se pudo eliminar $($backup.Name): $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    Write-Host ""
    Write-Host "[OK] $removed respaldos eliminados" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "[OK] Limpieza completada" -ForegroundColor Green
if ($CleanupService) {
    Write-Host "[OK] Servicios y procesos relacionados limpiados" -ForegroundColor Green
}
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

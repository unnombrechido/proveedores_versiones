#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Service wrapper for running the Flask application as a Windows service.
This script starts the Flask app in service mode with proper logging.
"""

import sys
import os
import subprocess
import logging
import time
from pathlib import Path

def main():
    """Main entry point for the service wrapper"""
    # Set up logging
    log_dir = Path(__file__).parent.parent / 'logs'
    log_dir.mkdir(exist_ok=True)

    logging.basicConfig(
        filename=log_dir / 'service.log',
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger('ProveedoresService')

    logger.info("Starting Proveedores service wrapper")
    print("Starting Proveedores service wrapper")

    try:
        # Get the Python executable from the virtual environment
        venv_python = Path(__file__).parent.parent / 'venv' / 'Scripts' / 'python.exe'
        if not venv_python.exists():
            # Fallback to system python if venv doesn't exist
            venv_python = sys.executable
            logger.warning(f"Virtual environment Python not found, using system Python: {venv_python}")

        # Get the app.py path
        app_path = Path(__file__).parent / 'app.py'

        if not app_path.exists():
            raise FileNotFoundError(f"Flask app not found at {app_path}")

        # Start the Flask app with --service flag
        cmd = [str(venv_python), str(app_path), '--service']
        logger.info(f"Starting Flask app: {' '.join(cmd)}")

        # Run the subprocess
        process = subprocess.Popen(
            cmd,
            cwd=str(Path(__file__).parent.parent),  # Set working directory to project root
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        )

        logger.info(f"Flask app started with PID: {process.pid}")

        # Monitor the process
        while True:
            if process.poll() is not None:
                # Process has terminated
                stdout, stderr = process.communicate()
                logger.error(f"Flask app terminated unexpectedly. Exit code: {process.returncode}")
                if stdout:
                    logger.error(f"STDOUT: {stdout.decode(errors='ignore')}")
                if stderr:
                    logger.error(f"STDERR: {stderr.decode(errors='ignore')}")
                break

            time.sleep(1)

    except Exception as e:
        logger.error(f"Failed to start Flask app: {str(e)}")
        print(f"Failed to start Flask app: {str(e)}")
        raise

if __name__ == '__main__':
    main()
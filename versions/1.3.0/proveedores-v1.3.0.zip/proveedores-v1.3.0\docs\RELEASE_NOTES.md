# Release Notes - Sistema de Gestión de Proveedores v1.3.0

**Fecha de lanzamiento:** Febrero 2026  
**Versión:** 1.3.0  
**Tipo:** Feature Release

---

## 🎉 Novedades en la versión 1.3.0

### 🔧 Arquitectura Cliente-Servidor
- **Servidor independiente**: El backend ahora se ejecuta como servicio de Windows independiente
- **Prevención de instancias múltiples**: Solo una instancia de la aplicación puede ejecutarse simultáneamente
- **Cliente de escritorio mejorado**: Interfaz nativa que se conecta al servidor de servicio

### 🌐 Acceso Multi-Dispositivo
- **Acceso web universal**: Cualquier dispositivo con navegador puede acceder al sistema
- **Red local**: PCs, tablets y móviles en la misma red pueden conectarse
- **Configuración de servidor remoto**: Soporte para URLs de servidor personalizables
- **Cliente web completo**: Funcionalidad completa desde el navegador

### ⚙️ Mejoras de Configuración
- **Configuración estructurada**: Archivo `config.ini` con secciones `[COMPANY]` y `[SERVER]`
- **URL de servidor configurable**: Permite conexiones a servidores remotos
- **Instalador inteligente**: Detecta y preserva configuraciones existentes

### 🔒 Mejoras de Estabilidad
- **Servicio robusto**: El servidor se mantiene ejecutando independientemente de la UI
- **Gestión de procesos**: Prevención de conflictos entre múltiples instancias
- **Logging mejorado**: Mejor seguimiento de operaciones del servicio

---

# Release Notes - Sistema de Gestión de Proveedores v1.0

**Fecha de lanzamiento:** Febrero 2026  
**Versión:** 1.0  
**Tipo:** Major Release

---

## 🎉 Bienvenido a la versión 1.0

Esta es la primera versión estable del Sistema de Gestión de Proveedores e Inventario. Un sistema web completo y profesional diseñado para facilitar la gestión de proveedores, items/materiales y órdenes de compra.

**Actualización desde v0.1:** Si ya tienes instalada la v0.1, consulta [PATCH_v0.1.md](PATCH_v0.1.md) para actualizar.

---

## ✨ Lo Nuevo en Esta Versión

### 🚀 Instaladores Mejorados
- **INSTALAR.bat** - Instalador recomendado que evita problemas de permisos
- **setup-complete.ps1** - Instalador completo con configuración avanzada
- **install.bat** - Instalador para Windows (CMD)
- **install.ps1** - Instalador para Windows (PowerShell)
- **install.sh** - Instalador para Linux/Mac
- Verificación automática de Python y dependencias
- Creación automática de entorno virtual
- Instalación de todas las dependencias
- Inicialización de base de datos
- **Actualización automática del esquema de base de datos** durante upgrades
- Generación de scripts de inicio rápido
- Preservación de config.ini durante actualizaciones

### 🛠️ Utilidades de Mantenimiento (NUEVO)
- **Database Cleanup Utility** - Limpieza de base de datos corrupta
  - Interfaz interactiva: `utilities/cleanup_database.bat`
  - Respaldos automáticos antes de limpiar
  - Limpieza selectiva (proveedores, items, precios, órdenes)
  - Limpieza completa con recreación de tablas
  - Visor de estado de la base de datos
- **Sample Data Loader** - Carga automática de datos de ejemplo
  - Interfaz interactiva: `utilities/load_sample_data.bat`
  - 9 proveedores de ejemplo con información completa
  - 58 items/materiales con categorías y precios
  - Detección automática de duplicados
  - Opción de limpieza antes de cargar
  
### 🎨 Mejoras de UI/UX (NUEVO)
- **Logo Configurable** - Logo personalizado desde config.ini
  - Soporte para archivos locales y URLs
  - Placeholder cuando no hay logo
  - Carga dinámica desde configuración del servidor
- **Modal de Importación Mejorado**
  - Botones pre-seleccionan el tipo correcto
  - "Importar Items" abre con tipo items seleccionado
  - "Importar Proveedores" abre con tipo proveedores seleccionado
  - Instrucciones contextuales según el tipo
- **Configuración Persistente**
  - Nombre de empresa guardado en servidor (config.ini)
  - Ruta de logo configurable
  - API endpoints para GET/POST configuración

### 📥 Importación Mejorada (NUEVO)
- **Soporte CSV para Items con Proveedores**
  - Antes solo soportaba Excel multi-hoja
  - Ahora acepta CSV con formato simplificado
  - Endpoint: `/api/suppliers/import/with-items`
  - Importa proveedores + items + precios en un solo archivo
- **Plantillas CSV Incluidas**
  - `examples/template_suppliers.csv` - Solo proveedores
  - `examples/template_items.csv` - Solo items
  - `examples/template_suppliers_items_prices.csv` - Combinado
  - `examples/README.md` - Documentación completa de plantillas
- **Datos de Ejemplo Listos**
  - `examples/import_proveedores.csv` - 9 proveedores reales
  - `examples/import_lista_materiales.csv` - 58 items con precios

### 📦 Gestión de Inventario
- Catálogo completo de items con búsqueda instantánea
- Múltiples proveedores por item con precios individuales
- Códigos SKU/SDK con consolidación automática
- 8 categorías de items predefinidas
- 10 unidades de medida estándar
- Edición inline con modales intuitivos
- Importación/Exportación CSV y Excel mejorada

### 👥 Gestión de Proveedores
- CRUD completo (Crear, Leer, Actualizar, Eliminar)
- Información detallada: contacto, dirección, calificación
- Búsqueda avanzada con filtros múltiples
- Sistema de calificación de 1-5 estrellas
- Vista de catálogo por proveedor
- Importación/Exportación de datos mejorada

### 💰 Gestión de Precios
- Página dedicada para relaciones proveedor-item-precio
- Filtros por estado (Activas/Disponibles)
- Filtros por categoría de item
- Filtros por ciudad del proveedor
- Agregar/Editar/Eliminar precios fácilmente
- Vista consolidada de todos los precios

### 🔍 Búsqueda Inteligente
- Búsqueda de items con selección múltiple
- Identificación automática de proveedores comunes
- Badge visual de "Mejor Precio"
- Creación optimizada de órdenes
- División inteligente cuando se requieren múltiples proveedores
- Filtros avanzados y ordenamiento

### 📋 Gestión de Órdenes
- Creación desde múltiples puntos del sistema
- Modal avanzado con selección de items
- Cálculo automático de totales y subtotales
- 5 estados: Pendiente, Confirmada, Enviada, Entregada, Cancelada
- Vista detallada con modal
- Edición de estado inline
- Impresión optimizada:
  - Ventana de impresión en escritorio
  - Botón compartir en móviles (WhatsApp, Email, etc.)
  - Formato profesional con detalles completos

### 🎨 Interfaz de Usuario
- Diseño responsive (escritorio, tablet, móvil)
- Tema morado profesional (#667eea)
- Sidebar con navegación clara
- Iconos intuitivos con tooltips
- Notificaciones toast personalizadas (no alerts)
- Modales de confirmación profesionales
- Animaciones y transiciones suaves

### 🌐 API REST
- 30+ endpoints RESTful
- CRUD completo para todas las entidades
- Endpoints especializados:
  - GET/PUT para estado de órdenes
  - GET para items por proveedor
  - GET para proveedores por item
  - POST/PUT/DELETE para relaciones proveedor-item
- Respuestas JSON estructuradas
- Manejo de errores consistente

### 💾 Base de Datos
- SQLite por defecto (cero configuración)
- Soporte opcional para MySQL/MariaDB
- 4 tablas principales:
  - suppliers (proveedores)
  - items (materiales/productos)
  - supplier_items (relaciones con precios)
  - orders (órdenes de compra)
- Auto-migraciones al iniciar
- Relaciones many-to-many
- Índices optimizados

### 📊 Importación/Exportación
- Importar proveedores: CSV, Excel (.xlsx, .xls, .xlsm)
- Importar items: CSV, Excel con relaciones automáticas
- Exportar proveedores: CSV, Excel
- Exportar items: CSV, Excel
- Validación robusta de datos
- Prevención automática de duplicados
- Mensajes de error detallados

### 🌍 Despliegue
- Documentación completa para Cloudflare Tunnel
- Guías para ngrok
- Instrucciones para VPS (producción)
- Configuración de firewall Windows
- Ejemplos con Gunicorn

---

## 🔧 Aspectos Técnicos

### Stack Tecnológico
- **Backend**: Flask 3.0.0
- **ORM**: SQLAlchemy 2.0.46
- **Base de Datos**: SQLite (default) / MySQL (opcional)
- **Frontend**: Vanilla JavaScript ES6+
- **Procesamiento de datos**: pandas 3.0.0
- **Excel**: openpyxl 3.1.5
- **Estilos**: CSS3 con variables y animaciones

### Estructura del Proyecto
```
proveedores/
├── app.py              (1155 líneas - API REST)
├── database.py         (80 líneas - Configuración DB)
├── models.py           (177 líneas - Modelos ORM)
├── static/
│   ├── script.js       (3000+ líneas - Lógica frontend)
│   └── style.css       (1069 líneas - Estilos)
├── templates/
│   └── index.html      (473 líneas - SPA)
├── install.bat         (Instalador Windows)
├── install.ps1         (Instalador PowerShell)
├── install.sh          (Instalador Linux/Mac)
├── requirements.txt    (Dependencias)
├── VERSION             (0.1)
└── README.md           (Documentación completa)
```

### Dependencias Principales
```
Flask==3.0.0
SQLAlchemy==2.0.46
pandas==3.0.0
openpyxl==3.1.5
pymysql==1.1.1
python-dotenv==1.0.0
```

---

## 📖 Documentación

### Instalación
Ver [README.md](README.md) sección "Instalación Automática"

**Instalación rápida:**
```bash
# Windows
install.bat
start.bat

# Linux/Mac
chmod +x install.sh
./install.sh
./start.sh
```

### Configuración
- SQLite: Sin configuración necesaria
- MySQL: Crear archivo `.env` (ver README)
- Firewall: Configurar puerto 5000 (ver Troubleshooting)

### Uso
Ver [README.md](README.md) sección "Guía de Uso" para tutoriales detallados de cada módulo.

---

## 🐛 Problemas Conocidos

Ninguno reportado en esta versión inicial.

---

## 🔜 Próximas Versiones

### Planeado para v0.2
- Dashboard con estadísticas y gráficos
- Exportación de órdenes a PDF
- Sistema de usuarios y permisos
- Historial de cambios (audit log)
- Notificaciones por email
- Integración con APIs de proveedores

### Considerando para futuro
- PWA (Progressive Web App)
- Modo offline
- Sincronización multi-dispositivo
- Aplicación móvil nativa
- Reportes personalizables
- Integración con sistemas contables

---

## 📞 Soporte

- 📧 Email: support@example.com
- 📚 Documentación: README.md
- 🐛 Reportar bugs: GitHub Issues
- 💬 Preguntas: GitHub Discussions

---

## 🙏 Agradecimientos

Gracias a:
- Flask Framework team
- SQLAlchemy contributors
- Pandas developers
- OpenPyXL maintainers
- Cloudflare Tunnel team
- Toda la comunidad open source

---

## 📝 Notas de Actualización

### Desde ninguna versión anterior (Primera instalación)
1. Ejecuta el instalador correspondiente a tu sistema operativo
2. El sistema se configurará automáticamente
3. Usa `start.bat` o `start.sh` para iniciar
4. Accede a http://localhost:5000

### Migración de datos
No aplica para esta versión inicial.

---

**¡Gracias por usar el Sistema de Gestión de Proveedores!**

Desarrollado con ❤️ - Febrero 2026

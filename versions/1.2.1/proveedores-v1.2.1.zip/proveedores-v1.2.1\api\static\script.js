// API Base URL
const API_BASE = '/api';

// Global state
let suppliers = [];
let orders = [];
let items = [];
let currentPriceItem = null; // For price management page
let allPriceSuppliersData = []; // All suppliers for filtering
let currentUser = null; // Current authenticated user
let currentUserId = null; // For editing users
let aboutInfoCache = null;

// Check authentication on page load
document.addEventListener('DOMContentLoaded', async () => {
    await checkAuth();
    loadInitialData();
});

// Authentication Functions
async function checkAuth() {
    try {
        const response = await fetch(`${API_BASE}/auth/check`);
        const data = await response.json();
        
        if (!data.authenticated) {
            window.location.href = '/login';
            return;
        }
        
        currentUser = data.user;
        updateUIForUser(currentUser);
    } catch (error) {
        console.error('Auth check error:', error);
        window.location.href = '/login';
    }
}

function updateUIForUser(user) {
    // Update user info in sidebar
    document.getElementById('current-user-name').textContent = `${user.nombre} ${user.apellido}`;
    document.getElementById('current-user-role').textContent = `Rol: ${user.rol}`;
    
    // Show/hide navigation items based on role
    const userManagementNav = document.getElementById('user-management-nav');
    
    if (user.rol === 'sysadmin') {
        userManagementNav.style.display = 'block';
    } else if (user.rol === 'admin') {
        userManagementNav.style.display = 'none';
    } else if (user.rol === 'compras') {
        userManagementNav.style.display = 'none';
        
        // Hide management navigation buttons for compras role
        const inventoryNav = document.querySelector('[onclick="showSection(\'inventory\')"]');
        const vendorsNav = document.querySelector('[onclick="showSection(\'vendors\')"]');
        if (inventoryNav) inventoryNav.style.display = 'none';
        if (vendorsNav) vendorsNav.style.display = 'none';
    }
    
    // Apply permission-based restrictions
    applyPermissionRestrictions(user.rol);
}

function applyPermissionRestrictions(rol) {
    // Hide all buttons with data-permission="edit" for compras users
    if (rol === 'compras') {
        const restrictedButtons = document.querySelectorAll('[data-permission="edit"]');
        restrictedButtons.forEach(button => {
            button.style.display = 'none';
        });
        
        // Also disable edit/delete actions in tables
        hideTableActions();
    }
}

function hideTableActions() {
    // This will hide edit/delete buttons in inventory and vendor tables
    // Will be called after tables are loaded
    const editButtons = document.querySelectorAll('button[onclick*="edit"], button[onclick*="Edit"]');
    const deleteButtons = document.querySelectorAll('button[onclick*="delete"], button[onclick*="Delete"]');
    
    editButtons.forEach(btn => {
        if (currentUser && currentUser.rol === 'compras') {
            // Check if it's not an order-related button
            const onclick = btn.getAttribute('onclick') || '';
            if (!onclick.includes('Order') && !onclick.includes('order')) {
                btn.style.display = 'none';
            }
        }
    });
    
    deleteButtons.forEach(btn => {
        if (currentUser && currentUser.rol === 'compras') {
            const onclick = btn.getAttribute('onclick') || '';
            if (!onclick.includes('Order') && !onclick.includes('order')) {
                btn.style.display = 'none';
            }
        }
    });
}

async function logout() {
    try {
        await fetch(`${API_BASE}/auth/logout`, { method: 'POST' });
        window.location.href = '/login';
    } catch (error) {
        console.error('Logout error:', error);
        window.location.href = '/login';
    }
}

// User Management Functions
async function loadUsers() {
    if (!currentUser || currentUser.rol !== 'sysadmin') {
        return;
    }
    
    try {
        const search = document.getElementById('users-search').value;
        const rol = document.getElementById('role-filter').value;
        const status = document.getElementById('status-filter').value;
        
        let url = `${API_BASE}/users?`;
        if (search) url += `search=${encodeURIComponent(search)}&`;
        if (rol) url += `rol=${rol}&`;
        if (status) url += `status=${status}&`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            displayUsers(data.users);
        }
    } catch (error) {
        console.error('Error loading users:', error);
        showNotification('Error al cargar usuarios', 'error');
    }
}

function displayUsers(users) {
    const tbody = document.getElementById('users-tbody');
    tbody.innerHTML = '';
    
    users.forEach(user => {
        const tr = document.createElement('tr');
        const statusBadge = user.status === 'activo' 
            ? '<span style="color: green;">●</span> Activo' 
            : '<span style="color: red;">●</span> Inactivo';
        
        const roleBadge = {
            'sysadmin': '👑 Sysadmin',
            'admin': '⭐ Admin',
            'compras': '📦 Compras'
        }[user.rol] || user.rol;
        
        tr.innerHTML = `
            <td>${user.email}</td>
            <td>${user.nombre}</td>
            <td>${user.apellido}</td>
            <td>${user.telefono || '-'}</td>
            <td>${roleBadge}</td>
            <td>${statusBadge}</td>
            <td>${new Date(user.fecha_registro).toLocaleDateString()}</td>
            <td>
                <button class="btn btn-sm" onclick="editUser(${user.id})">✏️ Editar</button>
                <button class="btn btn-sm" onclick="changeUserPassword(${user.id})">🔑 Cambiar Contraseña</button>
                ${user.id !== currentUser.id ? `<button class="btn btn-sm btn-danger" onclick="deleteUser(${user.id})">🗑️ Eliminar</button>` : ''}
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function openUserModal(userId = null) {
    currentUserId = userId;
    const modal = document.getElementById('user-modal');
    const title = document.getElementById('user-modal-title');
    const form = document.getElementById('user-form');
    
    form.reset();
    
    if (userId) {
        title.textContent = 'Editar Usuario';
        document.getElementById('user-password').required = false;
        document.querySelector('label[for="user-password"] small').textContent = '(dejar vacío para mantener actual)';
        loadUserData(userId);
    } else {
        title.textContent = 'Nuevo Usuario';
        document.getElementById('user-password').required = true;
        document.querySelector('label[for="user-password"] small').textContent = '';
    }
    
    modal.style.display = 'block';
}

async function loadUserData(userId) {
    try {
        const response = await fetch(`${API_BASE}/users/${userId}`);
        const data = await response.json();
        
        if (data.success) {
            const user = data.user;
            document.getElementById('user-email').value = user.email;
            document.getElementById('user-nombre').value = user.nombre;
            document.getElementById('user-apellido').value = user.apellido;
            document.getElementById('user-telefono').value = user.telefono || '';
            document.getElementById('user-rol').value = user.rol;
            document.getElementById('user-status').value = user.status;
        }
    } catch (error) {
        console.error('Error loading user:', error);
        showNotification('Error al cargar usuario', 'error');
    }
}

async function saveUser(event) {
    event.preventDefault();
    
    const userData = {
        email: document.getElementById('user-email').value,
        nombre: document.getElementById('user-nombre').value,
        apellido: document.getElementById('user-apellido').value,
        telefono: document.getElementById('user-telefono').value,
        rol: document.getElementById('user-rol').value,
        status: document.getElementById('user-status').value
    };
    
    const password = document.getElementById('user-password').value;
    if (password) {
        userData.password = password;
    }
    
    try {
        let response;
        if (currentUserId) {
            response = await fetch(`${API_BASE}/users/${currentUserId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
        } else {
            response = await fetch(`${API_BASE}/users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
        }
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(data.message, 'success');
            closeUserModal();
            loadUsers();
        } else {
            showNotification(data.error, 'error');
        }
    } catch (error) {
        console.error('Error saving user:', error);
        showNotification('Error al guardar usuario', 'error');
    }
}

async function editUser(userId) {
    openUserModal(userId);
}

async function changeUserPassword(userId) {
    const newPassword = prompt('Ingrese la nueva contraseña (mínimo 6 caracteres):');
    
    if (!newPassword) return;
    
    if (newPassword.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/users/${userId}/password`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ new_password: newPassword })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Contraseña actualizada exitosamente', 'success');
        } else {
            showNotification(data.error, 'error');
        }
    } catch (error) {
        console.error('Error changing password:', error);
        showNotification('Error al cambiar contraseña', 'error');
    }
}

async function deleteUser(userId) {
    if (!confirm('¿Está seguro de eliminar este usuario? Esta acción no se puede deshacer.')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/users/${userId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Usuario eliminado exitosamente', 'success');
            loadUsers();
        } else {
            showNotification(data.error, 'error');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        showNotification('Error al eliminar usuario', 'error');
    }
}

function closeUserModal() {
    document.getElementById('user-modal').style.display = 'none';
    currentUserId = null;
}

// Notification helper function
function showNotification(message, type = 'info') {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('notification-toast');
    if (!notification) {
        notification = document.createElement('div');
        notification.id = 'notification-toast';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            z-index: 10000;
            box-shadow: 0 4px 6px rgba(0,0,0,0.2);
            max-width: 400px;
            animation: slideIn 0.3s ease-out;
        `;
        document.body.appendChild(notification);
    }
    
    // Set color based on type
    const colors = {
        'success': '#28a745',
        'error': '#dc3545',
        'warning': '#ffc107',
        'info': '#17a2b8'
    };
    
    notification.style.backgroundColor = colors[type] || colors['info'];
    notification.textContent = message;
    notification.style.display = 'block';
    
    // Auto-hide after 4 seconds
    setTimeout(() => {
        notification.style.display = 'none';
    }, 4000);
}

function loadInitialData() {
    // Load database info, company name, etc.
    loadDatabaseInfo();
    loadCompanyName();
    showSection('search-items'); // Show first section by default
    
    // Enter key search for items
    const itemsSearch = document.getElementById('items-search');
    if (itemsSearch) {
        itemsSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchItems();
            }
        });
    }
}

// Predefined Lists
const ITEM_CATEGORIES = [
    'General',
    'Materiales de Construcción',
    'Herramientas',
    'Equipos',
    'Consumibles',
    'Ferretería',
    'Eléctricos',
    'Plomería',
    'Pinturas y Acabados',
    'Seguridad Industrial',
    'Oficina',
    'Otro'
];

const UNITS_OF_MEASURE = [
    'Pieza (pza)',
    'Kilogramo (kg)',
    'Gramo (g)',
    'Litro (L)',
    'Mililitro (mL)',
    'Metro (m)',
    'Centímetro (cm)',
    'Metro cuadrado (m²)',
    'Metro cúbico (m³)',
    'Caja',
    'Paquete',
    'Rollo',
    'Galón',
    'Saco',
    'Tonelada (ton)',
    'Par',
    'Juego',
    'Otro'
];

// Utility Functions
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Initialize on page load
// This DOMContentLoaded is now handled at the top of the file with authentication check
// Moved to loadInitialData() function

// Predefined Lists// Company Name Management
function loadCompanyName() {
    // Load from server config.ini
    fetch('/api/config')
        .then(response => response.json())
        .then(data => {
            const input = document.getElementById('company-name');
            if (input) {
                input.value = data.companyName || 'Mi Empresa';
            }
            
            // Load logo if path is provided
            if (data.logoPath && data.logoPath.trim()) {
                const logoImg = document.getElementById('company-logo');
                const logoPlaceholder = document.getElementById('logo-placeholder');
                if (logoImg) {
                    let logoUrl = data.logoPath.trim();
                    
                    // If it's not an absolute URL, treat it as a static file path
                    if (!logoUrl.startsWith('http://') && !logoUrl.startsWith('https://') && !logoUrl.startsWith('/')) {
                        // Assume it's in the static folder
                        logoUrl = '/static/' + logoUrl;
                    }
                    
                    logoImg.src = logoUrl;
                    logoImg.style.display = 'block';
                    if (logoPlaceholder) {
                        logoPlaceholder.style.display = 'none';
                    }
                }
            }
        })
        .catch(error => {
            console.error('Error loading company name:', error);
            // Fallback to default
            const input = document.getElementById('company-name');
            if (input) {
                input.value = 'Mi Empresa';
            }
        });
}

function saveCompanyName() {
    const input = document.getElementById('company-name');
    if (input && input.value.trim()) {
        const companyName = input.value.trim();
        
        // Save to server config.ini
        fetch('/api/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                companyName: companyName,
                logoPath: '' // Logo path can be added later
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Company name saved successfully');
            } else {
                console.error('Error saving company name:', data.error);
            }
        })
        .catch(error => {
            console.error('Error saving company name:', error);
        });
    }
}

async function loadAboutInfo() {
    if (aboutInfoCache) {
        renderAboutInfo(aboutInfoCache);
        return;
    }

    try {
        const response = await fetch('/api/about');
        const data = await response.json();
        aboutInfoCache = data;
        renderAboutInfo(data);
    } catch (error) {
        console.error('Error loading about info:', error);
    }
}

function renderAboutInfo(data) {
    const versionBadge = document.getElementById('about-version');
    const developer = document.getElementById('about-developer');
    const releaseNotes = document.getElementById('about-release-notes');
    const licenseLink = document.getElementById('about-license');

    if (versionBadge) {
        versionBadge.textContent = `Versión: ${data.version || '-'}`;
    }
    if (developer) {
        developer.textContent = data.developer || '-';
    }
    if (releaseNotes) {
        if (data.hasReleaseNotes) {
            releaseNotes.href = data.releaseNotesUrl || '#';
            releaseNotes.style.pointerEvents = 'auto';
            releaseNotes.style.opacity = '1';
        } else {
            releaseNotes.href = '#';
            releaseNotes.style.pointerEvents = 'none';
            releaseNotes.style.opacity = '0.5';
        }
    }
    if (licenseLink) {
        if (data.hasLicense) {
            licenseLink.href = data.licenseUrl || '#';
            licenseLink.style.pointerEvents = 'auto';
            licenseLink.style.opacity = '1';
        } else {
            licenseLink.href = '#';
            licenseLink.style.pointerEvents = 'none';
            licenseLink.style.opacity = '0.5';
        }
    }
}

async function toggleLicense() {
    const licensePre = document.getElementById('about-license-text');
    if (!licensePre) return;

    const isHidden = licensePre.style.display === 'none' || licensePre.style.display === '';
    if (isHidden) {
        if (!licensePre.textContent.trim()) {
            try {
                if (!aboutInfoCache) {
                    const aboutResponse = await fetch('/api/about');
                    aboutInfoCache = await aboutResponse.json();
                    renderAboutInfo(aboutInfoCache);
                }
                const licenseUrl = aboutInfoCache?.licenseUrl;
                if (licenseUrl) {
                    const response = await fetch(licenseUrl);
                    licensePre.textContent = await response.text();
                }
            } catch (error) {
                console.error('Error loading license:', error);
                licensePre.textContent = 'No se pudo cargar la licencia.';
            }
        }
        licensePre.style.display = 'block';
    } else {
        licensePre.style.display = 'none';
    }
}

// Section Navigation
function showSection(sectionName) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Remove active from all nav items
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Show selected section
    const section = document.getElementById(sectionName + '-section');
    if (section) {
        section.classList.add('active');
    }
    
    // Set active nav item - find the button that was clicked or matches the section
    if (window.event && window.event.target) {
        const target = window.event.target;
        const clickedButton = target.classList?.contains('nav-item') 
            ? target 
            : (target.closest ? target.closest('.nav-item') : target.parentElement?.closest('.nav-item'));
        if (clickedButton) {
            clickedButton.classList.add('active');
        }
    } else {
        // If called programmatically, find the matching nav button
        const navButtons = document.querySelectorAll('.nav-item');
        navButtons.forEach(button => {
            const onclick = button.getAttribute('onclick');
            if (onclick && onclick.includes(sectionName)) {
                button.classList.add('active');
            }
        });
    }
    
    // Update section title
    const titles = {
        'search-items': 'Buscar Items',
        'search-vendors': 'Buscar Proveedores',
        'inventory': 'Gestión de Inventario',
        'vendors': 'Gestión de Proveedores',
        'orders': 'Gestión de Órdenes',
        'price-management': 'Gestión de Precios',
        'users': 'Gestión de Usuarios',
        'about': 'Acerca de'
    };
    const sectionTitle = document.getElementById('section-title');
    if (sectionTitle) {
        sectionTitle.textContent = titles[sectionName] || '';
    }
    
    // Load data when switching sections
    if (sectionName === 'users') {
        loadUsers();
    }
    // Load data for section
    if (sectionName === 'inventory') {
        loadInventory();
    } else if (sectionName === 'vendors') {
        loadSuppliers();
        loadCategories();
        loadCountries();
    } else if (sectionName === 'orders') {
        loadOrders();
        loadSuppliersForDropdown();
    } else if (sectionName === 'price-management') {
        if (currentPriceItem) {
            loadPriceManagement(currentPriceItem.id);
        }
    } else if (sectionName === 'about') {
        loadAboutInfo();
    }
}

// Database info
async function loadDatabaseInfo() {
    try {
        const response = await fetch(`${API_BASE}/database/info`);
        const data = await response.json();
        document.getElementById('db-type').textContent = `DB: ${data.type}`;
    } catch (error) {
        console.error('Error loading database info:', error);
    }
}

// ===== SEARCH ITEMS =====
let selectedItems = [];
let currentSearchResults = [];
let allCategories = new Set();
let allVendors = new Set();

async function searchItems() {
    const searchTerm = document.getElementById('items-search').value.trim();
    const resultsDiv = document.getElementById('items-results');
    
    if (!searchTerm) {
        resultsDiv.innerHTML = '<p class="placeholder-text">Ingrese un término de búsqueda</p>';
        currentSearchResults = [];
        return;
    }
    
    try {
        resultsDiv.innerHTML = '<p class="placeholder-text">Buscando...</p>';
        const response = await fetch(`${API_BASE}/items/search?search=${encodeURIComponent(searchTerm)}`);
        const results = await response.json();
        
        if (results.length === 0) {
            resultsDiv.innerHTML = '<p class="placeholder-text">No se encontraron resultados</p>';
            currentSearchResults = [];
            return;
        }
        
        // Store results globally
        currentSearchResults = results;
        
        // Consolidate items by name (same SDK for same item name)
        const consolidatedItems = consolidateItemsByName(results);
        
        // Populate filter dropdowns
        populateItemFilters(consolidatedItems);
        
        // Display results
        displaySearchResults(consolidatedItems);
        
    } catch (error) {
        console.error('Error searching items:', error);
        resultsDiv.innerHTML = '<p class="placeholder-text">Error al buscar items</p>';
    }
}

function populateItemFilters(consolidatedItems) {
    allCategories.clear();
    allVendors.clear();
    
    consolidatedItems.forEach(itemData => {
        if (itemData.item.category) {
            allCategories.add(itemData.item.category);
        }
        itemData.suppliers.forEach(s => {
            allVendors.add(s.supplier_name);
        });
    });
    
    // Update category filter
    const categoryFilter = document.getElementById('items-category-filter');
    if (categoryFilter) {
        const currentCategory = categoryFilter.value;
        categoryFilter.innerHTML = '<option value="">Todas las Categorías</option>';
        Array.from(allCategories).sort().forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            if (cat === currentCategory) option.selected = true;
            categoryFilter.appendChild(option);
        });
    }
    
    // Update vendor filter
    const vendorFilter = document.getElementById('items-vendor-filter');
    if (vendorFilter) {
        const currentVendor = vendorFilter.value;
        vendorFilter.innerHTML = '<option value="">Todos los Proveedores</option>';
        Array.from(allVendors).sort().forEach(vendor => {
            const option = document.createElement('option');
            option.value = vendor;
            option.textContent = vendor;
            if (vendor === currentVendor) option.selected = true;
            vendorFilter.appendChild(option);
        });
    }
}

function applyItemFilters() {
    if (currentSearchResults.length === 0) return;
    
    const categoryFilter = document.getElementById('items-category-filter').value;
    const vendorFilter = document.getElementById('items-vendor-filter').value;
    const sortBy = document.getElementById('items-sort').value;
    
    // Consolidate items
    let consolidatedItems = consolidateItemsByName(currentSearchResults);
    
    // Apply category filter
    if (categoryFilter) {
        consolidatedItems = consolidatedItems.filter(itemData => 
            itemData.item.category === categoryFilter
        );
    }
    
    // Apply vendor filter
    if (vendorFilter) {
        consolidatedItems = consolidatedItems.filter(itemData =>
            itemData.suppliers.some(s => s.supplier_name === vendorFilter)
        );
        // Filter suppliers within each item
        consolidatedItems = consolidatedItems.map(itemData => ({
            ...itemData,
            suppliers: itemData.suppliers.filter(s => s.supplier_name === vendorFilter)
        }));
    }
    
    // Apply sorting
    consolidatedItems.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return a.item.name.localeCompare(b.item.name);
            case 'vendor':
                const vendorA = a.suppliers[0]?.supplier_name || '';
                const vendorB = b.suppliers[0]?.supplier_name || '';
                return vendorA.localeCompare(vendorB);
            case 'price-asc':
                const minPriceA = Math.min(...a.suppliers.map(s => s.price || Infinity));
                const minPriceB = Math.min(...b.suppliers.map(s => s.price || Infinity));
                return minPriceA - minPriceB;
            case 'price-desc':
                const maxPriceA = Math.min(...a.suppliers.map(s => s.price || Infinity));
                const maxPriceB = Math.min(...b.suppliers.map(s => s.price || Infinity));
                return maxPriceB - maxPriceA;
            default:
                return 0;
        }
    });
    
    displaySearchResults(consolidatedItems);
}

function displaySearchResults(consolidatedItems) {
    const resultsDiv = document.getElementById('items-results');
    let html = '<div class="items-selection-container">';
        
        consolidatedItems.forEach(itemData => {
            const item = itemData.item;
            const suppliers = itemData.suppliers || [];
            
            // Find cheapest price
            const cheapestSupplier = suppliers.reduce((min, s) => 
                !min || (s.price && (!min.price || s.price < min.price)) ? s : min, null);
            
            html += `
                <div class="item-card">
                    <div class="item-header">
                        <label class="item-checkbox-label">
                            <input type="checkbox" class="item-checkbox" 
                                   data-item-id="${item.id}" 
                                   data-item-name="${item.name}"
                                   data-item-code="${item.item_code}"
                                   onchange="updateSelectedItems()">
                            <h3>${item.name}</h3>
                        </label>
                    </div>
                    <div class="item-info">
                        <div class="info-item">
                            <span class="info-label">Código (SDK)</span>
                            <span class="info-value">${item.item_code}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Categoría</span>
                            <span class="info-value">${item.category || 'N/A'}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Unidad</span>
                            <span class="info-value">${item.unit || 'N/A'}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Precio más bajo</span>
                            <span class="info-value">${cheapestSupplier && cheapestSupplier.price ? '$' + cheapestSupplier.price.toFixed(2) : 'N/A'}</span>
                        </div>
                    </div>
                    ${item.description ? `<p><strong>Descripción:</strong> ${item.description}</p>` : ''}
                    
                    <div class="suppliers-list">
                        <h4>Proveedores disponibles (${suppliers.length})</h4>
                        <div class="suppliers-grid">
                            ${suppliers.map(s => `
                                <div class="supplier-item ${cheapestSupplier && s.supplier_id === cheapestSupplier.supplier_id ? 'cheapest' : ''}">
                                    <div class="supplier-info">
                                        <strong>${s.supplier_name}</strong>
                                        ${cheapestSupplier && s.supplier_id === cheapestSupplier.supplier_id ? '<span class="badge-cheapest">Más Económico</span>' : ''}
                                        <br>
                                        <small>${s.email || ''} ${s.phone ? '| ' + s.phone : ''}</small>
                                        ${s.supplier_item_code ? `<br><small>Código: ${s.supplier_item_code}</small>` : ''}
                                    </div>
                                    <div class="supplier-price">
                                        ${s.price ? `<strong>$${s.price.toFixed(2)}</strong>` : 'N/A'}
                                        ${s.lead_time_days ? `<br><small>${s.lead_time_days} días</small>` : ''}
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        
        // Add single order button
        html += `
            <div class="order-action-bar">
                <div class="selected-items-summary" id="selected-summary">
                    <span>Seleccione items para crear orden</span>
                </div>
                <button onclick="createBulkOrder()" class="btn btn-primary btn-lg" id="create-order-btn" disabled>
                    📦 Crear Orden
                </button>
            </div>
        `;
        
        resultsDiv.innerHTML = html;
        selectedItems = [];
}

function consolidateItemsByName(results) {
    const itemsMap = new Map();
    
    results.forEach(result => {
        const item = result.item;
        const suppliers = result.suppliers || [];
        
        // Use item name as key to consolidate
        if (!itemsMap.has(item.name)) {
            itemsMap.set(item.name, {
                item: item,
                suppliers: []
            });
        }
        
        const consolidated = itemsMap.get(item.name);
        
        // Add suppliers from this result
        suppliers.forEach(supplier => {
            // Avoid duplicates
            if (!consolidated.suppliers.find(s => s.supplier_id === supplier.supplier_id)) {
                consolidated.suppliers.push(supplier);
            }
        });
    });
    
    return Array.from(itemsMap.values());
}

function updateSelectedItems() {
    const checkboxes = document.querySelectorAll('.item-checkbox:checked');
    selectedItems = Array.from(checkboxes).map(cb => ({
        id: parseInt(cb.dataset.itemId),
        name: cb.dataset.itemName,
        code: cb.dataset.itemCode
    }));
    
    const summary = document.getElementById('selected-summary');
    const orderBtn = document.getElementById('create-order-btn');
    
    if (selectedItems.length === 0) {
        summary.innerHTML = '<span>Seleccione items para crear orden</span>';
        orderBtn.disabled = true;
    } else {
        summary.innerHTML = `<span><strong>${selectedItems.length}</strong> item(s) seleccionado(s)</span>`;
        orderBtn.disabled = false;
    }
}

async function createBulkOrder() {
    if (selectedItems.length === 0) {
        showError('Seleccione al menos un item');
        return;
    }
    
    try {
        // Get common suppliers for selected items
        const itemIds = selectedItems.map(item => item.id);
        const response = await fetch(`${API_BASE}/items/common-suppliers`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ item_ids: itemIds })
        });
        
        const data = await response.json();
        
        if (data.common_suppliers && data.common_suppliers.length > 0) {
            // Has common suppliers - show modal to select supplier and quantities
            showBulkOrderModal(data.common_suppliers, selectedItems);
        } else if (data.supplier_groups && data.supplier_groups.length > 0) {
            // No common supplier - need multiple orders
            showMultipleOrdersModal(data.supplier_groups, selectedItems);
        } else {
            showError('No se encontraron proveedores para los items seleccionados');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al procesar la orden');
    }
}

function showBulkOrderModal(commonSuppliers, items) {
    // Sort by total cost (cheapest first)
    commonSuppliers.sort((a, b) => (a.total_cost || Infinity) - (b.total_cost || Infinity));
    
    const selectedSupplier = commonSuppliers[0]; // Default to cheapest
    
    let html = `
        <div id="bulk-order-modal" class="modal active">
            <div class="modal-content modal-large">
                <span class="close" onclick="closeBulkOrderModal()">&times;</span>
                <h2>Crear Orden - ${items.length} Items</h2>
                
                <div class="form-group">
                    <label>Proveedor</label>
                    <select id="bulk-supplier-select" onchange="updateBulkOrderSupplier()">
                        ${commonSuppliers.map((s, idx) => `
                            <option value="${idx}" ${idx === 0 ? 'selected' : ''}>
                                ${s.supplier_name} - Total: $${s.total_cost?.toFixed(2) || 'N/A'}
                                ${idx === 0 ? ' (Más Económico)' : ''}
                            </option>
                        `).join('')}
                    </select>
                </div>
                
                <div class="items-order-list">
                    <table>
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Código</th>
                                <th>Precio Unit.</th>
                                <th>Cantidad</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody id="bulk-order-items">
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4"><strong>Total:</strong></td>
                                <td><strong id="bulk-order-total">$0.00</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <div class="form-group">
                    <label>Fecha de Entrega *</label>
                    <input type="date" id="bulk-delivery-date" required>
                </div>
                
                <div class="form-group">
                    <label>Notas</label>
                    <textarea id="bulk-order-notes" rows="3"></textarea>
                </div>
                
                <div class="form-actions">
                    <button onclick="submitBulkOrder()" class="btn btn-primary">Crear Orden</button>
                    <button onclick="closeBulkOrderModal()" class="btn btn-secondary">Cancelar</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', html);
    
    // Store data in global for access
    window.bulkOrderData = { commonSuppliers, items };
    updateBulkOrderSupplier();
}

function updateBulkOrderSupplier() {
    const selectIdx = parseInt(document.getElementById('bulk-supplier-select').value);
    const supplier = window.bulkOrderData.commonSuppliers[selectIdx];
    const items = window.bulkOrderData.items;
    
    let html = '';
    let total = 0;
    
    items.forEach(item => {
        const itemPrice = supplier.items.find(i => i.item_id === item.id);
        const price = itemPrice?.price || 0;
        
        html += `
            <tr>
                <td>${item.name}</td>
                <td>${item.code}</td>
                <td>$${price.toFixed(2)}</td>
                <td>
                    <input type="number" class="qty-input" 
                           data-price="${price}" 
                           value="1" min="1" 
                           onchange="updateBulkOrderTotal()">
                </td>
                <td class="subtotal">$${price.toFixed(2)}</td>
            </tr>
        `;
        total += price;
    });
    
    document.getElementById('bulk-order-items').innerHTML = html;
    document.getElementById('bulk-order-total').textContent = '$' + total.toFixed(2);
}

function updateBulkOrderTotal() {
    let total = 0;
    document.querySelectorAll('.qty-input').forEach((input, idx) => {
        const price = parseFloat(input.dataset.price);
        const qty = parseInt(input.value) || 0;
        const subtotal = price * qty;
        
        const subtotalCell = input.closest('tr').querySelector('.subtotal');
        subtotalCell.textContent = '$' + subtotal.toFixed(2);
        
        total += subtotal;
    });
    
    document.getElementById('bulk-order-total').textContent = '$' + total.toFixed(2);
}

async function submitBulkOrder() {
    const selectIdx = parseInt(document.getElementById('bulk-supplier-select').value);
    const supplier = window.bulkOrderData.commonSuppliers[selectIdx];
    const deliveryDate = document.getElementById('bulk-delivery-date').value;
    const notes = document.getElementById('bulk-order-notes').value;
    
    if (!deliveryDate) {
        showError('Fecha de entrega requerida');
        return;
    }
    
    // Build items list
    const itemsText = [];
    let totalAmount = 0;
    
    document.querySelectorAll('.qty-input').forEach((input, idx) => {
        const qty = parseInt(input.value) || 0;
        const price = parseFloat(input.dataset.price);
        const itemName = window.bulkOrderData.items[idx].name;
        
        itemsText.push(`${qty} x ${itemName} @ $${price.toFixed(2)}`);
        totalAmount += qty * price;
    });
    
    const orderData = {
        supplier_id: supplier.supplier_id,
        delivery_date: deliveryDate,
        total_amount: totalAmount,
        items: itemsText.join('\n'),
        notes: notes
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        
        if (response.ok) {
            closeBulkOrderModal();
            showSuccess('Orden creada exitosamente');
            
            // Clear selections
            document.querySelectorAll('.item-checkbox').forEach(cb => cb.checked = false);
            updateSelectedItems();
        } else {
            showError('Error al crear orden');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear orden');
    }
}

function closeBulkOrderModal() {
    const modal = document.getElementById('bulk-order-modal');
    if (modal) {
        modal.remove();
    }
    window.bulkOrderData = null;
}

function showMultipleOrdersModal(supplierGroups, items) {
    let html = `
        <div id="bulk-order-modal" class="modal active">
            <div class="modal-content modal-large">
                <span class="close" onclick="closeBulkOrderModal()">&times;</span>
                <h2>Crear Órdenes Múltiples</h2>
                
                <div class="alert alert-info">
                    <strong>ℹ️ No hay un proveedor común para todos los items.</strong><br>
                    Se crearán ${supplierGroups.length} órdenes separadas:
                </div>
                
                <div class="orders-preview">
                    ${supplierGroups.map((group, idx) => `
                        <div class="order-group">
                            <h4>Orden ${idx + 1}: ${group.supplier_name}</h4>
                            <ul>
                                ${group.items.map(item => `
                                    <li>${item.item_name} - $${item.price?.toFixed(2) || 'N/A'}</li>
                                `).join('')}
                            </ul>
                            <p><strong>Total: $${group.total_cost?.toFixed(2) || 'N/A'}</strong></p>
                        </div>
                    `).join('')}
                </div>
                
                <div class="form-group">
                    <label>Fecha de Entrega (todas las órdenes) *</label>
                    <input type="date" id="multi-delivery-date" required>
                </div>
                
                <div class="form-actions">
                    <button onclick="submitMultipleOrders()" class="btn btn-primary">Crear ${supplierGroups.length} Órdenes</button>
                    <button onclick="closeBulkOrderModal()" class="btn btn-secondary">Cancelar</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', html);
    window.bulkOrderData = { supplierGroups };
}

async function submitMultipleOrders() {
    const deliveryDate = document.getElementById('multi-delivery-date').value;
    
    if (!deliveryDate) {
        showError('Fecha de entrega requerida');
        return;
    }
    
    const supplierGroups = window.bulkOrderData.supplierGroups;
    
    try {
        let successCount = 0;
        
        for (const group of supplierGroups) {
            const itemsText = group.items.map(item => 
                `1 x ${item.item_name} @ $${item.price?.toFixed(2) || '0.00'}`
            ).join('\n');
            
            const orderData = {
                supplier_id: group.supplier_id,
                delivery_date: deliveryDate,
                total_amount: group.total_cost,
                items: itemsText,
                notes: `Orden múltiple (${successCount + 1}/${supplierGroups.length})`
            };
            
            const response = await fetch(`${API_BASE}/orders`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderData)
            });
            
            if (response.ok) {
                successCount++;
            }
        }
        
        closeBulkOrderModal();
        showSuccess(`${successCount} órdenes creadas exitosamente`);
        
        // Clear selections
        document.querySelectorAll('.item-checkbox').forEach(cb => cb.checked = false);
        updateSelectedItems();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear órdenes');
    }
}

// ===== SEARCH VENDORS =====
let currentVendorResults = [];
let allVendorCategories = new Set();
let allVendorCities = new Set();

async function searchVendors() {
    const searchTerm = document.getElementById('vendors-search').value.trim();
    const resultsDiv = document.getElementById('vendors-results');
    
    if (!searchTerm) {
        resultsDiv.innerHTML = '<p class="placeholder-text">Ingrese un término de búsqueda</p>';
        currentVendorResults = [];
        return;
    }
    
    try {
        resultsDiv.innerHTML = '<p class="placeholder-text">Buscando...</p>';
        const response = await fetch(`${API_BASE}/suppliers?search=${encodeURIComponent(searchTerm)}`);
        const results = await response.json();
        
        if (results.length === 0) {
            resultsDiv.innerHTML = '<p class="placeholder-text">No se encontraron proveedores</p>';
            currentVendorResults = [];
            return;
        }
        
        currentVendorResults = results;
        populateVendorFilters(results);
        displayVendorResults(results);
        
    } catch (error) {
        console.error('Error searching vendors:', error);
        resultsDiv.innerHTML = '<p class="placeholder-text">Error al buscar proveedores</p>';
    }
}

function populateVendorFilters(vendors) {
    allVendorCategories.clear();
    allVendorCities.clear();
    
    vendors.forEach(vendor => {
        if (vendor.category) allVendorCategories.add(vendor.category);
        if (vendor.city) allVendorCities.add(vendor.city);
    });
    
    // Update category filter
    const categoryFilter = document.getElementById('vendors-category-filter');
    if (categoryFilter) {
        const currentCategory = categoryFilter.value;
        categoryFilter.innerHTML = '<option value="">Todas las Categorías</option>';
        Array.from(allVendorCategories).sort().forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            if (cat === currentCategory) option.selected = true;
            categoryFilter.appendChild(option);
        });
    }
    
    // Update city filter
    const cityFilter = document.getElementById('vendors-city-filter');
    if (cityFilter) {
        const currentCity = cityFilter.value;
        cityFilter.innerHTML = '<option value="">Todas las Ciudades</option>';
        Array.from(allVendorCities).sort().forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            if (city === currentCity) option.selected = true;
            cityFilter.appendChild(option);
        });
    }
}

function applyVendorFilters() {
    if (currentVendorResults.length === 0) return;
    
    const categoryFilter = document.getElementById('vendors-category-filter').value;
    const cityFilter = document.getElementById('vendors-city-filter').value;
    const sortBy = document.getElementById('vendors-sort').value;
    
    let filteredVendors = [...currentVendorResults];
    
    // Apply filters
    if (categoryFilter) {
        filteredVendors = filteredVendors.filter(v => v.category === categoryFilter);
    }
    if (cityFilter) {
        filteredVendors = filteredVendors.filter(v => v.city === cityFilter);
    }
    
    // Apply sorting
    filteredVendors.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return a.name.localeCompare(b.name);
            case 'category':
                return (a.category || '').localeCompare(b.category || '');
            case 'city':
                return (a.city || '').localeCompare(b.city || '');
            case 'rating-desc':
                return (b.rating || 0) - (a.rating || 0);
            case 'rating-asc':
                return (a.rating || 0) - (b.rating || 0);
            default:
                return 0;
        }
    });
    
    displayVendorResults(filteredVendors);
}

function displayVendorResults(vendors) {
    const resultsDiv = document.getElementById('vendors-results');
    
    if (vendors.length === 0) {
        resultsDiv.innerHTML = '<p class="placeholder-text">No hay proveedores que coincidan con los filtros</p>';
        return;
    }
    
    let html = '';
    vendors.forEach(vendor => {
        // Check if this vendor has price info (from item suppliers view)
        const priceInfo = vendor.price ? `<div class="info-item"><span class="info-label">Precio</span><span class="info-value">$${vendor.price.toFixed(2)}</span></div>` : '';
        
        html += `
            <div class="vendor-card">
                <h3>${vendor.name}</h3>
                <div class="vendor-info">
                    ${priceInfo}
                    <div class="info-item">
                        <span class="info-label">Email</span>
                        <span class="info-value">${vendor.email || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Teléfono</span>
                        <span class="info-value">${vendor.phone || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Ciudad</span>
                        <span class="info-value">${vendor.city || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Categoría</span>
                        <span class="info-value">${vendor.category || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Rating</span>
                        <span class="info-value">${vendor.rating ? '⭐ ' + vendor.rating : 'N/A'}</span>
                    </div>
                </div>
                ${vendor.address ? `<p><strong>Dirección:</strong> ${vendor.address}</p>` : ''}
                ${vendor.supplier_item_code ? `<p><strong>Código del proveedor:</strong> ${vendor.supplier_item_code}</p>` : ''}
                ${vendor.lead_time_days ? `<p><strong>Tiempo de entrega:</strong> ${vendor.lead_time_days} días</p>` : ''}
                <div style="margin-top: 15px; display: flex; gap: 10px;">
                    <button onclick='createOrderForVendor(${vendor.id}, "${vendor.name.replace(/"/g, '&quot;')}")' class="btn btn-primary btn-sm" title="Crear Orden">
                        📝
                    </button>
                    <button onclick="viewSupplierItems(${vendor.id})" class="btn btn-secondary btn-sm" title="Ver Items">
                        �
                    </button>
                </div>
            </div>
        `;
        });
        
        resultsDiv.innerHTML = html;
}

// Create order for specific vendor with items selector
async function createOrderForVendor(vendorId, vendorName) {
    try {
        // Get vendor's items
        const response = await fetch(`${API_BASE}/suppliers/${vendorId}/items`);
        const data = await response.json();
        const items = data.items || [];
        
        if (items.length === 0) {
            showError('Este proveedor no tiene items registrados');
            return;
        }
        
        // Show modal with items selector
        let html = `
            <div id="vendor-order-modal" class="modal active">
                <div class="modal-content modal-large">
                    <span class="close" onclick="closeVendorOrderModal()">&times;</span>
                    <h2>Crear Orden - ${vendorName}</h2>
                    
                    <div class="items-selector">
                        <div class="items-selector-header">
                            <h3>Seleccionar Items (${items.length})</h3>
                            <div class="items-search-box">
                                <input type="text" id="vendor-items-search" placeholder="🔍 Buscar items..." class="search-input-small" oninput="filterVendorItems()">
                            </div>
                        </div>
                        <div class="items-table-wrapper">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Seleccionar</th>
                                        <th>Item</th>
                                        <th>Código</th>
                                        <th>Precio</th>
                                        <th>Cantidad</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody id="vendor-items-tbody">
                                    ${items.map(item => `
                                        <tr class="vendor-item-row" 
                                            data-item-name="${item.name.toLowerCase()}" 
                                            data-item-code="${(item.supplier_item_code || item.item_code || '').toLowerCase()}"
                                            data-item-id="${item.id}">
                                            <td>
                                                <input type="checkbox" class="item-select-checkbox" 
                                                       data-item-id="${item.id}" 
                                                       data-item-name="${item.name}"
                                                       data-price="${item.price || 0}"
                                                       onchange="toggleItemQuantity(this); updateVendorOrderTotal(); filterVendorItems()">
                                            </td>
                                            <td>${item.name}</td>
                                            <td>${item.supplier_item_code || item.item_code || 'N/A'}</td>
                                            <td>$${(item.price || 0).toFixed(2)}</td>
                                            <td>
                                                <input type="number" class="qty-input" 
                                                       data-item-id="${item.id}"
                                                       value="1" min="1" 
                                                       onchange="updateVendorOrderTotal()" disabled>
                                            </td>
                                            <td class="item-subtotal">$${(item.price || 0).toFixed(2)}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="5"><strong>Total:</strong></td>
                                        <td><strong id="vendor-order-total">$0.00</strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Fecha de Entrega *</label>
                        <input type="date" id="vendor-order-delivery-date" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Notas</label>
                        <textarea id="vendor-order-notes" rows="3"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button onclick="submitVendorOrder(${vendorId})" class="btn btn-primary">Crear Orden</button>
                        <button onclick="closeVendorOrderModal()" class="btn btn-secondary">Cancelar</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', html);
        
        // Enable qty inputs when checkbox is selected
        document.querySelectorAll('.item-select-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const itemId = this.dataset.itemId;
                const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
                if (qtyInput) {
                    qtyInput.disabled = !this.checked;
                    if (!this.checked) qtyInput.value = 1;
                }
            });
        });
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar items del proveedor');
    }
}

function toggleItemQuantity(checkbox) {
    const itemId = checkbox.dataset.itemId;
    const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
    if (qtyInput) {
        qtyInput.disabled = !checkbox.checked;
        if (!checkbox.checked) {
            qtyInput.value = 1; // Reset to 1 when unchecked
        }
    }
}

function updateVendorOrderTotal() {
    let total = 0;
    document.querySelectorAll('.item-select-checkbox:checked').forEach(checkbox => {
        const itemId = checkbox.dataset.itemId;
        const price = parseFloat(checkbox.dataset.price);
        const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
        const qty = parseInt(qtyInput?.value || 0);
        const subtotal = price * qty;
        
        // Update subtotal display
        const subtotalCell = qtyInput?.closest('tr')?.querySelector('.item-subtotal');
        if (subtotalCell) {
            subtotalCell.textContent = '$' + subtotal.toFixed(2);
        }
        
        total += subtotal;
    });
    
    const totalElement = document.getElementById('vendor-order-total');
    if (totalElement) {
        totalElement.textContent = '$' + total.toFixed(2);
    }
}

function filterVendorItems() {
    const searchTerm = document.getElementById('vendor-items-search').value.toLowerCase().trim();
    const rows = document.querySelectorAll('.vendor-item-row');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const itemName = row.dataset.itemName || '';
        const itemCode = row.dataset.itemCode || '';
        const checkbox = row.querySelector('.item-select-checkbox');
        const isSelected = checkbox && checkbox.checked;
        
        // Show if matches search OR is selected (persist selected items)
        const matches = itemName.includes(searchTerm) || itemCode.includes(searchTerm);
        
        if (matches || isSelected) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
    // Update counter
    const header = document.querySelector('.items-selector-header h3');
    if (header) {
        const totalItems = rows.length;
        const selectedCount = document.querySelectorAll('.item-select-checkbox:checked').length;
        if (searchTerm) {
            header.textContent = `Seleccionar Items (${visibleCount} de ${totalItems}) - ${selectedCount} seleccionados`;
        } else {
            header.textContent = `Seleccionar Items (${totalItems}) - ${selectedCount} seleccionados`;
        }
    }
}

async function submitVendorOrder(vendorId) {
    const deliveryDate = document.getElementById('vendor-order-delivery-date').value;
    const notes = document.getElementById('vendor-order-notes').value;
    
    if (!deliveryDate) {
        showError('Fecha de entrega requerida');
        return;
    }
    
    const selectedItems = [];
    document.querySelectorAll('.item-select-checkbox:checked').forEach(checkbox => {
        const itemId = checkbox.dataset.itemId;
        const itemName = checkbox.dataset.itemName;
        const price = parseFloat(checkbox.dataset.price);
        const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
        const qty = parseInt(qtyInput?.value || 1);
        
        selectedItems.push({
            name: itemName,
            qty: qty,
            price: price
        });
    });
    
    if (selectedItems.length === 0) {
        showError('Seleccione al menos un item');
        return;
    }
    
    const itemsText = selectedItems.map(item => 
        `${item.qty} x ${item.name} @ $${item.price.toFixed(2)}`
    ).join('\n');
    
    const totalAmount = selectedItems.reduce((sum, item) => sum + (item.qty * item.price), 0);
    
    const orderData = {
        supplier_id: vendorId,
        delivery_date: deliveryDate,
        total_amount: totalAmount,
        items: itemsText,
        notes: notes
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        
        if (response.ok) {
            closeVendorOrderModal();
            showSuccess('Orden creada exitosamente');
        } else {
            showError('Error al crear orden');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear orden');
    }
}

function closeVendorOrderModal() {
    const modal = document.getElementById('vendor-order-modal');
    if (modal) {
        modal.remove();
    }
}

// Enter key search for vendors
document.addEventListener('DOMContentLoaded', function() {
    const vendorsSearch = document.getElementById('vendors-search');
    if (vendorsSearch) {
        vendorsSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchVendors();
            }
        });
    }
});

// ===== INVENTORY =====
async function loadInventory() {
    try {
        const response = await fetch(`${API_BASE}/items`);
        items = await response.json();
        
        // Populate category filter
        const categories = [...new Set(items.map(item => item.category).filter(Boolean))];
        const categoryFilter = document.getElementById('inventory-category-filter');
        const currentCategory = categoryFilter.value;
        categoryFilter.innerHTML = '<option value="">Todas las Categorías</option>';
        categories.sort().forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            if (cat === currentCategory) option.selected = true;
            categoryFilter.appendChild(option);
        });
        
        displayInventory();
    } catch (error) {
        console.error('Error loading inventory:', error);
    }
}

function applyInventoryFilters() {
    const searchTerm = document.getElementById('inventory-search')?.value.toLowerCase() || '';
    displayInventory(searchTerm);
}

function displayInventory(searchTerm = '') {
    const categoryFilter = document.getElementById('inventory-category-filter').value;
    const sortBy = document.getElementById('inventory-sort').value;
    
    // Filter items
    let filteredItems = [...items];
    
    // Apply search filter
    if (searchTerm) {
        filteredItems = filteredItems.filter(item => 
            item.name.toLowerCase().includes(searchTerm) ||
            item.item_code.toLowerCase().includes(searchTerm) ||
            (item.category && item.category.toLowerCase().includes(searchTerm)) ||
            (item.description && item.description.toLowerCase().includes(searchTerm))
        );
    }
    
    // Apply category filter
    if (categoryFilter) {
        filteredItems = filteredItems.filter(item => item.category === categoryFilter);
    }
    
    // Sort items
    filteredItems.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return a.name.localeCompare(b.name);
            case 'code':
                return a.item_code.localeCompare(b.item_code);
            case 'category':
                return (a.category || '').localeCompare(b.category || '');
            case 'price-asc':
                // For price, we'd need to fetch supplier prices - simplified for now
                return 0;
            case 'price-desc':
                return 0;
            default:
                return 0;
        }
    });
    
    const tbody = document.getElementById('inventory-tbody');
    tbody.innerHTML = filteredItems.map(item => {
        // Check if user has edit permissions (not compras role)
        const canEdit = currentUser && (currentUser.rol === 'sysadmin' || currentUser.rol === 'admin');
        
        return `
        <tr>
            <td>${item.item_code}</td>
            <td>${item.name}</td>
            <td>${item.description || ''}</td>
            <td>${item.category || ''}</td>
            <td>${item.unit || ''}</td>
            <td>
                <button onclick="viewSuppliersByItem(${item.id}, '${escapeHtml(item.name)}')" class="btn btn-secondary btn-sm" title="Ver Proveedores">
                    👁️
                </button>
            </td>
            <td style="white-space: nowrap;">
                ${canEdit ? `
                <button onclick="editItem(${item.id})" class="btn btn-warning btn-sm" title="Editar Item">✏️</button>
                <button onclick="manageItemSuppliers(${item.id}, '${escapeHtml(item.name)}')" class="btn btn-primary btn-sm" title="Gestionar Proveedores">
                    🏢
                </button>
                ` : '<span style="color: #999;">Solo lectura</span>'}
            </td>
        </tr>
        `;
    }).join('');
}

async function manageItemSuppliers(itemId, itemName) {
    const item = items.find(i => i.id === itemId);
    if (!item) {
        showError('Item no encontrado');
        return;
    }
    
    currentPriceItem = item;
    showSection('price-management');
}

async function viewSuppliersByItem(itemId, itemName) {
    // Show confirmation dialog
    showConfirmDialog(
        `¿Desea ver los proveedores que venden "${itemName}"?\n\nEsto lo llevará a la sección de búsqueda de proveedores.`,
        async () => {
            try {
                await loadSuppliersByItemConfirmed(itemId, itemName);
            } catch (error) {
                console.error('Error:', error);
                showError('Error al cargar proveedores del item');
            }
        }
    );
}

async function loadSuppliersByItemConfirmed(itemId, itemName) {
    try {
        // Fetch suppliers for this item
        const response = await fetch(`${API_BASE}/items/${itemId}/suppliers`);
        if (!response.ok) {
            throw new Error('Failed to fetch suppliers');
        }
        
        const suppliers = await response.json();
        
        if (suppliers.length === 0) {
            showError('Este item no tiene proveedores asociados');
            return;
        }
        
        // Switch to search vendors section
        showSection('search-vendors');
        
        // Store current search context
        currentVendorResults = suppliers;
        
        // Clear search input and populate filters
        const searchInput = document.getElementById('vendors-search');
        if (searchInput) {
            searchInput.value = '';
        }
        
        // Display the suppliers directly
        populateVendorFilters(suppliers);
        displayVendorResults(suppliers);
        
        // Show info message
        showSuccess(`Mostrando ${suppliers.length} proveedor(es) que venden: ${itemName}`);
        
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

function editItem(itemId) {
    const item = items.find(i => i.id === itemId);
    if (!item) {
        showError('Item no encontrado');
        return;
    }
    
    // Generate category options
    const categoryOptions = ITEM_CATEGORIES.map(cat => 
        `<option value="${cat}" ${item.category === cat ? 'selected' : ''}>${cat}</option>`
    ).join('');
    
    // Generate UOM options
    const uomOptions = UNITS_OF_MEASURE.map(unit => 
        `<option value="${unit}" ${item.unit === unit ? 'selected' : ''}>${unit}</option>`
    ).join('');
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'edit-item-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>Editar Item</h2>
                <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="edit-item-form" onsubmit="saveItemEdit(event, ${itemId})">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Código (No editable)</label>
                            <input type="text" value="${item.item_code}" disabled class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Nombre <span class="required">*</span></label>
                            <input type="text" id="edit-item-name" value="${item.name}" required class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea id="edit-item-description" class="form-control" rows="3">${item.description || ''}</textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Categoría</label>
                            <select id="edit-item-category" class="form-control">
                                <option value="">Seleccione una categoría</option>
                                ${categoryOptions}
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Unidad de Medida</label>
                            <select id="edit-item-unit" class="form-control">
                                <option value="">Seleccione una unidad</option>
                                ${uomOptions}
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="this.closest('.modal').remove()" class="btn btn-secondary">Cancelar</button>
                        <button type="submit" class="btn btn-primary">💾 Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
}

async function saveItemEdit(event, itemId) {
    event.preventDefault();
    
    const updatedItem = {
        name: document.getElementById('edit-item-name').value.trim(),
        description: document.getElementById('edit-item-description').value.trim(),
        category: document.getElementById('edit-item-category').value.trim(),
        unit: document.getElementById('edit-item-unit').value.trim()
    };
    
    if (!updatedItem.name) {
        showError('El nombre del item es requerido');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items/${itemId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedItem)
        });
        
        if (!response.ok) {
            throw new Error('Failed to update item');
        }
        
        // Close modal first
        const modal = document.getElementById('edit-item-modal');
        if (modal) {
            modal.remove();
        }
        
        // Then show success and reload
        showSuccess('Item actualizado correctamente');
        await loadInventory();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al actualizar el item');
    }
}

function openNewItemModal() {
    // Generate category options
    const categoryOptions = ITEM_CATEGORIES.map(cat => 
        `<option value="${cat}">${cat}</option>`
    ).join('');
    
    // Generate UOM options
    const uomOptions = UNITS_OF_MEASURE.map(unit => 
        `<option value="${unit}">${unit}</option>`
    ).join('');
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'new-item-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>Nuevo Item</h2>
                <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="new-item-form" onsubmit="saveNewItem(event)">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Código <span class="required">*</span></label>
                            <input type="text" id="new-item-code" required class="form-control" placeholder="SDK-001">
                        </div>
                        <div class="form-group">
                            <label>Nombre <span class="required">*</span></label>
                            <input type="text" id="new-item-name" required class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea id="new-item-description" class="form-control" rows="3"></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Categoría</label>
                            <select id="new-item-category" class="form-control">
                                <option value="">Seleccione una categoría</option>
                                ${categoryOptions}
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Unidad de Medida</label>
                            <select id="new-item-unit" class="form-control">
                                <option value="">Seleccione una unidad</option>
                                ${uomOptions}
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="this.closest('.modal').remove()" class="btn btn-secondary">Cancelar</button>
                        <button type="submit" class="btn btn-primary">💾 Crear Item</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
}

async function saveNewItem(event) {
    event.preventDefault();
    
    const newItem = {
        item_code: document.getElementById('new-item-code').value.trim(),
        name: document.getElementById('new-item-name').value.trim(),
        description: document.getElementById('new-item-description').value.trim(),
        category: document.getElementById('new-item-category').value.trim(),
        unit: document.getElementById('new-item-unit').value.trim()
    };
    
    if (!newItem.item_code || !newItem.name) {
        showError('Código y nombre son requeridos');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newItem)
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to create item');
        }
        
        const createdItem = await response.json();
        
        // Close modal first
        const modalToClose = document.getElementById('new-item-modal');
        if (modalToClose) {
            modalToClose.remove();
        }
        
        showSuccess('Item creado correctamente');
        
        // Ask if user wants to add suppliers now
        showConfirmDialog(
            `Item "${createdItem.name}" creado exitosamente.\n\n¿Desea agregar proveedores y precios ahora?`,
            () => {
                currentPriceItem = createdItem;
                showSection('price-management');
            },
            () => {
                loadInventory();
            }
        );
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message || 'Error al crear el item');
    }
}

async function openAddSuppliersModal(item) {
    try {
        // Load all suppliers
        const response = await fetch(`${API_BASE}/suppliers`);
        const allSuppliers = await response.json();
        
        if (allSuppliers.length === 0) {
            showError('No hay proveedores registrados. Agregue proveedores primero.');
            await loadInventory();
            return;
        }
        
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content modal-large">
                <div class="modal-header">
                    <h2>Agregar Proveedores - ${item.name}</h2>
                    <span class="close" onclick="closeAddSuppliersModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <p><strong>Item:</strong> ${item.item_code} - ${item.name}</p>
                    <hr>
                    
                    <div id="suppliers-list">
                        <h3>Seleccione proveedores y establezca precios:</h3>
                        <div class="suppliers-selector">
                            ${allSuppliers.map(supplier => `
                                <div class="supplier-row" data-supplier-id="${supplier.id}">
                                    <div class="supplier-select">
                                        <label>
                                            <input type="checkbox" class="supplier-checkbox" value="${supplier.id}">
                                            <strong>${supplier.name}</strong>
                                            <br>
                                            <small>${supplier.email || ''} ${supplier.city ? '- ' + supplier.city : ''}</small>
                                        </label>
                                    </div>
                                    <div class="supplier-price-fields" style="display: none;">
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label>Precio <span class="required">*</span></label>
                                                <input type="number" step="0.01" class="form-control price-input" placeholder="0.00" disabled>
                                            </div>
                                            <div class="form-group">
                                                <label>Código del Proveedor</label>
                                                <input type="text" class="form-control supplier-code-input" placeholder="Código interno" disabled>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label>Tiempo de Entrega (días)</label>
                                                <input type="number" class="form-control lead-time-input" placeholder="0" disabled>
                                            </div>
                                            <div class="form-group">
                                                <label>Cantidad Mínima</label>
                                                <input type="number" class="form-control min-qty-input" placeholder="1" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Notas</label>
                                            <textarea class="form-control notes-input" rows="2" disabled></textarea>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="closeAddSuppliersModal()" class="btn btn-secondary">
                            Omitir
                        </button>
                        <button type="button" onclick="saveSuppliersToItem(${item.id})" class="btn btn-primary">
                            💾 Guardar Proveedores
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        
        // Add event listeners to checkboxes
        document.querySelectorAll('.supplier-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const row = this.closest('.supplier-row');
                const fieldsDiv = row.querySelector('.supplier-price-fields');
                const inputs = row.querySelectorAll('input, textarea');
                
                if (this.checked) {
                    fieldsDiv.style.display = 'block';
                    inputs.forEach(input => {
                        if (!input.classList.contains('supplier-checkbox')) {
                            input.disabled = false;
                        }
                    });
                } else {
                    fieldsDiv.style.display = 'none';
                    inputs.forEach(input => {
                        if (!input.classList.contains('supplier-checkbox')) {
                            input.disabled = true;
                        }
                    });
                }
            });
        });
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar proveedores');
        await loadInventory();
    }
}

async function saveSuppliersToItem(itemId) {
    const selectedSuppliers = [];
    
    document.querySelectorAll('.supplier-checkbox:checked').forEach(checkbox => {
        const row = checkbox.closest('.supplier-row');
        const supplierId = parseInt(checkbox.value);
        const price = parseFloat(row.querySelector('.price-input').value);
        
        if (!price || price <= 0) {
            showError(`Debe ingresar un precio válido para todos los proveedores seleccionados`);
            return;
        }
        
        selectedSuppliers.push({
            supplier_id: supplierId,
            price: price,
            supplier_item_code: row.querySelector('.supplier-code-input').value.trim(),
            lead_time_days: parseInt(row.querySelector('.lead-time-input').value) || null,
            minimum_order_quantity: parseInt(row.querySelector('.min-qty-input').value) || null,
            notes: row.querySelector('.notes-input').value.trim()
        });
    });
    
    if (selectedSuppliers.length === 0) {
        showConfirmDialog(
            'No ha seleccionado ningún proveedor.\n\n¿Desea crear el item sin proveedores?',
            () => {
                closeAddSuppliersModal();
                loadInventory();
            }
        );
        return;
    }
    
    try {
        // Add each supplier to the item
        const promises = selectedSuppliers.map(supplierData =>
            fetch(`${API_BASE}/items/${itemId}/suppliers`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(supplierData)
            })
        );
        
        await Promise.all(promises);
        
        showSuccess(`Item configurado exitosamente con ${selectedSuppliers.length} proveedor(es)`);
        closeAddSuppliersModal();
        await loadInventory();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al guardar proveedores');
    }
}

function closeAddSuppliersModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.remove();
    }
}

function exportInventory() {
    window.location.href = `${API_BASE}/items/export`;
}

// ===== SUPPLIERS/VENDORS =====
async function loadSuppliers() {
    try {
        const search = document.getElementById('suppliers-search')?.value || '';
        const category = document.getElementById('category-filter')?.value || '';
        const country = document.getElementById('country-filter')?.value || '';
        
        let url = `${API_BASE}/suppliers?`;
        if (search) url += `search=${encodeURIComponent(search)}&`;
        if (category) url += `category=${encodeURIComponent(category)}&`;
        if (country) url += `country=${encodeURIComponent(country)}`;
        
        const response = await fetch(url);
        suppliers = await response.json();
        displaySuppliers();
    } catch (error) {
        console.error('Error loading suppliers:', error);
    }
}

function displaySuppliers() {
    const tbody = document.getElementById('suppliers-tbody');
    // Check if user has edit permissions (not compras role)
    const canEdit = currentUser && (currentUser.rol === 'sysadmin' || currentUser.rol === 'admin');
    
    tbody.innerHTML = suppliers.map(s => `
        <tr>
            <td>${s.name}</td>
            <td>${s.contact_person || ''}</td>
            <td>${s.email || ''}</td>
            <td>${s.phone || ''}</td>
            <td>${s.city || ''}</td>
            <td>${s.category || ''}</td>
            <td>${s.rating ? '⭐ ' + s.rating : ''}</td>
            <td style="white-space: nowrap;">
                ${canEdit ? `<button onclick="editSupplier(${s.id})" class="btn btn-warning btn-sm" title="Editar Proveedor">✏️</button>` : ''}
                <button onclick="createOrderForVendor(${s.id}, '${escapeHtml(s.name)}')" class="btn btn-primary btn-sm" title="Crear Orden">📝</button>
            </td>
        </tr>
    `).join('');
}

async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE}/suppliers/categories`);
        const categories = await response.json();
        const select = document.getElementById('category-filter');
        if (select) {
            select.innerHTML = '<option value="">Todas las Categorías</option>' +
                categories.map(c => `<option value="${c}">${c}</option>`).join('');
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function loadCountries() {
    try {
        const response = await fetch(`${API_BASE}/suppliers/countries`);
        const countries = await response.json();
        const select = document.getElementById('country-filter');
        if (select) {
            select.innerHTML = '<option value="">Todos los Países</option>' +
                countries.map(c => `<option value="${c}">${c}</option>`).join('');
        }
    } catch (error) {
        console.error('Error loading countries:', error);
    }
}

// ===== ORDERS =====
async function loadOrders() {
    try {
        const status = document.getElementById('order-status-filter')?.value || '';
        let url = `${API_BASE}/orders`;
        if (status) url += `?status=${status}`;
        
        const response = await fetch(url);
        orders = await response.json();
        displayOrders();
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

function displayOrders() {
    const tbody = document.getElementById('orders-tbody');
    tbody.innerHTML = orders.map(o => `
        <tr>
            <td>${o.order_number}</td>
            <td>${o.supplier_name}</td>
            <td>${new Date(o.order_date).toLocaleDateString()}</td>
            <td>${o.delivery_date ? new Date(o.delivery_date).toLocaleDateString() : ''}</td>
            <td>$${o.total_amount?.toFixed(2) || '0.00'}</td>
            <td><span class="status-badge status-${o.status}">${o.status}</span></td>
            <td style="white-space: nowrap;">
                <button onclick="viewOrder(${o.id})" class="btn btn-secondary btn-sm" title="Ver Orden">👁️</button>
                <button onclick="printOrder(${o.id})" class="btn btn-warning btn-sm" title="Imprimir Orden">🖨️</button>
            </td>
        </tr>
    `).join('');
}

async function viewOrder(orderId) {
    try {
        // Fetch order details
        const response = await fetch(`${API_BASE}/orders/${orderId}`);
        if (!response.ok) {
            throw new Error('Failed to load order');
        }
        
        const order = await response.json();
        
        // Create view order modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'view-order-modal';
        modal.innerHTML = `
            <div class="modal-content modal-large">
                <div class="modal-header">
                    <h2>Orden ${order.order_number}</h2>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="order-details-header" style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                            <div>
                                <strong>Proveedor:</strong><br>
                                <span style="font-size: 18px;">${order.supplier_name}</span>
                            </div>
                            <div>
                                <strong>Número de Orden:</strong><br>
                                <span style="font-size: 18px;">${order.order_number}</span>
                            </div>
                            <div>
                                <strong>Fecha de Orden:</strong><br>
                                ${new Date(order.order_date).toLocaleDateString()}
                            </div>
                            <div>
                                <strong>Fecha de Entrega:</strong><br>
                                ${order.delivery_date ? new Date(order.delivery_date).toLocaleDateString() : 'No especificada'}
                            </div>
                            <div>
                                <strong>Monto Total:</strong><br>
                                <span style="font-size: 20px; color: #667eea;">$${order.total_amount?.toFixed(2) || '0.00'}</span>
                            </div>
                            <div>
                                <strong>Estado:</strong><br>
                                <select id="order-status-select" class="form-control" style="max-width: 200px;">
                                    <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>Pendiente</option>
                                    <option value="confirmed" ${order.status === 'confirmed' ? 'selected' : ''}>Confirmado</option>
                                    <option value="shipped" ${order.status === 'shipped' ? 'selected' : ''}>Enviado</option>
                                    <option value="delivered" ${order.status === 'delivered' ? 'selected' : ''}>Entregado</option>
                                    <option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>Cancelado</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><strong>Items:</strong></label>
                        <textarea class="form-control" rows="8" readonly style="background: white;">${order.items || 'No hay items especificados'}</textarea>
                    </div>
                    
                    ${order.notes ? `
                        <div class="form-group">
                            <label><strong>Notas:</strong></label>
                            <textarea class="form-control" rows="3" readonly style="background: white;">${order.notes}</textarea>
                        </div>
                    ` : ''}
                    
                    <div class="form-actions">
                        <button onclick="updateOrderStatus(${order.id})" class="btn btn-success">
                            💾 Actualizar Estado
                        </button>
                        <button onclick="printOrderFromModal(${order.id})" class="btn btn-warning">
                            🖨️ Imprimir
                        </button>
                        <button onclick="this.closest('.modal').remove()" class="btn btn-secondary">
                            Cerrar
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar la orden');
    }
}

async function updateOrderStatus(orderId) {
    const newStatus = document.getElementById('order-status-select').value;
    
    try {
        const response = await fetch(`${API_BASE}/orders/${orderId}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: newStatus })
        });
        
        if (!response.ok) {
            throw new Error('Failed to update status');
        }
        
        showSuccess('Estado actualizado correctamente');
        
        // Reload orders list
        await loadOrders();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al actualizar el estado');
    }
}

function printOrderFromModal(orderId) {
    printOrder(orderId);
}

async function printOrder(orderId) {
    try {
        // Fetch order details
        const response = await fetch(`${API_BASE}/orders/${orderId}`);
        if (!response.ok) {
            throw new Error('Failed to load order');
        }
        
        const order = await response.json();
        
        // Detect if mobile device
        const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        
        // Create print window content
        const printContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Orden ${order.order_number}</title>
                <style>
                    * {
                        margin: 0;
                        padding: 0;
                        box-sizing: border-box;
                    }
                    body {
                        font-family: Arial, sans-serif;
                        padding: 15px;
                        max-width: 800px;
                        margin: 0 auto;
                        background: white;
                    }
                    .header {
                        text-align: center;
                        border-bottom: 2px solid #667eea;
                        padding-bottom: 15px;
                        margin-bottom: 20px;
                    }
                    .header h1 {
                        color: #667eea;
                        margin: 0 0 10px 0;
                        font-size: 24px;
                    }
                    .header h2 {
                        font-size: 20px;
                        margin: 5px 0;
                    }
                    .info-grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                        gap: 10px;
                        margin-bottom: 20px;
                    }
                    .info-item {
                        padding: 10px;
                        background: #f8f9fa;
                        border-radius: 5px;
                    }
                    .info-item strong {
                        display: block;
                        color: #667eea;
                        margin-bottom: 5px;
                        font-size: 12px;
                    }
                    .info-item div {
                        font-size: 14px;
                    }
                    .items-section {
                        margin: 20px 0;
                    }
                    .items-section h3 {
                        color: #667eea;
                        border-bottom: 1px solid #ddd;
                        padding-bottom: 8px;
                        font-size: 16px;
                        margin-bottom: 10px;
                    }
                    .items-content {
                        white-space: pre-wrap;
                        background: #f8f9fa;
                        padding: 12px;
                        border-radius: 5px;
                        line-height: 1.6;
                        font-size: 13px;
                    }
                    .notes-section {
                        margin: 15px 0;
                        padding: 12px;
                        background: #fffbf0;
                        border-left: 4px solid #ffc107;
                        border-radius: 5px;
                    }
                    .notes-section h3 {
                        color: #f57c00;
                        margin-top: 0;
                        font-size: 14px;
                        margin-bottom: 8px;
                    }
                    .notes-section div {
                        font-size: 13px;
                    }
                    .total {
                        text-align: right;
                        font-size: 22px;
                        font-weight: bold;
                        color: #667eea;
                        margin-top: 15px;
                        padding-top: 15px;
                        border-top: 2px solid #667eea;
                    }
                    .status-badge {
                        display: inline-block;
                        padding: 5px 15px;
                        border-radius: 20px;
                        font-size: 14px;
                        font-weight: bold;
                    }
                    .status-pending { background: #ffc107; color: white; }
                    .status-confirmed { background: #17a2b8; color: white; }
                    .status-shipped { background: #007bff; color: white; }
                    .status-delivered { background: #28a745; color: white; }
                    .status-cancelled { background: #dc3545; color: white; }
                    .buttons {
                        position: fixed;
                        bottom: 0;
                        left: 0;
                        right: 0;
                        background: white;
                        border-top: 1px solid #ddd;
                        padding: 15px;
                        display: flex;
                        gap: 10px;
                        justify-content: center;
                        box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
                    }
                    .btn {
                        padding: 12px 25px;
                        font-size: 16px;
                        cursor: pointer;
                        border: none;
                        border-radius: 5px;
                        font-weight: bold;
                        flex: 1;
                        max-width: 200px;
                    }
                    .btn-print {
                        background: #667eea;
                        color: white;
                    }
                    .btn-share {
                        background: #28a745;
                        color: white;
                    }
                    .btn-close {
                        background: #6c757d;
                        color: white;
                    }
                    @media print {
                        .buttons { display: none; }
                        body { padding-bottom: 0; }
                        .info-grid {
                            grid-template-columns: repeat(2, 1fr);
                        }
                    }
                    @media (max-width: 600px) {
                        body {
                            padding: 10px;
                            padding-bottom: 80px;
                        }
                        .header h1 {
                            font-size: 20px;
                        }
                        .header h2 {
                            font-size: 18px;
                        }
                        .info-grid {
                            grid-template-columns: 1fr;
                            gap: 8px;
                        }
                        .total {
                            font-size: 20px;
                        }
                        .btn {
                            padding: 10px 15px;
                            font-size: 14px;
                        }
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>ORDEN DE COMPRA</h1>
                    <h2>${order.order_number}</h2>
                </div>
                
                <div class="info-grid">
                    <div class="info-item">
                        <strong>Proveedor</strong>
                        <div>${order.supplier_name}</div>
                    </div>
                    <div class="info-item">
                        <strong>Fecha de Orden</strong>
                        <div>${new Date(order.order_date).toLocaleDateString()}</div>
                    </div>
                    <div class="info-item">
                        <strong>Fecha de Entrega</strong>
                        <div>${order.delivery_date ? new Date(order.delivery_date).toLocaleDateString() : 'No especificada'}</div>
                    </div>
                    <div class="info-item">
                        <strong>Estado</strong>
                        <div><span class="status-badge status-${order.status}">${order.status.toUpperCase()}</span></div>
                    </div>
                </div>
                
                <div class="items-section">
                    <h3>Items Solicitados</h3>
                    <div class="items-content">${order.items || 'No hay items especificados'}</div>
                </div>
                
                ${order.notes ? `
                    <div class="notes-section">
                        <h3>Notas</h3>
                        <div>${order.notes}</div>
                    </div>
                ` : ''}
                
                <div class="total">
                    TOTAL: $${order.total_amount?.toFixed(2) || '0.00'}
                </div>
                
                <div class="buttons">
                    ${isMobile ? `
                        <button onclick="shareOrder()" class="btn btn-share">📤 Compartir</button>
                    ` : ''}
                    <button onclick="window.print()" class="btn btn-print">🖨️ Imprimir</button>
                    <button onclick="window.close()" class="btn btn-close">✕ Cerrar</button>
                </div>
                
                <script>
                    function shareOrder() {
                        const text = \`ORDEN DE COMPRA: ${order.order_number}
Proveedor: ${order.supplier_name}
Fecha: ${new Date(order.order_date).toLocaleDateString()}
Total: $${order.total_amount?.toFixed(2) || '0.00'}

Items:
${order.items || 'No especificados'}

${order.notes ? 'Notas: ' + order.notes : ''}\`;
                        
                        if (navigator.share) {
                            navigator.share({
                                title: 'Orden ' + '${order.order_number}',
                                text: text
                            }).catch(err => console.log('Error sharing:', err));
                        } else {
                            // Fallback: copy to clipboard
                            navigator.clipboard.writeText(text).then(() => {
                                alert('✓ Orden copiada al portapapeles');
                            });
                        }
                    }
                    
                    // Auto-close after print on desktop
                    if (!${isMobile}) {
                        window.onafterprint = function() {
                            setTimeout(() => window.close(), 500);
                        };
                    }
                </script>
            </body>
            </html>
        `;
        
        // Open print window
        const printWindow = window.open('', '_blank', 'width=800,height=600');
        if (printWindow) {
            printWindow.document.write(printContent);
            printWindow.document.close();
        } else {
            showError('Por favor permita ventanas emergentes para imprimir');
        }
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al preparar la impresión');
    }
}

function exportOrders() {
    window.location.href = `${API_BASE}/orders/export`;
}

// ===== MODALS =====
function showAddSupplierModal() {
    document.getElementById('supplier-modal-title').textContent = 'Nuevo Proveedor';
    document.getElementById('supplier-form').reset();
    document.getElementById('supplier-id').value = '';
    document.getElementById('supplier-modal').classList.add('active');
}

function closeSupplierModal() {
    document.getElementById('supplier-modal').classList.remove('active');
}

function editSupplier(id) {
    const supplier = suppliers.find(s => s.id === id);
    if (!supplier) return;
    
    document.getElementById('supplier-modal-title').textContent = 'Editar Proveedor';
    document.getElementById('supplier-id').value = supplier.id;
    document.getElementById('supplier-name').value = supplier.name || '';
    document.getElementById('supplier-contact').value = supplier.contact_person || '';
    document.getElementById('supplier-email').value = supplier.email || '';
    document.getElementById('supplier-phone').value = supplier.phone || '';
    document.getElementById('supplier-address').value = supplier.address || '';
    document.getElementById('supplier-city').value = supplier.city || '';
    document.getElementById('supplier-country').value = supplier.country || '';
    document.getElementById('supplier-category').value = supplier.category || '';
    document.getElementById('supplier-rating').value = supplier.rating || '';
    document.getElementById('supplier-notes').value = supplier.notes || '';
    
    document.getElementById('supplier-modal').classList.add('active');
}

async function saveSupplier(event) {
    event.preventDefault();
    
    const id = document.getElementById('supplier-id').value;
    const data = {
        name: document.getElementById('supplier-name').value,
        contact_person: document.getElementById('supplier-contact').value,
        email: document.getElementById('supplier-email').value,
        phone: document.getElementById('supplier-phone').value,
        address: document.getElementById('supplier-address').value,
        city: document.getElementById('supplier-city').value,
        country: document.getElementById('supplier-country').value,
        category: document.getElementById('supplier-category').value,
        rating: parseFloat(document.getElementById('supplier-rating').value) || 0,
        notes: document.getElementById('supplier-notes').value
    };
    
    try {
        const url = id ? `${API_BASE}/suppliers/${id}` : `${API_BASE}/suppliers`;
        const method = id ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeSupplierModal();
            loadSuppliers();
            showSuccess(id ? 'Proveedor actualizado' : 'Proveedor creado');
        } else {
            showError('Error al guardar proveedor');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al guardar proveedor');
    }
}

async function showCreateOrderModal() {
    try {
        // Load all suppliers
        const response = await fetch(`${API_BASE}/suppliers`);
        const suppliers = await response.json();
        
        if (suppliers.length === 0) {
            showError('No hay proveedores registrados. Agregue proveedores primero.');
            return;
        }
        
        // Create supplier selection modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'supplier-select-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Crear Nueva Orden</h2>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Seleccione un Proveedor <span class="required">*</span></label>
                        <div class="search-filter" style="margin-bottom: 15px;">
                            <input type="text" id="supplier-quick-search" placeholder="🔍 Buscar proveedor..." class="search-input" oninput="filterSupplierSelection()">
                        </div>
                        <div id="supplier-selection-list" style="max-height: 400px; overflow-y: auto; border: 1px solid #ddd; border-radius: 4px;">
                            ${suppliers.map(s => `
                                <div class="supplier-selection-item" data-supplier-name="${escapeHtml(s.name.toLowerCase())}" data-supplier-id="${s.id}" style="padding: 12px; border-bottom: 1px solid #eee; cursor: pointer; transition: background 0.2s;" onmouseover="this.style.background='#f0f0f0'" onmouseout="this.style.background='white'" onclick="selectSupplierForOrder(${s.id}, '${escapeHtml(s.name)}')">
                                    <strong>${escapeHtml(s.name)}</strong><br>
                                    <small style="color: #666;">${s.email || ''} ${s.city ? '- ' + s.city : ''} ${s.category ? '(' + s.category + ')' : ''}</small>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="button" onclick="this.closest('.modal').remove()" class="btn btn-secondary">Cancelar</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar proveedores');
    }
}

function filterSupplierSelection() {
    const search = document.getElementById('supplier-quick-search').value.toLowerCase();
    const items = document.querySelectorAll('.supplier-selection-item');
    
    items.forEach(item => {
        const name = item.getAttribute('data-supplier-name');
        if (name.includes(search)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

function selectSupplierForOrder(supplierId, supplierName) {
    // Close supplier selection modal
    const modal = document.getElementById('supplier-select-modal');
    if (modal) {
        modal.remove();
    }
    
    // Open the advanced order modal
    createOrderForVendor(supplierId, supplierName);
}

function closeOrderModal() {
    document.getElementById('order-modal').classList.remove('active');
}

async function loadSuppliersForDropdown() {
    try {
        const response = await fetch(`${API_BASE}/suppliers`);
        const suppliers = await response.json();
        const select = document.getElementById('order-supplier');
        select.innerHTML = '<option value="">Seleccionar Proveedor</option>' +
            suppliers.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
    } catch (error) {
        console.error('Error loading suppliers:', error);
    }
}

function createOrderForSupplier(supplierId, itemName) {
    showCreateOrderModal();
    document.getElementById('order-supplier').value = supplierId;
    if (itemName) {
        document.getElementById('order-items').value = itemName;
    }
}

async function saveOrder(event) {
    event.preventDefault();
    
    const data = {
        supplier_id: parseInt(document.getElementById('order-supplier').value),
        delivery_date: document.getElementById('order-delivery-date').value,
        total_amount: parseFloat(document.getElementById('order-amount').value),
        items: document.getElementById('order-items').value,
        notes: document.getElementById('order-notes').value
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeOrderModal();
            loadOrders();
            showSuccess('Orden creada exitosamente');
        } else {
            showError('Error al crear orden');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear orden');
    }
}

// Import Modal
function showImportModal(type) {
    document.getElementById('import-modal').classList.add('active');
    if (type) {
        document.getElementById('import-type').value = type;
        updateImportInstructions();
    }
}

function closeImportModal() {
    document.getElementById('import-modal').classList.remove('active');
    document.getElementById('import-form').reset();
    document.getElementById('import-instructions').style.display = 'none';
}

function updateImportInstructions() {
    const importType = document.getElementById('import-type').value;
    const instructions = document.getElementById('import-instructions');
    const suppliersFormat = document.getElementById('suppliers-format');
    const itemsFormat = document.getElementById('items-format');
    
    if (importType) {
        instructions.style.display = 'block';
        if (importType === 'suppliers') {
            suppliersFormat.style.display = 'block';
            itemsFormat.style.display = 'none';
        } else if (importType === 'items') {
            suppliersFormat.style.display = 'none';
            itemsFormat.style.display = 'block';
        }
    } else {
        instructions.style.display = 'none';
    }
}

async function importFile(event) {
    event.preventDefault();
    
    const importType = document.getElementById('import-type').value;
    const fileInput = document.getElementById('import-file');
    const file = fileInput.files[0];
    
    if (!importType) {
        showError('Por favor seleccione el tipo de importación');
        return;
    }
    
    if (!file) {
        showError('Por favor seleccione un archivo');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    
    let endpoint;
    if (importType === 'suppliers') {
        endpoint = file.name.endsWith('.csv') ? 'csv' : 'excel';
        endpoint = `suppliers/import/${endpoint}`;
    } else if (importType === 'items') {
        // Check if CSV or Excel
        if (file.name.endsWith('.csv')) {
            endpoint = 'suppliers/import/with-items';
        } else {
            endpoint = 'suppliers/import/custom-excel';
        }
    }
    
    try {
        const response = await fetch(`${API_BASE}/${endpoint}`, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (response.ok) {
            closeImportModal();
            
            let message = result.message;
            if (importType === 'items') {
                message += `\n- Proveedores: ${result.suppliers_imported || 0}\n- Items: ${result.items_imported || 0}`;
            }
            showSuccess(message);
            
            // Reload appropriate data
            if (importType === 'suppliers') {
                loadSuppliers();
            } else {
                loadInventory();
                loadSuppliers();
            }
        } else {
            showError(result.error || 'Error al importar archivo');
        }
    } catch (error) {
        console.error('Error importing file:', error);
        showError('Error al importar archivo');
    }
}

function exportSuppliers(format) {
    window.location.href = `${API_BASE}/suppliers/export/${format}`;
}

// Messages - Custom Toast Notifications
function showSuccess(message) {
    showToast(message, 'success');
}

function showError(message) {
    showToast(message, 'error');
}

function showToast(message, type = 'info') {
    // Remove existing toasts
    const existingToast = document.querySelector('.toast-notification');
    if (existingToast) {
        existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</span>
            <span class="toast-message">${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // Trigger animation
    setTimeout(() => toast.classList.add('show'), 10);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function showConfirmDialog(message, onConfirm, onCancel = null) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content modal-confirm">
            <div class="modal-body">
                <p style="white-space: pre-line; margin: 20px 0; font-size: 15px;">${message}</p>
            </div>
            <div class="form-actions" style="margin-top: 20px;">
                <button type="button" class="btn btn-secondary confirm-cancel">Cancelar</button>
                <button type="button" class="btn btn-primary confirm-ok">Aceptar</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
    
    modal.querySelector('.confirm-ok').addEventListener('click', () => {
        modal.remove();
        if (onConfirm) onConfirm();
    });
    
    modal.querySelector('.confirm-cancel').addEventListener('click', () => {
        modal.remove();
        if (onCancel) onCancel();
    });
    
    // Close on backdrop click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
            if (onCancel) onCancel();
        }
    });
}

async function viewSupplierItems(supplierId) {
    try {
        // Get supplier info first
        const supplierResponse = await fetch(`${API_BASE}/suppliers/${supplierId}`);
        const supplier = await supplierResponse.json();
        
        // Show confirmation dialog
        showConfirmDialog(
            `¿Desea ver los items que vende "${supplier.name}"?\n\nEsto lo llevará a la sección de búsqueda de items.`,
            async () => {
                try {
                    await loadSupplierItemsConfirmed(supplierId, supplier.name);
                } catch (error) {
                    console.error('Error:', error);
                    showError('Error al cargar items del proveedor');
                }
            }
        );
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar información del proveedor');
    }
}

async function loadSupplierItemsConfirmed(supplierId, supplierName) {
    try {
        // Get supplier info first
        const supplierResponse = await fetch(`${API_BASE}/suppliers/${supplierId}`);
        const supplier = await supplierResponse.json();
        
        // Get supplier's items
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/items`);
        const data = await response.json();
        const items = data.items || [];
        
        if (items.length === 0) {
            showError('Este proveedor no tiene items registrados');
            return;
        }
        
        // Switch to search items section
        showSection('search-items');
        
        // Clear search input
        const searchInput = document.getElementById('items-search');
        if (searchInput) {
            searchInput.value = '';
        }
        
        // Transform the items to match the expected format for display
        const consolidatedItems = items.map(item => ({
            item: {
                id: item.id,
                item_code: item.item_code,
                name: item.name,
                description: item.description,
                category: item.category,
                unit: item.unit
            },
            suppliers: [{
                supplier_id: supplierId,
                supplier_name: supplier.name,
                email: supplier.email,
                phone: supplier.phone,
                price: item.price,
                supplier_item_code: item.supplier_item_code,
                lead_time_days: item.lead_time_days,
                minimum_order_quantity: item.minimum_order_quantity,
                notes: item.notes
            }]
        }));
        
        // Store in currentSearchResults for filtering to work
        currentSearchResults = items.map(item => ({
            item: {
                id: item.id,
                item_code: item.item_code,
                name: item.name,
                description: item.description,
                category: item.category,
                unit: item.unit
            },
            suppliers: [{
                supplier_id: supplierId,
                supplier_name: supplier.name,
                email: supplier.email,
                phone: supplier.phone,
                price: item.price,
                supplier_item_code: item.supplier_item_code,
                lead_time_days: item.lead_time_days,
                minimum_order_quantity: item.minimum_order_quantity,
                notes: item.notes
            }]
        }));
        
        // Display the items using existing function
        displaySearchResults(consolidatedItems);
        
        // Populate filters using existing function
        populateItemFilters(consolidatedItems);
        
        // Show info message
        showSuccess(`Mostrando ${items.length} item(s) vendidos por: ${supplierName}`);
        
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// ===== PRICE MANAGEMENT PAGE =====

function backToInventory() {
    currentPriceItem = null;
    showSection('inventory');
}

async function loadPriceManagement(itemId) {
    try {
        // Get item details
        const itemResponse = await fetch(`${API_BASE}/items/${itemId}`);
        const item = await itemResponse.json();
        currentPriceItem = item;
        
        // Update header
        document.getElementById('price-item-name').textContent = `${item.item_code} - ${item.name}`;
        document.getElementById('price-item-details').textContent = 
            `${item.description || ''} | Categoría: ${item.category || 'N/A'} | Unidad: ${item.unit || 'N/A'}`;
        
        // Get all suppliers
        const suppliersResponse = await fetch(`${API_BASE}/suppliers`);
        const allSuppliers = await suppliersResponse.json();
        
        // Get item-supplier relationships
        const relationshipsResponse = await fetch(`${API_BASE}/items/${itemId}/suppliers`);
        const relationships = await relationshipsResponse.json();
        
        // Merge data
        allPriceSuppliersData = allSuppliers.map(supplier => {
            const relationship = relationships.find(r => r.id === supplier.id);
            return {
                ...supplier,
                hasRelationship: !!relationship,
                price: relationship?.price || null,
                supplier_item_code: relationship?.supplier_item_code || null,
                lead_time_days: relationship?.lead_time_days || null,
                minimum_order_quantity: relationship?.minimum_order_quantity || null,
                notes: relationship?.notes || null
            };
        });
        
        // Populate filter dropdowns
        populatePriceFilters(allPriceSuppliersData);
        
        // Display suppliers
        filterPriceSuppliers();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar gestión de precios');
    }
}

function populatePriceFilters(suppliers) {
    // Categories
    const categories = [...new Set(suppliers.map(s => s.category).filter(Boolean))].sort();
    const categoryFilter = document.getElementById('price-category-filter');
    categoryFilter.innerHTML = '<option value="">Todas</option>' + 
        categories.map(cat => `<option value="${cat}">${cat}</option>`).join('');
    
    // Cities
    const cities = [...new Set(suppliers.map(s => s.city).filter(Boolean))].sort();
    const cityFilter = document.getElementById('price-city-filter');
    cityFilter.innerHTML = '<option value="">Todas</option>' + 
        cities.map(city => `<option value="${city}">${city}</option>`).join('');
}

function filterPriceSuppliers() {
    const searchTerm = document.getElementById('price-supplier-search').value.toLowerCase();
    const relationshipFilter = document.getElementById('price-relationship-filter').value;
    const categoryFilter = document.getElementById('price-category-filter').value;
    const cityFilter = document.getElementById('price-city-filter').value;
    
    let filtered = [...allPriceSuppliersData];
    
    // Filter by search term
    if (searchTerm) {
        filtered = filtered.filter(s => 
            (s.name || '').toLowerCase().includes(searchTerm) ||
            (s.email || '').toLowerCase().includes(searchTerm) ||
            (s.city || '').toLowerCase().includes(searchTerm)
        );
    }
    
    // Filter by relationship status
    if (relationshipFilter === 'active') {
        filtered = filtered.filter(s => s.hasRelationship);
    } else if (relationshipFilter === 'available') {
        filtered = filtered.filter(s => !s.hasRelationship);
    }
    
    // Filter by category
    if (categoryFilter) {
        filtered = filtered.filter(s => s.category === categoryFilter);
    }
    
    // Filter by city
    if (cityFilter) {
        filtered = filtered.filter(s => s.city === cityFilter);
    }
    
    displayPriceSuppliers(filtered);
}

function displayPriceSuppliers(suppliers) {
    const tbody = document.getElementById('price-suppliers-tbody');
    
    if (suppliers.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="placeholder-text">No se encontraron proveedores</td></tr>';
        return;
    }
    
    tbody.innerHTML = suppliers.map(supplier => {
        if (supplier.hasRelationship) {
            // Existing relationship - show in edit mode
            return `
                <tr data-supplier-id="${supplier.id}" class="relationship-active">
                    <td><strong>${supplier.name}</strong></td>
                    <td>${supplier.email || '-'}</td>
                    <td>${supplier.city || '-'}</td>
                    <td>${supplier.category || '-'}</td>
                    <td>
                        <input type="number" step="0.01" class="form-control form-control-sm price-edit" 
                               value="${supplier.price || ''}" placeholder="Precio">
                    </td>
                    <td>
                        <input type="text" class="form-control form-control-sm code-edit" 
                               value="${supplier.supplier_item_code || ''}" placeholder="Código">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm leadtime-edit" 
                               value="${supplier.lead_time_days || ''}" placeholder="Días">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm minqty-edit" 
                               value="${supplier.minimum_order_quantity || ''}" placeholder="Cant.">
                    </td>
                    <td style="white-space: nowrap;">
                        <button onclick="updateSupplierPrice(${supplier.id})" class="btn btn-success btn-sm" title="Guardar Cambios">
                            💾
                        </button>
                        <button onclick="removeSupplierFromItem(${supplier.id}, '${escapeHtml(supplier.name)}')" 
                                class="btn btn-danger btn-sm" title="Eliminar Proveedor">
                            🗑️
                        </button>
                    </td>
                </tr>
            `;
        } else {
            // No relationship - show add mode
            return `
                <tr data-supplier-id="${supplier.id}" class="relationship-available">
                    <td><strong>${supplier.name}</strong></td>
                    <td>${supplier.email || '-'}</td>
                    <td>${supplier.city || '-'}</td>
                    <td>${supplier.category || '-'}</td>
                    <td>
                        <input type="number" step="0.01" class="form-control form-control-sm price-new" 
                               placeholder="Ingrese precio">
                    </td>
                    <td>
                        <input type="text" class="form-control form-control-sm code-new" 
                               placeholder="Código">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm leadtime-new" 
                               placeholder="Días">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm minqty-new" 
                               placeholder="Cant.">
                    </td>
                    <td>
                        <button onclick="addSupplierToItem(${supplier.id}, '${escapeHtml(supplier.name)}')" 
                                class="btn btn-primary btn-sm" title="Agregar Proveedor">
                            ➕
                        </button>
                    </td>
                </tr>
            `;
        }
    }).join('');
}

async function addSupplierToItem(supplierId, supplierName) {
    const row = document.querySelector(`tr[data-supplier-id="${supplierId}"]`);
    const price = parseFloat(row.querySelector('.price-new').value);
    const supplierCode = row.querySelector('.code-new').value;
    const leadTime = parseInt(row.querySelector('.leadtime-new').value) || null;
    const minQty = parseInt(row.querySelector('.minqty-new').value) || null;
    
    if (!price || price <= 0) {
        showError('Debe ingresar un precio válido');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items/${currentPriceItem.id}/suppliers`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                supplier_id: supplierId,
                price: price,
                supplier_item_code: supplierCode || null,
                lead_time_days: leadTime,
                minimum_order_quantity: minQty,
                notes: null
            })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Error al agregar proveedor');
        }
        
        showSuccess(`Proveedor ${supplierName} agregado exitosamente`);
        await loadPriceManagement(currentPriceItem.id);
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message);
    }
}

async function updateSupplierPrice(supplierId) {
    const row = document.querySelector(`tr[data-supplier-id="${supplierId}"]`);
    const price = parseFloat(row.querySelector('.price-edit').value);
    const supplierCode = row.querySelector('.code-edit').value;
    const leadTime = parseInt(row.querySelector('.leadtime-edit').value) || null;
    const minQty = parseInt(row.querySelector('.minqty-edit').value) || null;
    
    if (!price || price <= 0) {
        showError('Debe ingresar un precio válido');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items/${currentPriceItem.id}/suppliers/${supplierId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                price: price,
                supplier_item_code: supplierCode || null,
                lead_time_days: leadTime,
                minimum_order_quantity: minQty,
                notes: null
            })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Error al actualizar precio');
        }
        
        showSuccess('Precio actualizado exitosamente');
        await loadPriceManagement(currentPriceItem.id);
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message);
    }
}

async function removeSupplierFromItem(supplierId, supplierName) {
    showConfirmDialog(
        `¿Está seguro de eliminar a ${supplierName} de este item?`,
        async () => {
            try {
                await removeSupplierFromItemConfirmed(supplierId, supplierName);
            } catch (error) {
                console.error('Error:', error);
                showError(error.message);
            }
        }
    );
}

async function removeSupplierFromItemConfirmed(supplierId, supplierName) {
    try {
        const response = await fetch(`${API_BASE}/items/${currentPriceItem.id}/suppliers/${supplierId}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Error al eliminar proveedor');
        }
        
        showSuccess(`Proveedor ${supplierName} eliminado exitosamente`);
        await loadPriceManagement(currentPriceItem.id);
        
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

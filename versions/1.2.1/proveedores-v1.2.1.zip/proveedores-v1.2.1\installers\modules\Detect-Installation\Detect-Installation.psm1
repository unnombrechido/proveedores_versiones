# Detect-Installation.psm1
# Detects existing installation structure and version

function Get-InstallationInfo {
    param(
        [string]$Path
    )
    
    $info = @{
        Exists = $false
        Version = "none"
        Structure = "none"
        DatabasePath = $null
        DatabaseSize = 0
        ConfigPath = $null
        HasData = $false
    }
    
    if (-not (Test-Path $Path)) {
        return $info
    }
    
    $info.Exists = $true
    
    # Detect v1.0 structure (modular)
    if ((Test-Path "$Path\api\app.py") -and (Test-Path "$Path\data")) {
        $info.Version = "1.0"
        $info.Structure = "modular"
        
        if (Test-Path "$Path\data\suppliers.db") {
            $info.DatabasePath = "$Path\data\suppliers.db"
            $info.DatabaseSize = (Get-Item "$Path\data\suppliers.db").Length
            $info.HasData = $info.DatabaseSize -gt 8192  # SQLite min size
        }
        
        if (Test-Path "$Path\config\config.ini") {
            $info.ConfigPath = "$Path\config\config.ini"
        } elseif (Test-Path "$Path\config.ini") {
            $info.ConfigPath = "$Path\config.ini"
        } elseif (Test-Path "$Path\api\config.ini") {
            $info.ConfigPath = "$Path\api\config.ini"
        }
    }
    # Detect v0.1 structure (flat)
    elseif (Test-Path "$Path\app.py") {
        $info.Version = "0.1"
        $info.Structure = "flat"
        
        # Check for database in root or subdirectories
        $dbPaths = @(
            "$Path\suppliers.db",
            "$Path\proveedores.db",
            "$Path\data\suppliers.db"
        )
        
        foreach ($dbPath in $dbPaths) {
            if (Test-Path $dbPath) {
                $info.DatabasePath = $dbPath
                $info.DatabaseSize = (Get-Item $dbPath).Length
                $info.HasData = $info.DatabaseSize -gt 8192  # SQLite min size
                break
            }
        }
        
        if (Test-Path "$Path\config.ini") {
            $info.ConfigPath = "$Path\config.ini"
        }
    }
    else {
        $info.Exists = $false
    }
    
    return $info
}

Export-ModuleMember -Function Get-InstallationInfo
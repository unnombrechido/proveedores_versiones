# Install-NewStructure.psm1
# Installs new modular structure

function Install-ModularStructure {
    param(
        [string]$SourcePath,
        [string]$DestPath,
        [bool]$IsUpgrade = $false
    )
    
    $result = @{
        Success = $false
        DirectoriesCreated = @()
        FilesCopied = 0
        Errors = @()
    }
    
    try {
        # Define required directories for v1.0
        $directories = @(
            "api",
            "api\static",
            "api\templates",
            "bin",
            "data",
            "scripts",
            "docs",
            "examples",
            "config",
            "logs",
            "utilities",
            "installers"
        )
        
        # Create directories
        foreach ($dir in $directories) {
            $dirPath = Join-Path $DestPath $dir
            if (-not (Test-Path $dirPath)) {
                New-Item -ItemType Directory -Path $dirPath -Force | Out-Null
                $result.DirectoriesCreated += $dir
            }
        }
        
        # Copy files from source to destination
        $filesToCopy = @(
            @{ Source = "api\app.py"; Dest = "api\app.py" },
            @{ Source = "api\database.py"; Dest = "api\database.py" },
            @{ Source = "api\models.py"; Dest = "api\models.py" },
            @{ Source = "api\init_users.py"; Dest = "api\init_users.py" },
            @{ Source = "api\config.ini"; Dest = "config.ini"; SkipIfExists = $true },
            @{ Source = "api\static"; Dest = "api\static"; IsDir = $true },
            @{ Source = "api\templates"; Dest = "api\templates"; IsDir = $true },
            @{ Source = "bin"; Dest = "bin"; IsDir = $true },
            @{ Source = "scripts"; Dest = "scripts"; IsDir = $true },
            @{ Source = "utilities"; Dest = "utilities"; IsDir = $true },
            @{ Source = "docs"; Dest = "docs"; IsDir = $true },
            @{ Source = "examples"; Dest = "examples"; IsDir = $true },
            @{ Source = "installers"; Dest = "installers"; IsDir = $true },
            @{ Source = "config"; Dest = "config"; IsDir = $true },
            @{ Source = "requirements.txt"; Dest = "requirements.txt" },
            @{ Source = "VERSION"; Dest = "VERSION" },
            @{ Source = "LICENSE"; Dest = "LICENSE" },
            @{ Source = "INSTALAR.bat"; Dest = "INSTALAR.bat" },
            @{ Source = "LEEME_PRIMERO.txt"; Dest = "LEEME_PRIMERO.txt" }
        )
        
        foreach ($item in $filesToCopy) {
            $srcPath = Join-Path $SourcePath $item.Source
            $dstPath = Join-Path $DestPath $item.Dest
            
            if (Test-Path $srcPath) {
                if ($item.SkipIfExists -and (Test-Path $dstPath)) {
                    continue
                }

                if ($item.IsDir) {
                    Copy-Item -Path $srcPath -Destination (Split-Path $dstPath -Parent) -Recurse -Force -ErrorAction SilentlyContinue
                } else {
                    Copy-Item -Path $srcPath -Destination $dstPath -Force -ErrorAction SilentlyContinue
                }
                $result.FilesCopied++
            }
        }
        
        $result.Success = $true
    }
    catch {
        $result.Success = $false
        $result.Errors += $_.Exception.Message
    }

    return $result
}

Export-ModuleMember -Function Install-ModularStructure
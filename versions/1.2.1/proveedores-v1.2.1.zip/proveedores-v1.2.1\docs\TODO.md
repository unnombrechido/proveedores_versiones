# TODO

## Instalación y servicio
- Make app a service to run in the background
- Add an option to start automatically after install and on system restart
- Stop the app if running during installation
- Add an icon to the service
- Add a shortcut to the web app
- Add uninstaller
- Use company logo as icon for the web app
- Remove browser artifacts
- Make it run on a separate window

## Pedidos y plantillas
- User templates for orders
- Separate order versions for user and for sending to vendors (user’s must have prices for estimates, vendor’s must not)

## Catálogo y datos
- Add remove/deactivate vendors/items process
- Add who columns
- Add inventory and inventory management (different from items list)
- Add company letterhead to vendor sending orders

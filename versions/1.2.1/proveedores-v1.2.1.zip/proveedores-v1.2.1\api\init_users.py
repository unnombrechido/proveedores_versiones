"""
Initialize users table and create default sysadmin account
SAFE: This script only ADDS the users table and default user.
It does NOT delete or modify existing data (items, suppliers, orders).

Expected structure:
  project_root/
  ├── api/
  │   ├── app.py
  │   ├── database.py
  │   ├── models.py
  │   └── init_users.py (this file)
  ├── data/
  │   └── suppliers.db
  └── venv/
"""
import sys
import os

# Add api directory to path for imports
api_dir = os.path.dirname(os.path.abspath(__file__))
if api_dir not in sys.path:
    sys.path.insert(0, api_dir)

from database import SessionLocal, Base, engine
from models import User
from sqlalchemy import inspect

def create_users_table_only():
    """Create ONLY the users table if it doesn't exist"""
    inspector = inspect(engine)
    existing_tables = inspector.get_table_names()
    
    if 'users' not in existing_tables:
        print("Creating users table...")
        # Only create the User table, not all tables
        User.__table__.create(bind=engine, checkfirst=True)
        print("Users table created successfully.")
    else:
        print("Users table already exists. Skipping creation.")

def create_default_admin():
    """Create default sysadmin user if not exists"""
    db = SessionLocal()
    try:
        # Check if any users exist
        existing_user = db.query(User).first()
        if existing_user:
            print("Users already exist. Skipping default admin creation.")
            return
        
        # Create default sysadmin
        admin = User(
            email='admin@proveedores.com',
            nombre='System',
            apellido='Administrator',
            telefono='',
            rol='sysadmin',
            status='activo'
        )
        admin.set_password('admin123')  # Default password
        
        db.add(admin)
        db.commit()
        
        print("=" * 60)
        print("Default sysadmin user created successfully!")
        print("=" * 60)
        print("Email: admin@proveedores.com")
        print("Password: admin123")
        print("Role: sysadmin")
        print("=" * 60)
        print("IMPORTANT: Change this password after first login!")
        print("=" * 60)
        
    except Exception as e:
        print(f"Error creating default admin: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == '__main__':
    print("=" * 60)
    print("SAFE DATABASE UPGRADE - Adding User Authentication")
    print("=" * 60)
    print("This script will:")
    print("  1. Create the 'users' table (if it doesn't exist)")
    print("  2. Add default sysadmin user (if no users exist)")
    print("  3. Preserve ALL existing data (items, suppliers, orders)")
    print("=" * 60)
    
    create_users_table_only()
    create_default_admin()
    
    print("=" * 60)
    print("Database upgrade complete!")
    print("Your existing data (items, suppliers, orders) is intact.")
    print("=" * 60)

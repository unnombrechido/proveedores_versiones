# Propuesta de Reorganización de Carpetas

## Estructura Actual (Desordenada)
```
proveedores/
├── app.py
├── database.py
├── models.py
├── INSTALAR.bat
├── setup-complete.ps1
├── install.bat
├── install.ps1
├── install.sh
├── setup.bat
├── create_distribution.bat
├── start.bat
├── README.md
├── INSTALL.txt
├── INSTRUCCIONES_USUARIO.txt
├── UPGRADE_GUIDE.md
├── PERMISSIONS.md
├── RELEASE_NOTES.md
├── LEEME_PRIMERO.txt
├── requirements.txt
├── example_suppliers.csv
├── VERSION
├── LICENSE
├── static/
└── templates/
```

## Opción 1: Estructura Profesional (Para Desarrollo)
```
proveedores/
├── INSTALAR.bat                    ← Instalador principal (raíz para fácil acceso)
├── LEEME_PRIMERO.txt              ← Guía rápida (raíz)
├── LICENSE
├── VERSION
├── requirements.txt
│
├── app/                            ← Código de la aplicación
│   ├── app.py
│   ├── database.py
│   ├── models.py
│   ├── static/
│   └── templates/
│
├── installers/                     ← Scripts de instalación
│   ├── setup-complete.ps1
│   ├── install.bat
│   ├── install.ps1
│   ├── install.sh
│   └── create_distribution.bat
│
├── docs/                           ← Documentación
│   ├── README.md
│   ├── INSTALL.txt
│   ├── INSTRUCCIONES_USUARIO.txt
│   ├── UPGRADE_GUIDE.md
│   ├── PERMISSIONS.md
│   └── RELEASE_NOTES.md
│
└── examples/                       ← Archivos de ejemplo
    └── example_suppliers.csv
```

## Opción 2: Estructura Híbrida (Recomendada para Distribución)
```
proveedores/
├── INSTALAR.bat                    ← Instalador principal
├── LEEME_PRIMERO.txt              ← Inicio rápido
├── README.md                       ← Documentación principal
├── LICENSE
├── VERSION
│
├── app.py                          ← Archivos principales (raíz)
├── database.py
├── models.py
├── requirements.txt
├── static/
└── templates/
│
├── install/                        ← Instaladores adicionales
│   ├── setup-complete.ps1
│   ├── install.bat
│   ├── install.ps1
│   ├── install.sh
│   └── create_distribution.bat
│
└── docs/                           ← Documentación adicional
    ├── INSTALL.txt
    ├── INSTRUCCIONES_USUARIO.txt
    ├── UPGRADE_GUIDE.md
    ├── PERMISSIONS.md
    ├── RELEASE_NOTES.md
    └── example_suppliers.csv
```

## Opción 3: Estructura Plana Mejorada (Mínimos Cambios)
```
proveedores/
├── INSTALAR.bat                    ← Principal
├── LEEME_PRIMERO.txt
├── README.md
│
├── app.py                          ← Código
├── database.py
├── models.py
├── requirements.txt
├── static/
├── templates/
│
├── setup-complete.ps1              ← Instaladores agrupados con prefijo
├── install-windows.bat             (renombrado)
├── install-windows.ps1             (renombrado)
├── install-linux.sh                (renombrado)
├── tools-create-distribution.bat   (renombrado)
│
├── doc-INSTALL.txt                 ← Docs con prefijo
├── doc-UPGRADE_GUIDE.md
├── doc-PERMISSIONS.md
├── doc-RELEASE_NOTES.md
├── doc-INSTRUCCIONES_USUARIO.txt
│
├── example_suppliers.csv
├── VERSION
└── LICENSE
```

## ¿Cuál Prefieres?

**Opción 1**: Más profesional, mejor para desarrollo, requiere cambios en scripts
**Opción 2**: Balance entre organización y facilidad de uso
**Opción 3**: Mínimos cambios, solo renombrar archivos con prefijos

## Recomendación

Para un sistema **distribuible a usuarios finales**, recomiendo **Opción 2**:
- Instaladores principales en raíz (fácil acceso)
- Código de aplicación en raíz (Flask necesita paths relativos simples)
- Documentación secundaria en carpeta `docs/`
- Instaladores alternativos en carpeta `install/`

¿Cuál prefieres implementar?

# CSV Import Templates

This folder contains CSV templates for importing data into the Sistema de Proveedores.

## Available Templates

### 1. `template_suppliers.csv` - Import Suppliers Only
Use this template to import supplier/vendor information.

**Required fields:**
- `name` - Supplier name (required)

**Optional fields:**
- `contact_person` - Name of contact person
- `email` - Email address
- `phone` - Phone number
- `address` - Street address
- `city` - City
- `country` - Country
- `tax_id` - Tax ID / RFC (must be unique)
- `category` - Supplier category (e.g., Metales, Construcción, Ferretería)
- `rating` - Rating from 0.0 to 5.0
- `payment_terms` - Payment terms (e.g., "30 días", "60 días")
- `notes` - Additional notes
- `active` - 1 for active, 0 for inactive (default: 1)

**How to use:**
1. Open template_suppliers.csv in Excel or text editor
2. Delete example rows and add your suppliers
3. Save as CSV (UTF-8)
4. In the application, go to Suppliers → Import → Choose CSV file

---

### 2. `template_items.csv` - Import Items Only
Use this template to import items/products/materials without supplier associations.

**Required fields:**
- `item_code` - Unique item code (e.g., "ACR-001", "TOR-001")
- `name` - Item name (required)

**Optional fields:**
- `description` - Detailed description
- `category` - Item category (e.g., Metales, Ferretería, Construcción)
- `unit` - Unit of measure (e.g., kg, pza, litro, bulto, m3)

**How to use:**
1. Open template_items.csv in Excel or text editor
2. Delete example rows and add your items
3. Save as CSV (UTF-8)
4. In the application, go to Items → Import → Choose CSV file

---

### 3. `template_suppliers_items_prices.csv` - Import Everything (Recommended)
Use this template to import suppliers, items, and prices all at once. This is the most complete option.

**Supplier fields:**
- `supplier_name` - Supplier name (required)
- `supplier_email` - Supplier email
- `supplier_phone` - Supplier phone
- `supplier_city` - Supplier city
- `supplier_country` - Supplier country

**Item fields:**
- `item_code` - Unique item code (required)
- `item_name` - Item name (required)
- `item_description` - Item description
- `item_category` - Item category
- `unit` - Unit of measure

**Price/Relationship fields:**
- `price` - Price per unit (numeric, e.g., 85.50)
- `supplier_item_code` - Supplier's own code for this item
- `lead_time_days` - Delivery time in days
- `minimum_order_quantity` - Minimum order quantity
- `notes` - Notes about this supplier-item relationship

**How to use:**
1. Open template_suppliers_items_prices.csv in Excel or text editor
2. Delete example rows and add your data
3. You can have multiple rows for the same supplier (one per item they supply)
4. You can have multiple rows for the same item (one per supplier)
5. Save as CSV (UTF-8)
6. In the application, use the combined import feature

**Special notes:**
- If a supplier already exists (by name), it will be reused
- If an item already exists (by item_code), it will be reused
- Prices are associated with the supplier-item pair
- One supplier can supply many items (multiple rows with same supplier_name)
- One item can have many suppliers (multiple rows with same item_code)

---

## Common Categories

**Supplier Categories:**
- Metales
- Construcción
- Ferretería
- Pinturas
- Herramientas
- Electricidad
- Plomería
- Maderas

**Item Categories:**
- Metales
- Construcción
- Ferretería
- Pinturas
- Equipos
- Madera
- Electricidad
- Plomería

**Common Units:**
- kg (kilogramos)
- pza (piezas)
- litro (litros)
- m (metros)
- m2 (metros cuadrados)
- m3 (metros cúbicos)
- bulto (bultos)
- caja (cajas)
- rollo (rollos)

---

## Tips

1. **Use consistent naming:** Keep supplier and item names consistent across rows
2. **Unique codes:** Make sure item_code is unique for each item
3. **Encoding:** Save files as CSV (UTF-8) to preserve special characters (ñ, á, é, etc.)
4. **Excel vs Text Editor:** 
   - Excel is easier for editing
   - Text editors (VSCode, Notepad++) are better for UTF-8 encoding
5. **Test with small batches:** Import 5-10 rows first to test, then do bulk import
6. **Backup:** The system automatically backs up data during imports, but keep your CSV files as backup

---

## Example Scenarios

### Scenario 1: New System Setup
Use `template_suppliers_items_prices.csv` to import everything at once.

### Scenario 2: Add Suppliers Only
Use `template_suppliers.csv` to add new suppliers without items.

### Scenario 3: Add Items Only
Use `template_items.csv` to add new items to your catalog.

### Scenario 4: Update Prices
Use `template_suppliers_items_prices.csv` with existing suppliers and items to update prices.

---

## Need Help?

See the full documentation in the `docs/` folder or the in-app help system.

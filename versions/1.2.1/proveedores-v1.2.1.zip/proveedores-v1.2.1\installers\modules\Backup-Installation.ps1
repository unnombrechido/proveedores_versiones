# Backup-Installation.ps1
# Creates backup of existing installation

function New-InstallationBackup {
    param(
        [string]$InstallPath,
        [hashtable]$InstallInfo
    )
    
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupName = "backup_${timestamp}_v$($InstallInfo.Version)"
    $backupPath = Join-Path $InstallPath $backupName
    
    try {
        New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
        
        $backupResult = @{
            Success = $true
            Path = $backupPath
            Files = @()
            TotalSize = 0
        }
        
        # Backup database
        if ($InstallInfo.DatabasePath -and (Test-Path $InstallInfo.DatabasePath)) {
            $dbName = Split-Path $InstallInfo.DatabasePath -Leaf
            $destPath = Join-Path $backupPath $dbName
            Copy-Item $InstallInfo.DatabasePath $destPath -Force
            
            $size = (Get-Item $destPath).Length
            $backupResult.Files += "Database: $dbName ($([math]::Round($size/1KB, 2)) KB)"
            $backupResult.TotalSize += $size
        }
        
        # Backup config
        if ($InstallInfo.ConfigPath -and (Test-Path $InstallInfo.ConfigPath)) {
            $configName = Split-Path $InstallInfo.ConfigPath -Leaf
            $destPath = Join-Path $backupPath $configName
            Copy-Item $InstallInfo.ConfigPath $destPath -Force
            
            $size = (Get-Item $destPath).Length
            $backupResult.Files += "Config: $configName ($([math]::Round($size/1KB, 2)) KB)"
            $backupResult.TotalSize += $size
        }
        
        # Backup entire config folder if exists (v1.0)
        if (Test-Path "$InstallPath\config") {
            $configBackup = Join-Path $backupPath "config"
            Copy-Item "$InstallPath\config" $configBackup -Recurse -Force -ErrorAction SilentlyContinue
        }
        
        # Create backup info file
        @"
Backup Information
==================
Created: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Original Version: $($InstallInfo.Version)
Original Structure: $($InstallInfo.Structure)
Database Size: $([math]::Round($InstallInfo.DatabaseSize/1KB, 2)) KB
Backup Location: $backupPath

Files Backed Up:
$($backupResult.Files -join "`n")

To restore:
1. Stop the application
2. Copy files from this backup folder to installation folder
3. Restart the application
"@ | Out-File -FilePath (Join-Path $backupPath "README.txt") -Encoding UTF8
        
        return $backupResult
        
    } catch {
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

Export-ModuleMember -Function New-InstallationBackup

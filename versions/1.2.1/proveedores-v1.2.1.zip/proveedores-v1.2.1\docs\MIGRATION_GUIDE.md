# Guía de Migración v0.1 → v1.0

## Resumen

La versión 1.0 introduce una **estructura modular profesional** y **sistema de autenticación**. Esta guía explica cómo actualizar de forma segura sin perder datos.

## Cambios Principales

### Estructura de Carpetas

**v0.1 (Estructura Antigua)**:
```
SistemaProveedores/
├── app.py
├── database.py
├── models.py
├── suppliers.db          ← Base de datos en raíz
├── config.ini
├── static/
├── templates/
└── venv/
```

**v1.0 (Estructura Modular Nueva)**:
```
SistemaProveedores/
├── api/                  ← Aplicación Flask
│   ├── app.py
│   ├── database.py
│   ├── models.py
│   ├── static/
│   └── templates/
├── bin/                  ← Ejecutables
│   ├── run.bat
│   └── INSTALAR.bat
├── data/                 ← Bases de datos
│   └── suppliers.db
├── scripts/              ← Utilidades Python
├── docs/                 ← Documentación
├── examples/             ← Datos de ejemplo
├── config/               ← Archivos de configuración
├── logs/                 ← Archivos de log
└── venv/                 ← Entorno virtual
```

### Nuevas Funcionalidades

- ✨ **Sistema de Autenticación**: Login con usuarios y contraseñas
- 👥 **Gestión de Usuarios**: Crear, editar, eliminar usuarios
- 🔐 **Roles y Permisos**:
  - `sysadmin`: Acceso completo
  - `admin`: Gestión de inventario y proveedores
  - `compras`: Solo consulta (sin edición)
- 📊 **Nueva Tabla**: `users` para almacenar usuarios

## Proceso de Migración Segura

### Opción 1: Migración Automática (Recomendada)

#### Paso 1: Crear Respaldo Manual

Antes de empezar, copia tu instalación actual:

```powershell
# Desde PowerShell
Copy-Item "C:\Users\TuUsuario\SistemaProveedores" `
          "C:\Users\TuUsuario\SistemaProveedores_BACKUP" `
          -Recurse
```

#### Paso 2: Verificar Respaldo

Verifica que tu base de datos esté respaldada:

```powershell
Test-Path "C:\Users\TuUsuario\SistemaProveedores_BACKUP\suppliers.db"
```

Debe mostrar `True`.

#### Paso 3: Extraer Nueva Versión

1. Descarga `proveedores-v1.0.zip`
2. Extrae a una carpeta temporal
3. Copia el contenido a tu carpeta de instalación

La nueva estructura se creará automáticamente.

#### Paso 4: Migrar Base de Datos

Ejecuta el utilitario de migración:

```batch
cd C:\Users\TuUsuario\SistemaProveedores
utilities\migrate_database.bat ..\SistemaProveedores_BACKUP\suppliers.db
```

Esto:
- ✅ Crea respaldo automático de destino
- ✅ Copia datos de todas las tablas
- ✅ Maneja diferencias de esquema
- ✅ Preserva usuarios existentes (si los hay)

#### Paso 5: Inicializar Usuarios

Si es tu primera vez con el sistema de autenticación:

```batch
utilities\init_users.bat
```

Esto crea el usuario administrador por defecto:
- **Email**: `admin@proveedores.com`
- **Contraseña**: `admin123`

⚠️ **IMPORTANTE**: Cambia esta contraseña después del primer login.

#### Paso 6: Iniciar Aplicación

```batch
bin\run.bat
```

Abre tu navegador en: http://localhost:5000/login

### Opción 2: Migración Manual

Si prefieres control total:

#### 1. Instalar Nueva Versión en Carpeta Diferente

```powershell
# Extraer a nueva ubicación
Expand-Archive proveedores-v1.0.zip -DestinationPath C:\SistemaProveedores_v1.0
```

#### 2. Copiar Base de Datos Antigua

```powershell
Copy-Item "C:\SistemaProveedores_v0.1\suppliers.db" `
          "C:\SistemaProveedores_v1.0\data\suppliers.db"
```

#### 3. Inicializar Sistema

```batch
cd C:\SistemaProveedores_v1.0
utilities\init_users.bat
bin\run.bat
```

#### 4. Verificar Datos

1. Login con admin@proveedores.com / admin123
2. Ir a sección "Inventario"
3. Verificar que todos tus productos aparecen
4. Ir a sección "Proveedores"
5. Verificar que todos tus proveedores aparecen

#### 5. Si Todo está OK, Eliminar Versión Antigua

```powershell
# Solo después de verificar que todo funciona
Remove-Item "C:\SistemaProveedores_v0.1" -Recurse -Force
```

## Migración de Datos Explicada

### Tablas Compatibles

Las siguientes tablas se migran sin cambios:

| Tabla | Columnas Preservadas | Notas |
|-------|---------------------|-------|
| `items` | id, name, description, unit, category, stock, min_stock, max_stock, last_updated | ✅ 100% compatible |
| `suppliers` | id, name, contact, phone, email, address, notes, last_updated | ✅ 100% compatible |
| `supplier_items` | id, supplier_id, item_id, supplier_code, price, currency, min_quantity, lead_time_days, notes, last_updated | ✅ 100% compatible |
| `purchase_orders` | id, supplier_id, order_date, expected_date, status, total, notes, created_at | ✅ 100% compatible (si existe) |

### Tabla Nueva

| Tabla | Descripción | Acción |
|-------|-------------|--------|
| `users` | Usuarios y roles | ⚡ Se crea automáticamente con usuario admin |

### Proceso Inteligente

El script `migrate_database.py`:

1. **Detecta esquema origen**
   - Lee estructura de tabla antigua
   
2. **Detecta esquema destino**
   - Lee estructura de tabla nueva

3. **Encuentra columnas comunes**
   - Solo migra datos que existen en ambas

4. **Ignora columnas nuevas**
   - Si v1.0 agrega columnas, usa valores por defecto

5. **Ignora columnas eliminadas**
   - Si v1.0 elimina columnas, se pierden (generalmente no hay)

6. **Preserva usuarios**
   - No sobrescribe tabla `users` si existe

## Verificación Post-Migración

### Checklist de Verificación

- [ ] La aplicación inicia sin errores
- [ ] Puedo hacer login con admin@proveedores.com
- [ ] Veo todos mis productos en "Inventario"
- [ ] Veo todos mis proveedores en "Proveedores"
- [ ] Puedo buscar productos
- [ ] Puedo buscar proveedores
- [ ] Puedo agregar un producto nuevo
- [ ] Puedo agregar un proveedor nuevo
- [ ] Puedo crear nuevos usuarios
- [ ] Los roles funcionan (compras no puede editar)

### Problemas Comunes

#### "No se encontró la base de datos"

**Síntoma**: Error al iniciar

**Solución**:
```powershell
# Verificar ubicación
Test-Path "data\suppliers.db"

# Si no existe, crear una nueva
bin\run.bat  # Esto crea la base de datos vacía

# Luego migrar datos
utilities\migrate_database.bat ruta\a\suppliers_viejo.db
```

#### "No puedo hacer login"

**Síntoma**: Credenciales no funcionan

**Solución**:
```batch
# Reinicializar usuarios
utilities\init_users.bat

# Usar credenciales por defecto
# admin@proveedores.com / admin123
```

#### "Mis datos no aparecen"

**Síntoma**: Inventario vacío

**Solución**:
```powershell
# Verificar que la migración se ejecutó
Test-Path "data\suppliers.db"

# Revisar el backup
dir backup_*

# Ejecutar migración nuevamente
utilities\migrate_database.bat backup_YYYYMMDD_HHMMSS\suppliers.db
```

## Rollback (Volver a v0.1)

Si algo sale mal, puedes volver atrás:

### 1. Detener la aplicación nueva

Cierra la ventana de PowerShell donde corre.

### 2. Restaurar backup

```powershell
# Eliminar instalación nueva
Remove-Item "C:\SistemaProveedores" -Recurse -Force

# Restaurar backup
Copy-Item "C:\SistemaProveedores_BACKUP" `
          "C:\SistemaProveedores" `
          -Recurse
```

### 3. Iniciar versión antigua

```batch
cd C:\SistemaProveedores
venv\Scripts\activate
python app.py
```

## Soporte

Si encuentras problemas durante la migración:

1. **No borres tu backup** hasta verificar que todo funciona
2. Revisa `logs/app.log` para errores
3. Verifica que Python y dependencias estén actualizadas
4. Consulta `docs/TROUBLESHOOTING.md`

## Recomendaciones

### Antes de Migrar

- ✅ Crea un backup completo
- ✅ Verifica que tienes Python 3.8+
- ✅ Ten a mano las credenciales del administrador
- ✅ Anota tu configuración personalizada

### Durante la Migración

- ⏱️ No interrumpas el proceso
- 📝 Lee todos los mensajes del instalador
- ⚠️ Si hay errores, no continues

### Después de Migrar

- 🔒 Cambia la contraseña del admin
- 👥 Crea usuarios para tu equipo
- 🧪 Prueba todas las funciones críticas
- 💾 Configura backups periódicos

## Scripts Útiles

### Verificar Contenido de Base de Datos

```powershell
# Ver tablas
sqlite3 data\suppliers.db ".tables"

# Contar registros
sqlite3 data\suppliers.db "SELECT COUNT(*) FROM items;"
sqlite3 data\suppliers.db "SELECT COUNT(*) FROM suppliers;"
```

### Exportar Datos a CSV (Backup Extra)

```powershell
# Exportar items
sqlite3 -header -csv data\suppliers.db "SELECT * FROM items;" > items_backup.csv

# Exportar suppliers
sqlite3 -header -csv data\suppliers.db "SELECT * FROM suppliers;" > suppliers_backup.csv
```

## Conclusión

La migración de v0.1 a v1.0 es segura si:

1. ✅ Creas un backup antes de empezar
2. ✅ Usas los scripts de migración proporcionados
3. ✅ Verificas los datos después

**Tus datos NO se pierden** - el proceso está diseñado para preservarlos completamente.

# ⚠️ IMPORTANTE: Seguridad de Datos en Actualización v0.1 → v1.0

## Resumen Rápido

✅ **TUS DATOS ESTÁN SEGUROS** - El proceso de instalación/actualización:

1. **DETECTA** automáticamente si hay una instalación previa
2. **CREA RESPALDO** completo antes de cualquier cambio
3. **MIGRA** tus datos preservando toda la información
4. **NO ELIMINA** nada sin confirmación

## Proceso Automático de Protección

```
┌─────────────────────────────────────────┐
│ 1. DETECCIÓN                             │
│    ✓ Encuentra instalación v0.1         │
│    ✓ Identifica base de datos           │
│    ✓ Identifica configuración           │
└─────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────┐
│ 2. RESPALDO AUTOMÁTICO                   │
│    ✓ backup_YYYYMMDD_HHMMSS/            │
│      ├── suppliers.db                    │
│      └── config.ini                      │
└─────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────┐
│ 3. INSTALACIÓN NUEVA ESTRUCTURA          │
│    ✓ api/  (código de aplicación)       │
│    ✓ data/ (bases de datos)             │
│    ✓ bin/  (ejecutables)                │
│    ✓ ...etc                              │
└─────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────┐
│ 4. MIGRACIÓN INTELIGENTE DE DATOS        │
│    ✓ Copia TODOS los productos          │
│    ✓ Copia TODOS los proveedores        │
│    ✓ Copia TODAS las relaciones         │
│    ✓ Maneja diferencias de esquema      │
└─────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────┐
│ 5. VERIFICACIÓN                          │
│    ✓ Confirma datos migrados            │
│    ✓ Crea usuario admin inicial         │
│    ✓ Sistema listo para usar            │
└─────────────────────────────────────────┘
```

## Qué se Preserva

| Elemento | Estado | Notas |
|----------|--------|-------|
| 📦 Productos (items) | ✅ Preservado 100% | Todos los campos |
| 🏢 Proveedores (suppliers) | ✅ Preservado 100% | Todos los campos |
| 🔗 Relaciones precio/proveedor | ✅ Preservado 100% | supplier_items |
| 📋 Órdenes de compra | ✅ Preservado 100% | Si existen |
| ⚙️ Configuración | ✅ Preservado | Valores restaurados |
| 👤 Usuarios | ⚡ Nuevo | Se crea tabla users |

## Qué NO se Borra

- ❌ **NO** se elimina la base de datos original
- ❌ **NO** se elimina la configuración original
- ❌ **NO** se sobrescribe nada sin backup previo
- ❌ **NO** se procede sin tu confirmación

## Ubicación de Backups

Cuando actualizas, se crea:

```
C:\Users\TuUsuario\SistemaProveedores\
├── api/                          ← Nueva estructura
├── data/
│   └── suppliers.db              ← Base de datos nueva (con tus datos migrados)
├── backup_20260204_143022_v0.1/  ← ⭐ TU RESPALDO AUTOMÁTICO
│   ├── suppliers.db              ← Tu base de datos original intacta
│   └── config.ini                ← Tu configuración original intacta
└── ...
```

## Migración Manual (Más Segura)

Si prefieres instalar en ubicación nueva:

### 1. Instalar en Carpeta Nueva

```powershell
# Extraer a ubicación diferente
Expand-Archive proveedores-v1.0.zip -DestinationPath C:\SistemaProveedores_v1
```

### 2. Migrar Datos con Script

```batch
cd C:\SistemaProveedores_v1
utilities\migrate_database.bat C:\SistemaProveedores_v0.1\suppliers.db
```

### 3. Verificar Todo Funciona

```batch
bin\run.bat
# Abrir http://localhost:5000/login
# Login: admin@proveedores.com / admin123
# Verificar que todos tus datos aparecen
```

### 4. Solo Entonces Eliminar Versión Antigua

```powershell
# SOLO después de verificar que v1.0 funciona bien
Remove-Item C:\SistemaProveedores_v0.1 -Recurse
```

## Script de Migración Incluido

El sistema incluye `scripts/migrate_database.py` que:

```python
✅ Lee esquema de base de datos origen
✅ Lee esquema de base de datos destino
✅ Identifica columnas comunes
✅ Copia TODOS los datos compatibles
✅ Reporta cuántos registros migró
✅ Crea backup automático antes de migrar
✅ Maneja tablas nuevas (users)
✅ Maneja columnas nuevas (valores por defecto)
```

## Verificación Post-Migración

Después de actualizar, verifica:

```batch
# 1. Iniciar aplicación
bin\run.bat

# 2. Login
# http://localhost:5000/login
# admin@proveedores.com / admin123

# 3. Verificar datos
# - Ir a "Inventario" → debes ver todos tus productos
# - Ir a "Proveedores" → debes ver todos tus proveedores
# - Buscar algo específico para confirmar
```

## Rollback (Si Algo Sale Mal)

Si necesitas volver atrás:

```powershell
# 1. Cerrar aplicación nueva

# 2. Copiar backup a ubicación original
Copy-Item backup_20260204_143022_v0.1\suppliers.db data\suppliers.db -Force

# 3. O usar instalación antigua completa
cd C:\SistemaProveedores_v0.1
venv\Scripts\activate
python app.py
```

## Comandos Útiles de Verificación

### Ver cuántos registros tienes

```powershell
# En base de datos antigua
sqlite3 C:\SistemaProveedores_v0.1\suppliers.db "SELECT COUNT(*) FROM items;"

# En base de datos nueva (después de migrar)
sqlite3 C:\SistemaProveedores_v1\data\suppliers.db "SELECT COUNT(*) FROM items;"

# Los números deben ser IGUALES
```

### Comparar datos

```powershell
# Exportar ambas para comparar
sqlite3 -csv old\suppliers.db "SELECT * FROM items ORDER BY id;" > old_items.csv
sqlite3 -csv new\data\suppliers.db "SELECT * FROM items ORDER BY id;" > new_items.csv

# Comparar archivos (deben ser iguales)
Compare-Object (Get-Content old_items.csv) (Get-Content new_items.csv)
# Si no hay diferencias, muestra nada
```

## Preguntas Frecuentes

### ¿Perderé mis datos si actualizo?

**NO.** El proceso:
1. Crea backup automático
2. Migra todos tus datos
3. Preserva todo el contenido

### ¿Qué pasa si la migración falla?

1. Tu backup está intacto en `backup_YYYYMMDD_HHMMSS/`
2. Puedes copiar de vuelta: `Copy-Item backup_*\suppliers.db data\`
3. O reinstalar v0.1 y seguir usando

### ¿Puedo tener ambas versiones?

**SÍ.** Instala v1.0 en carpeta diferente:
- `C:\SistemaProveedores_v0.1\` → versión antigua
- `C:\SistemaProveedores_v1.0\` → versión nueva

Ambas pueden coexistir sin problemas.

### ¿Necesito hacer algo especial?

**NO.** Solo:
1. Ejecutar instalador
2. Confirmar cuando pregunte
3. El resto es automático

## Garantías

✅ **Backup automático antes de cualquier cambio**
✅ **Migración inteligente de datos**
✅ **Verificación de integridad**
✅ **Rollback disponible**
✅ **No se elimina nada sin confirmación**

## Conclusión

**Actualizar es SEGURO porque:**

1. 📦 Se crea backup automático
2. 🔄 La migración es inteligente
3. ✅ Puedes verificar antes de continuar
4. ↩️ Puedes volver atrás fácilmente
5. 📋 Tienes logs de todo el proceso

**NO tengas miedo de actualizar.**

Para detalles técnicos completos, ver [MIGRATION_GUIDE.md](MIGRATION_GUIDE.md)

# Initialize-System.psm1
# Initializes Python environment and database

function Initialize-PythonEnvironment {
    param(
        [string]$InstallPath,
        [string]$PythonCmd
    )
    
    $result = @{
        Success = $false
        VenvCreated = $false
        DependenciesInstalled = $false
        Errors = @()
    }
    
    Push-Location $InstallPath
    
    try {
        # Create virtual environment
        if (Test-Path "venv") {
            Remove-Item -Recurse -Force venv -ErrorAction SilentlyContinue
        }
        
        & $PythonCmd -m venv venv 2>&1 | Out-Null
        
        if ($LASTEXITCODE -eq 0) {
            $result.VenvCreated = $true
        } else {
            $result.Errors += "Failed to create virtual environment"
            Pop-Location
            return $result
        }
        
        # Install dependencies
        if (Test-Path "requirements.txt") {
            $pipPath = "venv\Scripts\pip.exe"
            
            # Upgrade pip
            & $pipPath install --upgrade pip --quiet 2>&1 | Out-Null
            
            # Install requirements
            & $pipPath install -r requirements.txt --quiet 2>&1 | Out-Null
            
            if ($LASTEXITCODE -eq 0) {
                $result.DependenciesInstalled = $true
                $result.Success = $true
            } else {
                $result.Errors += "Failed to install dependencies"
            }
        }
    }
    catch {
        $result.Success = $false
        $result.Errors += $_.Exception.Message
    }
    finally {
        Pop-Location
    }
    
    return $result
}

function Initialize-Database {
    param(
        [string]$InstallPath,
        [bool]$CreateDefaultAdmin = $false
    )
    
    $result = @{
        Success = $false
        AdminCreated = $false
        Errors = @()
    }
    
    try {
        # Ensure data directory exists
        $dataDir = Join-Path $InstallPath "data"
        if (-not (Test-Path $dataDir)) {
            New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
        }
        
        $dbPath = Join-Path $dataDir "suppliers.db"
        
        # Database already exists - skip initialization to preserve data
        if (Test-Path $dbPath) {
            $result.Success = $true
            return $result
        }
        
        # Create new database using Python
        $pythonExe = Join-Path $InstallPath "venv\Scripts\python.exe"
        
        if (-not (Test-Path $pythonExe)) {
            $result.Errors += "Python virtual environment not found. Run Initialize-PythonEnvironment first."
            return $result
        }
        
        # Create database using Python database.py
        $databasePy = Join-Path $InstallPath "api\database.py"
        
        if (Test-Path $databasePy) {
            # Create a temporary script to initialize database
            # Script must be in api directory so database.py can find correct paths
            $apiDir = Join-Path $InstallPath "api"
            $initScript = @"
import sys
import os

# Ensure we're working from the api directory
api_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(api_dir)
sys.path.insert(0, api_dir)

from database import init_db
import models  # Import models to register them with Base metadata
init_db()
print("Database initialized successfully")
"@
            $tempScript = Join-Path $apiDir "temp_init_db.py"
            Set-Content -Path $tempScript -Value $initScript -Encoding UTF8
            
            Push-Location $apiDir
            $output = & $pythonExe $tempScript 2>&1
            $exitCode = $LASTEXITCODE
            Remove-Item $tempScript -Force -ErrorAction SilentlyContinue
            
            Pop-Location
            
            # Give filesystem a moment to sync (SQLite write may be buffered)
            Start-Sleep -Milliseconds 500
            
            # Check if database was created successfully
            # Look for success message in output AND verify file exists
            $outputStr = $output -join ' '
            $hasSuccessMessage = $outputStr -match "Database initialized successfully"
            
            # Try to extract actual database path from Python output
            $actualDbPath = $null
            if ($outputStr -match "Creating database at:\s+([^\s]+)") {
                $actualDbPath = $matches[1]
            }
            
            $fileExists = Test-Path $dbPath
            
            if ($hasSuccessMessage -and $fileExists) {
                $result.Success = $true
            } elseif ($hasSuccessMessage -and -not $fileExists) {
                # Success message but file not found - check if it's at a different location
                if ($actualDbPath -and (Test-Path $actualDbPath)) {
                    $result.Errors += "Database created at unexpected location: $actualDbPath"
                    $result.Errors += "Expected location: $dbPath"
                    $result.Errors += "This indicates a path configuration issue"
                } else {
                    # Wait a bit more and recheck
                    Start-Sleep -Milliseconds 1000
                    if (Test-Path $dbPath) {
                        $result.Success = $true
                    } else {
                        $result.Errors += "Database initialized but file not found at: $dbPath"
                        if ($actualDbPath) {
                            $result.Errors += "Python reported creating at: $actualDbPath"
                        }
                        $result.Errors += "Python output: $outputStr"
                    }
                }
            } else {
                $result.Errors += "Database file was not created"
                if ($output) {
                    $result.Errors += "Python output: $outputStr"
                }
                if ($exitCode -ne 0) {
                    $result.Errors += "Exit code: $exitCode"
                }
            }
        } else {
            $result.Errors += "database.py not found at $databasePy"
        }
        
        # Create default admin user if requested
        if ($result.Success -and $CreateDefaultAdmin) {
            $initUsersPy = Join-Path $InstallPath "api\init_users.py"
            
            if (Test-Path $initUsersPy) {
                $pythonExe = Join-Path $InstallPath "venv\Scripts\python.exe"
                Push-Location (Join-Path $InstallPath "api")
                
                $output = & $pythonExe $initUsersPy 2>&1
                
                Pop-Location
                
                if ($LASTEXITCODE -eq 0) {
                    $result.AdminCreated = $true
                }
            }
        }
    }
    catch {
        $result.Success = $false
        $result.Errors += $_.Exception.Message
    }
    
    return $result
}

Export-ModuleMember -Function Initialize-PythonEnvironment, Initialize-Database
# ============================================================
#  Sistema de Gestión de Proveedores v1.2.1
#  Instalador Completo con Migración Inteligente
# ============================================================

$versionPath = Join-Path (Split-Path $PSScriptRoot -Parent) "VERSION"
$VERSION = if (Test-Path $versionPath) { (Get-Content $versionPath -Raw).Trim() } else { "1.2.1" }
$Host.UI.RawUI.WindowTitle = "Sistema de Proveedores v$VERSION - Instalador Completo"
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "White"
Clear-Host

# Configuration
$GITHUB_RELEASE_URL = "https://github.com/TU_USUARIO/proveedores/releases/download/v$VERSION/proveedores-v$VERSION.zip"
$TEMP_ZIP = "$env:TEMP\proveedores-v$VERSION.zip"

# Progress tracking function
function Show-OverallProgress {
    param(
        [int]$Step,
        [int]$TotalSteps,
        [string]$Description
    )
    
    $percent = [math]::Floor(($Step / $TotalSteps) * 100)
    $progressChars = [math]::Floor($percent / 2)
    $progressBar = "[" + ("█" * $progressChars) + ("·" * (50 - $progressChars)) + "]"
    
    Write-Host ""
    Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor DarkCyan
    Write-Host " PROGRESO GENERAL: $progressBar $percent%" -ForegroundColor Cyan
    Write-Host " Paso $Step de ${TotalSteps}: $Description" -ForegroundColor White
    Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor DarkCyan
    Write-Host ""
}

# Detect installation structure version
function Get-InstallationStructure {
    param(
        [string]$Path
    )
    
    # Check for v1.0 structure (modular: api/, bin/, data/, scripts/)
    if ((Test-Path "$Path\api\app.py") -and 
        (Test-Path "$Path\bin") -and 
        (Test-Path "$Path\data")) {
        return "v1.0"
    }
    
    # Check for v0.1 structure (old: app/, suppliers.db at root)
    if ((Test-Path "$Path\app\app.py") -or (Test-Path "$Path\app.py")) {
        return "v0.1"
    }
    
    return "unknown"
}

# Backup existing installation
function Backup-Installation {
    param(
        [string]$InstallDir,
        [string]$Structure
    )
    
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupDir = "$InstallDir\backup_${timestamp}_${Structure}"
    
    Write-Host "[INFO] Creando respaldo completo..." -ForegroundColor Yellow
    
    try {
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        
        # Backup database
        if ($Structure -eq "v0.1") {
            if (Test-Path "$InstallDir\suppliers.db") {
                Copy-Item "$InstallDir\suppliers.db" "$backupDir\suppliers.db" -Force
                Write-Host "  [OK] Base de datos respaldada" -ForegroundColor Green
            }
            if (Test-Path "$InstallDir\proveedores.db") {
                Copy-Item "$InstallDir\proveedores.db" "$backupDir\proveedores.db" -Force
                Write-Host "  [OK] Base de datos respaldada" -ForegroundColor Green
            }
        } else {
            if (Test-Path "$InstallDir\data\suppliers.db") {
                Copy-Item "$InstallDir\data\suppliers.db" "$backupDir\suppliers.db" -Force
                Write-Host "  [OK] Base de datos respaldada" -ForegroundColor Green
            }
        }
        
        # Backup config
        if (Test-Path "$InstallDir\config\config.ini") {
            Copy-Item "$InstallDir\config\config.ini" "$backupDir\config.ini" -Force
            Write-Host "  [OK] Configuración respaldada" -ForegroundColor Green
        } elseif (Test-Path "$InstallDir\config.ini") {
            Copy-Item "$InstallDir\config.ini" "$backupDir\config.ini" -Force
            Write-Host "  [OK] Configuración respaldada" -ForegroundColor Green
        }
        
        Write-Host ""
        Write-Host "[OK] Respaldo creado en: $backupDir" -ForegroundColor Green
        return $backupDir
    } catch {
        Write-Host "[ERROR] Fallo al crear respaldo: $_" -ForegroundColor Red
        return $null
    }
}

function Create-DesktopShortcut {
    param(
        [string]$Name,
        [string]$TargetPath,
        [string]$WorkingDirectory,
        [string]$Description
    )

    try {
        $desktop = @([Environment]::GetFolderPath('Desktop'))[0]
        $shortcutPath = Join-Path $desktop "$Name.lnk"

        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut($shortcutPath)
        $Shortcut.TargetPath = $TargetPath
        $Shortcut.WorkingDirectory = $WorkingDirectory
        $Shortcut.Description = $Description
        $Shortcut.Save()
        return $true
    }
    catch {
        return $false
    }
}

function Read-HostDefault {
    param(
        [string]$Prompt,
        [string]$Default = ""
    )

    $suffix = if ([string]::IsNullOrWhiteSpace($Default)) { "" } else { " [$Default]" }
    $value = Read-Host "$Prompt$suffix"
    if ([string]::IsNullOrWhiteSpace($value)) {
        return $Default
    }
    return $value
}

function Normalize-PathInput {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $Value }
    return $Value.Trim().Trim('"').Trim("'")
}

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# Banner
Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  SISTEMA DE GESTION DE PROVEEDORES E INVENTARIO v$VERSION" -ForegroundColor Cyan
Write-Host "  Instalador Completo con Migración Inteligente" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

if ($isAdmin) {
    Write-Host "[INFO] Ejecutando con permisos de administrador" -ForegroundColor Green
} else {
    Write-Host "[INFO] Ejecutando como usuario normal" -ForegroundColor Gray
}
Write-Host ""

Show-OverallProgress -Step 1 -TotalSteps 8 -Description "Verificando Python"

# Check Python
Write-Host "[Verificando requisitos...]" -ForegroundColor Yellow
Write-Host ""

$pythonInstalled = $false
$pythonCmd = "python"

# Try python3 first (common on systems with both Python 2 and 3)
try {
    $pythonVersion = python3 --version 2>&1 | Out-String
    if ($pythonVersion -match "Python 3") {
        Write-Host "[OK] Python 3 detectado: $pythonVersion" -ForegroundColor Green
        $pythonCmd = "python3"
        $pythonInstalled = $true
    }
} catch {
    # python3 command not found, try python
}

# If python3 didn't work, try python
if (-not $pythonInstalled) {
    try {
        $pythonVersion = python --version 2>&1 | Out-String
        if ($pythonVersion -match "Python 3") {
            Write-Host "[OK] Python detectado: $pythonVersion" -ForegroundColor Green
            $pythonCmd = "python"
            $pythonInstalled = $true
        } elseif ($pythonVersion -match "Python 2") {
            Write-Host "[ADVERTENCIA] Se detecto Python 2.7: $pythonVersion" -ForegroundColor Yellow
            Write-Host "[INFO] Se requiere Python 3.8+, pero se encontro Python 2.x" -ForegroundColor Yellow
            Write-Host ""
            # Don't set $pythonInstalled = $true, let it try to install Python 3
        }
    } catch {
        Write-Host "[INFO] Python no esta instalado." -ForegroundColor Yellow
        Write-Host ""
    }
}

# Try to install Python automatically if not found
if (-not $pythonInstalled) {
    Write-Host "Intentando instalar Python automaticamente..." -ForegroundColor Cyan
    Write-Host ""
    
    # Check if we need admin rights
    if (-not $isAdmin) {
        Write-Host "[ADVERTENCIA] No se detectaron permisos de administrador." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Para instalar Python automaticamente, necesitas:" -ForegroundColor White
        Write-Host "1. Cerrar esta ventana" -ForegroundColor Gray
        Write-Host "2. Clic derecho en setup-complete.ps1" -ForegroundColor Gray
        Write-Host "3. Seleccionar 'Ejecutar con PowerShell como Administrador'" -ForegroundColor Gray
        Write-Host ""
        $continueAnyway = Read-HostDefault "Continuar sin instalar Python automaticamente? (S/N)" "N"
        
        if ($continueAnyway -ne "S" -and $continueAnyway -ne "s") {
            Write-Host ""
            Write-Host "Instalacion cancelada. Ejecuta como administrador e intenta de nuevo." -ForegroundColor Yellow
            Read-HostDefault "Presiona Enter para salir" ""
            exit 1
        }
        
        # User chose to continue, skip to manual instructions
        Write-Host ""
        Write-Host "[INFO] Saltando instalacion automatica..." -ForegroundColor Yellow
        Write-Host ""
    }
    
    # Try winget first (Windows 10 1709+ / Windows 11)
    if ($isAdmin) {
        try {
            $wingetCheck = Get-Command winget -ErrorAction SilentlyContinue
            if ($wingetCheck) {
                Write-Host "[INFO] Usando winget para instalar Python 3.13.9..." -ForegroundColor Cyan
                Write-Host "[INFO] Esto puede tardar varios minutos..." -ForegroundColor Gray
                Write-Host ""
                
                # Try to install Python for all users (needs admin)
                $wingetResult = winget install Python.Python.3.13 --silent --scope machine --accept-package-agreements --accept-source-agreements 2>&1
                
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "[OK] Python instalado exitosamente" -ForegroundColor Green
                    Write-Host "[INFO] Reiniciando terminal para actualizar PATH..." -ForegroundColor Yellow
                    Write-Host ""
                    Write-Host "IMPORTANTE: Cierra esta ventana y ejecuta el instalador nuevamente." -ForegroundColor Cyan
                    Write-Host ""
                    Read-HostDefault "Presiona Enter para cerrar" ""
                    exit 0
                } else {
                    Write-Host "[ADVERTENCIA] winget fallo: $wingetResult" -ForegroundColor Yellow
                    Write-Host "[INFO] Intentando instalacion para usuario actual..." -ForegroundColor Cyan
                    
                    # Try user-level install as fallback
                    $wingetResult2 = winget install Python.Python.3.13 --silent --scope user --accept-package-agreements --accept-source-agreements 2>&1
                    
                    if ($LASTEXITCODE -eq 0) {
                        Write-Host "[OK] Python instalado para usuario actual" -ForegroundColor Green
                        Write-Host "[INFO] Reiniciando terminal..." -ForegroundColor Yellow
                        Write-Host ""
                        Write-Host "IMPORTANTE: Cierra esta ventana y ejecuta el instalador nuevamente." -ForegroundColor Cyan
                        Write-Host ""
                        Read-HostDefault "Presiona Enter para cerrar" ""
                        exit 0
                    }
                }
            }
        } catch {
            Write-Host "[INFO] winget no disponible o fallo: $_" -ForegroundColor Gray
        }
    }
    
    # If we get here, automatic installation failed or was skipped
    Write-Host "[INFO] Instalacion automatica no disponible." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Por favor instala Python manualmente:" -ForegroundColor White
    Write-Host ""
    Write-Host "1. Visita: https://www.python.org/downloads/" -ForegroundColor Cyan
    Write-Host "2. Descarga Python 3.13.9 (o superior)" -ForegroundColor Gray
    Write-Host "3. Durante la instalacion, marca:" -ForegroundColor Gray
    Write-Host "   [X] Add Python to PATH" -ForegroundColor Yellow
    Write-Host "4. Completa la instalacion" -ForegroundColor Gray
    Write-Host "5. Ejecuta este instalador nuevamente" -ForegroundColor Gray
    Write-Host ""
    
    $openBrowser = Read-HostDefault "Abrir pagina de descarga ahora? (S/N)" "N"
    if ($openBrowser -eq "S" -or $openBrowser -eq "s") {
        Start-Process "https://www.python.org/downloads/"
    }
    
    Write-Host ""
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}

# Check Python version
$versionCheck = & $pythonCmd -c "import sys; exit(0 if sys.version_info >= (3, 8) else 1)" 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Se requiere Python 3.8 o superior." -ForegroundColor Red
    Write-Host "La version instalada es muy antigua." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Por favor actualiza Python desde: https://www.python.org/downloads/" -ForegroundColor Cyan
    Write-Host ""
    Read-HostDefault "Presiona Enter para salir" ""
    exit 1
}

Write-Host "[INFO] Usando comando: $pythonCmd" -ForegroundColor Cyan
Write-Host ""

Show-OverallProgress -Step 2 -TotalSteps 8 -Description "Configuracion de Instalacion"

Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  CONFIGURACION DE INSTALACION" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Antes de continuar, asegúrate de cerrar la aplicación si está en ejecución." -ForegroundColor Yellow
Read-HostDefault "Presiona Enter para continuar" ""

# Ask for installation directory
$defaultDir = "C:\SistemaProveedores"
Write-Host "Ubicacion de instalacion por defecto:" -ForegroundColor White
Write-Host "$defaultDir" -ForegroundColor Gray
Write-Host ""
$installDir = Normalize-PathInput (Read-HostDefault "Presiona ENTER para usar por defecto, o escribe nueva ruta" $defaultDir)

Write-Host ""
Write-Host "[INFO] Se instalara en: $installDir" -ForegroundColor Cyan
Write-Host ""

# Ask for company name
$companyName = Read-HostDefault "Nombre de tu empresa (opcional, presiona ENTER para omitir)" ""
Write-Host ""

# Ask for logo path
Write-Host "Logo de la empresa (opcional):" -ForegroundColor White
Write-Host "Proporciona la ruta a tu logo (PNG/JPG/SVG)" -ForegroundColor Gray
Write-Host "Si no tienes uno, presiona ENTER para usar el logo por defecto" -ForegroundColor Gray
Write-Host ""
$logoPath = Normalize-PathInput (Read-HostDefault "Ruta completa al logo (o ENTER para omitir)" "")
Write-Host ""

# Validate logo if provided
if (-not [string]::IsNullOrWhiteSpace($logoPath)) {
    if (-not (Test-Path $logoPath)) {
        Write-Host "[ADVERTENCIA] La ruta del logo no existe. Se usara el logo por defecto." -ForegroundColor Yellow
        $logoPath = ""
        Start-Sleep -Seconds 2
    }
}

# Show summary
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  RESUMEN DE CONFIGURACION" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Ubicacion:  " -NoNewline -ForegroundColor White
Write-Host "$installDir" -ForegroundColor Yellow

if (-not [string]::IsNullOrWhiteSpace($companyName)) {
    Write-Host "Empresa:    " -NoNewline -ForegroundColor White
    Write-Host "$companyName" -ForegroundColor Yellow
} else {
    Write-Host "Empresa:    " -NoNewline -ForegroundColor White
    Write-Host "[No especificado]" -ForegroundColor Gray
}

if (-not [string]::IsNullOrWhiteSpace($logoPath)) {
    Write-Host "Logo:       " -NoNewline -ForegroundColor White
    Write-Host "$logoPath" -ForegroundColor Yellow
} else {
    Write-Host "Logo:       " -NoNewline -ForegroundColor White
    Write-Host "[Por defecto]" -ForegroundColor Gray
}

Write-Host ""
$confirm = Read-HostDefault "Continuar con la instalacion? (S/N)" "S"

if ($confirm -ne "S" -and $confirm -ne "s") {
    Write-Host "Instalacion cancelada." -ForegroundColor Yellow
    Read-HostDefault "Presiona Enter para salir" ""
    exit 0
}

Show-OverallProgress -Step 3 -TotalSteps 8 -Description "Preparando Instalacion"

Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  DESCARGANDO E INSTALANDO SISTEMA" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# Create installation directory
Write-Host "[3.1] Verificando directorio de instalacion..." -ForegroundColor Yellow

$isUpgrade = $false
$existingConfig = $null
$existingDB = $null
$existingConfigPath = $null
$existingDbPath = $null
$structure = "unknown"

if (Test-Path $installDir) {
    $structure = Get-InstallationStructure -Path $installDir
    if ($structure -ne "unknown") {
        $isUpgrade = $true
        Write-Host "[INFO] Instalacion existente detectada!" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Se encontro una instalacion anterior en:" -ForegroundColor White
        Write-Host "$installDir" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Los siguientes datos se preservaran:" -ForegroundColor Green

        if (Test-Path "$installDir\config\config.ini") {
            $existingConfigPath = "$installDir\config\config.ini"
        } elseif (Test-Path "$installDir\config.ini") {
            $existingConfigPath = "$installDir\config.ini"
        }

        if ($existingConfigPath) {
            Write-Host "  [X] Configuracion (config.ini)" -ForegroundColor Green
            $existingConfig = Get-Content $existingConfigPath -Raw
        } else {
            Write-Host "  [ ] Configuracion (no encontrada)" -ForegroundColor Gray
        }

        if ($structure -eq "v1.0" -and (Test-Path "$installDir\data\suppliers.db")) {
            $existingDbPath = "$installDir\data\suppliers.db"
            $dbSize = (Get-Item $existingDbPath).Length
            $dbSizeKB = [math]::Round($dbSize / 1KB, 2)
            Write-Host "  [X] Base de datos (data\suppliers.db - $dbSizeKB KB)" -ForegroundColor Green
        } elseif (Test-Path "$installDir\proveedores.db") {
            $existingDbPath = "$installDir\proveedores.db"
            $dbSize = (Get-Item $existingDbPath).Length
            $dbSizeKB = [math]::Round($dbSize / 1KB, 2)
            Write-Host "  [X] Base de datos (proveedores.db - $dbSizeKB KB)" -ForegroundColor Green
        } elseif (Test-Path "$installDir\suppliers.db") {
            $existingDbPath = "$installDir\suppliers.db"
            $dbSize = (Get-Item $existingDbPath).Length
            $dbSizeKB = [math]::Round($dbSize / 1KB, 2)
            Write-Host "  [X] Base de datos (suppliers.db - $dbSizeKB KB)" -ForegroundColor Green
        } else {
            Write-Host "  [ ] Base de datos (no encontrada)" -ForegroundColor Gray
        }

        Write-Host ""
        Write-Host "IMPORTANTE: Tus proveedores, productos y pedidos NO se borraran." -ForegroundColor Cyan
        Write-Host ""
        $continueUpgrade = Read-HostDefault "Continuar con la actualizacion? (S/N)" "S"

        if ($continueUpgrade -ne "S" -and $continueUpgrade -ne "s") {
            Write-Host "Actualizacion cancelada." -ForegroundColor Yellow
            Read-HostDefault "Presiona Enter para salir" ""
            exit 0
        }

        Write-Host ""
        Write-Host "[INFO] Creando respaldo de seguridad..." -ForegroundColor Yellow
        $backupDir = "$installDir\backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

        if ($existingConfigPath) {
            Copy-Item $existingConfigPath "$backupDir\config.ini" -Force
        }
        if ($existingDbPath) {
            Copy-Item $existingDbPath "$backupDir\$([System.IO.Path]::GetFileName($existingDbPath))" -Force
        }

        Write-Host "[OK] Respaldo creado en: $backupDir" -ForegroundColor Green
        Write-Host ""
    } else {
        Write-Host "[OK] Directorio ya existe (vacio)" -ForegroundColor Green
    }
} else {
    try {
        New-Item -ItemType Directory -Path $installDir -Force | Out-Null
        Write-Host "[OK] Directorio creado: $installDir" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] No se pudo crear el directorio." -ForegroundColor Red
        Write-Host "Verifica que tienes permisos o elige otra ubicacion." -ForegroundColor Yellow
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}
Write-Host ""

# Check if files are in current directory (manual installation)
$currentDir = Get-Location
$parentDir = Split-Path -Parent $currentDir

# Check if we're in the installers folder or root
$appDir = if (Test-Path "$parentDir\app\app.py") { "$parentDir\app" } elseif (Test-Path "$currentDir\app\app.py") { "$currentDir\app" } else { $null }

if ($appDir) {
    Write-Host "[INFO] Archivos detectados en: $appDir" -ForegroundColor Cyan
    
    Show-OverallProgress -Step 4 -TotalSteps 8 -Description "Copiando Archivos del Sistema"
    
    Write-Host "[3.2] Copiando archivos al directorio de instalacion..." -ForegroundColor Yellow
    
    # Copy app files
    Copy-Item -Path "$appDir\*" -Destination $installDir -Recurse -Force
    
    # Copy root files (requirements.txt, VERSION, LICENSE)
    $rootDir = if (Test-Path "$parentDir\requirements.txt") { $parentDir } else { $currentDir }
    if (Test-Path "$rootDir\requirements.txt") {
        Copy-Item -Path "$rootDir\requirements.txt" -Destination $installDir -Force
    }
    if (Test-Path "$rootDir\VERSION") {
        Copy-Item -Path "$rootDir\VERSION" -Destination $installDir -Force
    }
    if (Test-Path "$rootDir\LICENSE") {
        Copy-Item -Path "$rootDir\LICENSE" -Destination $installDir -Force
    }
    
    Write-Host "[OK] Archivos copiados" -ForegroundColor Green
    Write-Host ""
} else {
    # Try to download from GitHub
    Write-Host "[2/6] Descargando desde GitHub..." -ForegroundColor Yellow
    Write-Host "[INFO] URL: $GITHUB_RELEASE_URL" -ForegroundColor Gray
    Write-Host ""
    Write-Host "[NOTA] Si la descarga falla, copia manualmente los archivos a:" -ForegroundColor Yellow
    Write-Host "$installDir" -ForegroundColor Gray
    Write-Host ""
    
    try {
        # Download (this will fail if URL doesn't exist yet)
        # Invoke-WebRequest -Uri $GITHUB_RELEASE_URL -OutFile $TEMP_ZIP
        # Expand-Archive -Path $TEMP_ZIP -DestinationPath $installDir -Force
        # Remove-Item $TEMP_ZIP -Force
        
        Write-Host "[ERROR] La descarga automatica aun no esta configurada." -ForegroundColor Red
        Write-Host ""
        Write-Host "Por favor copia manualmente estos archivos a: $installDir" -ForegroundColor Yellow
        Write-Host "  - app.py, database.py, models.py" -ForegroundColor Gray
        Write-Host "  - requirements.txt" -ForegroundColor Gray
        Write-Host "  - static/ (carpeta completa)" -ForegroundColor Gray
        Write-Host "  - templates/ (carpeta completa)" -ForegroundColor Gray
        Write-Host "  - Todos los archivos .bat, .md" -ForegroundColor Gray
        Write-Host ""
        Write-Host "Luego ejecuta este instalador nuevamente." -ForegroundColor Cyan
        Write-Host ""
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    } catch {
        Write-Host "[ERROR] No se pudo descargar: $_" -ForegroundColor Red
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}

# Change to installation directory
Set-Location $installDir

Show-OverallProgress -Step 5 -TotalSteps 8 -Description "Configurando Personalizacion"

# Create or restore config file
Write-Host "[5.1] Configurando sistema..." -ForegroundColor Yellow

# Resolve current app version from source VERSION file (if present)
$sourceVersionPath = Join-Path (Split-Path $PSScriptRoot -Parent) "VERSION"
$currentVersion = ""
if (Test-Path $sourceVersionPath) {
    $currentVersion = (Get-Content $sourceVersionPath -Raw).Trim()
}

if ($isUpgrade -and $existingConfig) {
    # Restore existing config (preserve user settings)
    Write-Host "[INFO] Restaurando configuracion existente..." -ForegroundColor Cyan
    if (-not (Test-Path "config")) {
        New-Item -ItemType Directory -Path "config" -Force | Out-Null
    }
    $existingConfig | Out-File -FilePath "config\config.ini" -Encoding ASCII
    
    # Update version and date
    $configLines = Get-Content "config\config.ini"
    $newConfig = @()
    $versionFound = $false
    
    foreach ($line in $configLines) {
        if ($line -match "^VERSION=") {
            $newConfig += "VERSION=$currentVersion"
            $versionFound = $true
        } elseif ($line -match "^INSTALL_DATE=") {
            $newConfig += "LAST_UPDATE=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        } else {
            $newConfig += $line
        }
    }
    
    if (-not $versionFound) {
        $newConfig += "VERSION=$currentVersion"
        $newConfig += "LAST_UPDATE=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    }
    
    $newConfig | Out-File -FilePath "config\config.ini" -Encoding ASCII
    Write-Host "[OK] Configuracion restaurada y actualizada" -ForegroundColor Green
} else {
    # Create new config
    $configContent = @"
COMPANY_NAME=$companyName
LOGO_PATH=$logoPath
INSTALL_DIR=$installDir
VERSION=$currentVersion
INSTALL_DATE=$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
"@
    if (-not (Test-Path "config")) {
        New-Item -ItemType Directory -Path "config" -Force | Out-Null
    }
    $configContent | Out-File -FilePath "config\config.ini" -Encoding ASCII
    Write-Host "[OK] Configuracion guardada" -ForegroundColor Green
}
Write-Host ""

# Restore database if upgrading
if ($isUpgrade -and $existingDbPath) {
    Write-Host "[INFO] Restaurando base de datos..." -ForegroundColor Cyan
    # Database file should already be there, just verify
    if (Test-Path $existingDbPath) {
        Write-Host "[OK] Base de datos preservada (sin cambios)" -ForegroundColor Green
    }
    Write-Host ""
}

# Copy logo if provided (only for new installations or if user provided new logo)
if (-not $isUpgrade) {
    if (-not [string]::IsNullOrWhiteSpace($logoPath) -and (Test-Path $logoPath)) {
        Write-Host "[5.2] Copiando logo personalizado..." -ForegroundColor Yellow
        $logoExt = [System.IO.Path]::GetExtension($logoPath)
        Copy-Item -Path $logoPath -Destination "static\logo$logoExt" -Force
        Write-Host "[OK] Logo copiado" -ForegroundColor Green
    } else {
        Write-Host "[5.2] Usando logo por defecto..." -ForegroundColor Yellow
        Write-Host "[OK] Logo por defecto configurado" -ForegroundColor Green
    }
} else {
    Write-Host "[5.2] Logo existente preservado..." -ForegroundColor Yellow
    Write-Host "[OK] Logo sin cambios" -ForegroundColor Green
}
Write-Host ""

Show-OverallProgress -Step 6 -TotalSteps 8 -Description "Configurando Entorno Python"

# Create virtual environment
if ($isUpgrade -and (Test-Path "venv")) {
    Write-Host "[6.1] Actualizando entorno virtual..." -ForegroundColor Yellow
    Write-Host "[INFO] Entorno virtual existente detectado" -ForegroundColor Cyan
} else {
    Write-Host "[6.1] Creando entorno virtual..." -ForegroundColor Yellow
    & $pythonCmd -m venv venv
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[ERROR] No se pudo crear el entorno virtual" -ForegroundColor Red
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}
Write-Host "[OK] Entorno virtual creado" -ForegroundColor Green
Write-Host ""

Show-OverallProgress -Step 7 -TotalSteps 8 -Description "Instalando Dependencias"

# Activate and install dependencies
Write-Host "[7.1] Instalando dependencias..." -ForegroundColor Yellow
Write-Host "Este proceso puede tardar 2-5 minutos..." -ForegroundColor Gray
Write-Host ""

& .\venv\Scripts\Activate.ps1

Write-Host "[INFO] Actualizando pip..." -ForegroundColor Cyan
& $pythonCmd -m pip install --upgrade pip --quiet 2>&1 | Out-Null
Write-Host "[OK] pip actualizado" -ForegroundColor Green
Write-Host ""

Write-Host "[INFO] Leyendo requirements.txt..." -ForegroundColor Cyan
$requirements = Get-Content requirements.txt | Where-Object { $_ -notmatch '^\s*#' -and $_ -notmatch '^\s*$' }
$totalPackages = $requirements.Count
Write-Host "[INFO] Paquetes a instalar: $totalPackages" -ForegroundColor Cyan
Write-Host ""

# Install packages one by one to show progress
$installedCount = 0
foreach ($package in $requirements) {
    $installedCount++
    $packageName = $package -replace '[>=<].*', ''
    $percent = [math]::Floor(($installedCount / $totalPackages) * 100)
    
    Write-Host "[$installedCount/$totalPackages] Instalando $packageName..." -NoNewline -ForegroundColor Cyan
    
    $result = pip install $package --quiet 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host " [OK]" -ForegroundColor Green
    } else {
        Write-Host " [ERROR]" -ForegroundColor Red
        Write-Host "Detalles: $result" -ForegroundColor Yellow
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}

Write-Host ""
Write-Host "[OK] Dependencias instaladas" -ForegroundColor Green
Write-Host ""

# Verify installation
Write-Host "[Verificando instalacion...]" -ForegroundColor Yellow

$modulesToVerify = @('flask', 'sqlalchemy', 'pandas', 'openpyxl', 'werkzeug')
$verifiedCount = 0
foreach ($module in $modulesToVerify) {
    $verifiedCount++
    Write-Host "[$verifiedCount/$($modulesToVerify.Count)] Verificando $module..." -NoNewline -ForegroundColor Cyan
    
    $checkResult = & $pythonCmd -c "import $module" 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host " [OK]" -ForegroundColor Green
    } else {
        Write-Host " [ERROR]" -ForegroundColor Red
        Write-Host "Fallo la verificacion de $module" -ForegroundColor Red
        Read-HostDefault "Presiona Enter para salir" ""
        exit 1
    }
}

Write-Host "[OK] Verificacion completa" -ForegroundColor Green
Write-Host ""

Show-OverallProgress -Step 8 -TotalSteps 8 -Description "Finalizando Instalacion"

# Initialize database
if ($isUpgrade -and (Test-Path $existingDbPath)) {
    Write-Host "[INFO] Base de datos existente detectada" -ForegroundColor Cyan
    Write-Host "[OK] Saltando inicializacion (datos preservados)" -ForegroundColor Green
    Write-Host ""
    Write-Host "IMPORTANTE: Tus proveedores, productos y pedidos estan intactos." -ForegroundColor Green
    Write-Host ""
} else {
    Write-Host "[8.1] Inicializando base de datos..." -ForegroundColor Yellow
    & $pythonCmd -c "from database import init_db; init_db(); print('Base de datos creada')"
    Write-Host ""
}

# Create start script
Write-Host "[8.2] Creando scripts de inicio..." -ForegroundColor Yellow

# Remove unused installer copy in bin
if (Test-Path "bin\INSTALAR.bat") {
    Remove-Item "bin\INSTALAR.bat" -Force -ErrorAction SilentlyContinue
}

# Remove obsolete root start.bat if present
if (Test-Path "start.bat") {
    Remove-Item "start.bat" -Force -ErrorAction SilentlyContinue
}

# Remove old root run.bat if present
if (Test-Path "run.bat") {
    Remove-Item "run.bat" -Force -ErrorAction SilentlyContinue
}

# Create desktop shortcuts (optional)
$createAppShortcut = (Read-HostDefault "Deseas crear/actualizar acceso directo de la aplicacion? (S/N): " "S") -in @('S', 's')
if ($createAppShortcut) {
    $desktop = @([Environment]::GetFolderPath('Desktop'))[0]
    $oldLinks = @(
        (Join-Path $desktop "Sistema Proveedores.lnk")
        (Join-Path $desktop "Sistema de Proveedores.lnk")
    )
    foreach ($link in $oldLinks) {
        if (Test-Path $link) { Remove-Item $link -Force -ErrorAction SilentlyContinue }
    }

    if (Create-DesktopShortcut -Name "Sistema Proveedores" -TargetPath "$installDir\bin\run.bat" -WorkingDirectory $installDir -Description "Sistema de Gestion de Proveedores") {
        Write-Host "[OK] Acceso directo de la aplicacion creado/actualizado" -ForegroundColor Green
    } else {
        Write-Host "[ADVERTENCIA] No se pudo crear el acceso directo de la aplicacion" -ForegroundColor Yellow
        Write-Host "[INFO] Puedes crear uno manualmente mas tarde" -ForegroundColor Gray
    }
}

$createWebShortcut = (Read-HostDefault "Deseas crear/actualizar acceso directo de la web? (S/N): " "S") -in @('S', 's')
if ($createWebShortcut) {
    $desktop = @([Environment]::GetFolderPath('Desktop'))[0]
    $webShortcut = Join-Path $desktop "Sistema Proveedores Web.url"
    @(
        '[InternetShortcut]',
        'URL=http://localhost:5000/login'
    ) | Out-File -FilePath $webShortcut -Encoding ASCII -Force
    Write-Host "[OK] Acceso directo web creado/actualizado" -ForegroundColor Green
}

Write-Host ""
Write-Host ""
Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor DarkGreen
Write-Host " PROGRESO: [██████████████████████████████████████████████████] 100%" -ForegroundColor Green
Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor DarkGreen
Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
if ($isUpgrade) {
    Write-Host "  ACTUALIZACION COMPLETADA EXITOSAMENTE!" -ForegroundColor Green
} else {
    Write-Host "  INSTALACION COMPLETADA EXITOSAMENTE!" -ForegroundColor Green
}
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""

if ($isUpgrade) {
    Write-Host "[ACTUALIZACION COMPLETADA]" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Version actualizada a: " -NoNewline -ForegroundColor White
    Write-Host "0.1" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Datos preservados:" -ForegroundColor Green
    Write-Host "  [X] Configuracion de la empresa" -ForegroundColor Green
    Write-Host "  [X] Base de datos (proveedores, productos, pedidos)" -ForegroundColor Green
    Write-Host "  [X] Logo personalizado" -ForegroundColor Green
    Write-Host ""
    if (Test-Path "$installDir\backup_*") {
        $backupFolder = Get-ChildItem "$installDir\backup_*" | Select-Object -Last 1
        Write-Host "Respaldo creado en: " -NoNewline -ForegroundColor White
        Write-Host "$($backupFolder.Name)" -ForegroundColor Gray
        Write-Host ""
    }
}

if (-not [string]::IsNullOrWhiteSpace($companyName)) {
    Write-Host "Instalacion personalizada para: " -NoNewline -ForegroundColor White
    Write-Host "$companyName" -ForegroundColor Cyan
    Write-Host ""
}

Write-Host "Ubicacion: " -NoNewline -ForegroundColor White
Write-Host "$installDir" -ForegroundColor Yellow
Write-Host ""
Write-Host "Para iniciar el servicio (manual):" -ForegroundColor White
Write-Host "  1. Ejecuta " -NoNewline -ForegroundColor Gray
Write-Host "start.bat " -NoNewline -ForegroundColor Yellow
Write-Host "en: $installDir" -ForegroundColor Gray
Write-Host "  2. O usa el acceso directo del escritorio (si lo creaste)" -ForegroundColor Gray
Write-Host ""
Write-Host "Luego abre tu navegador en: " -NoNewline -ForegroundColor White
Write-Host "http://localhost:5000" -ForegroundColor Yellow
Write-Host ""
Write-Host "Documentacion completa: README.md" -ForegroundColor Gray
Write-Host ""
Read-HostDefault "Presiona Enter para finalizar" ""

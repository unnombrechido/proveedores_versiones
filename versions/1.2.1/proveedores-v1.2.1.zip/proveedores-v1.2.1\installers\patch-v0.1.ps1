# ============================================================
# Sistema de Proveedores - Patch v0.1
# ============================================================
# This script updates existing installations with new features:
# - Database cleanup utility
# - Sample data loader
# - Fixed logo loading
# - Fixed import modal (CSV support for items)
# - Fixed run.bat path
# ============================================================

param(
    [switch]$WhatIf,
    [switch]$NoBackup
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  SISTEMA DE PROVEEDORES - PATCH v0.1" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Check if running in correct directory
if (-not (Test-Path "app\app.py")) {
    Write-Host "[ERROR] Este script debe ejecutarse desde el directorio raiz de la instalacion" -ForegroundColor Red
    Write-Host "        (donde se encuentra la carpeta 'app')" -ForegroundColor Red
    Write-Host ""
    exit 1
}

Write-Host "[INFO] Directorio de instalacion: $PWD" -ForegroundColor Yellow
Write-Host ""

# Create backup if not disabled
if (-not $NoBackup -and -not $WhatIf) {
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupDir = "backup_$timestamp"
    
    Write-Host "[1/4] Creando respaldo..." -ForegroundColor Cyan
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    
    # Backup files that will be modified
    $filesToBackup = @(
        "app\app.py",
        "app\static\script.js",
        "app\templates\index.html",
        "run.bat"
    )
    
    foreach ($file in $filesToBackup) {
        if (Test-Path $file) {
            $destPath = Join-Path $backupDir $file
            $destDir = Split-Path -Parent $destPath
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
            Copy-Item -Path $file -Destination $destPath -Force
            Write-Host "  ✓ Respaldado: $file" -ForegroundColor Gray
        }
    }
    
    Write-Host "  ✓ Respaldo creado en: $backupDir" -ForegroundColor Green
    Write-Host ""
}

# Function to download file from source
function Copy-PatchFile {
    param(
        [string]$SourcePath,
        [string]$DestPath
    )
    
    $sourceFullPath = Join-Path $PSScriptRoot "..\$SourcePath"
    
    if (Test-Path $sourceFullPath) {
        $destDir = Split-Path -Parent $DestPath
        if ($destDir -and -not (Test-Path $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }
        
        if ($WhatIf) {
            Write-Host "  [WHATIF] Copiaria: $SourcePath -> $DestPath" -ForegroundColor Yellow
        } else {
            Copy-Item -Path $sourceFullPath -Destination $DestPath -Force
            Write-Host "  ✓ $DestPath" -ForegroundColor Green
        }
        return $true
    } else {
        Write-Host "  ✗ No encontrado en patch: $SourcePath" -ForegroundColor Red
        return $false
    }
}

# Add new files
Write-Host "[2/4] Agregando archivos nuevos..." -ForegroundColor Cyan

$newFiles = @{
    "utilities\cleanup_database.py" = "utilities\cleanup_database.py"
    "utilities\cleanup_database.bat" = "utilities\cleanup_database.bat"
    "utilities\load_sample_data.py" = "utilities\load_sample_data.py"
    "utilities\load_sample_data.bat" = "utilities\load_sample_data.bat"
    "docs\DATABASE_CLEANUP.md" = "docs\DATABASE_CLEANUP.md"
    "docs\LOAD_SAMPLE_DATA.md" = "docs\LOAD_SAMPLE_DATA.md"
}

foreach ($item in $newFiles.GetEnumerator()) {
    Copy-PatchFile -SourcePath $item.Key -DestPath $item.Value | Out-Null
}

Write-Host ""

# Update existing files
Write-Host "[3/4] Actualizando archivos existentes..." -ForegroundColor Cyan

# Update run.bat
if (Test-Path "run.bat") {
    if ($WhatIf) {
        Write-Host "  [WHATIF] Actualizaria: run.bat" -ForegroundColor Yellow
    } else {
        Copy-PatchFile -SourcePath "run.bat" -DestPath "run.bat" | Out-Null
    }
}

# Update app.py - add with-items endpoint
if (Test-Path "app\app.py") {
    if ($WhatIf) {
        Write-Host "  [WHATIF] Actualizaria: app\app.py (CSV support for items import)" -ForegroundColor Yellow
    } else {
        $appContent = Get-Content "app\app.py" -Raw -Encoding UTF8
        
        # Check if patch is already applied
        if ($appContent -notmatch "@app\.route\('/api/suppliers/import/with-items'") {
            # Add the new route decorator
            $appContent = $appContent -replace `
                "(@app\.route\('/api/suppliers/import/items-excel', methods=\['POST'\]\))", `
                "$1`n@app.route('/api/suppliers/import/with-items', methods=['POST'])"
            
            # Update the function to handle CSV
            $appContent = $appContent -replace `
                '"""Import suppliers and their items from Excel file"""', `
                '"""Import suppliers and their items from CSV or Excel file' + "`n" + `
                '    Expected CSV/Excel columns:' + "`n" + `
                '    - Required: supplier_name, item_code, item_name, price' + "`n" + `
                '    - Optional: supplier_email, supplier_phone, supplier_city, supplier_country,' + "`n" + `
                '                item_description, item_category, unit, supplier_item_code,' + "`n" + `
                '                lead_time_days, minimum_order_quantity, notes' + "`n" + `
                '    """'
            
            # Update file reading to support CSV
            $appContent = $appContent -replace `
                '        # Read Excel file\s+df = pd\.read_excel\(file\)', `
                ('        # Read CSV or Excel file' + "`n" + `
                '        if file.filename.endswith(''.csv''):' + "`n" + `
                '            df = pd.read_csv(file)' + "`n" + `
                '        else:' + "`n" + `
                '            df = pd.read_excel(file)')
            
            Set-Content "app\app.py" -Value $appContent -Encoding UTF8
            Write-Host "  ✓ app\app.py actualizado (CSV support)" -ForegroundColor Green
        } else {
            Write-Host "  ⊘ app\app.py ya estaba actualizado" -ForegroundColor Gray
        }
    }
}

# Update script.js - fix logo loading and import modal
if (Test-Path "app\static\script.js") {
    if ($WhatIf) {
        Write-Host "  [WHATIF] Actualizaria: app\static\script.js" -ForegroundColor Yellow
    } else {
        Copy-PatchFile -SourcePath "app\static\script.js" -DestPath "app\static\script.js" | Out-Null
    }
}

# Update index.html - fix import modal
if (Test-Path "app\templates\index.html") {
    if ($WhatIf) {
        Write-Host "  [WHATIF] Actualizaria: app\templates\index.html" -ForegroundColor Yellow
    } else {
        Copy-PatchFile -SourcePath "app\templates\index.html" -DestPath "app\templates\index.html" | Out-Null
    }
}

Write-Host ""

# Summary
Write-Host "[4/4] Verificando instalacion..." -ForegroundColor Cyan

$checkResults = @{
    "utilities\cleanup_database.py" = Test-Path "utilities\cleanup_database.py"
    "utilities\load_sample_data.py" = Test-Path "utilities\load_sample_data.py"
    "docs\DATABASE_CLEANUP.md" = Test-Path "docs\DATABASE_CLEANUP.md"
    "docs\LOAD_SAMPLE_DATA.md" = Test-Path "docs\LOAD_SAMPLE_DATA.md"
}

$allOk = $true
foreach ($item in $checkResults.GetEnumerator()) {
    if ($item.Value) {
        Write-Host "  ✓ $($item.Key)" -ForegroundColor Green
    } else {
        Write-Host "  ✗ $($item.Key)" -ForegroundColor Red
        $allOk = $false
    }
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
if ($WhatIf) {
    Write-Host "  VISTA PREVIA COMPLETADA (no se realizaron cambios)" -ForegroundColor Yellow
} elseif ($allOk) {
    Write-Host "  PATCH APLICADO EXITOSAMENTE!" -ForegroundColor Green
} else {
    Write-Host "  PATCH APLICADO CON ADVERTENCIAS" -ForegroundColor Yellow
}
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

if (-not $WhatIf) {
    Write-Host "Nuevas caracteristicas disponibles:" -ForegroundColor White
    Write-Host "  • Utilidad de limpieza de base de datos:" -ForegroundColor White
    Write-Host "    utilities\cleanup_database.bat" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  • Carga de datos de ejemplo:" -ForegroundColor White
    Write-Host "    utilities\load_sample_data.bat" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  • Logo configurable desde config.ini" -ForegroundColor White
    Write-Host "    LOGO_PATH=logo.png o URL completa" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  • Importacion CSV para items con proveedores" -ForegroundColor White
    Write-Host "    Opcion: Proveedores + Items + Precios" -ForegroundColor Gray
    Write-Host ""
    
    if (-not $NoBackup) {
        Write-Host "Respaldo de archivos antiguos en: backup_*" -ForegroundColor Yellow
    }
    Write-Host ""
}

Write-Host "Presiona cualquier tecla para continuar..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

# -*- coding: utf-8 -*-
"""
Database Cleanup Utility
========================
Script to clean/reset database tables when corrupted or need fresh start.

Usage:
    python cleanup_database.py [options]

Options:
    --all              Drop and recreate all tables
    --suppliers        Clean only suppliers table
    --items            Clean only items table
    --prices           Clean only supplier-item relationships (prices)
    --orders           Clean only orders table
    --backup           Create backup before cleaning (default: yes)
    --no-backup        Skip backup
    --force            Skip confirmation prompts

Examples:
    python cleanup_database.py --all
    python cleanup_database.py --suppliers --items
    python cleanup_database.py --all --no-backup --force
"""

import os
import sys
import shutil
from datetime import datetime
from sqlalchemy import inspect, text

# Add parent directory and app directory to path to import modules
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
api_dir = os.path.join(parent_dir, 'api')

# Debug: Print paths to help troubleshoot
print("Debug Info:")
print("  Current dir: {}".format(current_dir))
print("  Parent dir: {}".format(parent_dir))
print("  API dir: {}".format(api_dir))
print("  API dir exists: {}".format(os.path.exists(api_dir)))
print("  database.py exists: {}".format(os.path.exists(os.path.join(api_dir, 'database.py'))))
print("  models.py exists: {}".format(os.path.exists(os.path.join(api_dir, 'models.py'))))
print()

# Change working directory to parent
os.chdir(parent_dir)

# Add api directory to Python path
sys.path.insert(0, api_dir)

from database import engine, SessionLocal, Base, get_database_url
from models import Supplier, Item, Order, supplier_items


def backup_database():
    """Create a backup of the current database"""
    db_url = get_database_url()
    
    if 'sqlite' in db_url:
        # For SQLite, copy the file
        db_path = db_url.replace('sqlite:///', '')
        if os.path.exists(db_path):
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_path = "{}.backup_{}".format(db_path, timestamp)
            shutil.copy2(db_path, backup_path)
            print("✓ Database backed up to: {}".format(backup_path))
            return backup_path
        else:
            print("⚠ Database file not found: {}".format(db_path))
            return None
    else:
        print("⚠ Backup only supported for SQLite databases")
        print("  For MySQL/PostgreSQL, use native backup tools")
        return None


def get_table_counts():
    """Get record counts for all tables"""
    db = SessionLocal()
    try:
        counts = {}
        counts['suppliers'] = db.query(Supplier).count()
        counts['items'] = db.query(Item).count()
        counts['orders'] = db.query(Order).count()
        
        # Count supplier-item relationships
        result = db.execute(text("SELECT COUNT(*) FROM supplier_items"))
        counts['supplier_items'] = result.scalar()
        
        return counts
    finally:
        db.close()


def drop_table(table_name):
    """Drop a specific table"""
    try:
        with engine.connect() as conn:
            conn.execute(text("DROP TABLE IF EXISTS {}".format(table_name)))
            conn.commit()
        print("✓ Dropped table: {}".format(table_name))
        return True
    except Exception as e:
        print("✗ Error dropping table {}: {}".format(table_name, e))
        return False


def clean_all_tables():
    """Drop and recreate all tables"""
    print("\n" + "="*60)
    print("CLEANING ALL TABLES")
    print("="*60)
    
    # Drop all tables
    print("\n[1/2] Dropping all tables...")
    Base.metadata.drop_all(bind=engine)
    print("✓ All tables dropped")
    
    # Recreate tables
    print("\n[2/2] Recreating tables...")
    Base.metadata.create_all(bind=engine)
    print("✓ All tables recreated")
    
    print("\n" + "="*60)
    print("✓ Database cleaned successfully!")
    print("="*60)


def clean_suppliers():
    """Clean suppliers table (deletes all suppliers and their relationships)"""
    print("\n" + "="*60)
    print("CLEANING SUPPLIERS TABLE")
    print("="*60)
    
    db = SessionLocal()
    try:
        # Get count
        count = db.query(Supplier).count()
        print("\nFound {} suppliers to delete...".format(count))
        
        # Delete all suppliers (cascade will handle relationships)
        db.query(Supplier).delete()
        db.commit()
        
        print("✓ Deleted {} suppliers".format(count))
        print("✓ Related supplier-item relationships also deleted")
    except Exception as e:
        db.rollback()
        print("✗ Error cleaning suppliers: {}".format(e))
    finally:
        db.close()


def clean_items():
    """Clean items table (deletes all items and their relationships)"""
    print("\n" + "="*60)
    print("CLEANING ITEMS TABLE")
    print("="*60)
    
    db = SessionLocal()
    try:
        # Get count
        count = db.query(Item).count()
        print("\nFound {} items to delete...".format(count))
        
        # Delete all items (cascade will handle relationships)
        db.query(Item).delete()
        db.commit()
        
        print("✓ Deleted {} items".format(count))
        print("✓ Related supplier-item relationships also deleted")
    except Exception as e:
        db.rollback()
        print("✗ Error cleaning items: {}".format(e))
    finally:
        db.close()


def clean_prices():
    """Clean supplier-item relationships (prices) only"""
    print("\n" + "="*60)
    print("CLEANING SUPPLIER-ITEM RELATIONSHIPS (PRICES)")
    print("="*60)
    
    db = SessionLocal()
    try:
        # Get count
        result = db.execute(text("SELECT COUNT(*) FROM supplier_items"))
        count = result.scalar()
        print("\nFound {} relationships to delete...".format(count))
        
        # Delete all relationships
        db.execute(text("DELETE FROM supplier_items"))
        db.commit()
        
        print("✓ Deleted {} supplier-item relationships".format(count))
    except Exception as e:
        db.rollback()
        print("✗ Error cleaning prices: {}".format(e))
    finally:
        db.close()


def clean_orders():
    """Clean orders table"""
    print("\n" + "="*60)
    print("CLEANING ORDERS TABLE")
    print("="*60)
    
    db = SessionLocal()
    try:
        # Get count
        count = db.query(Order).count()
        print("\nFound {} orders to delete...".format(count))
        
        # Delete all orders
        db.query(Order).delete()
        db.commit()
        
        print("✓ Deleted {} orders".format(count))
    except Exception as e:
        db.rollback()
        print("✗ Error cleaning orders: {}".format(e))
    finally:
        db.close()


def show_status():
    """Show current database status"""
    print("\n" + "="*60)
    print("CURRENT DATABASE STATUS")
    print("="*60)
    
    try:
        counts = get_table_counts()
        print("\nSuppliers:           {:>6}".format(counts['suppliers']))
        print("Items:               {:>6}".format(counts['items']))
        print("Supplier-Items:      {:>6}".format(counts['supplier_items']))
        print("Orders:              {:>6}".format(counts['orders']))
        print("\nDatabase: {}".format(get_database_url()))
    except Exception as e:
        print("✗ Error getting status: {}".format(e))


def confirm_action(message):
    """Ask user for confirmation"""
    response = input("\n{} (yes/no): ".format(message)).strip().lower()
    return response in ['yes', 'y']


def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Database Cleanup Utility',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument('--all', action='store_true', 
                       help='Drop and recreate all tables')
    parser.add_argument('--suppliers', action='store_true',
                       help='Clean suppliers table')
    parser.add_argument('--items', action='store_true',
                       help='Clean items table')
    parser.add_argument('--prices', action='store_true',
                       help='Clean supplier-item relationships')
    parser.add_argument('--orders', action='store_true',
                       help='Clean orders table')
    parser.add_argument('--backup', action='store_true', default=True,
                       help='Create backup before cleaning (default)')
    parser.add_argument('--no-backup', action='store_true',
                       help='Skip backup')
    parser.add_argument('--force', action='store_true',
                       help='Skip confirmation prompts')
    parser.add_argument('--status', action='store_true',
                       help='Show database status and exit')
    
    args = parser.parse_args()
    
    # Show status and exit if requested
    if args.status:
        show_status()
        return
    
    # If no options specified, show help
    if not any([args.all, args.suppliers, args.items, args.prices, args.orders]):
        parser.print_help()
        print("\n" + "="*60)
        show_status()
        return
    
    print("\n" + "="*60)
    print("DATABASE CLEANUP UTILITY")
    print("="*60)
    
    # Show current status
    show_status()
    
    # Determine backup setting
    do_backup = args.backup and not args.no_backup
    
    # Confirm action
    if not args.force:
        print("\n" + "="*60)
        print("⚠  WARNING: This operation will delete data!")
        print("="*60)
        
        actions = []
        if args.all:
            actions.append("- Drop and recreate ALL tables")
        if args.suppliers:
            actions.append("- Delete all suppliers")
        if args.items:
            actions.append("- Delete all items")
        if args.prices:
            actions.append("- Delete all supplier-item relationships")
        if args.orders:
            actions.append("- Delete all orders")
        
        print("\nActions to perform:")
        for action in actions:
            print(action)
        
        if not confirm_action("\nDo you want to continue?"):
            print("\n✗ Operation cancelled")
            return
    
    # Create backup
    if do_backup:
        print("\n" + "="*60)
        print("CREATING BACKUP")
        print("="*60)
        backup_path = backup_database()
        if backup_path:
            print("\n✓ Backup saved: {}".format(backup_path))
    
    # Perform cleanup operations
    if args.all:
        clean_all_tables()
    else:
        if args.suppliers:
            clean_suppliers()
        if args.items:
            clean_items()
        if args.prices:
            clean_prices()
        if args.orders:
            clean_orders()
    
    # Show final status
    print("\n" + "="*60)
    print("FINAL STATUS")
    print("="*60)
    show_status()
    
    print("\n✓ Cleanup complete!")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n✗ Operation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print("\n\n✗ Unexpected error: {}".format(e))
        import traceback
        traceback.print_exc()
        sys.exit(1)

# Backup-Installation.psm1
# Creates backup of existing installation

function New-InstallationBackup {
    param(
        [string]$InstallPath,
        [hashtable]$InstallInfo
    )
    
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupName = "backup_${timestamp}_v$($InstallInfo.Version)"
    $backupPath = Join-Path $InstallPath $backupName
    
    $backupResult = @{
        Success = $false
        Path = $backupPath
        Files = @()
        TotalSize = 0
        Error = ""
    }
    
    try {
        New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
        
        # Backup database
        if ($InstallInfo.DatabasePath -and (Test-Path $InstallInfo.DatabasePath)) {
            $dbName = Split-Path $InstallInfo.DatabasePath -Leaf
            $destPath = Join-Path $backupPath $dbName
            Copy-Item $InstallInfo.DatabasePath $destPath -Force
            
            $size = (Get-Item $destPath).Length
            $backupResult.Files += "Database: $dbName ($([math]::Round($size/1KB, 2)) KB)"
            $backupResult.TotalSize += $size
        }
        
        # Backup config
        if ($InstallInfo.ConfigPath -and (Test-Path $InstallInfo.ConfigPath)) {
            $configName = Split-Path $InstallInfo.ConfigPath -Leaf
            $destPath = Join-Path $backupPath $configName
            Copy-Item $InstallInfo.ConfigPath $destPath -Force
            
            $size = (Get-Item $destPath).Length
            $backupResult.Files += "Config: $configName"
            $backupResult.TotalSize += $size
        }
        
        $backupResult.Success = $true
    }
    catch {
        $backupResult.Success = $false
        $backupResult.Error = $_.Exception.Message
    }
    
    return $backupResult
}

Export-ModuleMember -Function New-InstallationBackup
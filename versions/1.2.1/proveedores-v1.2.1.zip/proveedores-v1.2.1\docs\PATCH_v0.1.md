# Patch v0.1 - Instrucciones de Actualización

## ¿Qué incluye este patch?

Este parche actualiza instalaciones existentes del Sistema de Proveedores con las siguientes mejoras:

### ✨ Nuevas Características

1. **Utilidad de Limpieza de Base de Datos**
   - Script interactivo para limpiar tablas corruptas
   - Respaldos automáticos antes de limpiar
   - Limpieza selectiva o completa
   - Ubicación: `utilities/cleanup_database.bat`

2. **Carga Automática de Datos de Ejemplo**
   - 9 proveedores de ejemplo
   - 58 items/materiales con precios
   - Carga desde línea de comandos sin usar la interfaz web
   - Ubicación: `utilities/load_sample_data.bat`

3. **Logo Configurable**
   - Soporte para logos personalizados
   - Configurable desde `config.ini`
   - Soporta archivos locales y URLs

4. **Importación CSV Mejorada**
   - Soporte CSV para importar items con proveedores y precios
   - Antes solo soportaba Excel para esta función
   - Nuevo endpoint: `/api/suppliers/import/with-items`

5. **Correcciones**
   - Ruta corregida en `run.bat` (ahora apunta a `app\app.py`)
   - Modal de importación pre-selecciona el tipo correcto

## Requisitos

- Instalación existente del Sistema de Proveedores v0.1
- PowerShell (incluido en Windows)
- Permisos de escritura en el directorio de instalación

## Instrucciones de Instalación

### Opción 1: Instalación Automática (Recomendada)

1. **Descargar el patch**
   - Extraer el contenido del archivo patch en una carpeta temporal

2. **Copiar el instalador**
   ```
   Copiar patch-v0.1.ps1 y PATCH-v0.1.bat
   al directorio de instalación (donde está la carpeta 'app')
   ```

3. **Ejecutar el patch**
   ```batch
   Hacer doble clic en: PATCH-v0.1.bat
   ```
   O desde línea de comandos:
   ```batch
   cd C:\RutaDeLaInstalacion
   installers\PATCH-v0.1.bat
   ```

4. **Confirmar la instalación**
   - El script mostrará qué archivos se actualizarán
   - Presionar `S` para confirmar
   - Se creará un respaldo automático en `backup_YYYYMMDD_HHMMSS/`

### Opción 2: Vista Previa (Sin Cambios)

Para ver qué cambios se realizarían sin aplicarlos:

```powershell
powershell -ExecutionPolicy Bypass -File installers\patch-v0.1.ps1 -WhatIf
```

### Opción 3: Sin Respaldo (No Recomendado)

Si no desea crear respaldo:

```powershell
powershell -ExecutionPolicy Bypass -File installers\patch-v0.1.ps1 -NoBackup
```

## Archivos Modificados

### Archivos Nuevos
- `utilities/cleanup_database.py`
- `utilities/cleanup_database.bat`
- `utilities/load_sample_data.py`
- `utilities/load_sample_data.bat`
- `docs/DATABASE_CLEANUP.md`
- `docs/LOAD_SAMPLE_DATA.md`

### Archivos Actualizados
- `app/app.py` - Nuevo endpoint para CSV con items
- `app/static/script.js` - Logo dinámico, modal de importación mejorado
- `app/templates/index.html` - Logo placeholder, botones de importación
- `run.bat` - Ruta corregida a app/app.py

### Archivos Respaldados
El patch crea un respaldo automático de todos los archivos que modifica en:
```
backup_YYYYMMDD_HHMMSS/
  app/
    app.py
    static/script.js
    templates/index.html
  run.bat
```

## Verificación Post-Instalación

Después de aplicar el patch, verificar:

1. **Utilidades instaladas**
   ```batch
   cd utilities
   dir *.bat
   ```
   Debe mostrar: `cleanup_database.bat`, `load_sample_data.bat`

2. **Documentación disponible**
   ```batch
   cd docs
   dir *.md
   ```
   Debe incluir: `DATABASE_CLEANUP.md`, `LOAD_SAMPLE_DATA.md`

3. **Aplicación funcional**
   ```batch
   run.bat
   ```
   La aplicación debe iniciar normalmente

4. **Probar nueva funcionalidad**
   - Abrir navegador en http://localhost:5000
   - Verificar que el modal de importación funciona
   - Probar `utilities\load_sample_data.bat`

## Reversión del Patch

Si necesita revertir los cambios:

1. **Detener la aplicación**
   ```batch
   Presionar Ctrl+C en la ventana donde corre run.bat
   ```

2. **Restaurar desde respaldo**
   ```batch
   # Identificar la carpeta de respaldo
   dir backup_*
   
   # Copiar archivos del respaldo
   copy backup_YYYYMMDD_HHMMSS\app\app.py app\app.py
   copy backup_YYYYMMDD_HHMMSS\app\static\script.js app\static\script.js
   copy backup_YYYYMMDD_HHMMSS\app\templates\index.html app\templates\index.html
   copy backup_YYYYMMDD_HHMMSS\run.bat run.bat
   ```

3. **Opcional: Eliminar archivos nuevos**
   ```batch
   rd /s /q utilities
   del docs\DATABASE_CLEANUP.md
   del docs\LOAD_SAMPLE_DATA.md
   ```

## Solución de Problemas

### "No se puede ejecutar patch-v0.1.ps1"
**Causa:** Política de ejecución de PowerShell

**Solución:**
```batch
powershell -ExecutionPolicy Bypass -File installers\patch-v0.1.ps1
```

### "Este script debe ejecutarse desde el directorio raiz"
**Causa:** Ejecutando desde ubicación incorrecta

**Solución:**
```batch
cd C:\RutaDeInstalacion
installers\PATCH-v0.1.bat
```

### "No encontrado en patch: [archivo]"
**Causa:** Archivos del patch incompletos

**Solución:**
- Volver a descargar el patch completo
- Verificar que todos los archivos se extrajeron correctamente

### La aplicación no inicia después del patch
**Causa:** Error durante la actualización

**Solución:**
1. Revisar la carpeta `backup_*` más reciente
2. Restaurar los archivos desde el respaldo
3. Reportar el problema con el log de errores

## Notas Adicionales

### Compatibilidad
- Compatible con instalaciones v0.1
- Requiere Python 3.6+ (ya instalado con la aplicación)
- Requiere Windows 7 o superior

### Base de Datos
- El patch NO modifica la base de datos
- Todos los datos existentes se conservan
- Las nuevas utilidades permiten gestionar la base de datos por separado

### Configuración
- El archivo `config.ini` NO se modifica
- Para usar un logo personalizado, editar manualmente `config.ini`:
  ```ini
  LOGO_PATH=mi-logo.png
  ```
  (Colocar el archivo en `app/static/`)

## Soporte

Para reportar problemas o solicitar ayuda:
1. Verificar la carpeta `backup_*` con fecha más reciente
2. Revisar logs de error si la aplicación no inicia
3. Incluir versión de Windows y Python al reportar

## Ver También

- [DATABASE_CLEANUP.md](DATABASE_CLEANUP.md) - Guía de limpieza de base de datos
- [LOAD_SAMPLE_DATA.md](LOAD_SAMPLE_DATA.md) - Guía de carga de datos de ejemplo
- [QUICKSTART.md](../QUICKSTART.md) - Guía de inicio rápido

﻿# Create Distribution v1.2.1
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  CREAR DISTRIBUCION v1.2.1" -ForegroundColor Cyan  
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

$zipName = "proveedores-v1.2.1.zip"
$tempFolder = "proveedores-v1.2.1"

Write-Host "[1/6] Preparando carpeta temporal..." -ForegroundColor Yellow
if (Test-Path $tempFolder) { Remove-Item -Recurse -Force $tempFolder }
New-Item -ItemType Directory -Path $tempFolder | Out-Null
Write-Host "  OK Carpeta creada" -ForegroundColor Green
Write-Host ""

Write-Host "[2/6] Copiando estructura modular..." -ForegroundColor Yellow
$folders = @("api", "bin", "docs", "examples", "scripts", "installers", "utilities")
$copied = 0
foreach ($folder in $folders) {
    if (Test-Path $folder) {
        Copy-Item -Path $folder -Destination "$tempFolder\$folder" -Recurse -Force
        $copied++
    }
}
# Replace non-ASCII characters with ASCII equivalents
Write-Host "  OK $copied carpetas copiadas" -ForegroundColor Green
Write-Host ""

Write-Host "[3/6] Creando carpetas vacias..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path "$tempFolder\data" -Force | Out-Null
New-Item -ItemType Directory -Path "$tempFolder\logs" -Force | Out-Null
New-Item -ItemType Directory -Path "$tempFolder\config" -Force | Out-Null
Write-Host "  OK data/, logs/, config/ creadas" -ForegroundColor Green
Write-Host ""

Write-Host "[4/6] Copiando archivos raiz..." -ForegroundColor Yellow
$files = @("requirements.txt", "VERSION", "LICENSE", "README.md", "LEEME_PRIMERO.txt", "INSTALAR.bat")
$fileCopied = 0
foreach ($file in $files) {
    if (Test-Path $file) {
        Copy-Item $file "$tempFolder\$file" -Force
        $fileCopied++
    }
}
Write-Host "  OK $fileCopied archivos copiados" -ForegroundColor Green
Write-Host ""

Write-Host "[5/6] Limpiando archivos de desarrollo..." -ForegroundColor Yellow
Get-ChildItem -Path $tempFolder -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force
Get-ChildItem -Path $tempFolder -Recurse -File -Include "*.pyc","*.pyo","*.pyd" -ErrorAction SilentlyContinue | Remove-Item -Force
if (Test-Path "$tempFolder\data") { Get-ChildItem -Path "$tempFolder\data" -Filter "*.db" -ErrorAction SilentlyContinue | Remove-Item -Force }
Write-Host "  OK Limpieza completada" -ForegroundColor Green
Write-Host ""

Write-Host "[6/6] Creando archivo ZIP..." -ForegroundColor Yellow
if (Test-Path $zipName) { Remove-Item $zipName -Force }

$maxAttempts = 3
$zipCreated = $false
for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
    try {
        Compress-Archive -Path $tempFolder -DestinationPath $zipName -CompressionLevel Optimal -Force
        $zipCreated = $true
        break
    } catch {
        if ($_.Exception.Message -match "being used by another process") {
            Write-Host "  [ADVERTENCIA] Hay archivos en uso. Cierra la app/editores y reintenta." -ForegroundColor Yellow
            if ($attempt -lt $maxAttempts) {
                Read-Host "Presiona Enter para reintentar ($attempt/$maxAttempts)"
                Start-Sleep -Seconds 1
            }
        } else {
            throw
        }
    }
}

if (-not $zipCreated) {
    throw "No se pudo crear el ZIP. Hay archivos en uso."
}

$sizeMB = [math]::Round((Get-Item $zipName).Length / 1MB, 2)
Write-Host "  OK ZIP creado: $zipName ($sizeMB MB)" -ForegroundColor Green
Write-Host ""

Remove-Item -Recurse -Force $tempFolder
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  DISTRIBUCION CREADA: $zipName ($sizeMB MB)" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# Quick Start Guide - Sistema de Gestión de Proveedores

## Getting Started in 5 Minutes

### 1. Install Dependencies (1 minute)
```bash
pip install -r requirements.txt
```

### 2. Configure Environment (30 seconds)
```bash
cp .env.example .env
# Edit .env if you want to use a different database
# By default, it uses SQLite (no configuration needed)
```

### 3. Start the Application (30 seconds)
```bash
python app.py
```

### 4. Open in Browser
Navigate to: http://localhost:5000

## First Steps

### Import Sample Data
1. Click "📥 Importar" button
2. Select the `example_suppliers.csv` file included in the repository
3. Click "Importar"
4. You'll see 8 sample suppliers loaded

### Create Your First Order
1. Click the "📦 Orden" button next to any supplier
2. Fill in the order details
3. Click "Crear Orden"
4. Switch to the "Órdenes" tab to see your order

### Search and Filter
- Use the search box to find suppliers by name, email, category, or city
- Use the dropdown filters to filter by category, country, or status
- Try filtering by "Metales" category to see only metal suppliers

### Export Data
- Click "📤 Exportar CSV" or "📤 Exportar Excel" to download your supplier list
- The file will include all current suppliers with all their information

## Database Options

### SQLite (Default - No Setup Required)
Already configured! Just run the app.

### MySQL
Edit `.env`:
```env
DATABASE_TYPE=mysql
DATABASE_HOST=localhost
DATABASE_PORT=3306
DATABASE_USER=root
DATABASE_PASSWORD=your_password
DATABASE_NAME=proveedores
```

### PostgreSQL
Edit `.env`:
```env
DATABASE_TYPE=postgresql
DATABASE_HOST=localhost
DATABASE_PORT=5432
DATABASE_USER=postgres
DATABASE_PASSWORD=your_password
DATABASE_NAME=proveedores
```

### Microsoft SQL Server
Edit `.env`:
```env
DATABASE_TYPE=mssql
DATABASE_HOST=localhost
DATABASE_PORT=1433
DATABASE_USER=sa
DATABASE_PASSWORD=your_password
DATABASE_NAME=proveedores
```

### Oracle Database
Edit `.env`:
```env
DATABASE_TYPE=oracle
DATABASE_HOST=localhost
DATABASE_PORT=1521
DATABASE_USER=system
DATABASE_PASSWORD=your_password
DATABASE_SERVICE=XEPDB1
```

## API Examples

### Get All Suppliers
```bash
curl http://localhost:5000/api/suppliers
```

### Search Suppliers
```bash
curl "http://localhost:5000/api/suppliers?search=metal"
```

### Filter by Category
```bash
curl "http://localhost:5000/api/suppliers?category=Metales"
```

### Create a Supplier
```bash
curl -X POST http://localhost:5000/api/suppliers \
  -H "Content-Type: application/json" \
  -d '{
    "name": "New Supplier",
    "email": "contact@newsupplier.com",
    "category": "Materials",
    "rating": 4.0
  }'
```

### Create an Order
```bash
curl -X POST http://localhost:5000/api/orders \
  -H "Content-Type: application/json" \
  -d '{
    "supplier_id": 1,
    "delivery_date": "2026-03-01",
    "total_amount": 5000.00,
    "items": "100 x Product A\n50 x Product B",
    "notes": "Urgent order"
  }'
```

## Troubleshooting

### Port Already in Use
```bash
PORT=8080 python app.py
```

### Database Connection Error
- Check your database credentials in `.env`
- Make sure your database server is running
- For MySQL/PostgreSQL, create the database first:
  ```sql
  CREATE DATABASE proveedores;
  ```

### Import/Export Not Working
- Check file format (CSV or Excel)
- Ensure the file has the correct column names
- See README.md for the required column format

## Need Help?

- Check the full documentation in README.md
- Review the example data in example_suppliers.csv
- Open an issue on GitHub

## Happy Managing! 🎉

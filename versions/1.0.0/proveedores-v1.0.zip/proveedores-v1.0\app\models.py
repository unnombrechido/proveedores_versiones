from sqlalchemy import Column, Integer, String, Float, DateTime, Text, ForeignKey, Table
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

# Association table for many-to-many relationship between suppliers and items
supplier_items = Table('supplier_items', Base.metadata,
    Column('supplier_id', Integer, ForeignKey('suppliers.id'), primary_key=True),
    Column('item_id', Integer, ForeignKey('items.id'), primary_key=True),
    Column('price', Float),
    Column('supplier_item_code', String(100)),
    Column('lead_time_days', Integer),
    Column('minimum_order_quantity', Integer),
    Column('notes', Text),
    Column('created_at', DateTime, default=datetime.utcnow),
    Column('updated_at', DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
)

class Item(Base):
    """Item/Supply model for storing product information"""
    __tablename__ = 'items'
    
    id = Column(Integer, primary_key=True, index=True)
    item_code = Column(String(100), unique=True, nullable=False, index=True)
    name = Column(String(200), nullable=False, index=True)
    description = Column(Text)
    category = Column(String(100), index=True)
    unit = Column(String(50))  # e.g., kg, pcs, liters, etc.
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship to suppliers
    suppliers = relationship('Supplier', secondary=supplier_items, back_populates='items')
    
    def to_dict(self, include_suppliers=False):
        """Convert item object to dictionary"""
        result = {
            'id': self.id,
            'item_code': self.item_code,
            'name': self.name,
            'description': self.description,
            'category': self.category,
            'unit': self.unit,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        if include_suppliers:
            result['suppliers'] = [s.to_dict() for s in self.suppliers]
        return result

class Supplier(Base):
    """Supplier model for storing supplier information"""
    __tablename__ = 'suppliers'
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False, index=True)
    contact_person = Column(String(200))
    email = Column(String(200), index=True)
    phone = Column(String(50))
    address = Column(Text)
    city = Column(String(100))
    country = Column(String(100))
    tax_id = Column(String(50), unique=True, index=True)
    category = Column(String(100), index=True)
    rating = Column(Float, default=0.0)
    payment_terms = Column(String(100))
    notes = Column(Text)
    active = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship to items
    items = relationship('Item', secondary=supplier_items, back_populates='suppliers')
    
    def to_dict(self, include_items=False):
        """Convert supplier object to dictionary"""
        result = {
            'id': self.id,
            'name': self.name,
            'contact_person': self.contact_person,
            'email': self.email,
            'phone': self.phone,
            'address': self.address,
            'city': self.city,
            'country': self.country,
            'tax_id': self.tax_id,
            'category': self.category,
            'rating': self.rating,
            'payment_terms': self.payment_terms,
            'notes': self.notes,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        if include_items:
            result['items'] = [i.to_dict() for i in self.items]
        return result

class Order(Base):
    """Order model for storing order information"""
    __tablename__ = 'orders'
    
    id = Column(Integer, primary_key=True, index=True)
    order_number = Column(String(50), unique=True, nullable=False, index=True)
    supplier_id = Column(Integer, nullable=False, index=True)
    supplier_name = Column(String(200))
    order_date = Column(DateTime, default=datetime.utcnow)
    delivery_date = Column(DateTime)
    status = Column(String(50), default='pending', index=True)
    total_amount = Column(Float, default=0.0)
    items = Column(Text)
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Convert order object to dictionary"""
        return {
            'id': self.id,
            'order_number': self.order_number,
            'supplier_id': self.supplier_id,
            'supplier_name': self.supplier_name,
            'order_date': self.order_date.isoformat() if self.order_date else None,
            'delivery_date': self.delivery_date.isoformat() if self.delivery_date else None,
            'status': self.status,
            'total_amount': self.total_amount,
            'items': self.items,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

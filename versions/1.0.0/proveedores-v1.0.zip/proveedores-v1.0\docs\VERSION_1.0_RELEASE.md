# Version 1.0 Release Checklist

## ✅ Files Updated for v1.0 Release

### Version Files
- ✅ `VERSION` - Updated from 0.1 to 1.0
- ✅ `docs/RELEASE_NOTES.md` - Updated to v1.0 with new features
- ✅ `docs/RELEASE_SUMMARY.md` - Updated to v1.0 with "What's New" section
- ✅ `docs/DISTRIBUTION.md` - Updated ZIP name to proveedores-v1.0.zip
- ✅ `installers/create_distribution.bat` - Updated to create proveedores-v1.0.zip

### Distribution Files
The distribution will create: **proveedores-v1.0.zip**

### New Features Added in v1.0

#### 1. Database Utilities
- `utilities/cleanup_database.py` (11.8 KB)
- `utilities/cleanup_database.bat` (2.1 KB)
- `docs/DATABASE_CLEANUP.md` (5.6 KB)

#### 2. Sample Data Loader
- `utilities/load_sample_data.py` (11.6 KB)
- `utilities/load_sample_data.bat` (2.5 KB)
- `docs/LOAD_SAMPLE_DATA.md` (5.6 KB)
- `examples/import_proveedores.csv` (9 suppliers)
- `examples/import_lista_materiales.csv` (58 items with prices)

#### 3. CSV Import Templates
- `examples/template_suppliers.csv`
- `examples/template_items.csv`
- `examples/template_suppliers_items_prices.csv`
- `examples/README.md` (template documentation)

#### 4. Configuration Improvements
- Logo configurable via `config.ini` (LOGO_PATH)
- Server-side config API endpoints (GET/POST `/api/config`)
- Dynamic logo loading in UI
- Config preservation during upgrades

#### 5. UI/UX Improvements
- Import modal pre-selects correct type
- CSV support for items+suppliers+prices import
- Fixed run.bat path (app\app.py)
- Logo placeholder when no logo configured

#### 6. Upgrade Path
- `installers/patch-v0.1.ps1` (PowerShell patch installer)
- `installers/PATCH-v0.1.bat` (Windows wrapper)
- `docs/PATCH_v0.1.md` (Upgrade documentation)

## 📊 File Count

### Distribution Contents
- Total files: **44** (was 41 in v0.1)
- ZIP size: **~134 KB** (was 127 KB)

### New Files Added
- Utilities: **4 files** (2 Python + 2 BAT)
- Documentation: **3 files** (2 utility guides + 1 patch guide)
- Examples: **6 files** (3 templates + 2 sample data + 1 README)
- Installers: **2 files** (patch installer + wrapper)

## 🚀 Pre-Release Checklist

### Required Before Creating Distribution

1. ✅ All version numbers updated to 1.0
2. ✅ Release notes completed
3. ✅ New features documented
4. ✅ Utilities tested
5. ⏳ Create final distribution ZIP
6. ⏳ Test installation from ZIP
7. ⏳ Test utilities in installed environment
8. ⏳ Test upgrade from v0.1

### Distribution Steps

1. **Create Distribution**
   ```batch
   cd installers
   .\create_distribution.bat
   ```
   Expected output: `proveedores-v1.0.zip` (134 KB)

2. **Verify Contents**
   ```powershell
   Expand-Archive proveedores-v1.0.zip -DestinationPath test-v1.0
   cd test-v1.0\proveedores-v1.0
   dir utilities  # Should show 4 files
   dir examples   # Should show 6 CSV files + README
   ```

3. **Test Fresh Installation**
   ```batch
   # Extract to clean location
   # Run INSTALAR.bat
   # Verify app starts
   # Test utilities\load_sample_data.bat
   ```

4. **Test Upgrade Path**
   ```batch
   # On v0.1 installation:
   # Copy patch files to installation directory
   # Run installers\PATCH-v0.1.bat
   # Verify backup created
   # Verify new utilities present
   ```

## 📝 Release Notes Summary

### New in v1.0
- ✨ Database maintenance utilities
- ✨ Automatic sample data loader
- ✨ CSV import templates with examples
- ✨ Configurable logo support
- ✨ CSV support for combined imports
- ✨ Patch installer for v0.1 upgrades
- 🐛 Fixed import modal pre-selection
- 🐛 Fixed run.bat path
- 🐛 Server-side configuration persistence

### Breaking Changes
- None (fully backward compatible with v0.1 data)

### Migration from v0.1
- Use `installers/PATCH-v0.1.bat` for automatic upgrade
- All data preserved
- Config.ini preserved
- Database structure unchanged

## 🎯 Post-Release Tasks

1. **Tag Release**
   ```bash
   git tag -a v1.0 -m "Release version 1.0"
   git push origin v1.0
   ```

2. **Create GitHub Release**
   - Title: "Sistema de Proveedores v1.0 - First Stable Release"
   - Attach: `proveedores-v1.0.zip`
   - Release notes: Copy from RELEASE_NOTES.md

3. **Update Documentation**
   - Update main README.md if needed
   - Verify all links work
   - Update screenshots if UI changed

4. **Announce Release**
   - Internal team notification
   - User documentation available
   - Migration guide available

## 📋 Testing Checklist

### Fresh Installation (Windows)
- [ ] Extract ZIP to clean directory
- [ ] Run INSTALAR.bat
- [ ] Verify venv created
- [ ] Verify dependencies installed
- [ ] Run run.bat
- [ ] Open http://localhost:5000
- [ ] Test basic CRUD operations
- [ ] Test utilities\load_sample_data.bat
- [ ] Verify 9 suppliers + 58 items loaded
- [ ] Test utilities\cleanup_database.bat
- [ ] Test import CSV with items+suppliers

### Upgrade from v0.1
- [ ] Have v0.1 installation with data
- [ ] Copy patch files
- [ ] Run PATCH-v0.1.bat
- [ ] Verify backup_YYYYMMDD created
- [ ] Verify utilities folder added
- [ ] Verify docs updated
- [ ] Run app and verify data intact
- [ ] Test new utilities
- [ ] Test new import features

### Logo Configuration
- [ ] Place logo file in app/static/
- [ ] Edit config.ini: LOGO_PATH=logo.png
- [ ] Restart app
- [ ] Verify logo displays
- [ ] Test with URL: LOGO_PATH=https://example.com/logo.png
- [ ] Verify placeholder shows when no logo

### Import Features
- [ ] Test "Importar Proveedores" button
- [ ] Verify modal opens with suppliers selected
- [ ] Test "Importar Items" button
- [ ] Verify modal opens with items selected
- [ ] Import examples/import_proveedores.csv
- [ ] Import examples/import_lista_materiales.csv
- [ ] Verify data imported correctly

## 🔧 Troubleshooting

### Common Issues

**Q: Distribution script fails**
- Verify all new files exist
- Check utilities/ folder has 4 files
- Check examples/ folder complete

**Q: Version still shows 0.1**
- Check VERSION file contains "1.0"
- Rebuild distribution

**Q: Utilities not in ZIP**
- Verify create_distribution.bat includes "utilities" in $folders array
- Re-run distribution script

**Q: Patch fails on v0.1**
- Verify patch-v0.1.ps1 script syntax
- Check file paths are correct
- Verify source files exist

## ✅ Final Verification

Before releasing v1.0, confirm:
- [ ] VERSION file = 1.0
- [ ] RELEASE_NOTES.md mentions v1.0
- [ ] RELEASE_SUMMARY.md mentions v1.0
- [ ] Distribution creates proveedores-v1.0.zip
- [ ] All 44 files included in ZIP
- [ ] Utilities folder with 4 files
- [ ] Examples folder with 6+ files
- [ ] Docs folder with new guides
- [ ] Patch installer tested
- [ ] Fresh install tested
- [ ] Logo feature tested
- [ ] CSV import tested
- [ ] Sample data loader tested

---

**Ready for Release:** ✅ All version numbers updated to 1.0
**Distribution File:** proveedores-v1.0.zip
**Release Date:** February 2026

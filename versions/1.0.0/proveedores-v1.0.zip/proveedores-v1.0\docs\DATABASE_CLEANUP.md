# Database Cleanup Utility

Quick utility to clean/reset corrupted database tables.

## Quick Start

### Windows (Easiest)
```batch
cleanup_database.bat
```

Interactive menu with options to clean specific tables or everything.

### Command Line (Advanced)

**Show current status:**
```bash
python cleanup_database.py --status
```

**Clean everything (drop & recreate all tables):**
```bash
python cleanup_database.py --all
```

**Clean specific tables:**
```bash
python cleanup_database.py --suppliers
python cleanup_database.py --items
python cleanup_database.py --prices
python cleanup_database.py --orders
```

**Clean multiple tables:**
```bash
python cleanup_database.py --suppliers --items
```

**Skip backup (faster, but dangerous):**
```bash
python cleanup_database.py --all --no-backup
```

**Skip confirmation prompts:**
```bash
python cleanup_database.py --all --force
```

## What Each Option Does

### `--all`
- **Drops ALL tables** (suppliers, items, supplier_items, orders)
- **Recreates tables** with fresh schema
- Use when database is corrupted or you want a complete fresh start
- **⚠️ WARNING: Deletes everything!**

### `--suppliers`
- Deletes all supplier records
- Also deletes related supplier-item relationships (prices)
- Items remain intact

### `--items`
- Deletes all item/material records
- Also deletes related supplier-item relationships (prices)
- Suppliers remain intact

### `--prices`
- Deletes only supplier-item relationships (price associations)
- Keeps suppliers and items intact
- Use when you want to re-import pricing data

### `--orders`
- Deletes all order records
- Suppliers and items remain intact

### `--status`
- Shows current record counts
- Displays database path/URL
- Does not modify anything

## Safety Features

✅ **Automatic Backup** - Creates `.backup_YYYYMMDD_HHMMSS` file (SQLite only)  
✅ **Confirmation Prompts** - Asks before deleting (unless `--force`)  
✅ **Status Display** - Shows before/after record counts  
✅ **Error Handling** - Rolls back on failure  

## Common Scenarios

### Scenario 1: Corrupted Items/Suppliers Tables
```bash
# See what's there
python cleanup_database.py --status

# Clean and start fresh
python cleanup_database.py --all

# Re-import your data
# (use the CSV import feature in the web app)
```

### Scenario 2: Wrong Prices Imported
```bash
# Delete only price relationships, keep suppliers and items
python cleanup_database.py --prices

# Re-import pricing data
```

### Scenario 3: Duplicate Suppliers
```bash
# Clean suppliers only
python cleanup_database.py --suppliers

# Re-import supplier list
```

### Scenario 4: Complete Fresh Start
```bash
# Nuclear option - delete everything
python cleanup_database.py --all --force --no-backup

# Or use the interactive menu
cleanup_database.bat
```

## Examples

**Check database status:**
```bash
$ python cleanup_database.py --status

============================================================
CURRENT DATABASE STATUS
============================================================

Suppliers:              12
Items:                 156
Supplier-Items:        342
Orders:                  5

Database: sqlite:///suppliers.db
```

**Clean everything with confirmation:**
```bash
$ python cleanup_database.py --all

============================================================
DATABASE CLEANUP UTILITY
============================================================

[Shows current status]

============================================================
⚠  WARNING: This operation will delete data!
============================================================

Actions to perform:
- Drop and recreate ALL tables

Do you want to continue? (yes/no): yes

============================================================
CREATING BACKUP
============================================================

✓ Database backed up to: suppliers.db.backup_20260204_153045

============================================================
CLEANING ALL TABLES
============================================================

[1/2] Dropping all tables...
✓ All tables dropped

[2/2] Recreating tables...
✓ All tables recreated

============================================================
✓ Database cleaned successfully!
============================================================

[Shows final status]

✓ Cleanup complete!
```

## Backup Notes

- **SQLite:** Automatic file copy to `.backup_YYYYMMDD_HHMMSS`
- **MySQL/PostgreSQL:** Manual backup recommended (use `mysqldump` or `pg_dump`)
- Backups are created by default (use `--no-backup` to skip)

## Troubleshooting

**"Table doesn't exist" error:**
- Database might already be empty
- Run with `--all` to recreate schema

**Permission denied:**
- Close any programs using the database
- Make sure you're in the correct directory

**Python not found:**
- Activate virtual environment first: `venv\Scripts\activate`
- Or use full path: `venv\Scripts\python.exe cleanup_database.py`

## Need Help?

Run without arguments to see all options:
```bash
python cleanup_database.py
```

Or use the interactive menu:
```bash
cleanup_database.bat
```

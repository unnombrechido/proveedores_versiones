// API Base URL
const API_BASE = '/api';

// Global state
let suppliers = [];
let orders = [];
let categories = [];
let countries = [];

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    loadDatabaseInfo();
    loadSuppliers();
    loadOrders();
    loadCategories();
    loadCountries();
});

// Tab management
function showTab(tabName, event) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabName + '-tab').classList.add('active');
    if (event && event.target) {
        event.target.classList.add('active');
    }
}

// Database info
async function loadDatabaseInfo() {
    try {
        const response = await fetch(`${API_BASE}/database/info`);
        const data = await response.json();
        document.getElementById('db-type').textContent = `Database: ${data.type}`;
    } catch (error) {
        console.error('Error loading database info:', error);
    }
}

// Suppliers
async function loadSuppliers() {
    try {
        const search = document.getElementById('search').value;
        const category = document.getElementById('category-filter').value;
        const country = document.getElementById('country-filter').value;
        const active = document.getElementById('active-filter').value;
        
        let url = `${API_BASE}/suppliers?`;
        if (search) url += `search=${encodeURIComponent(search)}&`;
        if (category) url += `category=${encodeURIComponent(category)}&`;
        if (country) url += `country=${encodeURIComponent(country)}&`;
        if (active) url += `active=${active}&`;
        
        const response = await fetch(url);
        suppliers = await response.json();
        displaySuppliers();
    } catch (error) {
        console.error('Error loading suppliers:', error);
        showError('Error al cargar proveedores');
    }
}

function displaySuppliers() {
    const tbody = document.getElementById('suppliers-tbody');
    
    if (suppliers.length === 0) {
        tbody.innerHTML = '<tr><td colspan="11" class="empty-state"><h3>No hay proveedores</h3><p>Agregue un nuevo proveedor o importe desde un archivo</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = suppliers.map(supplier => `
        <tr>
            <td>${supplier.id}</td>
            <td><strong>${supplier.name}</strong></td>
            <td>${supplier.contact_person || '-'}</td>
            <td>${supplier.email || '-'}</td>
            <td>${supplier.phone || '-'}</td>
            <td>${supplier.city || '-'}</td>
            <td>${supplier.country || '-'}</td>
            <td>${supplier.category || '-'}</td>
            <td class="rating">${'⭐'.repeat(Math.round(supplier.rating))}</td>
            <td class="${supplier.active ? 'status-active' : 'status-inactive'}">
                ${supplier.active ? 'Activo' : 'Inactivo'}
            </td>
            <td>
                <button onclick="editSupplier(${supplier.id})" class="btn btn-primary btn-small">✏️ Editar</button>
                <button onclick="deleteSupplier(${supplier.id})" class="btn btn-danger btn-small">🗑️ Eliminar</button>
                <button onclick="createOrderForSupplier(${supplier.id})" class="btn btn-secondary btn-small">📦 Orden</button>
            </td>
        </tr>
    `).join('');
}

function searchSuppliers() {
    loadSuppliers();
}

function filterSuppliers() {
    loadSuppliers();
}

// Supplier CRUD operations
function showAddSupplierModal() {
    document.getElementById('modal-title').textContent = 'Agregar Proveedor';
    document.getElementById('supplier-form').reset();
    document.getElementById('supplier-id').value = '';
    document.getElementById('supplier-modal').classList.add('active');
}

function closeSupplierModal() {
    document.getElementById('supplier-modal').classList.remove('active');
}

async function editSupplier(id) {
    try {
        const response = await fetch(`${API_BASE}/suppliers/${id}`);
        const supplier = await response.json();
        
        document.getElementById('modal-title').textContent = 'Editar Proveedor';
        document.getElementById('supplier-id').value = supplier.id;
        document.getElementById('name').value = supplier.name;
        document.getElementById('contact-person').value = supplier.contact_person || '';
        document.getElementById('email').value = supplier.email || '';
        document.getElementById('phone').value = supplier.phone || '';
        document.getElementById('address').value = supplier.address || '';
        document.getElementById('city').value = supplier.city || '';
        document.getElementById('country').value = supplier.country || '';
        document.getElementById('tax-id').value = supplier.tax_id || '';
        document.getElementById('category').value = supplier.category || '';
        document.getElementById('rating').value = supplier.rating || 0;
        document.getElementById('payment-terms').value = supplier.payment_terms || '';
        document.getElementById('notes').value = supplier.notes || '';
        document.getElementById('active').checked = supplier.active === 1;
        
        document.getElementById('supplier-modal').classList.add('active');
    } catch (error) {
        console.error('Error loading supplier:', error);
        showError('Error al cargar proveedor');
    }
}

async function saveSupplier(event) {
    event.preventDefault();
    
    const id = document.getElementById('supplier-id').value;
    const data = {
        name: document.getElementById('name').value,
        contact_person: document.getElementById('contact-person').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        address: document.getElementById('address').value,
        city: document.getElementById('city').value,
        country: document.getElementById('country').value,
        tax_id: document.getElementById('tax-id').value,
        category: document.getElementById('category').value,
        rating: parseFloat(document.getElementById('rating').value),
        payment_terms: document.getElementById('payment-terms').value,
        notes: document.getElementById('notes').value,
        active: document.getElementById('active').checked ? 1 : 0
    };
    
    try {
        const url = id ? `${API_BASE}/suppliers/${id}` : `${API_BASE}/suppliers`;
        const method = id ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeSupplierModal();
            loadSuppliers();
            loadCategories();
            loadCountries();
            showSuccess(id ? 'Proveedor actualizado' : 'Proveedor creado');
        } else {
            const error = await response.json();
            showError(error.error || 'Error al guardar proveedor');
        }
    } catch (error) {
        console.error('Error saving supplier:', error);
        showError('Error al guardar proveedor');
    }
}

async function deleteSupplier(id) {
    if (!confirm('¿Está seguro de que desea eliminar este proveedor?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/suppliers/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            loadSuppliers();
            showSuccess('Proveedor eliminado');
        } else {
            const error = await response.json();
            showError(error.error || 'Error al eliminar proveedor');
        }
    } catch (error) {
        console.error('Error deleting supplier:', error);
        showError('Error al eliminar proveedor');
    }
}

// Categories and countries
async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE}/suppliers/categories`);
        categories = await response.json();
        
        const select = document.getElementById('category-filter');
        select.innerHTML = '<option value="">Todas las Categorías</option>' +
            categories.map(cat => `<option value="${cat}">${cat}</option>`).join('');
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function loadCountries() {
    try {
        const response = await fetch(`${API_BASE}/suppliers/countries`);
        countries = await response.json();
        
        const select = document.getElementById('country-filter');
        select.innerHTML = '<option value="">Todos los Países</option>' +
            countries.map(country => `<option value="${country}">${country}</option>`).join('');
    } catch (error) {
        console.error('Error loading countries:', error);
    }
}

// Import/Export
function showImportModal() {
    document.getElementById('import-modal').classList.add('active');
}

function closeImportModal() {
    document.getElementById('import-modal').classList.remove('active');
}

function updateImportInstructions() {
    const importType = document.getElementById('import-type').value;
    const instructions = document.getElementById('import-instructions');
    const suppliersFormat = document.getElementById('suppliers-format');
    const itemsFormat = document.getElementById('items-format');
    
    if (importType) {
        instructions.style.display = 'block';
        if (importType === 'suppliers') {
            suppliersFormat.style.display = 'block';
            itemsFormat.style.display = 'none';
        } else if (importType === 'items') {
            suppliersFormat.style.display = 'none';
            itemsFormat.style.display = 'block';
        }
    } else {
        instructions.style.display = 'none';
    }
}

async function importFile(event) {
    event.preventDefault();
    
    const importType = document.getElementById('import-type').value;
    const fileInput = document.getElementById('import-file');
    const file = fileInput.files[0];
    
    if (!importType) {
        showError('Por favor seleccione el tipo de importación');
        return;
    }
    
    if (!file) {
        showError('Por favor seleccione un archivo');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    
    let endpoint;
    if (importType === 'suppliers') {
        endpoint = file.name.endsWith('.csv') ? 'csv' : 'excel';
        endpoint = `suppliers/import/${endpoint}`;
    } else if (importType === 'items') {
        endpoint = 'suppliers/import/custom-excel';
    }
    
    try {
        const response = await fetch(`${API_BASE}/${endpoint}`, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (response.ok) {
            closeImportModal();
            loadSuppliers();
            loadCategories();
            loadCountries();
            
            let message = result.message;
            if (importType === 'items') {
                message += `\n- Proveedores: ${result.suppliers_imported || 0}\n- Items: ${result.items_imported || 0}`;
                if (result.errors && result.errors.length > 0) {
                    message += `\n\nAdvertencias: ${result.errors.length} errores (ver consola)`;
                    console.warn('Import errors:', result.errors);
                }
            }
            showSuccess(message);
        } else {
            showError(result.error || 'Error al importar archivo');
        }
    } catch (error) {
        console.error('Error importing file:', error);
        showError('Error al importar archivo');
    }
}

async function exportSuppliers(format) {
    try {
        const url = `${API_BASE}/suppliers/export/${format}`;
        window.location.href = url;
        showSuccess(`Exportando proveedores a ${format.toUpperCase()}...`);
    } catch (error) {
        console.error('Error exporting suppliers:', error);
        showError('Error al exportar proveedores');
    }
}

// Orders
async function loadOrders() {
    try {
        const status = document.getElementById('order-status-filter').value;
        let url = `${API_BASE}/orders?`;
        if (status) url += `status=${status}&`;
        
        const response = await fetch(url);
        orders = await response.json();
        displayOrders();
    } catch (error) {
        console.error('Error loading orders:', error);
        showError('Error al cargar órdenes');
    }
}

function displayOrders() {
    const tbody = document.getElementById('orders-tbody');
    
    if (orders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><h3>No hay órdenes</h3><p>Cree una nueva orden de compra</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = orders.map(order => `
        <tr>
            <td><strong>${order.order_number}</strong></td>
            <td>${order.supplier_name}</td>
            <td>${new Date(order.order_date).toLocaleDateString()}</td>
            <td>${order.delivery_date ? new Date(order.delivery_date).toLocaleDateString() : '-'}</td>
            <td><span class="badge badge-${order.status}">${getStatusLabel(order.status)}</span></td>
            <td>$${order.total_amount.toFixed(2)}</td>
            <td>
                <button onclick="viewOrder(${order.id})" class="btn btn-primary btn-small">👁️ Ver</button>
            </td>
        </tr>
    `).join('');
}

function getStatusLabel(status) {
    const labels = {
        'pending': 'Pendiente',
        'confirmed': 'Confirmado',
        'shipped': 'Enviado',
        'delivered': 'Entregado',
        'cancelled': 'Cancelado'
    };
    return labels[status] || status;
}

function filterOrders() {
    loadOrders();
}

async function showCreateOrderModal() {
    // Load suppliers for dropdown
    try {
        const response = await fetch(`${API_BASE}/suppliers?active=1`);
        const activeSuppliers = await response.json();
        
        const select = document.getElementById('order-supplier');
        select.innerHTML = '<option value="">Seleccionar Proveedor</option>' +
            activeSuppliers.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
        
        document.getElementById('order-modal').classList.add('active');
    } catch (error) {
        console.error('Error loading suppliers:', error);
        showError('Error al cargar proveedores');
    }
}

function closeOrderModal() {
    document.getElementById('order-modal').classList.remove('active');
}

async function createOrderForSupplier(supplierId) {
    await showCreateOrderModal();
    document.getElementById('order-supplier').value = supplierId;
}

async function saveOrder(event) {
    event.preventDefault();
    
    const data = {
        supplier_id: parseInt(document.getElementById('order-supplier').value),
        delivery_date: document.getElementById('delivery-date').value || null,
        status: document.getElementById('order-status').value,
        total_amount: parseFloat(document.getElementById('total-amount').value),
        items: document.getElementById('order-items').value,
        notes: document.getElementById('order-notes').value
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeOrderModal();
            loadOrders();
            showSuccess('Orden creada exitosamente');
        } else {
            const error = await response.json();
            showError(error.error || 'Error al crear orden');
        }
    } catch (error) {
        console.error('Error creating order:', error);
        showError('Error al crear orden');
    }
}

function viewOrder(id) {
    const order = orders.find(o => o.id === id);
    if (order) {
        alert(`Orden: ${order.order_number}\n\nProveedor: ${order.supplier_name}\nEstado: ${getStatusLabel(order.status)}\nMonto: $${order.total_amount}\n\nItems:\n${order.items}\n\nNotas:\n${order.notes}`);
    }
}

// Notifications
function showSuccess(message) {
    showNotification(message, 'success');
}

function showError(message) {
    showNotification(message, 'error');
}

function showNotification(message, type) {
    const div = document.createElement('div');
    div.className = `message message-${type}`;
    div.textContent = message;
    div.style.position = 'fixed';
    div.style.top = '20px';
    div.style.right = '20px';
    div.style.zIndex = '10000';
    div.style.minWidth = '300px';
    
    document.body.appendChild(div);
    
    setTimeout(() => {
        div.remove();
    }, 5000);
}

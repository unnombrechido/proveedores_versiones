# -*- coding: utf-8 -*-
"""
Load Sample Data Script
========================
Script to load sample CSV data files into the database.

Usage:
    python load_sample_data.py [options]

Options:
    --clean            Clean database before loading (optional)
    --suppliers-only   Load only suppliers (import_proveedores.csv)
    --items-only       Load only items with prices (import_lista_materiales.csv)

Examples:
    python load_sample_data.py
    python load_sample_data.py --clean
    python load_sample_data.py --suppliers-only
"""

import os
import sys
import pandas as pd
from datetime import datetime

# Add parent directory and app directory to path to import modules
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
app_dir = os.path.join(parent_dir, 'app')

# Check if database.py is in app/ subdirectory or directly in parent
if os.path.exists(os.path.join(app_dir, 'database.py')):
    # Structure: parent/app/database.py
    sys.path.insert(0, app_dir)
elif os.path.exists(os.path.join(parent_dir, 'database.py')):
    # Structure: parent/database.py (direct)
    sys.path.insert(0, parent_dir)
else:
    print("ERROR: No se pudo encontrar database.py")
    sys.exit(1)

# Change working directory to parent (where config.ini and database are)
os.chdir(parent_dir)

from database import SessionLocal
from models import Supplier, Item, supplier_items
from sqlalchemy import select


def load_suppliers_csv(csv_path, db):
    """Load suppliers from CSV file"""
    print("\n" + "="*60)
    print("CARGANDO PROVEEDORES")
    print("="*60)
    
    if not os.path.exists(csv_path):
        print("✗ Archivo no encontrado: {}".format(csv_path))
        return 0
    
    df = pd.read_csv(csv_path)
    print("\nArchivo: {}".format(csv_path))
    print("Registros encontrados: {}".format(len(df)))
    
    imported = 0
    skipped = 0
    errors = []
    
    for index, row in df.iterrows():
        try:
            # Check if supplier already exists
            existing = db.query(Supplier).filter(Supplier.name == row['name']).first()
            if existing:
                skipped += 1
                continue
            
            # Create new supplier
            supplier = Supplier(
                name=row['name'],
                contact_person=row.get('contact_person') if pd.notna(row.get('contact_person')) else None,
                email=row.get('email') if pd.notna(row.get('email')) else None,
                phone=row.get('phone') if pd.notna(row.get('phone')) else None,
                address=row.get('address') if pd.notna(row.get('address')) else None,
                city=row.get('city') if pd.notna(row.get('city')) else None,
                country=row.get('country') if pd.notna(row.get('country')) else None,
                tax_id=row.get('tax_id') if pd.notna(row.get('tax_id')) else None,
                category=row.get('category') if pd.notna(row.get('category')) else None,
                rating=int(row['rating']) if pd.notna(row.get('rating')) else None,
                payment_terms=row.get('payment_terms') if pd.notna(row.get('payment_terms')) else None,
                notes=row.get('notes') if pd.notna(row.get('notes')) else None,
                active=bool(row.get('active', True))
            )
            db.add(supplier)
            imported += 1
            
        except Exception as e:
            errors.append("Fila {}: {}".format(index + 2, str(e)))
    
    db.commit()
    
    print("\n✓ Proveedores importados: {}".format(imported))
    if skipped > 0:
        print("⊘ Proveedores omitidos (ya existen): {}".format(skipped))
    if errors:
        print("\n✗ Errores:")
        for error in errors[:5]:  # Show first 5 errors
            print("  - {}".format(error))
        if len(errors) > 5:
            print("  ... y {} errores mas".format(len(errors) - 5))
    
    return imported


def load_items_with_suppliers_csv(csv_path, db):
    """Load items with suppliers and prices from CSV file"""
    print("\n" + "="*60)
    print("CARGANDO ITEMS CON PROVEEDORES Y PRECIOS")
    print("="*60)
    
    if not os.path.exists(csv_path):
        print("✗ Archivo no encontrado: {}".format(csv_path))
        return 0, 0, 0
    
    df = pd.read_csv(csv_path)
    print("\nArchivo: {}".format(csv_path))
    print("Registros encontrados: {}".format(len(df)))
    
    suppliers_created = 0
    items_created = 0
    relationships_created = 0
    errors = []
    
    for index, row in df.iterrows():
        try:
            # Get or create supplier
            supplier = db.query(Supplier).filter(Supplier.name == row['supplier_name']).first()
            if not supplier:
                supplier = Supplier(
                    name=row['supplier_name'],
                    email=row.get('supplier_email') if pd.notna(row.get('supplier_email')) else None,
                    phone=row.get('supplier_phone') if pd.notna(row.get('supplier_phone')) else None,
                    address=row.get('supplier_address') if pd.notna(row.get('supplier_address')) else None,
                    city=row.get('supplier_city') if pd.notna(row.get('supplier_city')) else None,
                    country=row.get('supplier_country') if pd.notna(row.get('supplier_country')) else None,
                    category=row.get('supplier_category') if pd.notna(row.get('supplier_category')) else None
                )
                db.add(supplier)
                db.flush()
                suppliers_created += 1
            
            # Get or create item
            item = db.query(Item).filter(Item.item_code == row['item_code']).first()
            if not item:
                item = Item(
                    item_code=row['item_code'],
                    name=row['item_name'],
                    description=row.get('item_description') if pd.notna(row.get('item_description')) else None,
                    category=row.get('item_category') if pd.notna(row.get('item_category')) else None,
                    unit=row.get('unit') if pd.notna(row.get('unit')) else None
                )
                db.add(item)
                db.flush()
                items_created += 1
            
            # Check if relationship already exists
            stmt = select(supplier_items).where(
                (supplier_items.c.supplier_id == supplier.id) &
                (supplier_items.c.item_id == item.id)
            )
            existing = db.execute(stmt).first()
            
            if not existing:
                # Create supplier-item relationship
                ins = supplier_items.insert().values(
                    supplier_id=supplier.id,
                    item_id=item.id,
                    price=float(row['price']) if pd.notna(row.get('price')) else None,
                    supplier_item_code=row.get('supplier_item_code') if pd.notna(row.get('supplier_item_code')) else None,
                    lead_time_days=int(row['lead_time_days']) if pd.notna(row.get('lead_time_days')) else None,
                    minimum_order_quantity=int(row['minimum_order_quantity']) if pd.notna(row.get('minimum_order_quantity')) else None,
                    notes=row.get('notes') if pd.notna(row.get('notes')) else None
                )
                db.execute(ins)
                relationships_created += 1
                
        except Exception as e:
            errors.append("Fila {}: {}".format(index + 2, str(e)))
    
    db.commit()
    
    print("\n✓ Proveedores creados: {}".format(suppliers_created))
    print("✓ Items creados: {}".format(items_created))
    print("✓ Relaciones proveedor-item creadas: {}".format(relationships_created))
    
    if errors:
        print("\n✗ Errores:")
        for error in errors[:5]:
            print("  - {}".format(error))
        if len(errors) > 5:
            print("  ... y {} errores mas".format(len(errors) - 5))
    
    return suppliers_created, items_created, relationships_created


def clean_database(db):
    """Clean all data from database"""
    print("\n" + "="*60)
    print("LIMPIANDO BASE DE DATOS")
    print("="*60)
    
    # Get counts before cleaning
    suppliers_count = db.query(Supplier).count()
    items_count = db.query(Item).count()
    
    print("\nRegistros actuales:")
    print("  Proveedores: {}".format(suppliers_count))
    print("  Items: {}".format(items_count))
    
    # Delete all data
    db.execute(supplier_items.delete())
    db.query(Item).delete()
    db.query(Supplier).delete()
    db.commit()
    
    print("\n✓ Base de datos limpiada")


def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Load Sample Data into Database',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument('--clean', action='store_true',
                       help='Clean database before loading')
    parser.add_argument('--suppliers-only', action='store_true',
                       help='Load only suppliers (import_proveedores.csv)')
    parser.add_argument('--items-only', action='store_true',
                       help='Load only items (import_lista_materiales.csv)')
    
    args = parser.parse_args()
    
    print("\n" + "="*60)
    print("CARGA DE DATOS DE EJEMPLO")
    print("="*60)
    print("\nFecha: {}".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    
    db = SessionLocal()
    
    try:
        # Clean if requested
        if args.clean:
            clean_database(db)
        
        # Determine paths
        examples_dir = os.path.join(parent_dir, 'examples')
        suppliers_csv = os.path.join(examples_dir, 'import_proveedores.csv')
        items_csv = os.path.join(examples_dir, 'import_lista_materiales.csv')
        
        total_suppliers = 0
        total_items = 0
        total_relationships = 0
        
        # Load suppliers only
        if args.suppliers_only:
            total_suppliers = load_suppliers_csv(suppliers_csv, db)
        # Load items only
        elif args.items_only:
            s, i, r = load_items_with_suppliers_csv(items_csv, db)
            total_suppliers += s
            total_items += i
            total_relationships += r
        # Load both
        else:
            total_suppliers = load_suppliers_csv(suppliers_csv, db)
            s, i, r = load_items_with_suppliers_csv(items_csv, db)
            total_suppliers += s
            total_items += i
            total_relationships += r
        
        # Summary
        print("\n" + "="*60)
        print("RESUMEN FINAL")
        print("="*60)
        print("\nProveedores totales: {}".format(db.query(Supplier).count()))
        print("Items totales: {}".format(db.query(Item).count()))
        
        print("\n✓ Carga completada exitosamente!")
        
    except Exception as e:
        db.rollback()
        print("\n✗ Error: {}".format(str(e)))
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        db.close()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n✗ Operacion cancelada por usuario")
        sys.exit(1)

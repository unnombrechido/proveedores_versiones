# Guía de Permisos - Sistema de Proveedores

## 🔐 Requisitos de Permisos por Operación

Esta guía explica cuándo necesitas permisos de administrador y cuándo no.

---

## ✅ Operaciones SIN Permisos de Administrador

Las siguientes operaciones NO requieren permisos elevados:

### 📦 Instalación Normal
- ✅ Instalar en directorio de usuario (`C:\Users\TuUsuario\...`)
- ✅ Crear entorno virtual Python
- ✅ Instalar paquetes Python con pip
- ✅ Crear base de datos SQLite
- ✅ Crear archivos de configuración
- ✅ Copiar archivos dentro de tu perfil de usuario
- ✅ Crear accesos directos en tu escritorio
- ✅ Ejecutar el servidor web (puerto 5000)

### 🔄 Actualización
- ✅ Actualizar a nueva versión
- ✅ Preservar datos existentes
- ✅ Crear respaldos automáticos
- ✅ Actualizar dependencias Python

### 🚀 Uso Diario
- ✅ Iniciar/detener el servidor
- ✅ Acceder a la interfaz web
- ✅ Agregar/editar/eliminar proveedores
- ✅ Crear órdenes de compra
- ✅ Importar/exportar datos
- ✅ Hacer respaldos manuales

**Recomendación:** Ejecuta como usuario normal para operaciones diarias.

---

## ⚠️ Operaciones QUE Requieren Administrador

### 🐍 Auto-instalación de Python (Primera Vez)

Si Python NO está instalado y quieres que el instalador lo instale automáticamente:

**Método 1: Ejecutar como Administrador**
1. Clic derecho en `setup-complete.ps1`
2. Selecciona **"Ejecutar con PowerShell como Administrador"**
3. Confirma el UAC (Control de Cuentas de Usuario)
4. El instalador usará winget para instalar Python

**¿Por qué se necesita?**
- Winget instala Python a nivel de sistema (para todos los usuarios)
- Modifica PATH del sistema
- Requiere permisos elevados

### 🌐 Usar Puertos Privilegiados

Si quieres usar puertos < 1024 (ej: puerto 80, 443):

```powershell
# Requiere ejecutar como administrador
python app.py --port 80
```

**Nota:** El sistema usa puerto 5000 por defecto (NO requiere admin).

---

## 🔀 Alternativas Sin Permisos de Administrador

### Si No Puedes Ejecutar Como Administrador

#### Opción 1: Instalar Python Manualmente (Sin Admin)
1. Descarga Python desde [python.org](https://www.python.org/downloads/)
2. Durante instalación, selecciona:
   - **Install for current user only** (NO "for all users")
   - ☑ **Add Python to PATH**
3. Luego ejecuta `setup-complete.ps1` normalmente (sin admin)

#### Opción 2: Usar Python Portable
1. Descarga WinPython o Python embebido
2. Extrae en tu carpeta de usuario
3. Configura PATH manualmente
4. Ejecuta el instalador

#### Opción 3: Pedir a TI que Instale Python
En entornos corporativos:
1. Solicita a IT que instale Python 3.13+
2. Una vez instalado, tú puedes instalar el sistema sin permisos de admin

---

## 🛡️ Política de Seguridad del Instalador

### Detección Automática de Permisos

El instalador `setup-complete.ps1` detecta automáticamente si tienes permisos de administrador:

```powershell
[INFO] Ejecutando con permisos de administrador  # Si tienes admin
[INFO] Ejecutando como usuario normal             # Si NO tienes admin
```

### Comportamiento Según Permisos

| Situación | Permisos Detectados | Comportamiento |
|-----------|---------------------|----------------|
| Python ya instalado | Admin o Normal | Continúa normalmente |
| Python NO instalado | Admin | Intenta instalar con winget |
| Python NO instalado | Normal | Ofrece opciones: <br>1. Cancelar y reiniciar como admin<br>2. Continuar y mostrar instrucciones manuales |

### Mensajes de Advertencia

Si ejecutas sin permisos de admin y Python no está instalado:

```
[ADVERTENCIA] No se detectaron permisos de administrador.

Para instalar Python automaticamente, necesitas:
1. Cerrar esta ventana
2. Clic derecho en setup-complete.ps1
3. Seleccionar 'Ejecutar con PowerShell como Administrador'

Continuar sin instalar Python automaticamente? (S/N)
```

---

## 📋 Checklist: ¿Necesito Permisos de Admin?

```
☐ ¿Es tu primera instalación?
  ├─ ☑ Python ya está instalado → NO necesitas admin
  └─ ☐ Python NO está instalado
      ├─ Quiero auto-instalación → SÍ necesitas admin
      └─ Puedo instalar Python manualmente → NO necesitas admin

☐ ¿Estoy actualizando el sistema?
  └─ Python ya está instalado → NO necesitas admin

☐ ¿Estoy usando el sistema diariamente?
  └─ Solo uso normal → NO necesitas admin

☐ ¿Quiero usar puerto 80/443?
  └─ Puertos < 1024 → SÍ necesitas admin
  └─ Puerto 5000 (default) → NO necesitas admin
```

---

## 🔧 Solución de Problemas de Permisos

### Error: "Access Denied" al instalar Python

**Causa:** No tienes permisos de administrador.

**Solución:**
```powershell
# Opción 1: Reiniciar como admin
# Clic derecho → Ejecutar como Administrador

# Opción 2: Instalar Python manualmente sin admin
# Descargar e instalar "solo para este usuario"
```

### Error: "Cannot create directory"

**Causa:** Intentando instalar en ubicación protegida.

**Solución:**
```powershell
# Usa directorio en tu perfil de usuario
$installDir = "$env:USERPROFILE\SistemaProveedores"  # ✅ Correcto
$installDir = "C:\Program Files\Sistema"             # ❌ Requiere admin
```

### Error: winget requiere permisos elevados

**Causa:** winget detecta que necesita permisos de admin para instalar.

**Solución:**
```powershell
# El instalador ahora ofrece:
# 1. Reiniciar como admin
# 2. Continuar con instalación manual

# También puedes usar:
winget install Python.Python.3.13 --scope user  # Instalar solo para ti
```

---

## 📚 Recursos Adicionales

### Cómo Ejecutar Como Administrador en Windows

**Método 1: Clic Derecho**
1. Clic derecho en `setup-complete.ps1`
2. "Ejecutar con PowerShell como Administrador"
3. Confirma UAC

**Método 2: Desde PowerShell Admin**
```powershell
# Abre PowerShell como admin
# Win + X → "Windows PowerShell (Administrador)"

cd "C:\ruta\a\proveedores"
.\setup-complete.ps1
```

**Método 3: Desde Terminal Admin**
```powershell
# Abre Windows Terminal como admin
# Clic derecho en icono Terminal → Ejecutar como Administrador

pwsh
cd "C:\ruta\a\proveedores"
.\setup-complete.ps1
```

### Verificar Permisos Actuales

```powershell
# En PowerShell, ejecuta:
([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# Resultado:
# True  = Tienes permisos de administrador
# False = Usuario normal
```

---

## 🎯 Mejores Prácticas

### ✅ Recomendado

1. **Primera instalación:** Ejecuta como admin si quieres auto-instalación de Python
2. **Uso diario:** Ejecuta como usuario normal
3. **Actualizaciones:** Usuario normal (no requiere admin)
4. **Directorio de instalación:** Dentro de tu perfil de usuario

### ❌ Evitar

1. Ejecutar el servidor web como administrador (riesgo de seguridad)
2. Instalar en `C:\Program Files\` (innecesario y requiere permisos)
3. Dar permisos de admin permanentemente al script
4. Ejecutar como admin "por las dudas" (principio de mínimo privilegio)

---

**Actualizado:** Febrero 2026  
**Versión:** 1.0

import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

load_dotenv()

Base = declarative_base()

def get_database_url():
    """Generate database URL based on configuration"""
    db_type = os.getenv('DATABASE_TYPE', 'sqlite')
    
    if db_type == 'sqlite':
        db_path = os.getenv('DATABASE_PATH', 'suppliers.db')
        return f'sqlite:///{db_path}'
    
    elif db_type == 'mysql':
        host = os.getenv('DATABASE_HOST', 'localhost')
        port = os.getenv('DATABASE_PORT', '3306')
        user = os.getenv('DATABASE_USER', 'root')
        password = os.getenv('DATABASE_PASSWORD', '')
        database = os.getenv('DATABASE_NAME', 'proveedores')
        return f'mysql+pymysql://{user}:{password}@{host}:{port}/{database}'
    
    else:
        raise ValueError(f'Unsupported database type: {db_type}')

# Create engine and session
engine = create_engine(get_database_url(), echo=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def init_db():
    """Initialize database tables"""
    Base.metadata.create_all(bind=engine)

def get_db():
    """Get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

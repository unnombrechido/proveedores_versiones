#!/bin/bash
# ============================================================
#  Sistema de Gestión de Proveedores e Inventario v0.1
#  Instalador Automático para Linux/Mac
# ============================================================

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo ""
echo -e "${CYAN}========================================================${NC}"
echo -e "${CYAN}  INSTALADOR - Sistema de Gestion de Proveedores v0.1${NC}"
echo -e "${CYAN}========================================================${NC}"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[ERROR] Python3 no esta instalado en el sistema.${NC}"
    echo ""
    echo "Por favor instala Python 3.8 o superior:"
    echo ""
    echo "Ubuntu/Debian:"
    echo "  sudo apt update && sudo apt install python3 python3-venv python3-pip"
    echo ""
    echo "macOS (con Homebrew):"
    echo "  brew install python3"
    echo ""
    exit 1
fi

echo -e "${GREEN}[OK] Python detectado:${NC}"
python3 --version
echo ""

# Check Python version
python3 -c "import sys; exit(0 if sys.version_info >= (3, 8) else 1)" 2>/dev/null
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERROR] Se requiere Python 3.8 o superior.${NC}"
    echo "Por favor actualiza tu version de Python."
    exit 1
fi

echo -e "${YELLOW}[1/5] Verificando entorno virtual...${NC}"
if [ -d "venv" ]; then
    echo -e "${YELLOW}[INFO] Entorno virtual existente detectado. Se eliminara y recreara.${NC}"
    rm -rf venv
fi

echo -e "${YELLOW}[2/5] Creando entorno virtual...${NC}"
python3 -m venv venv
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERROR] No se pudo crear el entorno virtual.${NC}"
    echo "Puede que necesites instalar python3-venv:"
    echo "  sudo apt install python3-venv"
    exit 1
fi
echo -e "${GREEN}[OK] Entorno virtual creado exitosamente.${NC}"
echo ""

echo -e "${YELLOW}[3/5] Activando entorno virtual...${NC}"
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERROR] No se pudo activar el entorno virtual.${NC}"
    exit 1
fi
echo -e "${GREEN}[OK] Entorno virtual activado.${NC}"
echo ""

echo -e "${YELLOW}[4/5] Instalando dependencias...${NC}"
echo "Este proceso puede tardar algunos minutos..."
echo ""
python -m pip install --upgrade pip --quiet
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERROR] Fallo la instalacion de dependencias.${NC}"
    echo "Verifica tu conexion a internet e intenta nuevamente."
    exit 1
fi
echo ""
echo -e "${GREEN}[OK] Dependencias instaladas correctamente.${NC}"
echo ""

echo -e "${YELLOW}[5/5] Verificando instalacion...${NC}"
python -c "import flask, sqlalchemy, pandas, openpyxl" 2>/dev/null
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERROR] La verificacion de modulos fallo.${NC}"
    exit 1
fi
echo -e "${GREEN}[OK] Todos los modulos fueron instalados correctamente.${NC}"
echo ""

# Create launch script
echo -e "${YELLOW}[EXTRA] Creando script de inicio rapido...${NC}"
cat > start.sh << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
source venv/bin/activate
python app.py
EOF
chmod +x start.sh
echo -e "${GREEN}[OK] Script 'start.sh' creado.${NC}"
echo ""

# Create database if not exists
if [ ! -f "suppliers.db" ]; then
    echo -e "${YELLOW}[SETUP] Inicializando base de datos...${NC}"
    python -c "from database import init_db; init_db(); print('Base de datos creada exitosamente.')"
    echo ""
fi

echo -e "${GREEN}========================================================${NC}"
echo -e "${GREEN}  INSTALACION COMPLETADA EXITOSAMENTE!${NC}"
echo -e "${GREEN}========================================================${NC}"
echo ""
echo -e "${CYAN}El sistema esta listo para usar.${NC}"
echo ""
echo "Para iniciar la aplicacion:"
echo "  1. Ejecuta './start.sh' en esta carpeta, o"
echo "  2. Ejecuta manualmente:"
echo "     source venv/bin/activate"
echo "     python app.py"
echo ""
echo -e "Luego abre tu navegador en: ${YELLOW}http://localhost:5000${NC}"
echo ""
echo "Documentacion completa: README.md"
echo ""

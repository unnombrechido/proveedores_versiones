# Guía de Distribución - Sistema de Proveedores v0.1

## 📦 Paquetes de Distribución

### Opción 1: ZIP Completo (Recomendado para distribución general)

**Archivo:** `proveedores-v0.1.zip`

**Contenido:**
```
proveedores-v0.1/
├── app.py
├── database.py
├── models.py
├── requirements.txt
├── static/
│   ├── script.js
│   ├── style.css
│   └── logo-placeholder.png
├── templates/
│   └── index.html
├── setup-complete.ps1   ← INSTALADOR PRINCIPAL (recomendado)
├── install.bat          ← Instalador básico
├── install.ps1          ← Instalador PowerShell básico
├── install.sh           ← Instalador Linux/Mac
├── README.md
├── RELEASE_NOTES.md
├── INSTALL.txt
├── QUICKSTART.md
├── VERSION
├── LICENSE
└── example_suppliers.csv
```

**Instrucciones para el usuario:**
1. Descargar `proveedores-v0.1.zip`
2. Extraer en cualquier ubicación temporal
3. **Windows:** Hacer clic derecho en `setup-complete.ps1` → "Ejecutar con PowerShell"
4. **Linux/Mac:** `chmod +x install.sh && ./install.sh`
5. Seguir el asistente de instalación

---

### Opción 2: Instalador Auto-Contenido (Avanzado)

Para crear un instalador único que descargue todo desde GitHub:

#### Paso 1: Crear Release en GitHub

1. Crear tag v0.1:
   ```bash
   git tag -a v0.1 -m "Release version 0.1"
   git push origin v0.1
   ```

2. Ir a GitHub → Releases → "Create a new release"
3. Seleccionar tag v0.1
4. Subir `proveedores-v0.1.zip` como asset
5. Publicar el release

#### Paso 2: Actualizar URL en setup-complete.ps1

Editar línea 10:
```powershell
$GITHUB_RELEASE_URL = "https://github.com/TU_USUARIO/proveedores/releases/download/v0.1/proveedores-v0.1.zip"
```

#### Paso 3: Distribuir solo setup-complete.ps1

Ahora puedes distribuir solo el archivo `setup-complete.ps1` que:
- Descarga automáticamente el ZIP desde GitHub
- Configura la instalación
- Personaliza con nombre de empresa y logo
- Instala todo automáticamente

---

## 🔧 Proceso de Instalación

### Instalador Completo (setup-complete.ps1)

**Flujo del instalador:**

1. **Verificación de requisitos**
   - Comprueba Python 3.8+
   - Verifica versión

2. **Configuración interactiva**
   - Pregunta ubicación de instalación (default: `C:\Users\Usuario\SistemaProveedores`)
   - Pregunta nombre de empresa (opcional)
   - Pregunta ruta del logo (opcional)

3. **Confirmación**
   - Muestra resumen de configuración
   - Solicita confirmación

4. **Instalación**
   - Crea directorio de instalación
   - Copia/descarga archivos
   - Crea archivo `config.ini` con configuración
   - Copia logo personalizado (si se proporcionó)
   - Crea entorno virtual Python
   - Instala dependencias
   - Inicializa base de datos
   - Crea `start.bat`
   - Opcionalmente crea acceso directo en escritorio

5. **Finalización**
   - Muestra instrucciones de uso
   - Sistema listo para usar

### Archivo config.ini

El instalador crea `config.ini` con:
```ini
COMPANY_NAME=Mi Empresa SA
LOGO_PATH=C:\MiEmpresa\logo.png
INSTALL_DIR=C:\Users\Usuario\SistemaProveedores
VERSION=0.1
INSTALL_DATE=2026-02-03 21:30:00
```

Este archivo es leído por:
- `start.bat` - Muestra nombre de empresa al iniciar
- `install.bat` - Aplica configuración personalizada
- `app.py` - (próxima actualización) Mostrará nombre de empresa en la interfaz

---

## 📋 Checklist para Preparar Distribución

### Antes de Crear el ZIP

- [ ] Verificar que todas las funciones están operativas
- [ ] Ejecutar `install.bat` en máquina limpia para probar
- [ ] Verificar que `example_suppliers.csv` tiene datos válidos
- [ ] Actualizar VERSION a 0.1
- [ ] Revisar README.md
- [ ] Revisar RELEASE_NOTES.md
- [ ] Verificar que no hay archivos de desarrollo (`.pyc`, `__pycache__`, `venv/`, `suppliers.db`)

### Archivos que NO deben incluirse en el ZIP

```
# No incluir:
venv/
__pycache__/
*.pyc
*.pyo
.env
suppliers.db
*.db
.git/
.gitignore
.vscode/
.idea/
```

### Crear el ZIP

**Windows PowerShell:**
```powershell
# Desde el directorio del proyecto
$exclude = @('venv', '__pycache__', '*.pyc', '*.db', '.git', '.env')
Compress-Archive -Path * -DestinationPath ..\proveedores-v0.1.zip -Force
```

**Linux/Mac:**
```bash
# Desde el directorio padre
zip -r proveedores-v0.1.zip proveedores/ \
    -x "proveedores/venv/*" \
    -x "proveedores/__pycache__/*" \
    -x "proveedores/*.pyc" \
    -x "proveedores/*.db" \
    -x "proveedores/.git/*" \
    -x "proveedores/.env"
```

---

## 🌐 Distribución

### Opción A: GitHub Releases (Recomendado)

1. Subir código a GitHub
2. Crear release v0.1
3. Adjuntar `proveedores-v0.1.zip`
4. Los usuarios descargan desde: `https://github.com/TU_USUARIO/proveedores/releases/latest`

### Opción B: Servidor Web Propio

1. Subir ZIP a tu servidor
2. Proporcionar link de descarga
3. Actualizar URL en `setup-complete.ps1`

### Opción C: Distribución Directa

1. Enviar ZIP por email/USB
2. Usuario extrae y ejecuta `setup-complete.ps1`

---

## 📝 Instrucciones para el Usuario Final

### README_USUARIO.txt (crear este archivo)

```
================================================================
  SISTEMA DE GESTION DE PROVEEDORES v0.1
  Instrucciones de Instalación
================================================================

INSTALACION RAPIDA (Windows):
------------------------------
1. Extraer este ZIP en cualquier ubicación
2. Hacer clic derecho en "setup-complete.ps1"
3. Seleccionar "Ejecutar con PowerShell"
4. Seguir el asistente de instalación
5. El sistema se instalará automáticamente

Si PowerShell da error de permisos:
1. Abrir PowerShell como Administrador
2. Ejecutar: Set-ExecutionPolicy RemoteSigned
3. Cerrar PowerShell e intentar de nuevo

INSTALACION RAPIDA (Linux/Mac):
--------------------------------
1. Extraer este ZIP
2. Abrir terminal en la carpeta
3. Ejecutar: chmod +x install.sh && ./install.sh
4. Seguir las instrucciones

REQUISITOS:
-----------
- Python 3.8 o superior
- 50 MB de espacio en disco
- Conexión a internet (para descargar dependencias)

PERSONALIZACION:
----------------
Durante la instalación se te pedirá:
- Ubicación donde instalar el sistema
- Nombre de tu empresa (aparecerá en la interfaz)
- Ruta a tu logo (opcional)

INICIAR EL SISTEMA:
-------------------
Después de instalar:
1. Ve a la ubicación de instalación
2. Ejecuta "start.bat" (Windows) o "./start.sh" (Linux/Mac)
3. Abre tu navegador en: http://localhost:5000

SOPORTE:
--------
- Documentación: README.md
- Email: support@example.com
- GitHub: https://github.com/TU_USUARIO/proveedores

================================================================
```

---

## 🔄 Proceso de Actualización (para futuras versiones)

### v0.1 → v0.2

1. Crear nuevo instalador que:
   - Detecte instalación existente
   - Haga backup de `suppliers.db`
   - Preserve `config.ini`
   - Actualice solo los archivos de código
   - Ejecute migraciones de BD si es necesario

2. Script de actualización: `update.bat` / `update.sh`

---

## 📊 Métricas de Distribución

Considerar trackear:
- Número de descargas
- Versión de Python más usada
- Sistema operativo más común
- Errores de instalación comunes

---

## ✅ Testing Pre-Release

### En Windows 10/11 limpio:
- [ ] Instalar Python fresh
- [ ] Descargar ZIP
- [ ] Ejecutar setup-complete.ps1
- [ ] Verificar instalación completa
- [ ] Probar start.bat
- [ ] Verificar acceso http://localhost:5000
- [ ] Probar personalización (empresa + logo)

### En Linux Ubuntu:
- [ ] Instalar Python3
- [ ] Descargar ZIP
- [ ] Ejecutar install.sh
- [ ] Verificar instalación
- [ ] Probar ./start.sh

### En macOS:
- [ ] Verificar Python3 instalado
- [ ] Descargar ZIP
- [ ] Ejecutar install.sh
- [ ] Verificar instalación

---

**Última actualización:** Febrero 2026  
**Versión del documento:** 1.0

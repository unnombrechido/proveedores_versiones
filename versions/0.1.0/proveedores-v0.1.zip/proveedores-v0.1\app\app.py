from flask import Flask, jsonify, request, send_file, render_template
from flask_cors import CORS
import os
import pandas as pd
from datetime import datetime
from io import BytesIO
from database import init_db, SessionLocal, get_database_url
from models import Supplier, Order, Item, supplier_items
from sqlalchemy import select

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key')

# Initialize database
init_db()

# Routes
@app.route('/')
def index():
    """Serve the main UI"""
    return render_template('index.html')

@app.route('/api/suppliers', methods=['GET'])
def get_suppliers():
    """Get all suppliers with optional search and filter"""
    db = SessionLocal()
    try:
        query = db.query(Supplier)
        
        # Search by name, email, or category
        search = request.args.get('search', '')
        if search:
            query = query.filter(
                (Supplier.name.ilike(f'%{search}%')) |
                (Supplier.email.ilike(f'%{search}%')) |
                (Supplier.category.ilike(f'%{search}%')) |
                (Supplier.city.ilike(f'%{search}%'))
            )
        
        # Filter by category
        category = request.args.get('category', '')
        if category:
            query = query.filter(Supplier.category == category)
        
        # Filter by active status
        active = request.args.get('active', '')
        if active:
            query = query.filter(Supplier.active == int(active))
        
        # Filter by country
        country = request.args.get('country', '')
        if country:
            query = query.filter(Supplier.country == country)
        
        suppliers = query.all()
        return jsonify([s.to_dict() for s in suppliers])
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>', methods=['GET'])
def get_supplier(supplier_id):
    """Get a specific supplier"""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        return jsonify(supplier.to_dict())
    finally:
        db.close()

@app.route('/api/suppliers', methods=['POST'])
def create_supplier():
    """Create a new supplier"""
    db = SessionLocal()
    try:
        data = request.json
        supplier = Supplier(
            name=data.get('name'),
            contact_person=data.get('contact_person'),
            email=data.get('email'),
            phone=data.get('phone'),
            address=data.get('address'),
            city=data.get('city'),
            country=data.get('country'),
            tax_id=data.get('tax_id'),
            category=data.get('category'),
            rating=data.get('rating', 0.0),
            payment_terms=data.get('payment_terms'),
            notes=data.get('notes'),
            active=data.get('active', 1)
        )
        db.add(supplier)
        db.commit()
        db.refresh(supplier)
        return jsonify(supplier.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>', methods=['PUT'])
def update_supplier(supplier_id):
    """Update a supplier"""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        data = request.json
        for key, value in data.items():
            if hasattr(supplier, key):
                setattr(supplier, key, value)
        
        supplier.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(supplier)
        return jsonify(supplier.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>', methods=['DELETE'])
def delete_supplier(supplier_id):
    """Delete a supplier"""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        db.delete(supplier)
        db.commit()
        return jsonify({'message': 'Supplier deleted successfully'})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/categories', methods=['GET'])
def get_categories():
    """Get all unique categories"""
    db = SessionLocal()
    try:
        categories = db.query(Supplier.category).distinct().all()
        return jsonify([c[0] for c in categories if c[0]])
    finally:
        db.close()

@app.route('/api/suppliers/countries', methods=['GET'])
def get_countries():
    """Get all unique countries"""
    db = SessionLocal()
    try:
        countries = db.query(Supplier.country).distinct().all()
        return jsonify([c[0] for c in countries if c[0]])
    finally:
        db.close()

@app.route('/api/suppliers/import/csv', methods=['POST'])
def import_csv():
    """Import suppliers from CSV file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    db = SessionLocal()
    try:
        df = pd.read_csv(file)
        count = 0
        errors = []
        
        for index, row in df.iterrows():
            try:
                name = row.get('name')
                if pd.isna(name) or not str(name).strip():
                    continue
                
                supplier = Supplier(
                    name=str(name).strip(),
                    contact_person=str(row.get('contact_person')).strip() if pd.notna(row.get('contact_person')) else None,
                    email=str(row.get('email')).strip() if pd.notna(row.get('email')) else None,
                    phone=str(row.get('phone')).strip() if pd.notna(row.get('phone')) else None,
                    address=str(row.get('address')).strip() if pd.notna(row.get('address')) else None,
                    city=str(row.get('city')).strip() if pd.notna(row.get('city')) else None,
                    country=str(row.get('country')).strip() if pd.notna(row.get('country')) else None,
                    tax_id=str(row.get('tax_id')).strip() if pd.notna(row.get('tax_id')) else None,
                    category=str(row.get('category')).strip() if pd.notna(row.get('category')) else None,
                    rating=float(row.get('rating', 0.0)) if pd.notna(row.get('rating')) else 0.0,
                    payment_terms=str(row.get('payment_terms')).strip() if pd.notna(row.get('payment_terms')) else None,
                    notes=str(row.get('notes')).strip() if pd.notna(row.get('notes')) else None,
                    active=int(row.get('active', 1))
                )
                db.add(supplier)
                count += 1
            except Exception as e:
                errors.append(f'Row {index + 2}: {str(e)}')
        
        db.commit()
        result = {'message': f'{count} suppliers imported successfully', 'count': count}
        if errors:
            result['errors'] = errors
        return jsonify(result)
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/import/excel', methods=['POST'])
def import_excel():
    """Import suppliers from Excel file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    db = SessionLocal()
    try:
        df = pd.read_excel(file)
        count = 0
        errors = []
        
        for index, row in df.iterrows():
            try:
                name = row.get('name')
                if pd.isna(name) or not str(name).strip():
                    continue
                
                supplier = Supplier(
                    name=str(name).strip(),
                    contact_person=str(row.get('contact_person')).strip() if pd.notna(row.get('contact_person')) else None,
                    email=str(row.get('email')).strip() if pd.notna(row.get('email')) else None,
                    phone=str(row.get('phone')).strip() if pd.notna(row.get('phone')) else None,
                    address=str(row.get('address')).strip() if pd.notna(row.get('address')) else None,
                    city=str(row.get('city')).strip() if pd.notna(row.get('city')) else None,
                    country=str(row.get('country')).strip() if pd.notna(row.get('country')) else None,
                    tax_id=str(row.get('tax_id')).strip() if pd.notna(row.get('tax_id')) else None,
                    category=str(row.get('category')).strip() if pd.notna(row.get('category')) else None,
                    rating=float(row.get('rating', 0.0)) if pd.notna(row.get('rating')) else 0.0,
                    payment_terms=str(row.get('payment_terms')).strip() if pd.notna(row.get('payment_terms')) else None,
                    notes=str(row.get('notes')).strip() if pd.notna(row.get('notes')) else None,
                    active=int(row.get('active', 1))
                )
                db.add(supplier)
                count += 1
            except Exception as e:
                errors.append(f'Row {index + 2}: {str(e)}')
        
        db.commit()
        result = {'message': f'{count} suppliers imported successfully', 'count': count}
        if errors:
            result['errors'] = errors
        return jsonify(result)
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/suppliers/export/csv', methods=['GET'])
def export_csv():
    """Export suppliers to CSV file"""
    db = SessionLocal()
    try:
        suppliers = db.query(Supplier).all()
        data = [s.to_dict() for s in suppliers]
        df = pd.DataFrame(data)
        
        output = BytesIO()
        df.to_csv(output, index=False)
        output.seek(0)
        
        return send_file(
            output,
            mimetype='text/csv',
            as_attachment=True,
            download_name=f'suppliers_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        )
    finally:
        db.close()

@app.route('/api/suppliers/export/excel', methods=['GET'])
def export_excel():
    """Export suppliers to Excel file"""
    db = SessionLocal()
    try:
        suppliers = db.query(Supplier).all()
        data = [s.to_dict() for s in suppliers]
        df = pd.DataFrame(data)
        
        output = BytesIO()
        df.to_excel(output, index=False, engine='openpyxl')
        output.seek(0)
        
        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=f'suppliers_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        )
    finally:
        db.close()

@app.route('/api/orders', methods=['GET'])
def get_orders():
    """Get all orders with optional filters"""
    db = SessionLocal()
    try:
        query = db.query(Order)
        
        # Filter by status
        status = request.args.get('status', '')
        if status:
            query = query.filter(Order.status == status)
        
        # Filter by supplier
        supplier_id = request.args.get('supplier_id', '')
        if supplier_id:
            query = query.filter(Order.supplier_id == int(supplier_id))
        
        orders = query.all()
        return jsonify([o.to_dict() for o in orders])
    finally:
        db.close()

@app.route('/api/orders', methods=['POST'])
def create_order():
    """Create a new order"""
    db = SessionLocal()
    try:
        data = request.json
        
        # Get supplier name
        supplier = db.query(Supplier).filter(Supplier.id == data.get('supplier_id')).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        # Generate order number
        last_order = db.query(Order).order_by(Order.id.desc()).first()
        order_number = f"ORD-{(last_order.id + 1 if last_order else 1):06d}"
        
        order = Order(
            order_number=order_number,
            supplier_id=data.get('supplier_id'),
            supplier_name=supplier.name,
            delivery_date=datetime.fromisoformat(data.get('delivery_date')) if data.get('delivery_date') else None,
            status=data.get('status', 'pending'),
            total_amount=data.get('total_amount', 0.0),
            items=data.get('items', ''),
            notes=data.get('notes', '')
        )
        db.add(order)
        db.commit()
        db.refresh(order)
        return jsonify(order.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

@app.route('/api/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    """Get a single order by ID"""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        return jsonify(order.to_dict())
    finally:
        db.close()

@app.route('/api/orders/<int:order_id>/status', methods=['PUT'])
def update_order_status(order_id):
    """Update order status"""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        
        data = request.json
        new_status = data.get('status')
        
        valid_statuses = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled']
        if new_status not in valid_statuses:
            return jsonify({'error': f'Invalid status. Must be one of: {", ".join(valid_statuses)}'}), 400
        
        order.status = new_status
        db.commit()
        
        return jsonify(order.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

# Item routes
@app.route('/api/items/search', methods=['GET'])
def search_items():
    """Search items by name or code and get suppliers that sell them"""
    db = SessionLocal()
    try:
        search = request.args.get('search', '')
        if not search:
            return jsonify({'error': 'Search parameter required'}), 400
        
        # Search for items
        items = db.query(Item).filter(
            (Item.name.ilike(f'%{search}%')) |
            (Item.item_code.ilike(f'%{search}%'))
        ).all()
        
        results = []
        for item in items:
            # Get suppliers for this item with their prices
            stmt = select(supplier_items).where(supplier_items.c.item_id == item.id)
            supplier_item_data = db.execute(stmt).fetchall()
            
            suppliers_info = []
            for si in supplier_item_data:
                supplier = db.query(Supplier).filter(Supplier.id == si.supplier_id).first()
                if supplier:
                    suppliers_info.append({
                        'supplier_id': supplier.id,
                        'supplier_name': supplier.name,
                        'email': supplier.email,
                        'phone': supplier.phone,
                        'price': si.price,
                        'supplier_item_code': si.supplier_item_code,
                        'lead_time_days': si.lead_time_days,
                        'minimum_order_quantity': si.minimum_order_quantity,
                        'notes': si.notes
                    })
            
            results.append({
                'item': item.to_dict(),
                'suppliers': suppliers_info
            })
        
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items', methods=['GET'])
def get_items():
    """Get all items"""
    db = SessionLocal()
    try:
        items = db.query(Item).all()
        return jsonify([item.to_dict() for item in items])
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items', methods=['POST'])
def create_item():
    """Create a new item"""
    db = SessionLocal()
    try:
        data = request.json
        
        # Validate required fields
        if not data.get('item_code') or not data.get('name'):
            return jsonify({'error': 'item_code and name are required'}), 400
        
        # Check if item code already exists
        existing = db.query(Item).filter(Item.item_code == data['item_code']).first()
        if existing:
            return jsonify({'error': 'Item code already exists'}), 400
        
        # Create new item
        new_item = Item(
            item_code=data['item_code'],
            name=data['name'],
            description=data.get('description', ''),
            category=data.get('category', ''),
            unit=data.get('unit', '')
        )
        
        db.add(new_item)
        db.commit()
        db.refresh(new_item)
        
        return jsonify(new_item.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items/<int:item_id>', methods=['GET'])
def get_item(item_id):
    """Get a specific item"""
    db = SessionLocal()
    try:
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404
        return jsonify(item.to_dict(include_suppliers=True))
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items/<int:item_id>', methods=['PUT'])
def update_item(item_id):
    """Update an item (non-key fields only)"""
    db = SessionLocal()
    try:
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404
        
        data = request.json
        
        # Update only non-key fields
        if 'name' in data:
            item.name = data['name']
        if 'description' in data:
            item.description = data['description']
        if 'category' in data:
            item.category = data['category']
        if 'unit' in data:
            item.unit = data['unit']
        
        item.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(item)
        
        return jsonify(item.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items/<int:item_id>/suppliers', methods=['GET', 'POST'])
def manage_item_suppliers(item_id):
    """Get all suppliers for an item (GET) or add a supplier to an item (POST)"""
    db = SessionLocal()
    try:
        # Verify item exists
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404
        
        if request.method == 'GET':
            # Get suppliers with their pricing info
            stmt = select(supplier_items).where(supplier_items.c.item_id == item_id)
            item_supplier_data = db.execute(stmt).fetchall()
            
            suppliers_info = []
            for si in item_supplier_data:
                supplier = db.query(Supplier).filter(Supplier.id == si.supplier_id).first()
                if supplier:
                    supplier_dict = supplier.to_dict()
                    supplier_dict['price'] = si.price
                    supplier_dict['supplier_item_code'] = si.supplier_item_code
                    supplier_dict['lead_time_days'] = si.lead_time_days
                    supplier_dict['minimum_order_quantity'] = si.minimum_order_quantity
                    supplier_dict['notes'] = si.notes
                    suppliers_info.append(supplier_dict)
            
            return jsonify(suppliers_info)
        
        elif request.method == 'POST':
            # Add a supplier to an item
            data = request.json
            supplier_id = data.get('supplier_id')
            
            if not supplier_id:
                return jsonify({'error': 'supplier_id is required'}), 400
            
            # Verify supplier exists
            supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
            if not supplier:
                return jsonify({'error': 'Supplier not found'}), 404
            
            # Check if relationship already exists
            stmt = select(supplier_items).where(
                (supplier_items.c.supplier_id == supplier_id) &
                (supplier_items.c.item_id == item_id)
            )
            existing = db.execute(stmt).fetchone()
            
            if existing:
                return jsonify({'error': 'This supplier is already associated with this item'}), 400
            
            # Insert new supplier-item relationship
            ins = supplier_items.insert().values(
                supplier_id=supplier_id,
                item_id=item_id,
                price=data.get('price'),
                supplier_item_code=data.get('supplier_item_code', ''),
                lead_time_days=data.get('lead_time_days'),
                minimum_order_quantity=data.get('minimum_order_quantity'),
                notes=data.get('notes', '')
            )
            db.execute(ins)
            db.commit()
            
            return jsonify({'message': 'Supplier added to item successfully'}), 201
            
    except Exception as e:
        if request.method == 'POST':
            db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items/<int:item_id>/suppliers/<int:supplier_id>', methods=['PUT', 'DELETE'])
def manage_item_supplier_relationship(item_id, supplier_id):
    """Update (PUT) or delete (DELETE) a supplier-item relationship"""
    db = SessionLocal()
    try:
        # Verify item exists
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404
        
        # Verify supplier exists
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        # Check if relationship exists
        stmt = select(supplier_items).where(
            (supplier_items.c.supplier_id == supplier_id) &
            (supplier_items.c.item_id == item_id)
        )
        existing = db.execute(stmt).fetchone()
        
        if not existing:
            return jsonify({'error': 'Relationship not found'}), 404
        
        if request.method == 'PUT':
            # Update the relationship
            data = request.json
            
            upd = supplier_items.update().where(
                (supplier_items.c.supplier_id == supplier_id) &
                (supplier_items.c.item_id == item_id)
            ).values(
                price=data.get('price'),
                supplier_item_code=data.get('supplier_item_code', ''),
                lead_time_days=data.get('lead_time_days'),
                minimum_order_quantity=data.get('minimum_order_quantity'),
                notes=data.get('notes', '')
            )
            db.execute(upd)
            db.commit()
            
            return jsonify({'message': 'Supplier relationship updated successfully'}), 200
        
        elif request.method == 'DELETE':
            # Delete the relationship
            dlt = supplier_items.delete().where(
                (supplier_items.c.supplier_id == supplier_id) &
                (supplier_items.c.item_id == item_id)
            )
            db.execute(dlt)
            db.commit()
            
            return jsonify({'message': 'Supplier relationship deleted successfully'}), 200
            
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/suppliers/<int:supplier_id>/items', methods=['GET'])
def get_supplier_items(supplier_id):
    """Get all items sold by a specific supplier"""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        
        # Get items with their pricing info
        stmt = select(supplier_items).where(supplier_items.c.supplier_id == supplier_id)
        supplier_item_data = db.execute(stmt).fetchall()
        
        items_info = []
        for si in supplier_item_data:
            item = db.query(Item).filter(Item.id == si.item_id).first()
            if item:
                item_dict = item.to_dict()
                item_dict['price'] = si.price
                item_dict['supplier_item_code'] = si.supplier_item_code
                item_dict['lead_time_days'] = si.lead_time_days
                item_dict['minimum_order_quantity'] = si.minimum_order_quantity
                item_dict['notes'] = si.notes
                items_info.append(item_dict)
        
        return jsonify({
            'supplier': supplier.to_dict(),
            'items': items_info
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/items/common-suppliers', methods=['POST'])
def get_common_suppliers():
    """Find suppliers that sell all specified items or group items by available suppliers"""
    db = SessionLocal()
    try:
        data = request.json
        item_ids = data.get('item_ids', [])
        
        if not item_ids:
            return jsonify({'error': 'No item IDs provided'}), 400
        
        # Get all suppliers for each item
        items_suppliers = {}
        for item_id in item_ids:
            stmt = select(supplier_items).where(supplier_items.c.item_id == item_id)
            supplier_data = db.execute(stmt).fetchall()
            items_suppliers[item_id] = [
                {
                    'supplier_id': sd.supplier_id,
                    'item_id': sd.item_id,
                    'price': sd.price,
                    'supplier_item_code': sd.supplier_item_code,
                    'lead_time_days': sd.lead_time_days
                }
                for sd in supplier_data
            ]
        
        # Find common suppliers (suppliers that have ALL items)
        if len(item_ids) == 1:
            # Single item - return all suppliers
            common_supplier_ids = set(s['supplier_id'] for s in items_suppliers[item_ids[0]])
        else:
            # Multiple items - find intersection
            supplier_sets = [
                set(s['supplier_id'] for s in items_suppliers[item_id])
                for item_id in item_ids
            ]
            common_supplier_ids = set.intersection(*supplier_sets) if supplier_sets else set()
        
        common_suppliers = []
        if common_supplier_ids:
            # Build details for common suppliers
            for supplier_id in common_supplier_ids:
                supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
                if not supplier:
                    continue
                
                supplier_items_list = []
                total_cost = 0
                
                for item_id in item_ids:
                    # Find this supplier's data for this item
                    item_data = next(
                        (s for s in items_suppliers[item_id] if s['supplier_id'] == supplier_id),
                        None
                    )
                    if item_data:
                        supplier_items_list.append({
                            'item_id': item_id,
                            'price': item_data['price'],
                            'supplier_item_code': item_data['supplier_item_code']
                        })
                        if item_data['price']:
                            total_cost += item_data['price']
                
                common_suppliers.append({
                    'supplier_id': supplier_id,
                    'supplier_name': supplier.name,
                    'email': supplier.email,
                    'phone': supplier.phone,
                    'items': supplier_items_list,
                    'total_cost': total_cost
                })
        
        # If no common suppliers, group items by best available suppliers
        supplier_groups = []
        if not common_supplier_ids:
            # For each item, find cheapest supplier
            used_suppliers = {}  # supplier_id -> [items]
            
            for item_id in item_ids:
                item = db.query(Item).filter(Item.id == item_id).first()
                suppliers_for_item = items_suppliers.get(item_id, [])
                
                if not suppliers_for_item:
                    continue
                
                # Find cheapest supplier for this item
                cheapest = min(
                    suppliers_for_item,
                    key=lambda x: x['price'] if x['price'] else float('inf')
                )
                
                supplier_id = cheapest['supplier_id']
                if supplier_id not in used_suppliers:
                    used_suppliers[supplier_id] = []
                
                used_suppliers[supplier_id].append({
                    'item_id': item_id,
                    'item_name': item.name if item else 'Unknown',
                    'price': cheapest['price'],
                    'supplier_item_code': cheapest['supplier_item_code']
                })
            
            # Build groups
            for supplier_id, items_list in used_suppliers.items():
                supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
                if not supplier:
                    continue
                
                total = sum(item['price'] for item in items_list if item['price'])
                
                supplier_groups.append({
                    'supplier_id': supplier_id,
                    'supplier_name': supplier.name,
                    'items': items_list,
                    'total_cost': total
                })
        
        return jsonify({
            'common_suppliers': common_suppliers,
            'supplier_groups': supplier_groups,
            'has_common_supplier': len(common_supplier_ids) > 0
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/suppliers/import/items-excel', methods=['POST'])
def import_suppliers_with_items():
    """Import suppliers and their items from Excel file"""
    db = SessionLocal()
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Read Excel file
        df = pd.read_excel(file)
        
        # Expected columns: supplier_name, item_code, item_name, item_description, item_category, unit, price, supplier_item_code, lead_time_days, minimum_order_quantity, notes
        required_columns = ['supplier_name', 'item_code', 'item_name']
        if not all(col in df.columns for col in required_columns):
            return jsonify({'error': f'Excel must contain columns: {", ".join(required_columns)}'}), 400
        
        imported_count = 0
        errors = []
        
        for index, row in df.iterrows():
            try:
                # Get or create supplier
                supplier = db.query(Supplier).filter(Supplier.name == row['supplier_name']).first()
                if not supplier:
                    supplier = Supplier(
                        name=row['supplier_name'],
                        email=row.get('supplier_email'),
                        phone=row.get('supplier_phone'),
                        address=row.get('supplier_address'),
                        city=row.get('supplier_city'),
                        country=row.get('supplier_country'),
                        tax_id=row.get('supplier_tax_id')
                    )
                    db.add(supplier)
                    db.flush()  # Get the supplier ID
                
                # Get or create item
                item = db.query(Item).filter(Item.item_code == row['item_code']).first()
                if not item:
                    item = Item(
                        item_code=row['item_code'],
                        name=row['item_name'],
                        description=row.get('item_description'),
                        category=row.get('item_category'),
                        unit=row.get('unit')
                    )
                    db.add(item)
                    db.flush()  # Get the item ID
                
                # Check if relationship already exists
                stmt = select(supplier_items).where(
                    (supplier_items.c.supplier_id == supplier.id) &
                    (supplier_items.c.item_id == item.id)
                )
                existing = db.execute(stmt).first()
                
                if not existing:
                    # Create supplier-item relationship
                    ins = supplier_items.insert().values(
                        supplier_id=supplier.id,
                        item_id=item.id,
                        price=float(row['price']) if pd.notna(row.get('price')) else None,
                        supplier_item_code=row.get('supplier_item_code'),
                        lead_time_days=int(row['lead_time_days']) if pd.notna(row.get('lead_time_days')) else None,
                        minimum_order_quantity=int(row['minimum_order_quantity']) if pd.notna(row.get('minimum_order_quantity')) else None,
                        notes=row.get('notes')
                    )
                    db.execute(ins)
                
                imported_count += 1
            except Exception as e:
                errors.append(f'Row {index + 2}: {str(e)}')
        
        db.commit()
        
        return jsonify({
            'message': f'Successfully imported {imported_count} supplier-item relationships',
            'errors': errors if errors else None
        })
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/suppliers/import/custom-excel', methods=['POST'])
def import_custom_excel():
    """Import suppliers and items from custom Excel format with multiple sheets
    Expected sheets:
    - Materials sheet (e.g., Hoja4): No., item/Material, Proveedor, Costo
    - Suppliers sheet (e.g., Hoja2): Proveedor, Tipo de proveedor, Telefonos, Correo, Direccion
    """
    db = SessionLocal()
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Get sheet names from request or use defaults
        materials_sheet = request.form.get('materials_sheet', 'Hoja4')
        suppliers_sheet = request.form.get('suppliers_sheet', 'Hoja2')
        
        # Read Excel file with multiple sheets
        excel_file = pd.ExcelFile(file)
        
        # Check which sheets exist
        available_sheets = excel_file.sheet_names
        
        # Find materials sheet (try specified name first, then look for keywords)
        mat_sheet = None
        if materials_sheet in available_sheets:
            mat_sheet = materials_sheet
        else:
            for sheet in available_sheets:
                if 'hoja' in sheet.lower() or 'material' in sheet.lower() or 'item' in sheet.lower():
                    mat_sheet = sheet
                    break
        
        if not mat_sheet:
            return jsonify({'error': f'Materials sheet not found. Available sheets: {", ".join(available_sheets)}'}), 400
        
        # Find suppliers sheet (optional)
        sup_sheet = None
        if suppliers_sheet in available_sheets:
            sup_sheet = suppliers_sheet
        else:
            for sheet in available_sheets:
                if 'proveedor' in sheet.lower() and 'hoja' in sheet.lower():
                    sup_sheet = sheet
                    break
        
        imported_suppliers = 0
        imported_items = 0
        errors = []
        
        # Import suppliers first if sheet exists
        if sup_sheet:
            try:
                df_suppliers = pd.read_excel(excel_file, sheet_name=sup_sheet)
                
                for index, row in df_suppliers.iterrows():
                    try:
                        supplier_name = row.get('Proveedor')
                        
                        # Skip rows with missing or empty supplier name
                        if supplier_name is None or pd.isna(supplier_name) or str(supplier_name).strip() == '':
                            continue
                        
                        supplier_name = str(supplier_name).strip()
                        
                        # Check if supplier already exists
                        existing = db.query(Supplier).filter(Supplier.name == supplier_name).first()
                        if not existing:
                            supplier = Supplier(
                                name=supplier_name,
                                category=str(row.get('Tipo de proveedor')).strip() if pd.notna(row.get('Tipo de proveedor')) else None,
                                phone=str(row.get('Telefonos')).strip() if pd.notna(row.get('Telefonos')) else None,
                                email=str(row.get('Correo')).strip() if pd.notna(row.get('Correo')) else None,
                                address=str(row.get('Direccion')).strip() if pd.notna(row.get('Direccion')) else None,
                                notes=str(row.get('Relacion Comercial')).strip() if pd.notna(row.get('Relacion Comercial')) else None,
                                active=1
                            )
                            db.add(supplier)
                            imported_suppliers += 1
                    except Exception as e:
                        errors.append(f'Supplier row {index + 2}: {str(e)}')
                
                db.commit()
            except Exception as e:
                errors.append(f'Error reading suppliers sheet: {str(e)}')
        
        # Import materials/items
        try:
            df_materials = pd.read_excel(excel_file, sheet_name=mat_sheet)
            
            for index, row in df_materials.iterrows():
                try:
                    # Get item details
                    item_no = row.get('No.')
                    item_name = row.get('item/Material') or row.get('Material') or row.get('Item')
                    supplier_name = row.get('Proveedor')
                    price_str = row.get('Costo')
                    
                    # Skip rows with missing required data
                    if item_name is None or pd.isna(item_name) or str(item_name).strip() == '':
                        continue
                    if supplier_name is None or pd.isna(supplier_name) or str(supplier_name).strip() == '':
                        continue
                    
                    # Clean the names
                    item_name = str(item_name).strip()
                    supplier_name = str(supplier_name).strip()
                    
                    # Clean price (remove $, commas, spaces)
                    price = None
                    if pd.notna(price_str):
                        try:
                            price_clean = str(price_str).replace('$', '').replace(',', '').replace(' ', '').strip()
                            if price_clean:
                                price = float(price_clean)
                        except:
                            pass
                    
                    # Get or create supplier
                    supplier = db.query(Supplier).filter(Supplier.name == supplier_name).first()
                    if not supplier:
                        supplier = Supplier(
                            name=supplier_name,
                            active=1
                        )
                        db.add(supplier)
                        db.flush()
                        imported_suppliers += 1
                    
                    # Create item_code from No. or generate one
                    item_code = f"ITEM-{int(item_no)}" if pd.notna(item_no) else f"ITEM-{index+1}"
                    
                    # Get or create item
                    item = db.query(Item).filter(Item.item_code == item_code).first()
                    if not item:
                        item = Item(
                            item_code=item_code,
                            name=item_name,
                            description=row.get('Descripciòn/codigo') or row.get('Descripcion'),
                            category=row.get('Categoria') or 'General',
                            unit=row.get('Unidad') or 'pza'
                        )
                        db.add(item)
                        db.flush()
                        imported_items += 1
                    
                    # Check if relationship already exists
                    stmt = select(supplier_items).where(
                        (supplier_items.c.supplier_id == supplier.id) &
                        (supplier_items.c.item_id == item.id)
                    )
                    existing = db.execute(stmt).first()
                    
                    if not existing:
                        # Create supplier-item relationship
                        ins = supplier_items.insert().values(
                            supplier_id=supplier.id,
                            item_id=item.id,
                            price=price,
                            supplier_item_code=None,
                            lead_time_days=None,
                            minimum_order_quantity=None,
                            notes=None
                        )
                        db.execute(ins)
                
                except Exception as e:
                    errors.append(f'Material row {index + 2}: {str(e)}')
            
            db.commit()
            
        except Exception as e:
            return jsonify({'error': f'Error reading materials sheet: {str(e)}'}), 400
        
        return jsonify({
            'message': f'Import complete: {imported_suppliers} suppliers, {imported_items} items',
            'suppliers_imported': imported_suppliers,
            'items_imported': imported_items,
            'sheets_used': {
                'materials': mat_sheet,
                'suppliers': sup_sheet
            },
            'available_sheets': available_sheets,
            'errors': errors if errors else None
        })
    
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/database/info', methods=['GET'])
def get_database_info():
    """Get database connection information"""
    try:
        db_url = get_database_url()
        db_type = os.getenv('DATABASE_TYPE', 'sqlite')
        return jsonify({
            'type': db_type,
            'url': db_url.split('@')[-1] if '@' in db_url else db_url
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/config', methods=['GET'])
def get_config():
    """Get configuration (company name and logo)"""
    try:
        config = {}
        config_path = 'config.ini'
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if '=' in line and not line.startswith('#'):
                        key, value = line.split('=', 1)
                        config[key.strip()] = value.strip()
        
        return jsonify({
            'companyName': config.get('COMPANY_NAME', ''),
            'logoPath': config.get('LOGO_PATH', '')
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/config', methods=['POST'])
def save_config():
    """Save configuration (company name and logo)"""
    try:
        data = request.json
        company_name = data.get('companyName', '')
        logo_path = data.get('logoPath', '')
        
        config_path = 'config.ini'
        config_content = f"""# Configuration file for Sistema de Proveedores
# Generated by the application
COMPANY_NAME={company_name}
LOGO_PATH={logo_path}
"""
        
        with open(config_path, 'w', encoding='utf-8') as f:
            f.write(config_content)
        
        return jsonify({
            'success': True,
            'message': 'Configuration saved successfully'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    app.run(host='0.0.0.0', port=port, debug=debug)

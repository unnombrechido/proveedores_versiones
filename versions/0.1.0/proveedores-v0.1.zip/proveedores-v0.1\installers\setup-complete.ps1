# ============================================================
#  Sistema de Gestión de Proveedores v0.1
#  Instalador Completo con Descarga Automática
# ============================================================

$Host.UI.RawUI.WindowTitle = "Sistema de Proveedores v0.1 - Instalador Completo"
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "White"
Clear-Host

# Configuration
$GITHUB_RELEASE_URL = "https://github.com/TU_USUARIO/proveedores/releases/download/v0.1/proveedores-v0.1.zip"
$TEMP_ZIP = "$env:TEMP\proveedores-v0.1.zip"

# Progress tracking function
function Show-OverallProgress {
    param(
        [int]$Step,
        [int]$TotalSteps,
        [string]$Description
    )
    
    $percent = [math]::Floor(($Step / $TotalSteps) * 100)
    $progressChars = [math]::Floor($percent / 2)
    $progressBar = "[" + ("█" * $progressChars) + ("·" * (50 - $progressChars)) + "]"
    
    Write-Host ""
    Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor DarkCyan
    Write-Host " PROGRESO GENERAL: $progressBar $percent%" -ForegroundColor Cyan
    Write-Host " Paso $Step de ${TotalSteps}: $Description" -ForegroundColor White
    Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor DarkCyan
    Write-Host ""
}

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# Banner
Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  SISTEMA DE GESTION DE PROVEEDORES E INVENTARIO v0.1" -ForegroundColor Cyan
Write-Host "  Instalador Completo" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

if ($isAdmin) {
    Write-Host "[INFO] Ejecutando con permisos de administrador" -ForegroundColor Green
} else {
    Write-Host "[INFO] Ejecutando como usuario normal" -ForegroundColor Gray
}
Write-Host ""

Show-OverallProgress -Step 1 -TotalSteps 8 -Description "Verificando Python"

# Check Python
Write-Host "[Verificando requisitos...]" -ForegroundColor Yellow
Write-Host ""

$pythonInstalled = $false
$pythonCmd = "python"

# Try python3 first (common on systems with both Python 2 and 3)
try {
    $pythonVersion = python3 --version 2>&1 | Out-String
    if ($pythonVersion -match "Python 3") {
        Write-Host "[OK] Python 3 detectado: $pythonVersion" -ForegroundColor Green
        $pythonCmd = "python3"
        $pythonInstalled = $true
    }
} catch {
    # python3 command not found, try python
}

# If python3 didn't work, try python
if (-not $pythonInstalled) {
    try {
        $pythonVersion = python --version 2>&1 | Out-String
        if ($pythonVersion -match "Python 3") {
            Write-Host "[OK] Python detectado: $pythonVersion" -ForegroundColor Green
            $pythonCmd = "python"
            $pythonInstalled = $true
        } elseif ($pythonVersion -match "Python 2") {
            Write-Host "[ADVERTENCIA] Se detecto Python 2.7: $pythonVersion" -ForegroundColor Yellow
            Write-Host "[INFO] Se requiere Python 3.8+, pero se encontro Python 2.x" -ForegroundColor Yellow
            Write-Host ""
            # Don't set $pythonInstalled = $true, let it try to install Python 3
        }
    } catch {
        Write-Host "[INFO] Python no esta instalado." -ForegroundColor Yellow
        Write-Host ""
    }
}

# Try to install Python automatically if not found
if (-not $pythonInstalled) {
    Write-Host "Intentando instalar Python automaticamente..." -ForegroundColor Cyan
    Write-Host ""
    
    # Check if we need admin rights
    if (-not $isAdmin) {
        Write-Host "[ADVERTENCIA] No se detectaron permisos de administrador." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Para instalar Python automaticamente, necesitas:" -ForegroundColor White
        Write-Host "1. Cerrar esta ventana" -ForegroundColor Gray
        Write-Host "2. Clic derecho en setup-complete.ps1" -ForegroundColor Gray
        Write-Host "3. Seleccionar 'Ejecutar con PowerShell como Administrador'" -ForegroundColor Gray
        Write-Host ""
        $continueAnyway = Read-Host "Continuar sin instalar Python automaticamente? (S/N)"
        
        if ($continueAnyway -ne "S" -and $continueAnyway -ne "s") {
            Write-Host ""
            Write-Host "Instalacion cancelada. Ejecuta como administrador e intenta de nuevo." -ForegroundColor Yellow
            Read-Host "Presiona Enter para salir"
            exit 1
        }
        
        # User chose to continue, skip to manual instructions
        Write-Host ""
        Write-Host "[INFO] Saltando instalacion automatica..." -ForegroundColor Yellow
        Write-Host ""
    }
    
    # Try winget first (Windows 10 1709+ / Windows 11)
    if ($isAdmin) {
        try {
            $wingetCheck = Get-Command winget -ErrorAction SilentlyContinue
            if ($wingetCheck) {
                Write-Host "[INFO] Usando winget para instalar Python 3.13.9..." -ForegroundColor Cyan
                Write-Host "[INFO] Esto puede tardar varios minutos..." -ForegroundColor Gray
                Write-Host ""
                
                # Try to install Python for all users (needs admin)
                $wingetResult = winget install Python.Python.3.13 --silent --scope machine --accept-package-agreements --accept-source-agreements 2>&1
                
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "[OK] Python instalado exitosamente" -ForegroundColor Green
                    Write-Host "[INFO] Reiniciando terminal para actualizar PATH..." -ForegroundColor Yellow
                    Write-Host ""
                    Write-Host "IMPORTANTE: Cierra esta ventana y ejecuta el instalador nuevamente." -ForegroundColor Cyan
                    Write-Host ""
                    Read-Host "Presiona Enter para cerrar"
                    exit 0
                } else {
                    Write-Host "[ADVERTENCIA] winget fallo: $wingetResult" -ForegroundColor Yellow
                    Write-Host "[INFO] Intentando instalacion para usuario actual..." -ForegroundColor Cyan
                    
                    # Try user-level install as fallback
                    $wingetResult2 = winget install Python.Python.3.13 --silent --scope user --accept-package-agreements --accept-source-agreements 2>&1
                    
                    if ($LASTEXITCODE -eq 0) {
                        Write-Host "[OK] Python instalado para usuario actual" -ForegroundColor Green
                        Write-Host "[INFO] Reiniciando terminal..." -ForegroundColor Yellow
                        Write-Host ""
                        Write-Host "IMPORTANTE: Cierra esta ventana y ejecuta el instalador nuevamente." -ForegroundColor Cyan
                        Write-Host ""
                        Read-Host "Presiona Enter para cerrar"
                        exit 0
                    }
                }
            }
        } catch {
            Write-Host "[INFO] winget no disponible o fallo: $_" -ForegroundColor Gray
        }
    }
    
    # If we get here, automatic installation failed or was skipped
    Write-Host "[INFO] Instalacion automatica no disponible." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Por favor instala Python manualmente:" -ForegroundColor White
    Write-Host ""
    Write-Host "1. Visita: https://www.python.org/downloads/" -ForegroundColor Cyan
    Write-Host "2. Descarga Python 3.13.9 (o superior)" -ForegroundColor Gray
    Write-Host "3. Durante la instalacion, marca:" -ForegroundColor Gray
    Write-Host "   [X] Add Python to PATH" -ForegroundColor Yellow
    Write-Host "4. Completa la instalacion" -ForegroundColor Gray
    Write-Host "5. Ejecuta este instalador nuevamente" -ForegroundColor Gray
    Write-Host ""
    
    $openBrowser = Read-Host "Abrir pagina de descarga ahora? (S/N)"
    if ($openBrowser -eq "S" -or $openBrowser -eq "s") {
        Start-Process "https://www.python.org/downloads/"
    }
    
    Write-Host ""
    Read-Host "Presiona Enter para salir"
    exit 1
}

# Check Python version
$versionCheck = & $pythonCmd -c "import sys; exit(0 if sys.version_info >= (3, 8) else 1)" 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Se requiere Python 3.8 o superior." -ForegroundColor Red
    Write-Host "La version instalada es muy antigua." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Por favor actualiza Python desde: https://www.python.org/downloads/" -ForegroundColor Cyan
    Write-Host ""
    Read-Host "Presiona Enter para salir"
    exit 1
}

Write-Host "[INFO] Usando comando: $pythonCmd" -ForegroundColor Cyan
Write-Host ""

Show-OverallProgress -Step 2 -TotalSteps 8 -Description "Configuracion de Instalacion"

Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  CONFIGURACION DE INSTALACION" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# Ask for installation directory
$defaultDir = "$env:USERPROFILE\SistemaProveedores"
Write-Host "Ubicacion de instalacion por defecto:" -ForegroundColor White
Write-Host "$defaultDir" -ForegroundColor Gray
Write-Host ""
$installDir = Read-Host "Presiona ENTER para usar por defecto, o escribe nueva ruta"

if ([string]::IsNullOrWhiteSpace($installDir)) {
    $installDir = $defaultDir
}

Write-Host ""
Write-Host "[INFO] Se instalara en: $installDir" -ForegroundColor Cyan
Write-Host ""

# Ask for company name
$companyName = Read-Host "Nombre de tu empresa (opcional, presiona ENTER para omitir)"
Write-Host ""

# Ask for logo path
Write-Host "Logo de la empresa (opcional):" -ForegroundColor White
Write-Host "Proporciona la ruta a tu logo (PNG/JPG/SVG)" -ForegroundColor Gray
Write-Host "Si no tienes uno, presiona ENTER para usar el logo por defecto" -ForegroundColor Gray
Write-Host ""
$logoPath = Read-Host "Ruta completa al logo (o ENTER para omitir)"
Write-Host ""

# Validate logo if provided
if (-not [string]::IsNullOrWhiteSpace($logoPath)) {
    if (-not (Test-Path $logoPath)) {
        Write-Host "[ADVERTENCIA] La ruta del logo no existe. Se usara el logo por defecto." -ForegroundColor Yellow
        $logoPath = ""
        Start-Sleep -Seconds 2
    }
}

# Show summary
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  RESUMEN DE CONFIGURACION" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Ubicacion:  " -NoNewline -ForegroundColor White
Write-Host "$installDir" -ForegroundColor Yellow

if (-not [string]::IsNullOrWhiteSpace($companyName)) {
    Write-Host "Empresa:    " -NoNewline -ForegroundColor White
    Write-Host "$companyName" -ForegroundColor Yellow
} else {
    Write-Host "Empresa:    " -NoNewline -ForegroundColor White
    Write-Host "[No especificado]" -ForegroundColor Gray
}

if (-not [string]::IsNullOrWhiteSpace($logoPath)) {
    Write-Host "Logo:       " -NoNewline -ForegroundColor White
    Write-Host "$logoPath" -ForegroundColor Yellow
} else {
    Write-Host "Logo:       " -NoNewline -ForegroundColor White
    Write-Host "[Por defecto]" -ForegroundColor Gray
}

Write-Host ""
$confirm = Read-Host "Continuar con la instalacion? (S/N)"

if ($confirm -ne "S" -and $confirm -ne "s") {
    Write-Host "Instalacion cancelada." -ForegroundColor Yellow
    Read-Host "Presiona Enter para salir"
    exit 0
}

Show-OverallProgress -Step 3 -TotalSteps 8 -Description "Preparando Instalacion"

Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  DESCARGANDO E INSTALANDO SISTEMA" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# Create installation directory
Write-Host "[3.1] Verificando directorio de instalacion..." -ForegroundColor Yellow

$isUpgrade = $false
$existingConfig = $null
$existingDB = $null

if (Test-Path $installDir) {
    # Check if this is an existing installation
    if (Test-Path "$installDir\app.py") {
        $isUpgrade = $true
        Write-Host "[INFO] Instalacion existente detectada!" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Se encontro una instalacion anterior en:" -ForegroundColor White
        Write-Host "$installDir" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Los siguientes datos se preservaran:" -ForegroundColor Green
        
        # Check for config
        if (Test-Path "$installDir\config.ini") {
            Write-Host "  [X] Configuracion (config.ini)" -ForegroundColor Green
            $existingConfig = Get-Content "$installDir\config.ini" -Raw
        } else {
            Write-Host "  [ ] Configuracion (no encontrada)" -ForegroundColor Gray
        }
        
        # Check for database
        if (Test-Path "$installDir\proveedores.db") {
            $dbSize = (Get-Item "$installDir\proveedores.db").Length
            $dbSizeKB = [math]::Round($dbSize / 1KB, 2)
            Write-Host "  [X] Base de datos (proveedores.db - $dbSizeKB KB)" -ForegroundColor Green
            $existingDB = "$installDir\proveedores.db"
        } else {
            Write-Host "  [ ] Base de datos (no encontrada)" -ForegroundColor Gray
        }
        
        Write-Host ""
        Write-Host "IMPORTANTE: Tus proveedores, productos y pedidos NO se borraran." -ForegroundColor Cyan
        Write-Host ""
        $continueUpgrade = Read-Host "Continuar con la actualizacion? (S/N)"
        
        if ($continueUpgrade -ne "S" -and $continueUpgrade -ne "s") {
            Write-Host "Actualizacion cancelada." -ForegroundColor Yellow
            Read-Host "Presiona Enter para salir"
            exit 0
        }
        
        # Backup existing data
        Write-Host ""
        Write-Host "[INFO] Creando respaldo de seguridad..." -ForegroundColor Yellow
        $backupDir = "$installDir\backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        
        if ($existingConfig) {
            Copy-Item "$installDir\config.ini" "$backupDir\config.ini" -Force
        }
        if ($existingDB) {
            Copy-Item "$installDir\proveedores.db" "$backupDir\proveedores.db" -Force
        }
        
        Write-Host "[OK] Respaldo creado en: $backupDir" -ForegroundColor Green
        Write-Host ""
    } else {
        Write-Host "[OK] Directorio ya existe (vacio)" -ForegroundColor Green
    }
} else {
    try {
        New-Item -ItemType Directory -Path $installDir -Force | Out-Null
        Write-Host "[OK] Directorio creado: $installDir" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] No se pudo crear el directorio." -ForegroundColor Red
        Write-Host "Verifica que tienes permisos o elige otra ubicacion." -ForegroundColor Yellow
        Read-Host "Presiona Enter para salir"
        exit 1
    }
}
Write-Host ""

# Check if files are in current directory (manual installation)
$currentDir = Get-Location
$parentDir = Split-Path -Parent $currentDir

# Check if we're in the installers folder or root
$appDir = if (Test-Path "$parentDir\app\app.py") { "$parentDir\app" } elseif (Test-Path "$currentDir\app\app.py") { "$currentDir\app" } else { $null }

if ($appDir) {
    Write-Host "[INFO] Archivos detectados en: $appDir" -ForegroundColor Cyan
    
    Show-OverallProgress -Step 4 -TotalSteps 8 -Description "Copiando Archivos del Sistema"
    
    Write-Host "[3.2] Copiando archivos al directorio de instalacion..." -ForegroundColor Yellow
    
    # Copy app files
    Copy-Item -Path "$appDir\*" -Destination $installDir -Recurse -Force
    
    # Copy root files (requirements.txt, VERSION, LICENSE)
    $rootDir = if (Test-Path "$parentDir\requirements.txt") { $parentDir } else { $currentDir }
    if (Test-Path "$rootDir\requirements.txt") {
        Copy-Item -Path "$rootDir\requirements.txt" -Destination $installDir -Force
    }
    if (Test-Path "$rootDir\VERSION") {
        Copy-Item -Path "$rootDir\VERSION" -Destination $installDir -Force
    }
    if (Test-Path "$rootDir\LICENSE") {
        Copy-Item -Path "$rootDir\LICENSE" -Destination $installDir -Force
    }
    
    Write-Host "[OK] Archivos copiados" -ForegroundColor Green
    Write-Host ""
} else {
    # Try to download from GitHub
    Write-Host "[2/6] Descargando desde GitHub..." -ForegroundColor Yellow
    Write-Host "[INFO] URL: $GITHUB_RELEASE_URL" -ForegroundColor Gray
    Write-Host ""
    Write-Host "[NOTA] Si la descarga falla, copia manualmente los archivos a:" -ForegroundColor Yellow
    Write-Host "$installDir" -ForegroundColor Gray
    Write-Host ""
    
    try {
        # Download (this will fail if URL doesn't exist yet)
        # Invoke-WebRequest -Uri $GITHUB_RELEASE_URL -OutFile $TEMP_ZIP
        # Expand-Archive -Path $TEMP_ZIP -DestinationPath $installDir -Force
        # Remove-Item $TEMP_ZIP -Force
        
        Write-Host "[ERROR] La descarga automatica aun no esta configurada." -ForegroundColor Red
        Write-Host ""
        Write-Host "Por favor copia manualmente estos archivos a: $installDir" -ForegroundColor Yellow
        Write-Host "  - app.py, database.py, models.py" -ForegroundColor Gray
        Write-Host "  - requirements.txt" -ForegroundColor Gray
        Write-Host "  - static/ (carpeta completa)" -ForegroundColor Gray
        Write-Host "  - templates/ (carpeta completa)" -ForegroundColor Gray
        Write-Host "  - Todos los archivos .bat, .md" -ForegroundColor Gray
        Write-Host ""
        Write-Host "Luego ejecuta este instalador nuevamente." -ForegroundColor Cyan
        Write-Host ""
        Read-Host "Presiona Enter para salir"
        exit 1
    } catch {
        Write-Host "[ERROR] No se pudo descargar: $_" -ForegroundColor Red
        Read-Host "Presiona Enter para salir"
        exit 1
    }
}

# Change to installation directory
Set-Location $installDir

Show-OverallProgress -Step 5 -TotalSteps 8 -Description "Configurando Personalizacion"

# Create or restore config file
Write-Host "[5.1] Configurando sistema..." -ForegroundColor Yellow

if ($isUpgrade -and $existingConfig) {
    # Restore existing config (preserve user settings)
    Write-Host "[INFO] Restaurando configuracion existente..." -ForegroundColor Cyan
    $existingConfig | Out-File -FilePath "config.ini" -Encoding ASCII
    
    # Update version and date
    $configLines = Get-Content "config.ini"
    $newConfig = @()
    $versionFound = $false
    
    foreach ($line in $configLines) {
        if ($line -match "^VERSION=") {
            $newConfig += "VERSION=0.1"
            $versionFound = $true
        } elseif ($line -match "^INSTALL_DATE=") {
            $newConfig += "LAST_UPDATE=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        } else {
            $newConfig += $line
        }
    }
    
    if (-not $versionFound) {
        $newConfig += "VERSION=0.1"
        $newConfig += "LAST_UPDATE=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    }
    
    $newConfig | Out-File -FilePath "config.ini" -Encoding ASCII
    Write-Host "[OK] Configuracion restaurada y actualizada" -ForegroundColor Green
} else {
    # Create new config
    $configContent = @"
COMPANY_NAME=$companyName
LOGO_PATH=$logoPath
INSTALL_DIR=$installDir
VERSION=0.1
INSTALL_DATE=$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
"@
    $configContent | Out-File -FilePath "config.ini" -Encoding ASCII
    Write-Host "[OK] Configuracion guardada" -ForegroundColor Green
}
Write-Host ""

# Restore database if upgrading
if ($isUpgrade -and $existingDB) {
    Write-Host "[INFO] Restaurando base de datos..." -ForegroundColor Cyan
    # Database file should already be there, just verify
    if (Test-Path "proveedores.db") {
        Write-Host "[OK] Base de datos preservada (sin cambios)" -ForegroundColor Green
    }
    Write-Host ""
}

# Copy logo if provided (only for new installations or if user provided new logo)
if (-not $isUpgrade) {
    if (-not [string]::IsNullOrWhiteSpace($logoPath) -and (Test-Path $logoPath)) {
        Write-Host "[5.2] Copiando logo personalizado..." -ForegroundColor Yellow
        $logoExt = [System.IO.Path]::GetExtension($logoPath)
        Copy-Item -Path $logoPath -Destination "static\logo$logoExt" -Force
        Write-Host "[OK] Logo copiado" -ForegroundColor Green
    } else {
        Write-Host "[5.2] Usando logo por defecto..." -ForegroundColor Yellow
        Write-Host "[OK] Logo por defecto configurado" -ForegroundColor Green
    }
} else {
    Write-Host "[5.2] Logo existente preservado..." -ForegroundColor Yellow
    Write-Host "[OK] Logo sin cambios" -ForegroundColor Green
}
Write-Host ""

Show-OverallProgress -Step 6 -TotalSteps 8 -Description "Configurando Entorno Python"

# Create virtual environment
if ($isUpgrade -and (Test-Path "venv")) {
    Write-Host "[6.1] Actualizando entorno virtual..." -ForegroundColor Yellow
    Write-Host "[INFO] Entorno virtual existente detectado" -ForegroundColor Cyan
} else {
    Write-Host "[6.1] Creando entorno virtual..." -ForegroundColor Yellow
    & $pythonCmd -m venv venv
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[ERROR] No se pudo crear el entorno virtual" -ForegroundColor Red
        Read-Host "Presiona Enter para salir"
        exit 1
    }
}
Write-Host "[OK] Entorno virtual creado" -ForegroundColor Green
Write-Host ""

Show-OverallProgress -Step 7 -TotalSteps 8 -Description "Instalando Dependencias"

# Activate and install dependencies
Write-Host "[7.1] Instalando dependencias..." -ForegroundColor Yellow
Write-Host "Este proceso puede tardar 2-5 minutos..." -ForegroundColor Gray
Write-Host ""

& .\venv\Scripts\Activate.ps1

Write-Host "[INFO] Actualizando pip..." -ForegroundColor Cyan
& $pythonCmd -m pip install --upgrade pip --quiet 2>&1 | Out-Null
Write-Host "[OK] pip actualizado" -ForegroundColor Green
Write-Host ""

Write-Host "[INFO] Leyendo requirements.txt..." -ForegroundColor Cyan
$requirements = Get-Content requirements.txt | Where-Object { $_ -notmatch '^\s*#' -and $_ -notmatch '^\s*$' }
$totalPackages = $requirements.Count
Write-Host "[INFO] Paquetes a instalar: $totalPackages" -ForegroundColor Cyan
Write-Host ""

# Install packages one by one to show progress
$installedCount = 0
foreach ($package in $requirements) {
    $installedCount++
    $packageName = $package -replace '[>=<].*', ''
    $percent = [math]::Floor(($installedCount / $totalPackages) * 100)
    
    Write-Host "[$installedCount/$totalPackages] Instalando $packageName..." -NoNewline -ForegroundColor Cyan
    
    $result = pip install $package --quiet 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host " [OK]" -ForegroundColor Green
    } else {
        Write-Host " [ERROR]" -ForegroundColor Red
        Write-Host "Detalles: $result" -ForegroundColor Yellow
        Read-Host "Presiona Enter para salir"
        exit 1
    }
}

Write-Host ""
Write-Host "[OK] Dependencias instaladas" -ForegroundColor Green
Write-Host ""

# Verify installation
Write-Host "[Verificando instalacion...]" -ForegroundColor Yellow

$modulesToVerify = @('flask', 'sqlalchemy', 'pandas', 'openpyxl', 'werkzeug')
$verifiedCount = 0
foreach ($module in $modulesToVerify) {
    $verifiedCount++
    Write-Host "[$verifiedCount/$($modulesToVerify.Count)] Verificando $module..." -NoNewline -ForegroundColor Cyan
    
    $checkResult = & $pythonCmd -c "import $module" 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host " [OK]" -ForegroundColor Green
    } else {
        Write-Host " [ERROR]" -ForegroundColor Red
        Write-Host "Fallo la verificacion de $module" -ForegroundColor Red
        Read-Host "Presiona Enter para salir"
        exit 1
    }
}

Write-Host "[OK] Verificacion completa" -ForegroundColor Green
Write-Host ""

Show-OverallProgress -Step 8 -TotalSteps 8 -Description "Finalizando Instalacion"

# Initialize database
if ($isUpgrade -and (Test-Path "proveedores.db")) {
    Write-Host "[INFO] Base de datos existente detectada" -ForegroundColor Cyan
    Write-Host "[OK] Saltando inicializacion (datos preservados)" -ForegroundColor Green
    Write-Host ""
    Write-Host "IMPORTANTE: Tus proveedores, productos y pedidos estan intactos." -ForegroundColor Green
    Write-Host ""
} else {
    Write-Host "[8.1] Inicializando base de datos..." -ForegroundColor Yellow
    & $pythonCmd -c "from database import init_db; init_db(); print('Base de datos creada')"
    Write-Host ""
}

# Create start script
Write-Host "[8.2] Creando scripts de inicio..." -ForegroundColor Yellow

# Note: After venv activation, 'python' always points to the venv's Python (which is Python 3)
$startScript = @"
@echo off
cd /d "%~dp0"
call venv\Scripts\activate.bat
cls
echo ========================================================
if exist config.ini (
    for /f "tokens=1,2 delims==" %%a in (config.ini) do (
        if "%%a"=="COMPANY_NAME" if not "%%b"=="" echo   %%b
    )
)
echo   Sistema de Gestion de Proveedores v0.1
echo ========================================================
echo.
echo Iniciando servidor...
echo.
python app.py
pause
"@
$startScript | Out-File -FilePath "start.bat" -Encoding ASCII
Write-Host "[OK] start.bat creado" -ForegroundColor Green
Write-Host ""

# Create desktop shortcut (optional)
Write-Host "Deseas crear un acceso directo en el escritorio? (S/N)" -ForegroundColor Cyan
$createShortcut = Read-Host

if ($createShortcut -eq "S" -or $createShortcut -eq "s") {
    try {
        # Verify start.bat exists
        if (-not (Test-Path "$installDir\start.bat")) {
            Write-Host "[ERROR] start.bat no existe aun" -ForegroundColor Red
        } else {
            $desktopPath = [Environment]::GetFolderPath("Desktop")
            $shortcutPath = Join-Path $desktopPath "Sistema Proveedores.lnk"
            
            $WshShell = New-Object -ComObject WScript.Shell
            $Shortcut = $WshShell.CreateShortcut($shortcutPath)
            $Shortcut.TargetPath = "$installDir\start.bat"
            $Shortcut.WorkingDirectory = $installDir
            $Shortcut.Description = "Sistema de Gestion de Proveedores v0.1"
            $Shortcut.Save()
            
            Write-Host "[OK] Acceso directo creado en el escritorio" -ForegroundColor Green
        }
    } catch {
        Write-Host "[ADVERTENCIA] No se pudo crear el acceso directo: $_" -ForegroundColor Yellow
        Write-Host "[INFO] Puedes crear uno manualmente mas tarde" -ForegroundColor Gray
    }
}

Write-Host ""
Write-Host ""
Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor DarkGreen
Write-Host " PROGRESO: [██████████████████████████████████████████████████] 100%" -ForegroundColor Green
Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor DarkGreen
Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
if ($isUpgrade) {
    Write-Host "  ACTUALIZACION COMPLETADA EXITOSAMENTE!" -ForegroundColor Green
} else {
    Write-Host "  INSTALACION COMPLETADA EXITOSAMENTE!" -ForegroundColor Green
}
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""

if ($isUpgrade) {
    Write-Host "[ACTUALIZACION COMPLETADA]" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Version actualizada a: " -NoNewline -ForegroundColor White
    Write-Host "0.1" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Datos preservados:" -ForegroundColor Green
    Write-Host "  [X] Configuracion de la empresa" -ForegroundColor Green
    Write-Host "  [X] Base de datos (proveedores, productos, pedidos)" -ForegroundColor Green
    Write-Host "  [X] Logo personalizado" -ForegroundColor Green
    Write-Host ""
    if (Test-Path "$installDir\backup_*") {
        $backupFolder = Get-ChildItem "$installDir\backup_*" | Select-Object -Last 1
        Write-Host "Respaldo creado en: " -NoNewline -ForegroundColor White
        Write-Host "$($backupFolder.Name)" -ForegroundColor Gray
        Write-Host ""
    }
}

if (-not [string]::IsNullOrWhiteSpace($companyName)) {
    Write-Host "Instalacion personalizada para: " -NoNewline -ForegroundColor White
    Write-Host "$companyName" -ForegroundColor Cyan
    Write-Host ""
}

Write-Host "Ubicacion: " -NoNewline -ForegroundColor White
Write-Host "$installDir" -ForegroundColor Yellow
Write-Host ""
Write-Host "Para iniciar el sistema:" -ForegroundColor White
Write-Host "  1. Ejecuta " -NoNewline -ForegroundColor Gray
Write-Host "start.bat " -NoNewline -ForegroundColor Yellow
Write-Host "en: $installDir" -ForegroundColor Gray
Write-Host "  2. O usa el acceso directo del escritorio (si lo creaste)" -ForegroundColor Gray
Write-Host ""
Write-Host "Luego abre tu navegador en: " -NoNewline -ForegroundColor White
Write-Host "http://localhost:5000" -ForegroundColor Yellow
Write-Host ""
Write-Host "Documentacion completa: README.md" -ForegroundColor Gray
Write-Host ""
Read-Host "Presiona Enter para finalizar"

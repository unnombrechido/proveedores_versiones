@echo off
REM ============================================================
REM  Crear paquete de distribucion - Sistema de Proveedores
REM  Ejecutar desde: proveedores\installers\
REM ============================================================

setlocal enabledelayedexpansion
cd /d "%~dp0\.."

color 0B
cls

REM --- Read version ---
set "VERSION="
for /f "usebackq delims=" %%v in ("%~dp0..\VERSION") do set "VERSION=%%v"
if "%VERSION%"=="" set "VERSION=1.3.1"
for /l %%a in (1,1,31) do if "!VERSION:~-1!"==" " set "VERSION=!VERSION:~0,-1!"

echo.
echo ================================================================
echo   CREAR DISTRIBUCION v%VERSION%
echo   Sistema de Gestion de Proveedores
echo ================================================================
echo.

REM ---- Detect available compilers ----
set "HAS_ISS=0"
set "HAS_NSIS=0"

if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" set "HAS_ISS=1"
if exist "C:\Program Files\Inno Setup 6\ISCC.exe"       set "HAS_ISS=1"
if exist "C:\Program Files (x86)\NSIS\makensis.exe"     set "HAS_NSIS=1"
if exist "C:\Program Files\NSIS\makensis.exe"           set "HAS_NSIS=1"

echo   Compiladores detectados:
if "%HAS_ISS%"=="1"  (echo     [OK] Inno Setup 6) else (echo     [ ] Inno Setup 6  -- https://jrsoftware.org/isdl.php)
if "%HAS_NSIS%"=="1" (echo     [OK] NSIS)         else (echo     [ ] NSIS          -- https://nsis.sourceforge.io/)
echo.

REM ---- Menu ----
echo   Que deseas crear?
echo.
echo     1  Solo ZIP  (sin instalador .exe)
echo     2  ZIP + Inno Setup .exe  [recomendado - con salida en vivo]
echo     3  ZIP + NSIS .exe
echo     4  ZIP + ambos .exe
echo     0  Cancelar
echo.
set /p "CHOICE=  Opcion [1/2/3/4/0]: "

if "%CHOICE%"=="0" goto :cancelled
if "%CHOICE%"=="1" set "INSTALLER=none"   & goto :build
if "%CHOICE%"=="2" set "INSTALLER=iss"    & goto :build
if "%CHOICE%"=="3" set "INSTALLER=nsis"   & goto :build
if "%CHOICE%"=="4" set "INSTALLER=both"   & goto :build

echo   [ERROR] Opcion no valida.
pause
exit /b 1

:build
REM ---- Validate required compiler is present ----
if "%INSTALLER%"=="iss" (
    if "%HAS_ISS%"=="0" (
        echo.
        echo   [ERROR] Inno Setup no encontrado. Instala desde: https://jrsoftware.org/isdl.php
        pause & exit /b 1
    )
)
if "%INSTALLER%"=="nsis" (
    if "%HAS_NSIS%"=="0" (
        echo.
        echo   [ERROR] NSIS no encontrado. Instala desde: https://nsis.sourceforge.io/
        pause & exit /b 1
    )
)
if "%INSTALLER%"=="both" (
    if "%HAS_ISS%"=="0" if "%HAS_NSIS%"=="0" (
        echo.
        echo   [ERROR] Ningun compilador disponible.
        pause & exit /b 1
    )
)

echo.
echo   [OK] Creando: ZIP + instalador=%INSTALLER%
echo.

powershell -ExecutionPolicy Bypass -NoProfile ^
    -File "%~dp0create_distribution.ps1" ^
    -Installer "%INSTALLER%"

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] La distribucion termino con errores.
    pause
    exit /b 1
)

echo.
echo [OK] Proceso completado.
pause
exit /b 0

:cancelled
echo   Cancelado.
exit /b 0

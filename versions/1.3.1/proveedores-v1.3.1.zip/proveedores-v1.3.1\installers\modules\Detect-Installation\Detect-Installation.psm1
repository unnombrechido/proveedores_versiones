# Detect-Installation.psm1
# Detects existing installation structure and version

function Get-InstallationInfo {
    param(
        [string]$Path,
        [string]$CurrentVersion = "1.3.1"
    )
    
    $info = @{
        Exists = $false
        Version = "none"
        Structure = "none"
        DatabasePath = $null
        DatabaseSize = 0
        ConfigPath = $null
        HasData = $false
    }
    
    if (-not (Test-Path $Path)) {
        return $info
    }
    
    $info.Exists = $true
    
    # Detect modular structure (v1.0+)
    if ((Test-Path "$Path\api\app.py") -and (Test-Path "$Path\data")) {
        $info.Structure = "modular"
        
        # Read actual version from VERSION file
        $versionPath = "$Path\VERSION"
        if (Test-Path $versionPath) {
            try {
                $info.Version = (Get-Content $versionPath -Raw).Trim()
            } catch {
                $info.Version = "1.0"  # fallback
            }
        } else {
            $info.Version = "1.0"  # fallback
        }

        if (Test-Path "$Path\data\suppliers.db") {
            $info.DatabasePath = "$Path\data\suppliers.db"
            $info.DatabaseSize = (Get-Item "$Path\data\suppliers.db").Length
            $info.HasData = $info.DatabaseSize -gt 8192  # SQLite min size
        }

        if (Test-Path "$Path\config\config.ini") {
            $info.ConfigPath = "$Path\config\config.ini"
        } elseif (Test-Path "$Path\config.ini") {
            $info.ConfigPath = "$Path\config.ini"
        } elseif (Test-Path "$Path\api\config.ini") {
            $info.ConfigPath = "$Path\api\config.ini"
        }

        # Only consider it an existing installation if there's meaningful data or config
        # Don't disqualify based on version match since installer overwrites VERSION file
        $hasMeaningfulConfig = $false
        if ($info.ConfigPath -and (Test-Path $info.ConfigPath)) {
            try {
                $configContent = Get-Content $info.ConfigPath -Raw
                # Check if config has a non-empty, non-test company name
                if ($configContent -match "company_name\s*=\s*(.+)" -and $matches[1].Trim() -ne "" -and $matches[1].Trim() -notmatch "^(Test|Prueba|Demo|Sample|Tu Empresa)") {
                    $hasMeaningfulConfig = $true
                }
            } catch {
                # Ignore config read errors
            }
        }

        # Check for backup files as evidence of previous installation
        $hasBackups = $false
        if (Test-Path "$Path\data") {
            $backupFiles = Get-ChildItem "$Path\data" -Filter "*backup*" -File -ErrorAction SilentlyContinue
            if ($backupFiles.Count -gt 0) {
                $hasBackups = $true
            }
        }

        # Check for Windows service as evidence of installation
        $hasService = $false
        try {
            $service = Get-Service -Name "SistemaProveedores" -ErrorAction SilentlyContinue
            if ($service) {
                $hasService = $true
            }
        } catch {
            # Service check failed, ignore
        }

        # Consider it existing if it has data OR meaningful config OR backups OR service
        if (-not ($info.HasData -or $hasMeaningfulConfig -or $hasBackups -or $hasService)) {
            $info.Exists = $false
        }
    }
    # Detect v0.1 structure (flat)
    elseif (Test-Path "$Path\app.py") {
        $info.Version = "0.1"
        $info.Structure = "flat"
        
        # Check for database in root or subdirectories
        $dbPaths = @(
            "$Path\suppliers.db",
            "$Path\proveedores.db",
            "$Path\data\suppliers.db"
        )
        
        foreach ($dbPath in $dbPaths) {
            if (Test-Path $dbPath) {
                $info.DatabasePath = $dbPath
                $info.DatabaseSize = (Get-Item $dbPath).Length
                $info.HasData = $info.DatabaseSize -gt 8192  # SQLite min size
                break
            }
        }
        
        if (Test-Path "$Path\config.ini") {
            $info.ConfigPath = "$Path\config.ini"
        }
    }
    else {
        $info.Exists = $false
    }
    
    return $info
}

Export-ModuleMember -Function Get-InstallationInfo
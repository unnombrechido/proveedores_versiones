@echo off
REM ============================================================
REM  Sistema de Gestion de Proveedores
REM  Instalador automatico - Wrapper de setup-auto.ps1
REM  Uso: setup-auto.bat [flags...]
REM  Flags: -Upgrade | -FreshInstall | -Silent | -NoService
REM         -NoShortcuts | -Cleanup
REM  Empresa y logo se leen de installer_params.txt (creado por NSIS/ISS)
REM ============================================================
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0setup-auto.ps1" %*
set "EXIT_CODE=%errorlevel%"
REM Write done-file so the ISS installer knows we finished and what the exit code was
echo %EXIT_CODE%> "%~dp0installer_done.txt"
exit /b %EXIT_CODE%

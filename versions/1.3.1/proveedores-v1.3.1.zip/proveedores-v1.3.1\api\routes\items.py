# -*- coding: utf-8 -*-
"""Items routes blueprint."""
import os
from datetime import datetime

import pandas as pd
from flask import Blueprint, jsonify, request, session
from flask_login import login_required
from sqlalchemy import select

from ..database import SessionLocal
from ..models import Item, ItemCategory, ItemCondition, Supplier, UnitOfMeasure, supplier_items
from .decorators import permission_required

items_bp = Blueprint('items', __name__)


@items_bp.route('/api/items/search', methods=['GET'])
@permission_required('search')
def search_items():
    """Search items by name or code and get suppliers that sell them."""
    db = SessionLocal()
    try:
        search = request.args.get('search', '')
        if not search:
            return jsonify({'error': 'Search parameter required'}), 400

        items = db.query(Item).filter(
            (Item.name.ilike(f'%{search}%')) |
            (Item.item_code.ilike(f'%{search}%'))
        ).all()

        results = []
        for item in items:
            stmt = select(supplier_items).where(supplier_items.c.item_id == item.id)
            supplier_item_data = db.execute(stmt).fetchall()

            suppliers_info = []
            for si in supplier_item_data:
                supplier = db.query(Supplier).filter(Supplier.id == si.supplier_id).first()
                if supplier:
                    suppliers_info.append({
                        'supplier_id': supplier.id,
                        'supplier_name': supplier.name,
                        'email': supplier.email,
                        'phone': supplier.phone,
                        'price': si.price,
                        'supplier_item_code': si.supplier_item_code,
                        'lead_time_days': si.lead_time_days,
                        'minimum_order_quantity': si.minimum_order_quantity,
                        'notes': si.notes
                    })

            results.append({
                'item': item.to_dict(),
                'suppliers': suppliers_info
            })

        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@items_bp.route('/api/items', methods=['GET'])
@permission_required('view')
def get_items():
    """Get all items."""
    db = SessionLocal()
    try:
        items = db.query(Item).outerjoin(ItemCategory).outerjoin(UnitOfMeasure).outerjoin(ItemCondition).all()
        return jsonify([item.to_dict() for item in items])
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@items_bp.route('/api/items', methods=['POST'])
@permission_required('create')
def create_item():
    """Create a new item."""
    db = SessionLocal()
    try:
        data = request.json

        if not data.get('item_code') or not data.get('name'):
            return jsonify({'error': 'item_code and name are required'}), 400

        existing = db.query(Item).filter(Item.item_code == data['item_code']).first()
        if existing:
            return jsonify({'error': 'Item code already exists'}), 400

        new_item = Item(
            item_code=data['item_code'],
            name=data['name'],
            description=data.get('description', ''),
            category_id=data.get('category_id'),
            unit_id=data.get('unit_id'),
            condition_id=data.get('condition_id'),
            created_by=session.get('user_id')
        )

        db.add(new_item)
        db.commit()
        db.refresh(new_item)

        return jsonify(new_item.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@items_bp.route('/api/items/<int:item_id>', methods=['GET'])
def get_item(item_id):
    """Get a specific item."""
    db = SessionLocal()
    try:
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404
        return jsonify(item.to_dict(include_suppliers=True))
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@items_bp.route('/api/items/<int:item_id>', methods=['PUT'])
@permission_required('modify')
def update_item(item_id):
    """Update an item (non-key fields only)."""
    db = SessionLocal()
    try:
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404

        data = request.json

        if 'name' in data:
            item.name = data['name']
        if 'description' in data:
            item.description = data['description']
        if 'category' in data:
            item.category = data['category']
        if 'unit' in data:
            item.unit = data['unit']

        item.updated_at = datetime.utcnow()
        item.updated_by = session.get('user_id')
        db.commit()
        db.refresh(item)

        return jsonify(item.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@items_bp.route('/api/items/<int:item_id>/suppliers', methods=['GET', 'POST'])
@permission_required('view')
def manage_item_suppliers(item_id):
    """Get all suppliers for an item (GET) or add a supplier to an item (POST)."""
    db = SessionLocal()
    try:
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404

        if request.method == 'GET':
            stmt = select(supplier_items).where(supplier_items.c.item_id == item_id)
            item_supplier_data = db.execute(stmt).fetchall()

            suppliers_info = []
            for si in item_supplier_data:
                supplier = db.query(Supplier).filter(Supplier.id == si.supplier_id).first()
                if supplier:
                    supplier_dict = supplier.to_dict()
                    supplier_dict['price'] = si.price
                    supplier_dict['supplier_item_code'] = si.supplier_item_code
                    supplier_dict['lead_time_days'] = si.lead_time_days
                    supplier_dict['minimum_order_quantity'] = si.minimum_order_quantity
                    supplier_dict['notes'] = si.notes
                    suppliers_info.append(supplier_dict)

            return jsonify(suppliers_info)

        # POST – add supplier to item
        data = request.json
        supplier_id = data.get('supplier_id')

        if not supplier_id:
            return jsonify({'error': 'supplier_id is required'}), 400

        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404

        stmt = select(supplier_items).where(
            (supplier_items.c.supplier_id == supplier_id) &
            (supplier_items.c.item_id == item_id)
        )
        existing = db.execute(stmt).fetchone()

        if existing:
            return jsonify({'error': 'This supplier is already associated with this item'}), 400

        ins = supplier_items.insert().values(
            supplier_id=supplier_id,
            item_id=item_id,
            price=data.get('price'),
            supplier_item_code=data.get('supplier_item_code', ''),
            lead_time_days=data.get('lead_time_days'),
            minimum_order_quantity=data.get('minimum_order_quantity'),
            notes=data.get('notes', '')
        )
        db.execute(ins)
        db.commit()

        return jsonify({'message': 'Supplier added to item successfully'}), 201

    except Exception as e:
        if request.method == 'POST':
            db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@items_bp.route('/api/items/<int:item_id>/suppliers/<int:supplier_id>', methods=['PUT', 'DELETE'])
def manage_item_supplier_relationship(item_id, supplier_id):
    """Update (PUT) or delete (DELETE) a supplier-item relationship."""
    db = SessionLocal()
    try:
        item = db.query(Item).filter(Item.id == item_id).first()
        if not item:
            return jsonify({'error': 'Item not found'}), 404

        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404

        stmt = select(supplier_items).where(
            (supplier_items.c.supplier_id == supplier_id) &
            (supplier_items.c.item_id == item_id)
        )
        existing = db.execute(stmt).fetchone()

        if not existing:
            return jsonify({'error': 'Relationship not found'}), 404

        if request.method == 'PUT':
            data = request.json
            upd = supplier_items.update().where(
                (supplier_items.c.supplier_id == supplier_id) &
                (supplier_items.c.item_id == item_id)
            ).values(
                price=data.get('price'),
                supplier_item_code=data.get('supplier_item_code', ''),
                lead_time_days=data.get('lead_time_days'),
                minimum_order_quantity=data.get('minimum_order_quantity'),
                notes=data.get('notes', ''),
                updated_at=datetime.utcnow()
            )
            db.execute(upd)
            db.commit()
            return jsonify({'message': 'Supplier relationship updated successfully'}), 200

        # DELETE
        dlt = supplier_items.delete().where(
            (supplier_items.c.supplier_id == supplier_id) &
            (supplier_items.c.item_id == item_id)
        )
        db.execute(dlt)
        db.commit()
        return jsonify({'message': 'Supplier relationship deleted successfully'}), 200

    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@items_bp.route('/api/suppliers/<int:supplier_id>/items', methods=['GET'])
def get_supplier_items(supplier_id):
    """Get all items sold by a specific supplier."""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404

        stmt = select(supplier_items).where(supplier_items.c.supplier_id == supplier_id)
        supplier_item_data = db.execute(stmt).fetchall()

        items_info = []
        for si in supplier_item_data:
            item = db.query(Item).filter(Item.id == si.item_id).first()
            if item:
                item_dict = item.to_dict()
                item_dict['price'] = si.price
                item_dict['supplier_item_code'] = si.supplier_item_code
                item_dict['lead_time_days'] = si.lead_time_days
                item_dict['minimum_order_quantity'] = si.minimum_order_quantity
                item_dict['notes'] = si.notes
                items_info.append(item_dict)

        return jsonify({
            'supplier': supplier.to_dict(),
            'items': items_info
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@items_bp.route('/api/items/common-suppliers', methods=['POST'])
def get_common_suppliers():
    """Find suppliers that sell all specified items, or group items by available suppliers."""
    db = SessionLocal()
    try:
        data = request.json
        item_ids = data.get('item_ids', [])

        if not item_ids:
            return jsonify({'error': 'No item IDs provided'}), 400

        # Collect suppliers per item
        items_suppliers = {}
        for item_id in item_ids:
            stmt = select(supplier_items).where(supplier_items.c.item_id == item_id)
            supplier_data = db.execute(stmt).fetchall()
            items_suppliers[item_id] = [
                {
                    'supplier_id': sd.supplier_id,
                    'item_id': sd.item_id,
                    'price': sd.price,
                    'supplier_item_code': sd.supplier_item_code,
                    'lead_time_days': sd.lead_time_days
                }
                for sd in supplier_data
            ]

        # Find common suppliers
        if len(item_ids) == 1:
            common_supplier_ids = set(s['supplier_id'] for s in items_suppliers[item_ids[0]])
        else:
            supplier_sets = [
                set(s['supplier_id'] for s in items_suppliers[item_id])
                for item_id in item_ids
            ]
            common_supplier_ids = set.intersection(*supplier_sets) if supplier_sets else set()

        common_suppliers = []
        if common_supplier_ids:
            for supplier_id in common_supplier_ids:
                supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
                if not supplier:
                    continue

                supplier_items_list = []
                total_cost = 0

                for item_id in item_ids:
                    item_data = next(
                        (s for s in items_suppliers[item_id] if s['supplier_id'] == supplier_id),
                        None
                    )
                    if item_data:
                        supplier_items_list.append({
                            'item_id': item_id,
                            'price': item_data['price'],
                            'supplier_item_code': item_data['supplier_item_code']
                        })
                        if item_data['price']:
                            total_cost += item_data['price']

                common_suppliers.append({
                    'supplier_id': supplier_id,
                    'supplier_name': supplier.name,
                    'email': supplier.email,
                    'phone': supplier.phone,
                    'items': supplier_items_list,
                    'total_cost': total_cost
                })

        # If no common suppliers, group by cheapest available
        supplier_groups = []
        if not common_supplier_ids:
            used_suppliers = {}

            for item_id in item_ids:
                item = db.query(Item).filter(Item.id == item_id).first()
                suppliers_for_item = items_suppliers.get(item_id, [])

                if not suppliers_for_item:
                    continue

                cheapest = min(
                    suppliers_for_item,
                    key=lambda x: x['price'] if x['price'] else float('inf')
                )

                sid = cheapest['supplier_id']
                if sid not in used_suppliers:
                    used_suppliers[sid] = []

                used_suppliers[sid].append({
                    'item_id': item_id,
                    'item_name': item.name if item else 'Unknown',
                    'price': cheapest['price'],
                    'supplier_item_code': cheapest['supplier_item_code']
                })

            for sid, items_list in used_suppliers.items():
                supplier = db.query(Supplier).filter(Supplier.id == sid).first()
                if not supplier:
                    continue

                total = sum(i['price'] for i in items_list if i['price'])

                supplier_groups.append({
                    'supplier_id': sid,
                    'supplier_name': supplier.name,
                    'items': items_list,
                    'total_cost': total
                })

        return jsonify({
            'common_suppliers': common_suppliers,
            'supplier_groups': supplier_groups,
            'has_common_supplier': len(common_supplier_ids) > 0
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@items_bp.route('/api/items/export', methods=['GET'])
@permission_required('export')
def export_items():
    """Export items to Excel file."""
    db = SessionLocal()
    try:
        items = db.query(Item).all()
        data = [i.to_dict(include_suppliers=False) for i in items]
        df = pd.DataFrame(data)

        from datetime import datetime as _dt
        filename = f'items_{_dt.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        export_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'exports')
        os.makedirs(export_dir, exist_ok=True)
        file_path = os.path.abspath(os.path.join(export_dir, filename))
        df.to_excel(file_path, index=False, engine='openpyxl')
    finally:
        db.close()

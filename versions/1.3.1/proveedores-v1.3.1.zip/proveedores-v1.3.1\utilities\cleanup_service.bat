@echo off
REM ============================================================
REM  Service Cleanup Utility - Aggressive Fix for Stuck Services
REM ============================================================

cd /d "%~dp0\.."

echo.
echo ============================================================
echo   LIMPIEZA AGRESIVA DE SERVICIOS
echo ============================================================
echo.
echo Este script detendra y removera agresivamente el servicio
echo y terminara cualquier proceso relacionado.
echo.

powershell -ExecutionPolicy Bypass -Command "
    $serviceName = 'SistemaProveedores'
    Write-Host 'Iniciando limpieza agresiva del servicio...' -ForegroundColor Yellow
    
    # 1. Try to stop service normally first
    Write-Host '1. Intentando detener servicio normalmente...' -ForegroundColor Cyan
    try {
        Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
        Write-Host '   Servicio detenido normalmente' -ForegroundColor Green
    } catch {
        Write-Host '   Error deteniendo normalmente: $($_.Exception.Message)' -ForegroundColor Yellow
    }
    
    # 2. Kill any processes that might be running under the service
    Write-Host '2. Buscando y terminando procesos relacionados...' -ForegroundColor Cyan
    $killedCount = 0
    
    # Kill python processes
    $pythonProcesses = Get-Process -Name 'python' -ErrorAction SilentlyContinue
    foreach ($proc in $pythonProcesses) {
        try {
            $procPath = $proc.Path
            if ($procPath -and ($procPath -like '*proveedores*' -or $procPath -like '*SistemaProveedores*')) {
                Write-Host \"   Terminando proceso Python (PID: $($proc.Id))\" -ForegroundColor Yellow
                $proc.Kill()
                $killedCount++
            }
        } catch {
            Write-Host \"   [ADVERTENCIA] No se pudo terminar proceso $($proc.Id)\" -ForegroundColor Yellow
        }
    }
    
    # Kill any cmd processes that might be running the service
    $cmdProcesses = Get-Process -Name 'cmd' -ErrorAction SilentlyContinue
    foreach ($proc in $cmdProcesses) {
        try {
            $cmdLine = $proc.CommandLine
            if ($cmdLine -and ($cmdLine -like '*run.bat*' -or $cmdLine -like '*SistemaProveedores*')) {
                Write-Host \"   Terminando proceso CMD (PID: $($proc.Id))\" -ForegroundColor Yellow
                $proc.Kill()
                $killedCount++
            }
        } catch {
            Write-Host \"   [ADVERTENCIA] No se pudo terminar proceso CMD $($proc.Id)\" -ForegroundColor Yellow
        }
    }
    
    Write-Host \"   Procesos terminados: $killedCount\" -ForegroundColor Green
    
    # 3. Force remove service using multiple methods
    Write-Host '3. Removiendo servicio forzosamente...' -ForegroundColor Cyan
    
    # Method 1: NSSM remove
    $nssmPath = Join-Path (Get-Location) 'utilities\service\nssm.exe'
    if (Test-Path $nssmPath) {
        Write-Host '   Intentando NSSM remove...' -ForegroundColor Gray
        & $nssmPath remove $serviceName confirm 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Host '   [OK] Servicio removido con NSSM' -ForegroundColor Green
        } else {
            Write-Host '   NSSM remove fallo, intentando otros metodos...' -ForegroundColor Yellow
        }
    }
    
    # Method 2: SC delete
    Write-Host '   Intentando SC delete...' -ForegroundColor Gray
    $scResult = & sc.exe delete $serviceName 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Host '   [OK] Servicio removido con SC' -ForegroundColor Green
    } else {
        Write-Host '   SC delete fallo o servicio ya no existe' -ForegroundColor Yellow
    }
    
    # Method 3: Registry cleanup (nuclear option)
    Write-Host '   Limpiando entradas del registro...' -ForegroundColor Gray
    $regPaths = @(
        'HKLM:\SYSTEM\CurrentControlSet\Services\SistemaProveedores',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\SistemaProveedores'
    )
    
    foreach ($regPath in $regPaths) {
        try {
            if (Test-Path $regPath) {
                Remove-Item -Path $regPath -Recurse -Force -ErrorAction Stop
                Write-Host \"   [OK] Entrada de registro eliminada: $regPath\" -ForegroundColor Green
            }
        } catch {
            Write-Host \"   [ADVERTENCIA] No se pudo eliminar entrada de registro: $($_.Exception.Message)\" -ForegroundColor Yellow
        }
    }
    
    # 4. Wait and verify
    Write-Host '4. Verificando limpieza...' -ForegroundColor Cyan
    Start-Sleep -Seconds 3
    
    $serviceStillExists = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($serviceStillExists) {
        Write-Host '   [ADVERTENCIA] El servicio aun existe. Estado:' $serviceStillExists.Status -ForegroundColor Yellow
    } else {
        Write-Host '   [OK] Servicio completamente removido' -ForegroundColor Green
    }
    
    # 5. Final check for any remaining processes
    Write-Host '5. Verificacion final de procesos...' -ForegroundColor Cyan
    $remainingPython = Get-Process -Name 'python' -ErrorAction SilentlyContinue | Where-Object { $_.Path -like '*proveedores*' }
    if ($remainingPython) {
        Write-Host '   [ADVERTENCIA] Aun hay procesos Python relacionados:' -ForegroundColor Yellow
        $remainingPython | ForEach-Object { Write-Host \"     PID: $($_.Id) - $($_.Path)\" -ForegroundColor Yellow }
    } else {
        Write-Host '   [OK] No quedan procesos relacionados' -ForegroundColor Green
    }
    
    Write-Host ''
    Write-Host 'Limpieza agresiva completada.' -ForegroundColor Green
    Write-Host 'Si aun ves la aplicacion en la barra de tareas, reinicia el explorador de Windows.' -ForegroundColor Cyan
    Write-Host 'Puedes reinstalar el servicio ejecutando el instalador nuevamente.' -ForegroundColor Cyan
"

echo.
echo Presiona cualquier tecla para continuar...
pause >nul
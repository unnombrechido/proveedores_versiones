"""
Migration script to convert existing string-based LOV fields to ID-based references
This script should be run during application upgrades to maintain data integrity.

Safe migration process:
1. Create LOV tables and populate with default data (already done in init_lovs.py)
2. Map existing string values to LOV IDs
3. Update existing records to use LOV IDs
4. Handle unmapped values (create new LOV entries or set to null)

Expected structure:
  project_root/
  ├── api/
  │   ├── app.py
  │   ├── database.py
  │   ├── models.py
  │   └── migrate_lovs.py (this file)
  ├── data/
  │   └── suppliers.db
  └── venv/
"""
import sys
import os

# Add api directory to path for imports
api_dir = os.path.dirname(os.path.abspath(__file__))
if api_dir not in sys.path:
    sys.path.insert(0, api_dir)

from database import SessionLocal, Base, engine
from models import (
    Item, Supplier, Order,
    ItemCategory, SupplierCategory, UnitOfMeasure, ItemCondition,
    Country, State, PaymentTerm, OrderStatus, TaxType
)
from sqlalchemy import text
from collections import defaultdict

def migrate_item_categories():
    """Migrate item.category (string) to item.category_id (foreign key)"""
    print("Migrating item categories...")

    db = SessionLocal()
    try:
        # Get all unique existing categories from items
        result = db.execute(text("SELECT DISTINCT category FROM items WHERE category IS NOT NULL AND category != ''"))
        existing_categories = [row[0] for row in result]

        if not existing_categories:
            print("No item categories to migrate")
            return

        print(f"Found {len(existing_categories)} unique item categories: {existing_categories}")

        # Create mapping from string to LOV ID
        category_map = {}

        for cat_name in existing_categories:
            # Try to find existing LOV entry (case-insensitive)
            lov_entry = db.query(ItemCategory).filter(
                (ItemCategory.name_es.ilike(cat_name)) |
                (ItemCategory.name_en.ilike(cat_name))
            ).first()

            if lov_entry:
                category_map[cat_name] = lov_entry.id
                print(f"Mapped '{cat_name}' to existing LOV ID {lov_entry.id}")
            else:
                # Create new LOV entry
                new_lov = ItemCategory(
                    code=cat_name.upper().replace(' ', '_')[:50],
                    name_es=cat_name,
                    name_en=cat_name,  # Same for both languages
                    active=True
                )
                db.add(new_lov)
                db.flush()
                category_map[cat_name] = new_lov.id
                print(f"Created new LOV entry for '{cat_name}' with ID {new_lov.id}")

        # Update items to use LOV IDs
        for cat_name, lov_id in category_map.items():
            db.execute(text("UPDATE items SET category_id = :lov_id WHERE category = :cat_name"), {
                'lov_id': lov_id,
                'cat_name': cat_name
            })

        db.commit()
        print(f"Successfully migrated {len(category_map)} item categories")

    except Exception as e:
        print(f"Error migrating item categories: {e}")
        db.rollback()
    finally:
        db.close()

def migrate_supplier_categories():
    """Migrate supplier.category (string) to supplier.category_id (foreign key)"""
    print("Migrating supplier categories...")

    db = SessionLocal()
    try:
        # Get all unique existing categories from suppliers
        result = db.execute(text("SELECT DISTINCT category FROM suppliers WHERE category IS NOT NULL AND category != ''"))
        existing_categories = [row[0] for row in result]

        if not existing_categories:
            print("No supplier categories to migrate")
            return

        print(f"Found {len(existing_categories)} unique supplier categories: {existing_categories}")

        # Create mapping from string to LOV ID
        category_map = {}

        for cat_name in existing_categories:
            # Try to find existing LOV entry
            lov_entry = db.query(SupplierCategory).filter(
                (SupplierCategory.name_es.ilike(cat_name)) |
                (SupplierCategory.name_en.ilike(cat_name))
            ).first()

            if lov_entry:
                category_map[cat_name] = lov_entry.id
                print(f"Mapped '{cat_name}' to existing LOV ID {lov_entry.id}")
            else:
                # Create new LOV entry
                new_lov = SupplierCategory(
                    code=cat_name.upper().replace(' ', '_')[:50],
                    name_es=cat_name,
                    name_en=cat_name,
                    active=True
                )
                db.add(new_lov)
                db.flush()
                category_map[cat_name] = new_lov.id
                print(f"Created new LOV entry for '{cat_name}' with ID {new_lov.id}")

        # Update suppliers to use LOV IDs
        for cat_name, lov_id in category_map.items():
            db.execute(text("UPDATE suppliers SET category_id = :lov_id WHERE category = :cat_name"), {
                'lov_id': lov_id,
                'cat_name': cat_name
            })

        db.commit()
        print(f"Successfully migrated {len(category_map)} supplier categories")

    except Exception as e:
        print(f"Error migrating supplier categories: {e}")
        db.rollback()
    finally:
        db.close()

def migrate_units_of_measure():
    """Migrate item.unit (string) to item.unit_id (foreign key)"""
    print("Migrating units of measure...")

    db = SessionLocal()
    try:
        # Get all unique existing units from items
        result = db.execute(text("SELECT DISTINCT unit FROM items WHERE unit IS NOT NULL AND unit != ''"))
        existing_units = [row[0] for row in result]

        if not existing_units:
            print("No units of measure to migrate")
            return

        print(f"Found {len(existing_units)} unique units: {existing_units}")

        # Create mapping from string to LOV ID
        unit_map = {}

        for unit_name in existing_units:
            # Try to find existing LOV entry
            lov_entry = db.query(UnitOfMeasure).filter(
                (UnitOfMeasure.name_es.ilike(unit_name)) |
                (UnitOfMeasure.name_en.ilike(unit_name)) |
                (UnitOfMeasure.symbol.ilike(unit_name))
            ).first()

            if lov_entry:
                unit_map[unit_name] = lov_entry.id
                print(f"Mapped '{unit_name}' to existing LOV ID {lov_entry.id}")
            else:
                # Create new LOV entry
                new_lov = UnitOfMeasure(
                    code=unit_name.upper().replace(' ', '_')[:20],
                    name_es=unit_name,
                    name_en=unit_name,
                    symbol=unit_name[:10],  # Use first 10 chars as symbol
                    active=True
                )
                db.add(new_lov)
                db.flush()
                unit_map[unit_name] = new_lov.id
                print(f"Created new LOV entry for '{unit_name}' with ID {new_lov.id}")

        # Update items to use LOV IDs
        for unit_name, lov_id in unit_map.items():
            db.execute(text("UPDATE items SET unit_id = :lov_id WHERE unit = :unit_name"), {
                'lov_id': lov_id,
                'unit_name': unit_name
            })

        db.commit()
        print(f"Successfully migrated {len(unit_map)} units of measure")

    except Exception as e:
        print(f"Error migrating units of measure: {e}")
        db.rollback()
    finally:
        db.close()

def migrate_countries_and_states():
    """Migrate supplier.country (string) to supplier.country_id and add state support"""
    print("Migrating countries and states...")

    db = SessionLocal()
    try:
        # Get all unique existing countries from suppliers
        result = db.execute(text("SELECT DISTINCT country FROM suppliers WHERE country IS NOT NULL AND country != ''"))
        existing_countries = [row[0] for row in result]

        if not existing_countries:
            print("No countries to migrate")
            return

        print(f"Found {len(existing_countries)} unique countries: {existing_countries}")

        # Create mapping from string to LOV ID
        country_map = {}

        for country_name in existing_countries:
            # Try to find existing LOV entry
            lov_entry = db.query(Country).filter(
                (Country.name_es.ilike(country_name)) |
                (Country.name_en.ilike(country_name))
            ).first()

            if lov_entry:
                country_map[country_name] = lov_entry.id
                print(f"Mapped '{country_name}' to existing LOV ID {lov_entry.id}")
            else:
                # Create new LOV entry
                new_lov = Country(
                    code=country_name[:3].upper(),
                    name_es=country_name,
                    name_en=country_name,
                    active=True
                )
                db.add(new_lov)
                db.flush()
                country_map[country_name] = new_lov.id
                print(f"Created new LOV entry for '{country_name}' with ID {new_lov.id}")

        # Update suppliers to use LOV IDs
        for country_name, lov_id in country_map.items():
            db.execute(text("UPDATE suppliers SET country_id = :lov_id WHERE country = :country_name"), {
                'lov_id': lov_id,
                'country_name': country_name
            })

        db.commit()
        print(f"Successfully migrated {len(country_map)} countries")

    except Exception as e:
        print(f"Error migrating countries: {e}")
        db.rollback()
    finally:
        db.close()

def migrate_payment_terms():
    """Migrate supplier.payment_terms (string) to supplier.payment_term_id (foreign key)"""
    print("Migrating payment terms...")

    db = SessionLocal()
    try:
        # Get all unique existing payment terms from suppliers
        result = db.execute(text("SELECT DISTINCT payment_terms FROM suppliers WHERE payment_terms IS NOT NULL AND payment_terms != ''"))
        existing_terms = [row[0] for row in result]

        if not existing_terms:
            print("No payment terms to migrate")
            return

        print(f"Found {len(existing_terms)} unique payment terms: {existing_terms}")

        # Create mapping from string to LOV ID
        term_map = {}

        for term_name in existing_terms:
            # Try to find existing LOV entry
            lov_entry = db.query(PaymentTerm).filter(
                (PaymentTerm.name_es.ilike(term_name)) |
                (PaymentTerm.name_en.ilike(term_name))
            ).first()

            if lov_entry:
                term_map[term_name] = lov_entry.id
                print(f"Mapped '{term_name}' to existing LOV ID {lov_entry.id}")
            else:
                # Create new LOV entry
                new_lov = PaymentTerm(
                    code=term_name.upper().replace(' ', '_')[:50],
                    name_es=term_name,
                    name_en=term_name,
                    active=True
                )
                db.add(new_lov)
                db.flush()
                term_map[term_name] = new_lov.id
                print(f"Created new LOV entry for '{term_name}' with ID {new_lov.id}")

        # Update suppliers to use LOV IDs
        for term_name, lov_id in term_map.items():
            db.execute(text("UPDATE suppliers SET payment_term_id = :lov_id WHERE payment_terms = :term_name"), {
                'lov_id': lov_id,
                'term_name': term_name
            })

        db.commit()
        print(f"Successfully migrated {len(term_map)} payment terms")

    except Exception as e:
        print(f"Error migrating payment terms: {e}")
        db.rollback()
    finally:
        db.close()

def migrate_order_statuses():
    """Migrate order.status (string) to order.status_id (foreign key)"""
    print("Migrating order statuses...")

    db = SessionLocal()
    try:
        # Get all unique existing statuses from orders
        result = db.execute(text("SELECT DISTINCT status FROM orders WHERE status IS NOT NULL AND status != ''"))
        existing_statuses = [row[0] for row in result]

        if not existing_statuses:
            print("No order statuses to migrate")
            return

        print(f"Found {len(existing_statuses)} unique order statuses: {existing_statuses}")

        # Create mapping from string to LOV ID
        status_map = {}

        for status_name in existing_statuses:
            # Try to find existing LOV entry
            lov_entry = db.query(OrderStatus).filter(
                (OrderStatus.name_es.ilike(status_name)) |
                (OrderStatus.name_en.ilike(status_name))
            ).first()

            if lov_entry:
                status_map[status_name] = lov_entry.id
                print(f"Mapped '{status_name}' to existing LOV ID {lov_entry.id}")
            else:
                # Create new LOV entry
                new_lov = OrderStatus(
                    code=status_name.upper().replace(' ', '_')[:50],
                    name_es=status_name,
                    name_en=status_name,
                    active=True
                )
                db.add(new_lov)
                db.flush()
                status_map[status_name] = new_lov.id
                print(f"Created new LOV entry for '{status_name}' with ID {new_lov.id}")

        # Update orders to use LOV IDs
        for status_name, lov_id in status_map.items():
            db.execute(text("UPDATE orders SET status_id = :lov_id WHERE status = :status_name"), {
                'lov_id': lov_id,
                'status_name': status_name
            })

        db.commit()
        print(f"Successfully migrated {len(status_map)} order statuses")

    except Exception as e:
        print(f"Error migrating order statuses: {e}")
        db.rollback()
    finally:
        db.close()

def run_migration():
    """Run all LOV migrations"""
    print("=" * 60)
    print("LOV DATA MIGRATION")
    print("=" * 60)
    print("This script will:")
    print("  1. Convert existing string-based LOV fields to ID references")
    print("  2. Create new LOV entries for unmapped values")
    print("  3. Preserve all existing data")
    print("=" * 60)

    # Run migrations in order
    migrate_item_categories()
    migrate_supplier_categories()
    migrate_units_of_measure()
    migrate_countries_and_states()
    migrate_payment_terms()
    migrate_order_statuses()

    print("=" * 60)
    print("LOV migration complete!")
    print("All existing data has been converted to use LOV references.")
    print("=" * 60)

if __name__ == '__main__':
    run_migration()
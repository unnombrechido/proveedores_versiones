# -*- coding: utf-8 -*-
"""Authentication routes blueprint."""
from flask import Blueprint, jsonify, redirect, render_template, request, url_for
from flask_login import login_required, login_user, logout_user, current_user

from ..database import SessionLocal
from ..models import User

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login')
def login():
    """Serve the login page."""
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    return render_template('login.html')


@auth_bp.route('/api/auth/login', methods=['POST'])
def api_login():
    """Authenticate user and create session."""
    data = request.get_json()
    email = data.get('email', '').strip()
    password = data.get('password', '')

    if not email or not password:
        return jsonify({'error': 'Email y contraseña son requeridos'}), 400

    db = SessionLocal()
    try:
        user = db.query(User).filter(User.email == email).first()

        if not user:
            return jsonify({'error': 'Credenciales inválidas'}), 401

        if not user.check_password(password):
            return jsonify({'error': 'Credenciales inválidas'}), 401

        if not user.is_active:
            return jsonify({'error': 'Usuario inactivo. Contacte al administrador.'}), 403

        login_user(user, remember=True)

        return jsonify({
            'success': True,
            'message': 'Inicio de sesión exitoso',
            'user': user.to_dict()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@auth_bp.route('/api/auth/logout', methods=['POST'])
@login_required
def api_logout():
    """Logout current user."""
    logout_user()
    return jsonify({
        'success': True,
        'message': 'Sesión cerrada exitosamente'
    })


@auth_bp.route('/api/auth/me', methods=['GET'])
@login_required
def api_current_user():
    """Get current authenticated user info."""
    return jsonify({
        'success': True,
        'user': current_user.to_dict()
    })


@auth_bp.route('/api/auth/check', methods=['GET'])
def api_check_auth():
    """Check if user is authenticated."""
    if current_user.is_authenticated:
        return jsonify({
            'authenticated': True,
            'user': current_user.to_dict()
        })
    return jsonify({'authenticated': False})

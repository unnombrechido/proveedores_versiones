# -*- coding: utf-8 -*-
"""Flask application entry point.

All route logic lives in api/routes/ blueprints.
This module only wires the app together.
"""
from pathlib import Path

import os

from flask import Flask, jsonify, redirect, request, url_for
from flask_cors import CORS
from flask_login import LoginManager

from .database import init_db, SessionLocal
from .models import User

# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')

# ---------------------------------------------------------------------------
# Flask-Login setup
# ---------------------------------------------------------------------------

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Por favor inicie sesión para acceder a esta página.'


@login_manager.user_loader
def load_user(user_id):
    """Load user by ID for Flask-Login."""
    if user_id is None:
        return None
    db = SessionLocal()
    user = db.query(User).filter(User.id == int(user_id)).first()
    if user:
        db.expunge(user)
    db.close()
    return user


@login_manager.unauthorized_handler
def unauthorized():
    """Handle unauthorized access."""
    if request.path.startswith('/api/'):
        return jsonify({'error': 'Authentication required'}), 401
    return redirect(url_for('auth.login'))


# ---------------------------------------------------------------------------
# Database initialisation + blueprint registration
# ---------------------------------------------------------------------------

init_db()

from .routes import register_blueprints  # noqa: E402
register_blueprints(app)

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == '--service':
        from werkzeug.serving import make_server
        import logging
        import time

        log_dir = Path(__file__).parent.parent / 'logs'
        log_dir.mkdir(exist_ok=True)
        logging.basicConfig(
            filename=str(log_dir / 'service_startup.log'),
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        logger = logging.getLogger(__name__)
        logger.info("Starting Flask server in service mode")

        port = int(os.getenv('PORT', 5000))
        server = make_server('0.0.0.0', port, app, threaded=True)
        logger.info(f"Server created on port {port}")
        time.sleep(2)
        logger.info("Calling server.serve_forever()")
        server.serve_forever()
    else:
        port = int(os.getenv('PORT', 5000))
        debug = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
        app.run(host='0.0.0.0', port=port, debug=debug)

﻿// App Initialization
// Check authentication on page load
document.addEventListener('DOMContentLoaded', async () => {
    await checkAuth();
    loadInitialData();
    initZoom();
});


// Load all LOV data
async function loadLOVs() {
    try {
        const lovPromises = [
            loadLOV('itemCategories', '/api/lovs/item-categories'),
            loadLOV('supplierCategories', '/api/lovs/supplier-categories'),
            loadLOV('unitsOfMeasure', '/api/lovs/units-of-measure'),
            loadLOV('itemConditions', '/api/lovs/item-conditions'),
            loadLOV('locations', '/api/lovs/locations'),
            loadLOV('orderStatuses', '/api/lovs/order-statuses'),
            loadLOV('paymentMethods', '/api/lovs/payment-methods'),
            loadLOV('paymentTerms', '/api/lovs/payment-terms'),
            loadLOV('taxTypes', '/api/lovs/tax-types'),
            loadLOV('countries', '/api/lovs/countries')
        ];
        
        await Promise.all(lovPromises);
        console.log('All LOVs loaded successfully');
    } catch (error) {
        console.error('Error loading LOVs:', error);
    }
}

// Load a specific LOV
async function loadLOV(lovKey, url) {
    try {
        const response = await fetch(url);
        if (response.ok) {
            lovData[lovKey] = await response.json();
            console.log(`Loaded ${lovKey}:`, lovData[lovKey].length, 'items');
        } else {
            console.error(`Failed to load ${lovKey}:`, response.status);
            // Set empty array as fallback
            lovData[lovKey] = [];
        }
    } catch (error) {
        console.error(`Error loading ${lovKey}:`, error);
        // Set empty array as fallback
        lovData[lovKey] = [];
    }
}

// Database info
async function loadDatabaseInfo() {
    try {
        const response = await fetch(`${API_BASE}/database/info`);
        const data = await response.json();
        document.getElementById('db-type').textContent = `DB: ${data.type}`;
    } catch (error) {
        console.error('Error loading database info:', error);
    }
}


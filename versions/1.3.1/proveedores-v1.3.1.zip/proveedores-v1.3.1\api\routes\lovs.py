# -*- coding: utf-8 -*-
"""List-of-Values (LOV) routes blueprint."""
from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from datetime import datetime

from ..database import SessionLocal
from ..models import (
    ItemCategory, SupplierCategory, UnitOfMeasure, ItemCondition, Location,
    OrderStatus, PaymentMethod, PaymentTerm, TaxType, Country, State, ContactType
)
from .decorators import role_required

# ---------------------------------------------------------------------------
# Registry: maps URL slug → (model_class, list_of_writable_fields)
# ---------------------------------------------------------------------------
LOV_REGISTRY = {
    'item-categories':     (ItemCategory,     ['code', 'name_es', 'name_en', 'description', 'active']),
    'supplier-categories': (SupplierCategory, ['code', 'name_es', 'name_en', 'description', 'active']),
    'units-of-measure':    (UnitOfMeasure,    ['code', 'name_es', 'name_en', 'symbol', 'description', 'active']),
    'item-conditions':     (ItemCondition,    ['code', 'name_es', 'name_en', 'description', 'active']),
    'locations':           (Location,         ['code', 'name_es', 'name_en', 'type', 'parent_id', 'description', 'active']),
    'order-statuses':      (OrderStatus,      ['code', 'name_es', 'name_en', 'description', 'active']),
    'payment-methods':     (PaymentMethod,    ['code', 'name_es', 'name_en', 'description', 'active']),
    'payment-terms':       (PaymentTerm,      ['code', 'name_es', 'name_en', 'description', 'active']),
    'tax-types':           (TaxType,          ['code', 'name_es', 'name_en', 'rate', 'description', 'active']),
    'contact-types':       (ContactType,      ['code', 'name_es', 'name_en', 'description', 'active']),
    'countries':           (Country,          ['code', 'name_es', 'name_en', 'description', 'active']),
    'states':              (State,            ['code', 'name_es', 'name_en', 'country_id', 'description', 'active']),
}

lovs_bp = Blueprint('lovs', __name__)


@lovs_bp.route('/api/lovs/item-categories', methods=['GET'])
@login_required
def get_item_categories():
    """Get all active item categories."""
    db = SessionLocal()
    try:
        categories = db.query(ItemCategory).filter(ItemCategory.active == True).all()
        return jsonify([c.to_dict() for c in categories])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/supplier-categories', methods=['GET'])
@login_required
def get_supplier_categories():
    """Get all active supplier categories."""
    db = SessionLocal()
    try:
        categories = db.query(SupplierCategory).filter(SupplierCategory.active == True).all()
        return jsonify([c.to_dict() for c in categories])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/units-of-measure', methods=['GET'])
@login_required
def get_units_of_measure():
    """Get all active units of measure."""
    db = SessionLocal()
    try:
        units = db.query(UnitOfMeasure).filter(UnitOfMeasure.active == True).all()
        return jsonify([u.to_dict() for u in units])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/item-conditions', methods=['GET'])
@login_required
def get_item_conditions():
    """Get all active item conditions."""
    db = SessionLocal()
    try:
        conditions = db.query(ItemCondition).filter(ItemCondition.active == True).all()
        return jsonify([c.to_dict() for c in conditions])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/locations', methods=['GET'])
@login_required
def get_locations():
    """Get all active locations."""
    db = SessionLocal()
    try:
        locations = db.query(Location).filter(Location.active == True).all()
        return jsonify([l.to_dict() for l in locations])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/order-statuses', methods=['GET'])
@login_required
def get_order_statuses():
    """Get all active order statuses."""
    db = SessionLocal()
    try:
        statuses = db.query(OrderStatus).filter(OrderStatus.active == True).all()
        return jsonify([s.to_dict() for s in statuses])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/payment-methods', methods=['GET'])
@login_required
def get_payment_methods():
    """Get all active payment methods."""
    db = SessionLocal()
    try:
        methods = db.query(PaymentMethod).filter(PaymentMethod.active == True).all()
        return jsonify([m.to_dict() for m in methods])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/payment-terms', methods=['GET'])
@login_required
def get_payment_terms():
    """Get all active payment terms."""
    db = SessionLocal()
    try:
        terms = db.query(PaymentTerm).filter(PaymentTerm.active == True).all()
        return jsonify([t.to_dict() for t in terms])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/tax-types', methods=['GET'])
@login_required
def get_tax_types():
    """Get all active tax types."""
    db = SessionLocal()
    try:
        taxes = db.query(TaxType).filter(TaxType.active == True).all()
        return jsonify([t.to_dict() for t in taxes])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/countries', methods=['GET'])
@login_required
def get_countries():
    """Get all active countries."""
    db = SessionLocal()
    try:
        countries = db.query(Country).filter(Country.active == True).all()
        return jsonify([c.to_dict() for c in countries])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/contact-types', methods=['GET'])
def get_contact_types():
    """Get all active contact types."""
    db = SessionLocal()
    try:
        contact_types = db.query(ContactType).filter(ContactType.active == True).all()
        return jsonify([ct.to_dict() for ct in contact_types])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/states/<int:country_id>', methods=['GET'])
@login_required
def get_states(country_id):
    """Get all active states for a country."""
    db = SessionLocal()
    try:
        states = db.query(State).filter(State.active == True, State.country_id == country_id).all()
        return jsonify([s.to_dict() for s in states])
    finally:
        db.close()


# ===========================================================================
# Management endpoints (admin / sysadmin only)
# ===========================================================================

@lovs_bp.route('/api/lovs/manage/types', methods=['GET'])
@login_required
@role_required('admin', 'sysadmin')
def get_lov_types():
    """Return the list of manageable LOV types with their display labels."""
    LABELS = {
        'item-categories':     'Categorías de Artículos',
        'supplier-categories': 'Categorías de Proveedores',
        'units-of-measure':    'Unidades de Medida',
        'item-conditions':     'Condiciones de Artículo',
        'locations':           'Ubicaciones',
        'order-statuses':      'Estados de Orden',
        'payment-methods':     'Métodos de Pago',
        'payment-terms':       'Condiciones de Pago',
        'tax-types':           'Tipos de Impuesto',
        'contact-types':       'Tipos de Contacto',
        'countries':           'Países',
        'states':              'Estados / Provincias',
    }
    return jsonify([{'key': k, 'label': v} for k, v in LABELS.items()])


@lovs_bp.route('/api/lovs/manage/<string:lov_type>', methods=['GET'])
@login_required
@role_required('admin', 'sysadmin')
def manage_get_all(lov_type):
    """Return ALL records (active and inactive) for management."""
    entry = LOV_REGISTRY.get(lov_type)
    if not entry:
        return jsonify({'error': 'Tipo de LOV no encontrado'}), 404
    model, _ = entry
    db = SessionLocal()
    try:
        records = db.query(model).order_by(model.code).all()
        return jsonify([r.to_dict() for r in records])
    finally:
        db.close()


@lovs_bp.route('/api/lovs/manage/<string:lov_type>', methods=['POST'])
@login_required
@role_required('admin', 'sysadmin')
def manage_create(lov_type):
    """Create a new LOV record."""
    entry = LOV_REGISTRY.get(lov_type)
    if not entry:
        return jsonify({'error': 'Tipo de LOV no encontrado'}), 404
    model, allowed_fields = entry
    data = request.get_json() or {}
    db = SessionLocal()
    try:
        record = model()
        for field in allowed_fields:
            if field in data:
                setattr(record, field, data[field])
        record.created_by = current_user.id
        record.updated_by = current_user.id
        db.add(record)
        db.commit()
        db.refresh(record)
        return jsonify(record.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


@lovs_bp.route('/api/lovs/manage/<string:lov_type>/<int:record_id>', methods=['PUT'])
@login_required
@role_required('admin', 'sysadmin')
def manage_update(lov_type, record_id):
    """Update an existing LOV record."""
    entry = LOV_REGISTRY.get(lov_type)
    if not entry:
        return jsonify({'error': 'Tipo de LOV no encontrado'}), 404
    model, allowed_fields = entry
    data = request.get_json() or {}
    db = SessionLocal()
    try:
        record = db.query(model).get(record_id)
        if not record:
            return jsonify({'error': 'Registro no encontrado'}), 404
        for field in allowed_fields:
            if field in data:
                setattr(record, field, data[field])
        record.updated_by = current_user.id
        record.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(record)
        return jsonify(record.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


@lovs_bp.route('/api/lovs/manage/<string:lov_type>/<int:record_id>', methods=['DELETE'])
@login_required
@role_required('admin', 'sysadmin')
def manage_toggle_active(lov_type, record_id):
    """Toggle the active flag of a LOV record (soft delete / restore)."""
    entry = LOV_REGISTRY.get(lov_type)
    if not entry:
        return jsonify({'error': 'Tipo de LOV no encontrado'}), 404
    model, _ = entry
    db = SessionLocal()
    try:
        record = db.query(model).get(record_id)
        if not record:
            return jsonify({'error': 'Registro no encontrado'}), 404
        record.active = not record.active
        record.updated_by = current_user.id
        record.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(record)
        return jsonify(record.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()

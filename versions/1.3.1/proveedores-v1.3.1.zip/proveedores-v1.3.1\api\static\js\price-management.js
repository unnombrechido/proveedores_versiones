﻿// ===== PRICE MANAGEMENT PAGE =====
// ===== PRICE MANAGEMENT PAGE =====

function backToInventory() {
    currentPriceItem = null;
    showSection('inventory');
}

async function loadPriceManagement(itemId) {
    try {
        // Get item details
        const itemResponse = await fetch(`${API_BASE}/items/${itemId}`);
        const item = await itemResponse.json();
        currentPriceItem = item;
        
        // Update header
        document.getElementById('price-item-name').textContent = `${item.item_code} - ${item.name}`;
        document.getElementById('price-item-details').textContent = 
            `${item.description || ''} | Categoría: ${item.category || 'N/A'} | Unidad: ${item.unit || 'N/A'}`;
        
        // Get all suppliers
        const suppliersResponse = await fetch(`${API_BASE}/suppliers`);
        const allSuppliers = await suppliersResponse.json();
        
        // Get item-supplier relationships
        const relationshipsResponse = await fetch(`${API_BASE}/items/${itemId}/suppliers`);
        const relationships = await relationshipsResponse.json();
        
        // Merge data
        allPriceSuppliersData = allSuppliers.map(supplier => {
            const relationship = relationships.find(r => r.id === supplier.id);
            return {
                ...supplier,
                hasRelationship: !!relationship,
                price: relationship?.price || null,
                supplier_item_code: relationship?.supplier_item_code || null,
                lead_time_days: relationship?.lead_time_days || null,
                minimum_order_quantity: relationship?.minimum_order_quantity || null,
                notes: relationship?.notes || null
            };
        });
        
        // Populate filter dropdowns
        populatePriceFilters(allPriceSuppliersData);
        
        // Display suppliers
        filterPriceSuppliers();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar gestión de precios');
    }
}

function populatePriceFilters(suppliers) {
    // Categories
    const categories = [...new Set(suppliers.map(s => s.category).filter(Boolean))].sort();
    const categoryFilter = document.getElementById('price-category-filter');
    categoryFilter.innerHTML = '<option value="">Todas</option>' + 
        categories.map(cat => `<option value="${cat}">${cat}</option>`).join('');
    
    // Cities
    const cities = [...new Set(suppliers.map(s => s.city).filter(Boolean))].sort();
    const cityFilter = document.getElementById('price-city-filter');
    cityFilter.innerHTML = '<option value="">Todas</option>' + 
        cities.map(city => `<option value="${city}">${city}</option>`).join('');
}

function filterPriceSuppliers() {
    const searchTerm = document.getElementById('price-supplier-search').value.toLowerCase();
    const relationshipFilter = document.getElementById('price-relationship-filter').value;
    const categoryFilter = document.getElementById('price-category-filter').value;
    const cityFilter = document.getElementById('price-city-filter').value;
    
    let filtered = [...allPriceSuppliersData];
    
    // Filter by search term
    if (searchTerm) {
        filtered = filtered.filter(s => 
            (s.name || '').toLowerCase().includes(searchTerm) ||
            (s.email || '').toLowerCase().includes(searchTerm) ||
            (s.city || '').toLowerCase().includes(searchTerm)
        );
    }
    
    // Filter by relationship status
    if (relationshipFilter === 'active') {
        filtered = filtered.filter(s => s.hasRelationship);
    } else if (relationshipFilter === 'available') {
        filtered = filtered.filter(s => !s.hasRelationship);
    }
    
    // Filter by category
    if (categoryFilter) {
        filtered = filtered.filter(s => s.category === categoryFilter);
    }
    
    // Filter by city
    if (cityFilter) {
        filtered = filtered.filter(s => s.city === cityFilter);
    }
    
    displayPriceSuppliers(filtered);
}

function displayPriceSuppliers(suppliers) {
    const tbody = document.getElementById('price-suppliers-tbody');
    
    if (suppliers.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="placeholder-text">No se encontraron proveedores</td></tr>';
        return;
    }
    
    tbody.innerHTML = suppliers.map(supplier => {
        if (supplier.hasRelationship) {
            // Existing relationship - show in edit mode
            return `
                <tr data-supplier-id="${supplier.id}" class="relationship-active">
                    <td><strong>${supplier.name}</strong></td>
                    <td>${supplier.email || '-'}</td>
                    <td>${supplier.city || '-'}</td>
                    <td>${supplier.category || '-'}</td>
                    <td>
                        <input type="number" step="0.01" class="form-control form-control-sm price-edit" 
                               value="${supplier.price || ''}" placeholder="Precio">
                    </td>
                    <td>
                        <input type="text" class="form-control form-control-sm code-edit" 
                               value="${supplier.supplier_item_code || ''}" placeholder="Código">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm leadtime-edit" 
                               value="${supplier.lead_time_days || ''}" placeholder="Días">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm minqty-edit" 
                               value="${supplier.minimum_order_quantity || ''}" placeholder="Cant.">
                    </td>
                    <td style="white-space: nowrap;">
                        <button onclick="updateSupplierPrice(${supplier.id})" class="btn btn-success btn-sm" title="Guardar Cambios">
                            💾
                        </button>
                        <button onclick="removeSupplierFromItem(${supplier.id}, '${escapeHtml(supplier.name)}')" 
                                class="btn btn-danger btn-sm" title="Eliminar Proveedor">
                            🗑️
                        </button>
                    </td>
                </tr>
            `;
        } else {
            // No relationship - show add mode
            return `
                <tr data-supplier-id="${supplier.id}" class="relationship-available">
                    <td><strong>${supplier.name}</strong></td>
                    <td>${supplier.email || '-'}</td>
                    <td>${supplier.city || '-'}</td>
                    <td>${supplier.category || '-'}</td>
                    <td>
                        <input type="number" step="0.01" class="form-control form-control-sm price-new" 
                               placeholder="Ingrese precio">
                    </td>
                    <td>
                        <input type="text" class="form-control form-control-sm code-new" 
                               placeholder="Código">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm leadtime-new" 
                               placeholder="Días">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm minqty-new" 
                               placeholder="Cant.">
                    </td>
                    <td>
                        <button onclick="addSupplierToItem(${supplier.id}, '${escapeHtml(supplier.name)}')" 
                                class="btn btn-primary btn-sm" title="Agregar Proveedor">
                            ➕
                        </button>
                    </td>
                </tr>
            `;
        }
    }).join('');
}

async function addSupplierToItem(supplierId, supplierName) {
    const row = document.querySelector(`tr[data-supplier-id="${supplierId}"]`);
    const price = parseFloat(row.querySelector('.price-new').value);
    const supplierCode = row.querySelector('.code-new').value;
    const leadTime = parseInt(row.querySelector('.leadtime-new').value) || null;
    const minQty = parseInt(row.querySelector('.minqty-new').value) || null;
    
    if (!price || price <= 0) {
        showError('Debe ingresar un precio válido');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items/${currentPriceItem.id}/suppliers`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                supplier_id: supplierId,
                price: price,
                supplier_item_code: supplierCode || null,
                lead_time_days: leadTime,
                minimum_order_quantity: minQty,
                notes: null
            })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Error al agregar proveedor');
        }
        
        showSuccess(`Proveedor ${supplierName} agregado exitosamente`);
        await loadPriceManagement(currentPriceItem.id);
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message);
    }
}

async function updateSupplierPrice(supplierId) {
    const row = document.querySelector(`tr[data-supplier-id="${supplierId}"]`);
    const price = parseFloat(row.querySelector('.price-edit').value);
    const supplierCode = row.querySelector('.code-edit').value;
    const leadTime = parseInt(row.querySelector('.leadtime-edit').value) || null;
    const minQty = parseInt(row.querySelector('.minqty-edit').value) || null;
    
    if (!price || price <= 0) {
        showError('Debe ingresar un precio válido');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items/${currentPriceItem.id}/suppliers/${supplierId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                price: price,
                supplier_item_code: supplierCode || null,
                lead_time_days: leadTime,
                minimum_order_quantity: minQty,
                notes: null
            })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Error al actualizar precio');
        }
        
        showSuccess('Precio actualizado exitosamente');
        await loadPriceManagement(currentPriceItem.id);
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message);
    }
}

async function removeSupplierFromItem(supplierId, supplierName) {
    showConfirmDialog(
        `¿Está seguro de eliminar a ${supplierName} de este item?`,
        async () => {
            try {
                await removeSupplierFromItemConfirmed(supplierId, supplierName);
            } catch (error) {
                console.error('Error:', error);
                showError(error.message);
            }
        }
    );
}

async function removeSupplierFromItemConfirmed(supplierId, supplierName) {
    try {
        const response = await fetch(`${API_BASE}/items/${currentPriceItem.id}/suppliers/${supplierId}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Error al eliminar proveedor');
        }
        
        showSuccess(`Proveedor ${supplierName} eliminado exitosamente`);
        await loadPriceManagement(currentPriceItem.id);
        
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Zoom Functions

@echo off
REM ============================================================
REM  Sistema de Gestión de Proveedores v1.3.0
REM  Instalador Automático Modular
REM ============================================================

setlocal

REM Change to script directory
cd /d "%~dp0"

REM Check if PowerShell is available
where powershell >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo ============================================================
    echo   [ERROR] PowerShell no esta disponible
    echo ============================================================
    echo.
    echo Este instalador requiere PowerShell.
    echo PowerShell viene preinstalado en Windows 7 SP1 y superior.
    echo.
    pause
    exit /b 1
)

REM Show banner
color 0B
cls
set "APP_VERSION="
for /f "usebackq delims=" %%v in ("%~dp0VERSION") do set "APP_VERSION=%%v"
if "%APP_VERSION%"=="" set "APP_VERSION=1.3.0"
echo.
echo ================================================================
echo   SISTEMA DE GESTION DE PROVEEDORES E INVENTARIO v%APP_VERSION%
echo   Instalador Automatico con Migracion Inteligente
echo ================================================================
echo.
echo [INFO] Iniciando instalador automatico...
echo [INFO] Este instalador:
echo        - Detecta instalaciones previas
echo        - Crea backups automaticos
echo        - Migra datos sin intervencion
echo        - Configura todo automaticamente
echo.
echo [INFO] Esto puede tardar varios minutos, por favor espera...
echo.

REM Execute modular PowerShell installer
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0installers\setup-complete.ps1"

REM Capture exit code
set "EXIT_CODE=%errorlevel%"

REM Check if installation was successful
if %EXIT_CODE% equ 0 (
    color 0A
    echo.
    echo ================================================================
    echo   [EXITO] Instalacion completada
    echo ================================================================
    echo.
) else (
    color 0E
    echo.
    echo ================================================================
    echo   [ADVERTENCIA] El instalador termino con codigo: %EXIT_CODE%
    echo ================================================================
    echo.
)

pause
exit /b %EXIT_CODE%

# Install-NewStructure.ps1
# Installs new modular structure

function Install-ModularStructure {
    param(
        [string]$SourcePath,
        [string]$DestPath,
        [bool]$IsUpgrade = $false
    )
    
    Write-Host "=== Installing Modular Structure ===" -ForegroundColor Cyan
    Write-Host "Source Path: $SourcePath" -ForegroundColor Gray
    Write-Host "Destination Path: $DestPath" -ForegroundColor Gray
    Write-Host "Is Upgrade: $IsUpgrade" -ForegroundColor Gray
    
    $result = @{
        Success = $false
        DirectoriesCreated = @()
        FilesCopied = 0
        Errors = @()
    }
    
    try {
        # Define required directories for v1.0
        $directories = @(
            "api",
            "api\static",
            "api\templates",
            "bin",
            "data",
            "scripts",
            "docs",
            "examples",
            "config",
            "logs",
            "utilities",
            "installers"
        )
        
        Write-Host "Creating directories..." -ForegroundColor Yellow
        # Create directories
        foreach ($dir in $directories) {
            $dirPath = Join-Path $DestPath $dir
            if (-not (Test-Path $dirPath)) {
                Write-Host "  Creating: $dir" -ForegroundColor Gray
                New-Item -ItemType Directory -Path $dirPath -Force | Out-Null
                $result.DirectoriesCreated += $dir
            } else {
                Write-Host "  Exists: $dir" -ForegroundColor Gray
            }
        }
        
        # Copy files from source (if running from distribution)
        # Skip entirely when source == dest (NSIS already deployed files to $INSTDIR)
        $resolvedSource = if (Test-Path $SourcePath) { (Resolve-Path $SourcePath).Path } else { $null }
        $resolvedDest   = if (Test-Path $DestPath)   { (Resolve-Path $DestPath).Path   } else { $null }
        $isSamePath = $resolvedSource -and $resolvedDest -and ($resolvedSource.TrimEnd('\') -ieq $resolvedDest.TrimEnd('\'))

        if ($isSamePath) {
            Write-Host "Source equals destination - files already in place, skipping copy" -ForegroundColor Yellow
        } elseif (Test-Path $SourcePath) {
            Write-Host "Copying files from source..." -ForegroundColor Yellow
            $filesToCopy = @{
                "api\*" = "api\"
                "bin\*" = "bin\"
                "scripts\*" = "scripts\"
                "docs\*" = "docs\"
                "examples\*" = "examples\"
                "utilities\*" = "utilities\"
                "installers\*" = "installers\"
                "requirements.txt" = ""
                "VERSION" = ""
                "LICENSE" = ""
                "README.md" = ""
            }
            
            foreach ($source in $filesToCopy.Keys) {
                $dest = $filesToCopy[$source]
                $sourcePathFull = Join-Path $SourcePath $source
                $destPath = if ($dest) { Join-Path $DestPath $dest } else { $DestPath }
                
                if (Test-Path $sourcePathFull) {
                    Write-Host "  Copying: $source -> $destPath" -ForegroundColor Gray
                    Copy-Item -Path $sourcePathFull -Destination $destPath -Recurse -Force -ErrorAction SilentlyContinue
                    
                    # Count files copied
                    if ($source -like "*\*") {
                        $count = (Get-ChildItem -Path $sourcePathFull -Recurse -File).Count
                        $result.FilesCopied += $count
                        Write-Host "    Copied $count files" -ForegroundColor Gray
                    } else {
                        $result.FilesCopied++
                        Write-Host "    Copied 1 file" -ForegroundColor Gray
                    }
                } else {
                    Write-Host "  Source not found: $sourcePathFull" -ForegroundColor Red
                }
            }
        } else {
            Write-Host "Source path not found, skipping file copy" -ForegroundColor Yellow
        }  # end copy block

        $result.Success = $true
        Write-Host "Modular structure installation completed successfully" -ForegroundColor Green
        Write-Host "Directories created: $($result.DirectoriesCreated.Count)" -ForegroundColor Gray
        Write-Host "Files copied: $($result.FilesCopied)" -ForegroundColor Gray
        return $result
        
    } catch {
        $result.Errors += $_.Exception.Message
        return $result
    }
}

; ============================================================
; NSIS Installer - Sistema de Gestion de Proveedores
; ============================================================
; Build:  cd installers && makensis proveedores.nsi
; Output: proveedores-v1.3.1-nsis-setup.exe  (written to parent folder)
; Requires: NSIS 3.x, MUI2, nsDialogs, LogicLib plugins
; ============================================================

!define APPNAME      "Sistema de Gestion de Proveedores"
!define APPNAME_SAFE "SistemaProveedores"
!define COMPANYNAME  "Tu Empresa"
!define DESCRIPTION  "Sistema de gestion de proveedores e inventario"
!define VERSIONMAJOR 1
!define VERSIONMINOR 3
!define VERSIONBUILD 1
!define INSTALLSIZE  70000
!define HELPURL      "https://github.com/unnombrechido/proveedores_versiones"
!define REGKEY       "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME_SAFE}"

; Section indices (must match the declaration order of Section directives below)
!define IDX_MAIN      0
!define IDX_SERVICE   1
!define IDX_SHORTCUTS 2
!define IDX_CLEANUP   3

; ============================================================
; General settings
; ============================================================
Name            "${APPNAME}"
OutFile         "..\proveedores-v${VERSIONMAJOR}.${VERSIONMINOR}.${VERSIONBUILD}-nsis-setup.exe"
InstallDir      "C:\${APPNAME_SAFE}"
RequestExecutionLevel admin
ShowInstDetails show

!include "MUI2.nsh"
!include "nsDialogs.nsh"
!include "LogicLib.nsh"
!include "FileFunc.nsh"
!include "WinMessages.nsh"

; ============================================================
; MUI2 configuration
; ============================================================
!define MUI_ABORTWARNING
!define MUI_ICON          "..\favicon_io\favicon.ico"
!define MUI_UNICON        "..\favicon_io\favicon.ico"
!define MUI_HEADERIMAGE
!define MUI_WELCOMEFINISHPAGE_BITMAP_NOSTRETCH
!define MUI_WELCOMEPAGE_TITLE    "Bienvenido al instalador de${APPNAME}"
!define MUI_WELCOMEPAGE_TEXT     "Este asistente instalara o actualizara el ${APPNAME} v${VERSIONMAJOR}.${VERSIONMINOR}.${VERSIONBUILD}.$\r$\n$\r$\nSi tiene una instalacion anterior, se detectara automaticamente y podra elegir entre actualizar (conservando sus datos) o realizar una instalacion nueva.$\r$\n$\r$\nHaga clic en Siguiente para continuar."
!define MUI_FINISHPAGE_TITLE     "Instalacion completada"
!define MUI_FINISHPAGE_TEXT      "El ${APPNAME} ha sido instalado correctamente.$\r$\n$\r$\nPuede iniciar la aplicacion desde el menu Inicio o con el acceso directo del Escritorio."
!define MUI_FINISHPAGE_RUN       "$INSTDIR\start.bat"
!define MUI_FINISHPAGE_RUN_TEXT  "Iniciar el sistema ahora"

; ============================================================
; Variables
; ============================================================
Var IsUpgrade           ; "1" = upgrade detected, "" = fresh
Var ExistingVersion
Var ExistingCompanyName
Var ExistingLogoPath
Var CompanyName
Var LogoPath
Var UpgradeChoice       ; "upgrade" or "fresh"

; Dialog handles - upgrade page
Var UpgDlg
Var UpgInfoLabel
Var UpgCompanyText
Var UpgLogoText
Var UpgLogoBrowseBtn
Var UpgRadioUpgrade
Var UpgRadioFresh

; Dialog handles - company page
Var CmpDlg
Var CmpText

; Dialog handles - logo page
Var LogDlg
Var LogText

; ============================================================
; Pages
; ============================================================
!insertmacro MUI_PAGE_WELCOME

; Directory page - detect upgrade on leave
!define MUI_PAGE_CUSTOMFUNCTION_LEAVE "OnDirectoryLeave"
!insertmacro MUI_PAGE_DIRECTORY

; Custom wizard pages
Page custom UpgradePageCreate  UpgradePageLeave
Page custom CompanyPageCreate  CompanyPageLeave
Page custom LogoPageCreate     LogoPageLeave

!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

; Uninstaller pages
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "Spanish"

; ============================================================
; Section descriptions
; ============================================================
LangString DESC_SecMain      ${LANG_SPANISH} "Archivos principales de la aplicacion (obligatorio)"
LangString DESC_SecService   ${LANG_SPANISH} "Instala la aplicacion como servicio de Windows (inicio automatico)"
LangString DESC_SecShortcuts ${LANG_SPANISH} "Crea accesos directos en el Escritorio y el Menu Inicio"
LangString DESC_SecCleanup   ${LANG_SPANISH} "Elimina archivos de estructura obsoleta de versiones anteriores"

; ============================================================
; DetectConfigValues - finds config.ini anywhere under $INSTDIR,
;   reads company name, logo path and version regardless of format
;   (sectionless KEY=VALUE, [COMPANY] key=value, or any future layout).
;   Results written to registry then read back - avoids all encoding issues.
; Output: $ExistingCompanyName, $ExistingLogoPath, $ExistingVersion
;         $IsUpgrade = "1" if any known install signature found
; ============================================================
Function DetectConfigValues
  Push $R0
  Push $R1

  StrCpy $R0 "$TEMP\_nsis_detect.ps1"

  FileOpen $R1 "$R0" w
  FileWrite $R1 "$$d = '$INSTDIR'$\r$\n"
  FileWrite $R1 "; Find config.ini - check nested path first, then flat root$\r$\n"
  FileWrite $R1 "$$cfg = $$null$\r$\n"
  FileWrite $R1 "foreach ($$p in @($\"$$d\config\config.ini$\", $\"$$d\config.ini$\")) {$\r$\n"
  FileWrite $R1 "  if (Test-Path $$p) { $$cfg = $$p; break }$\r$\n"
  FileWrite $R1 "}$\r$\n"
  FileWrite $R1 "$$company = ''; $$logo = ''; $$ver = ''$\r$\n"
  FileWrite $R1 "if ($$cfg) {$\r$\n"
  FileWrite $R1 "  $$lines = Get-Content $$cfg -Encoding UTF8$\r$\n"
  FileWrite $R1 "  $$section = ''$\r$\n"
  FileWrite $R1 "  foreach ($$l in $$lines) {$\r$\n"
  FileWrite $R1 "    $$l = $$l.Trim()$\r$\n"
  FileWrite $R1 "    if ($$l -match '^\[(.+)\]$$') { $$section = $$Matches[1].ToLower(); continue }$\r$\n"
  FileWrite $R1 "    $$p = $$l.IndexOf('='); if ($$p -lt 0) { continue }$\r$\n"
  FileWrite $R1 "    $$key = $$l.Substring(0, $$p).Trim().ToLower()$\r$\n"
  FileWrite $R1 "    $$val = $$l.Substring($$p + 1).Trim()$\r$\n"
  FileWrite $R1 "    if ($$company -eq '' -and $$key -in @('company_name','companyname')) { $$company = $$val }$\r$\n"
  FileWrite $R1 "    if ($$logo    -eq '' -and $$key -in @('logo_path','logo','logopath'))  { $$logo    = $$val }$\r$\n"
  FileWrite $R1 "    if ($$ver     -eq '' -and $$key -eq 'version')                        { $$ver     = $$val }$\r$\n"
  FileWrite $R1 "  }$\r$\n"
  FileWrite $R1 "}$\r$\n"
  FileWrite $R1 "; Fall back to VERSION file if version still empty$\r$\n"
  FileWrite $R1 "if ($$ver -eq '') {$\r$\n"
  FileWrite $R1 "  $$vf = $\"$$d\VERSION$\"$\r$\n"
  FileWrite $R1 "  if (Test-Path $$vf) { $$ver = (Get-Content $$vf -Encoding UTF8 | Select-Object -First 1).Trim() }$\r$\n"
  FileWrite $R1 "}$\r$\n"
  FileWrite $R1 "$$null = New-Item -Path 'HKCU:\_nsis_detect' -Force$\r$\n"
  FileWrite $R1 "Set-ItemProperty -Path 'HKCU:\_nsis_detect' -Name 'company' -Value $$company$\r$\n"
  FileWrite $R1 "Set-ItemProperty -Path 'HKCU:\_nsis_detect' -Name 'logo'    -Value $$logo$\r$\n"
  FileWrite $R1 "Set-ItemProperty -Path 'HKCU:\_nsis_detect' -Name 'version' -Value $$ver$\r$\n"
  FileClose $R1

  nsExec::Exec 'powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$R0"'
  Pop $R1  ; discard exit code

  ReadRegStr $ExistingCompanyName HKCU "_nsis_detect" "company"
  ReadRegStr $ExistingLogoPath    HKCU "_nsis_detect" "logo"
  ReadRegStr $ExistingVersion     HKCU "_nsis_detect" "version"
  DeleteRegKey HKCU "_nsis_detect"
  Delete "$R0"

  Pop $R1
  Pop $R0
FunctionEnd

; ============================================================
; Admin check macro
; ============================================================
!macro VerifyUserIsAdmin
  UserInfo::GetAccountType
  Pop $0
  ${If} $0 != "admin"
    MessageBox MB_ICONSTOP "Se requieren permisos de administrador para instalar ${APPNAME}."
    SetErrorLevel 740
    Quit
  ${EndIf}
!macroend

; ============================================================
; .onInit - initialise variables
; ============================================================
Function .onInit
  SetShellVarContext all
  !insertmacro VerifyUserIsAdmin

  StrCpy $IsUpgrade           ""
  StrCpy $ExistingVersion     ""
  StrCpy $ExistingCompanyName ""
  StrCpy $ExistingLogoPath    ""
  StrCpy $CompanyName         ""
  StrCpy $LogoPath            ""
  StrCpy $UpgradeChoice       "upgrade"

  ; Pre-detect with the default InstallDir so the welcome banner can inform
  Call DetectExistingInstall
FunctionEnd

; ============================================================
; DetectExistingInstall - sets $IsUpgrade and calls DetectConfigValues
; Detects any known install signature under $INSTDIR
; ============================================================
Function DetectExistingInstall
  StrCpy $IsUpgrade ""
  StrCpy $ExistingCompanyName ""
  StrCpy $ExistingLogoPath    ""
  StrCpy $ExistingVersion     ""

  ; Any of these signatures counts as an existing installation
  ${If}   ${FileExists} "$INSTDIR\config\config.ini"
  ${OrIf} ${FileExists} "$INSTDIR\config.ini"
  ${OrIf} ${FileExists} "$INSTDIR\data\suppliers.db"
  ${OrIf} ${FileExists} "$INSTDIR\suppliers.db"
  ${OrIf} ${FileExists} "$INSTDIR\api\app.py"
  ${OrIf} ${FileExists} "$INSTDIR\app.py"
    StrCpy $IsUpgrade "1"
    Call DetectConfigValues
  ${EndIf}
FunctionEnd

; ============================================================
; OnDirectoryLeave - called when user clicks Next on dir page
; ============================================================
Function OnDirectoryLeave
  Call DetectExistingInstall
FunctionEnd

; ============================================================
; Logo browse button callback (used in upgrade page)
; ============================================================
Function OnLogoBrowseBtnClicked
  Pop $R0  ; hwnd passed by nsDialogs callback (discard)
  nsDialogs::SelectFileDialog open "" "Imagenes (*.png;*.jpg;*.jpeg;*.svg)|*.png;*.jpg;*.jpeg;*.svg|Todos los archivos (*.*)|*.*"
  Pop $R0
  ${If} $R0 != ""
    ${NSD_SetText} $UpgLogoText $R0
  ${EndIf}
FunctionEnd

; ============================================================
; UPGRADE PAGE - shown only when IsUpgrade == "1"
; Lets user see / edit company+logo and choose upgrade vs fresh
; ============================================================
Function UpgradePageCreate
  ${If} $IsUpgrade != "1"
    Abort   ; skip this page for fresh installs
  ${EndIf}

  nsDialogs::Create 1018
  Pop $UpgDlg
  ${If} $UpgDlg == error
    Abort
  ${EndIf}

  ; --- Info banner ---
  ${NSD_CreateLabel} 0 0 100% 20u "Instalacion existente detectada en $INSTDIR"
  Pop $UpgInfoLabel
  SendMessage $UpgInfoLabel ${WM_SETFONT} $PLUGINSDIR "" ; bold would need SendMessage

  ${NSD_CreateGroupBox} 0 24u 100% 52u "Configuracion actual (puede editar)"
  Pop $R0

  ${NSD_CreateLabel} 8u 38u 30u 10u "Empresa:"
  Pop $R0
  ${NSD_CreateText} 40u 36u 155u 12u "$ExistingCompanyName"
  Pop $UpgCompanyText

  ${NSD_CreateLabel} 8u 54u 30u 10u "Logo:"
  Pop $R0
  ${NSD_CreateText} 40u 52u 118u 12u "$ExistingLogoPath"
  Pop $UpgLogoText
  ${NSD_CreateButton} 162u 51u 33u 14u "..."
  Pop $UpgLogoBrowseBtn
  ${NSD_OnClick} $UpgLogoBrowseBtn OnLogoBrowseBtnClicked

  ${NSD_CreateGroupBox} 0 82u 100% 52u "Tipo de instalacion"
  Pop $R0

  ${NSD_CreateRadioButton} 8u 94u 90% 12u "Actualizar (mantener configuracion y datos - recomendado)"
  Pop $UpgRadioUpgrade
  ${NSD_SetState} $UpgRadioUpgrade ${BST_CHECKED}

  ${NSD_CreateRadioButton} 8u 110u 90% 12u "Instalacion nueva (ELIMINAR todos los datos existentes)"
  Pop $UpgRadioFresh

  ${NSD_CreateLabel} 0 142u 100% 20u "Version detectada: $ExistingVersion"
  Pop $R0

  nsDialogs::Show
FunctionEnd

Function UpgradePageLeave
  ${NSD_GetText} $UpgCompanyText $CompanyName
  ${NSD_GetText} $UpgLogoText    $LogoPath

  ${NSD_GetState} $UpgRadioFresh $R0
  ${If} $R0 == ${BST_CHECKED}
    ; Double confirmation before fresh install
    MessageBox MB_YESNO|MB_ICONEXCLAMATION \
      "ADVERTENCIA: Instalacion Nueva$\r$\n$\r$\nEsto eliminara TODOS los datos:$\r$\n  - Configuracion de empresa$\r$\n  - Base de datos de proveedores$\r$\n  - Todos los archivos existentes$\r$\n$\r$\n(Se creara un backup automaticamente)$\r$\n$\r$\n?Esta SEGURO?" \
      IDYES fresh_confirmed IDNO cancel_fresh
    cancel_fresh:
      MessageBox MB_OK "Operacion cancelada. La opcion 'Actualizar' fue restaurada."
      ${NSD_SetState} $UpgRadioUpgrade ${BST_CHECKED}
      ${NSD_SetState} $UpgRadioFresh   ${BST_UNCHECKED}
      Abort
    fresh_confirmed:
      StrCpy $UpgradeChoice "fresh"
      Return
  ${EndIf}
  StrCpy $UpgradeChoice "upgrade"
FunctionEnd

; ============================================================
; COMPANY PAGE - shown only for fresh installs
; ============================================================
Function CompanyPageCreate
  ${If} $IsUpgrade == "1"
    Abort   ; skip for upgrades (handled in upgrade page)
  ${EndIf}

  nsDialogs::Create 1018
  Pop $CmpDlg
  ${If} $CmpDlg == error
    Abort
  ${EndIf}

  !insertmacro MUI_HEADER_TEXT "Datos de la Empresa" "Ingrese el nombre de su empresa"

  ${NSD_CreateLabel} 0 0 100% 20u "Nombre de la empresa (aparecera en reportes y ordenes de compra):"
  Pop $R0

  ${NSD_CreateText} 0 24u 100% 14u "$CompanyName"
  Pop $CmpText

  ${NSD_CreateLabel} 0 44u 100% 30u "Puede dejar este campo vacio y configurarlo despues desde la aplicacion."
  Pop $R0

  nsDialogs::Show
FunctionEnd

Function CompanyPageLeave
  ${NSD_GetText} $CmpText $CompanyName
FunctionEnd

; ============================================================
; LOGO PAGE - shown only for fresh installs
; ============================================================
Function LogoPageCreate
  ${If} $IsUpgrade == "1"
    Abort   ; skip for upgrades
  ${EndIf}

  nsDialogs::Create 1018
  Pop $LogDlg
  ${If} $LogDlg == error
    Abort
  ${EndIf}

  !insertmacro MUI_HEADER_TEXT "Logo de la Empresa" "Seleccione el archivo de logo"

  ${NSD_CreateLabel} 0 0 100% 20u "Ruta completa al archivo de logo (PNG, JPG o SVG). Puede dejarlo vacio:"
  Pop $R0

  ${NSD_CreateText} 0 24u 100% 14u "$LogoPath"
  Pop $LogText

  ${NSD_CreateLabel} 0 45u 100% 20u "Ingrese la ruta completa al archivo (ej: C:\Logo.png). Puede dejarlo vacio."
  Pop $R0

  nsDialogs::Show
FunctionEnd

Function LogoPageLeave
  ${NSD_GetText} $LogText $LogoPath
FunctionEnd

; ============================================================
; SECTIONS
; ============================================================
Section "Aplicacion Principal" SecMain
  SectionIn RO   ; required - cannot be unchecked

  SetOverwrite on

  ; --- Core application files ---
  SetOutPath "$INSTDIR"
  File /nonfatal /r /x "*.pyc" /x "*.pyo" /x "*__pycache__*" /x "*.tmp" /x "*.log" "..\api"
  File /nonfatal /r /x "*.pyc" /x "*.pyo" /x "*__pycache__*" /x "test-*"            "..\bin"
  File /nonfatal /r /x "*.pyc" /x "*.pyo" /x "*__pycache__*" /x "*.db" /x "*.backup*" "..\data"
  ; docs/ is developer documentation - not deployed to end-user install
  File /nonfatal /r                                                                    "..\examples"
  File /nonfatal /r /x "*.pyc" /x "*.pyo" /x "*__pycache__*"                         "..\scripts"
  File /nonfatal /r /x "*.pyc" /x "*.pyo" /x "*__pycache__*"                         "..\utilities"

  ; Top-level files
  File /nonfatal "..\requirements.txt"  ; needed by setup-auto.ps1 to run pip install
  File /nonfatal "..\VERSION"
  File /nonfatal "..\LICENSE"
  File /nonfatal "..\LEEME_PRIMERO.txt"
  File /nonfatal "..\start.bat"

  ; Copy icon if it exists
  File /nonfatal "..\favicon_io\favicon.ico"

  ; Config template (only if config dir does not already have one)
  SetOutPath "$INSTDIR\config"
  File /nonfatal /oname=config.ini.template "..\config\config.ini"
  ; Order templates
  File /nonfatal "..\config\order_template_esp.html"
  File /nonfatal "..\config\order_template_eng.html"

  ; --- Installer engine (setup-auto.bat + setup-auto.ps1 + modules) ---
  SetOutPath "$INSTDIR"
  File /nonfatal "setup-auto.bat"
  File /nonfatal "setup-auto.ps1"

  SetOutPath "$INSTDIR\modules"
  File /nonfatal /r "modules\"

  ; --- Build the parameter file for setup-auto.bat / setup-auto.ps1 ---
  ; Company name and logo are written here to avoid quoting issues with spaces.
  ; Switch flags are passed on the command line instead.
  SetOutPath "$INSTDIR"
  FileOpen  $R9 "$INSTDIR\installer_params.txt" w
  FileWrite $R9 "COMPANYNAME=$CompanyName$\r$\n"
  FileWrite $R9 "LOGOPATH=$LogoPath$\r$\n"
  FileClose $R9

  ; --- Build switch flags for setup-auto.bat ---
  ; InstallPath and Silent are always present; Upgrade/Fresh and optional
  ; component flags are appended as needed.
  StrCpy $R0 '-InstallPath "$INSTDIR" -SourcePath "$INSTDIR" -Silent'

  ${If} $UpgradeChoice == "fresh"
    StrCpy $R0 '$R0 -FreshInstall'
  ${Else}
    StrCpy $R0 '$R0 -Upgrade'
  ${EndIf}

  ; Check optional sections (uses pre-defined index constants)
  SectionGetFlags ${IDX_SERVICE}   $R1
  IntOp $R1 $R1 & ${SF_SELECTED}
  ${If} $R1 == 0
    StrCpy $R0 '$R0 -NoService'
  ${EndIf}

  SectionGetFlags ${IDX_SHORTCUTS} $R1
  IntOp $R1 $R1 & ${SF_SELECTED}
  ${If} $R1 == 0
    StrCpy $R0 '$R0 -NoShortcuts'
  ${EndIf}

  SectionGetFlags ${IDX_CLEANUP}   $R1
  IntOp $R1 $R1 & ${SF_SELECTED}
  ${If} $R1 == 1
    StrCpy $R0 '$R0 -Cleanup'
  ${EndIf}

  ; --- Run setup-auto.bat (which calls setup-auto.ps1 internally) ---
  ; nsExec::ExecToLog streams every output line into the Details pane in real time.
  DetailPrint ""
  DetailPrint "========================================================"
  DetailPrint "  Ejecutando configuracion del sistema..."
  DetailPrint "========================================================"
  DetailPrint ""

  nsExec::ExecToLog '"$INSTDIR\setup-auto.bat" $R0'
  Pop $R1

  ; Clean up installer temp files - these are not part of the application
  Delete "$INSTDIR\installer_params.txt"
  Delete "$INSTDIR\config\config.ini.template"
  Delete "$INSTDIR\setup-auto.bat"
  Delete "$INSTDIR\setup-auto.ps1"
  RMDir /r "$INSTDIR\modules"
  ; Move install log to logs\ folder where it belongs
  CreateDirectory "$INSTDIR\logs"
  Rename "$INSTDIR\installer_log.txt" "$INSTDIR\logs\installer_log.txt"

  ${If} $R1 != 0
    DetailPrint ""
    DetailPrint "ADVERTENCIA: El script de configuracion termino con codigo $R1"
    DetailPrint "Log guardado en: $INSTDIR\logs\installer_log.txt"
    MessageBox MB_YESNO|MB_ICONEXCLAMATION \
      "La configuracion del sistema termino con advertencias (codigo: $R1).$\r$\n$\r$\nEl log completo fue guardado en:$\r$\n  $INSTDIR\logs\installer_log.txt$\r$\n$\r$\n?Desea abrir el log ahora?" \
      IDYES open_log IDNO skip_log
    open_log:
      ExecShell "open" "notepad.exe" '"$INSTDIR\logs\installer_log.txt"'
    skip_log:
  ${Else}
    DetailPrint ""
    DetailPrint "[OK] Configuracion completada exitosamente."
    DetailPrint "Log guardado en: $INSTDIR\logs\installer_log.txt"
  ${EndIf}

  ; --- Registry: Add/Remove Programs entry ---
  WriteRegStr   HKLM "${REGKEY}" "DisplayName"     "${APPNAME}"
  WriteRegStr   HKLM "${REGKEY}" "DisplayVersion"  "${VERSIONMAJOR}.${VERSIONMINOR}.${VERSIONBUILD}"
  WriteRegStr   HKLM "${REGKEY}" "Publisher"       "${COMPANYNAME}"
  WriteRegStr   HKLM "${REGKEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr   HKLM "${REGKEY}" "DisplayIcon"     "$INSTDIR\favicon_io\favicon.ico"
  WriteRegStr   HKLM "${REGKEY}" "UninstallString" '"$INSTDIR\uninstall.exe"'
  WriteRegStr   HKLM "${REGKEY}" "QuietUninstallString" '"$INSTDIR\uninstall.exe" /S'
  WriteRegStr   HKLM "${REGKEY}" "HelpLink"        "${HELPURL}"
  WriteRegStr   HKLM "${REGKEY}" "URLUpdateInfo"   "${HELPURL}"
  WriteRegDWORD HKLM "${REGKEY}" "VersionMajor"    ${VERSIONMAJOR}
  WriteRegDWORD HKLM "${REGKEY}" "VersionMinor"    ${VERSIONMINOR}
  WriteRegDWORD HKLM "${REGKEY}" "NoModify"        1
  WriteRegDWORD HKLM "${REGKEY}" "NoRepair"        1
  WriteRegDWORD HKLM "${REGKEY}" "EstimatedSize"   ${INSTALLSIZE}

  ; --- Write uninstaller ---
  WriteUninstaller "$INSTDIR\uninstall.exe"
SectionEnd

Section "Servicio de Windows" SecService
  ; Actual service installation is performed by setup-auto.ps1
  ; This section exists only for the components UI checkbox
  DetailPrint "Opcion: Instalar como servicio de Windows = SI"
SectionEnd

Section "Accesos Directos" SecShortcuts
  ; Shortcut creation is performed by setup-auto.ps1
  ; This section exists only for the components UI checkbox
  DetailPrint "Opcion: Crear accesos directos = SI"

  ; Start Menu
  CreateDirectory "$SMPROGRAMS\${APPNAME}"
  CreateShortcut  "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" \
                  "$INSTDIR\start.bat" "" "$INSTDIR\favicon_io\favicon.ico"
  CreateShortcut  "$SMPROGRAMS\${APPNAME}\Desinstalar.lnk" \
                  "$INSTDIR\uninstall.exe"

  ; Desktop
  CreateShortcut "$DESKTOP\${APPNAME}.lnk" \
                 "$INSTDIR\start.bat" "" "$INSTDIR\favicon_io\favicon.ico"
SectionEnd

Section "Limpiar archivos obsoletos" SecCleanup
  ; Cleanup handled by setup-auto.ps1 -Cleanup flag
  DetailPrint "Opcion: Limpiar archivos de versiones anteriores = SI"
SectionEnd

; Attach descriptions
!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
  !insertmacro MUI_DESCRIPTION_TEXT ${IDX_MAIN}      $(DESC_SecMain)
  !insertmacro MUI_DESCRIPTION_TEXT ${IDX_SERVICE}   $(DESC_SecService)
  !insertmacro MUI_DESCRIPTION_TEXT ${IDX_SHORTCUTS} $(DESC_SecShortcuts)
  !insertmacro MUI_DESCRIPTION_TEXT ${IDX_CLEANUP}   $(DESC_SecCleanup)
!insertmacro MUI_FUNCTION_DESCRIPTION_END

; ============================================================
; UNINSTALLER
; ============================================================
Section "Uninstall"
  ; Stop service if running
  DetailPrint "Deteniendo servicio si esta activo..."
  nsExec::ExecToLog 'sc.exe stop SistemaProveedores'
  nsExec::ExecToLog 'sc.exe delete SistemaProveedores'

  ; Remove registry key
  DeleteRegKey HKLM "${REGKEY}"

  ; Remove shortcuts
  Delete "$SMPROGRAMS\${APPNAME}\*.*"
  RMDir  "$SMPROGRAMS\${APPNAME}"
  Delete "$DESKTOP\${APPNAME}.lnk"

  ; Remove install directory (but warn if data exists)
  ${If} ${FileExists} "$INSTDIR\data\suppliers.db"
    MessageBox MB_YESNO|MB_ICONQUESTION \
      "Se encontro la base de datos en:$\r$\n  $INSTDIR\data\suppliers.db$\r$\n$\r$\n?Desea eliminar TODOS los archivos, incluyendo la base de datos?$\r$\n(No podrá revertir esta accion)" \
      IDYES remove_all IDNO keep_data
    keep_data:
      DetailPrint "Base de datos conservada. Solo se eliminan archivos del programa."
      RMDir /r "$INSTDIR\api"
      RMDir /r "$INSTDIR\bin"
      RMDir /r "$INSTDIR\docs"
      RMDir /r "$INSTDIR\scripts"
      RMDir /r "$INSTDIR\utilities"
      RMDir /r "$INSTDIR\modules"
      Delete   "$INSTDIR\requirements.txt"
      Delete   "$INSTDIR\VERSION"
      Delete   "$INSTDIR\LICENSE"
      Delete   "$INSTDIR\INSTALAR.bat"
      Delete   "$INSTDIR\start.bat"
      Delete   "$INSTDIR\setup-auto.ps1"
      Delete   "$INSTDIR\uninstall.exe"
      Goto done_uninstall
    remove_all:
  ${EndIf}

  RMDir /r "$INSTDIR"

  done_uninstall:
  DetailPrint "Desinstalacion completada."
SectionEnd

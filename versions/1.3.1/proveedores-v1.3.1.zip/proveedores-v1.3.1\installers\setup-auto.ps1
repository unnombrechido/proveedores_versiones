﻿# ============================================================
#  Sistema de Gestion de Proveedores v1.0
#  Instalador Automatico Modular
# ============================================================

param(
    [switch]$ServiceInstallOnly,
    [string]$InstallPath,
    [string]$SourcePath,
    [string]$CompanyName,
    [string]$LogoPath,
    [switch]$NoShortcuts,
    [switch]$NoService,
    [switch]$Silent,
    [switch]$Cleanup,
    [switch]$RemoveBackups,
    [switch]$Upgrade,
    [switch]$FreshInstall
)

# Check for NSIS silent mode parameter "/S"
if ($args -contains "/S") {
    $Silent = $true
}

$Host.UI.RawUI.WindowTitle = "Sistema de Proveedores v1.3.0 - Instalacion Automatica"
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "White"
Clear-Host

# Start logging to file
$logFile = Join-Path $PSScriptRoot "installer_log.txt"
Start-Transcript -Path $logFile -Append
Write-Host "=== INSTALLER LOG STARTED $(Get-Date) ===" -ForegroundColor Yellow
Write-Host "Log file: $logFile" -ForegroundColor Gray

# Debug: Show command line args
Write-Host "=== DEBUG: Command Line Args ===" -ForegroundColor Cyan
Write-Host "Args count: $($args.Count)" -ForegroundColor Gray
for ($i = 0; $i -lt $args.Count; $i++) {
    Write-Host "Arg[$i]: '$($args[$i])'" -ForegroundColor Gray
}
Write-Host "PSBoundParameters:" -ForegroundColor Gray
$PSBoundParameters.GetEnumerator() | ForEach-Object {
    Write-Host "  $($_.Key): '$($_.Value)'" -ForegroundColor Gray
}
Write-Host "============================" -ForegroundColor Cyan
Write-Host ""

# Ensure execution policy allows script execution
$currentPolicy = Get-ExecutionPolicy -Scope Process
if ($currentPolicy -eq 'Restricted' -or $currentPolicy -eq 'Undefined') {
    try {
        Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned -Force -ErrorAction Stop
    } catch {
        Write-Host "Error: No se pudo configurar la politica de ejecucion." -ForegroundColor Red
        Write-Host "Ejecuta este comando manualmente como administrador:" -ForegroundColor Yellow
        Write-Host "Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned -Force" -ForegroundColor Yellow
        if (-not $Silent) { Read-HostDefault "Presiona Enter para salir" "" }
        exit 1
    }
}

# Import modules
$moduleDir = Join-Path $PSScriptRoot "modules"
. (Join-Path $moduleDir "Detect-Installation.ps1")
. (Join-Path $moduleDir "Backup-Installation.ps1")
. (Join-Path $moduleDir "Migrate-Database.ps1")
. (Join-Path $moduleDir "Install-NewStructure.ps1")
. (Join-Path $moduleDir "Initialize-System.ps1")

# Check if this is a service-only installation
if ($ServiceInstallOnly) {
    Write-Host "Modo de instalacion: Solo Servicio" -ForegroundColor Cyan
    Write-Host ""
    
    # Get installation path from parameter
    if (-not $InstallPath -or -not (Test-Path $InstallPath)) {
        Write-Host "Ruta de instalacion no especificada o no encontrada" -ForegroundColor Red
        exit 1
    }
    
    # Install service
    $serviceInstalled = Install-Service -InstallPath $InstallPath
    
    if ($serviceInstalled) {
        Write-Host "Servicio instalado correctamente" -ForegroundColor Green
        exit 0
    } else {
        Write-Host "Fallo al instalar el servicio" -ForegroundColor Red
        exit 1
    }
}

# Configuration
$versionPath = Join-Path $PSScriptRoot "VERSION"
$VERSION = if (Test-Path $versionPath) { (Get-Content $versionPath -Raw).Trim() } else { "1.3.1" }
$MIN_PYTHON_VERSION = @(3, 8)

# Track changes for rollback
$script:installationChanges = @{
    DirectoriesCreated = @()
    FilesCreated = @()
    BackupPath = $null
    OldFilesPreserved = @()
}

# Stop running app instances
function Stop-RunningApp {
    param(
        [string]$InstallPath
    )
    
    Write-Host "[STOP] Verificando aplicaciones en ejecucion..." -ForegroundColor Yellow
    
    $appStopped = $false
    
    # Check if service is installed and running
    $serviceName = "SistemaProveedores"
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        $service = Get-Service -Name $serviceName
        Write-Host "  Servicio '$serviceName' encontrado - Estado: $($service.Status)" -ForegroundColor Gray
        
        # Check if service is active (Running or Starting)
        if ($service.Status -eq "Running" -or $service.Status -eq "Starting") {
            Write-Host "  Servicio '$serviceName' esta activo. Deteniendo..." -ForegroundColor Cyan
            
            # Try standard Stop-Service first
            try {
                Stop-Service -Name $serviceName -Force -ErrorAction Stop
                Write-Host "  [OK] Servicio detenido correctamente con Stop-Service" -ForegroundColor Green
                $appStopped = $true
            } catch {
                Write-Host "  [ADVERTENCIA] Stop-Service fallo, intentando con sc.exe..." -ForegroundColor Yellow

                # Try sc.exe stop as fallback
                try {
                    $scResult = sc.exe stop $serviceName 2>&1
                    if ($LASTEXITCODE -eq 0) {
                        Write-Host "  [OK] Servicio detenido correctamente con sc.exe" -ForegroundColor Green
                        $appStopped = $true
                    } else {
                        Write-Host "  [ERROR] No se pudo detener el servicio: sc.exe returned $LASTEXITCODE" -ForegroundColor Red
                    }
                } catch {
                    Write-Host "  [ERROR] No se pudo detener el servicio: $($_.Exception.Message)" -ForegroundColor Red
                }
            }
        } elseif ($service.Status -eq "Stopping") {
            Write-Host "  Servicio '$serviceName' se esta deteniendo. Esperando..." -ForegroundColor Yellow
            Start-Sleep -Seconds 5
            $service.Refresh()
            if ($service.Status -eq "Stopped") {
                Write-Host "  [OK] Servicio se detuvo automaticamente" -ForegroundColor Green
                $appStopped = $true
            }
        } else {
            Write-Host "  Servicio '$serviceName' instalado pero detenido" -ForegroundColor Gray
        }
    }
    
    # Check for running Python processes on port 5000 (Flask default)
    $pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
        $_.CommandLine -like "*app.py*" -or $_.CommandLine -like "*api/app.py*"
    }
    
    if ($pythonProcesses) {
        Write-Host "  Encontrados $($pythonProcesses.Count) procesos Python ejecutandose:" -ForegroundColor Cyan
        foreach ($process in $pythonProcesses) {
            Write-Host "    PID $($process.Id): $($process.CommandLine)" -ForegroundColor Gray
        }
        
        try {
            $pythonProcesses | Stop-Process -Force -ErrorAction Stop
            Write-Host "  [OK] Procesos Python detenidos correctamente" -ForegroundColor Green
            $appStopped = $true
        } catch {
            Write-Host "  [ADVERTENCIA] No se pudieron detener algunos procesos Python: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    
    # Check if port 5000 is in use (alternative method)
    $portInUse = Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue
    if ($portInUse) {
        Write-Host "  Puerto 5000 esta en uso. Aplicacion puede estar ejecutandose." -ForegroundColor Yellow
        Write-Host "  [RECOMENDACION] Asegurese de que la aplicacion este completamente detenida" -ForegroundColor Yellow
    }
    
    if ($appStopped) {
        Write-Host "  Aplicacion detenida exitosamente" -ForegroundColor Green
        Start-Sleep -Seconds 2  # Give time for cleanup
    } else {
        Write-Host "  No se encontraron aplicaciones ejecutandose" -ForegroundColor Gray
    }
    
    Write-Host ""
}

# Rollback function
function Invoke-Rollback {
    param([string]$Reason)
    
    Write-Host ""
    Write-Host "=========================================" -ForegroundColor Red
    Write-Host "  INSTALACION FALLIDA - REVERTIENDO" -ForegroundColor Red
    Write-Host "=========================================" -ForegroundColor Red
    Write-Host ""
    Show-Error "Razon: $Reason"
    Write-Host ""
    Show-Info "Revirtiendo cambios..."
    
    # Remove created files
    foreach ($file in $script:installationChanges.FilesCreated) {
        if (Test-Path $file) {
            Remove-Item $file -Force -ErrorAction SilentlyContinue
            Show-Info "Eliminado: $file"
        }
    }
    
    # Remove created directories (in reverse order)
    $script:installationChanges.DirectoriesCreated | Sort-Object -Descending | ForEach-Object {
        if (Test-Path $_) {
            Remove-Item $_ -Recurse -Force -ErrorAction SilentlyContinue
            Show-Info "Eliminado: $_"
        }
    }
    
    if ($script:installationChanges.BackupPath) {
        Write-Host ""
        Show-Success "Backup preservado en: $($script:installationChanges.BackupPath)"
    }
    
    Write-Host ""
    Write-Host "Sistema revertido al estado anterior" -ForegroundColor Yellow
    if (-not $Silent) { Read-HostDefault "Presiona Enter para salir" "" }
    exit 1
}

# Helper function for progress
function Show-Step {
    param([int]$Step, [int]$Total, [string]$Message)
    
    $percent = [math]::Round(($Step / $Total) * 100)
    $completed = [math]::Floor($percent / 10)
    $remaining = 10 - $completed
    
    $progressBar = "[" + ("=" * $completed) + ("." * $remaining) + "]"
    
    Write-Host ""
    Write-Host "$progressBar $percent% " -NoNewline -ForegroundColor Cyan
    Write-Host "[$Step/$Total] $Message" -ForegroundColor Cyan
}

function Show-Success {
    param([string]$Message)
    Write-Host "  " -NoNewline
    Write-Host "[OK]" -NoNewline -ForegroundColor Green
    Write-Host " $Message" -ForegroundColor White
}

function Show-Error {
    param([string]$Message)
    Write-Host "  " -NoNewline
    Write-Host "[X]" -NoNewline -ForegroundColor Red
    Write-Host " $Message" -ForegroundColor White
}

function Show-Warning {
    param([string]$Message)
    Write-Host "  " -NoNewline
    Write-Host "[!]" -NoNewline -ForegroundColor Yellow
    Write-Host " $Message" -ForegroundColor White
}

function Show-Info {
    param([string]$Message)
    Write-Host "  " -NoNewline
    Write-Host "[-]" -NoNewline -ForegroundColor Gray
    Write-Host " $Message" -ForegroundColor Gray
}

function Read-HostDefault {
    param(
        [string]$Prompt,
        [string]$Default = ""
    )

    $suffix = if ([string]::IsNullOrWhiteSpace($Default)) { "" } else { " [$Default]" }
    $value = Read-Host "$Prompt$suffix"
    if ([string]::IsNullOrWhiteSpace($value)) {
        return $Default
    }
    return $value
}

function Normalize-PathInput {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $Value }
    return $Value.Trim().Trim('"').Trim("'")
}

function Is-MeaningfulConfig {
    param([hashtable]$Config)

    # Check if company name exists and is not a test/default value
    if (-not $Config.CompanyName -or $Config.CompanyName.Trim() -eq "") {
        return $false
    }

    # Check for common test/default company names
    $testCompanyNames = @(
        "Test Company",
        "Test Company Updated",
        "Empresa de Prueba",
        "Company Test",
        "Demo Company",
        "Sample Company",
        "Test",
        "Prueba"
    )

    $companyName = $Config.CompanyName.Trim()
    foreach ($testName in $testCompanyNames) {
        if ($companyName -eq $testName) {
            return $false
        }
    }

    # If we have a non-empty, non-test company name, consider it meaningful
    return $true
}

function Read-ConfigFile {
    param([string]$Path)
    
    if (-not (Test-Path $Path)) {
        return $null
    }
    
    $config = @{
        CompanyName = ""
        LogoPath = ""
    }
    
    try {
        $content = Get-Content $Path -Raw
        if ($content -match "company_name\s*=\s*(.+)") {
            $config.CompanyName = $matches[1].Trim()
        }
        if ($content -match "logo_path\s*=\s*(.+)") {
            $config.LogoPath = $matches[1].Trim()
        }
    } catch {
        # Ignore read errors
    }
    
    return $config
}

function Write-ConfigFile {
    param(
        [string]$InstallPath,
        [string]$CompanyName,
        [string]$LogoPath
    )

    $versionValue = ""
    $versionPath = Join-Path $PSScriptRoot "..\VERSION"
    if (Test-Path $versionPath) {
        $versionValue = (Get-Content $versionPath -Raw).Trim()
    }

    $configContent = @"
[COMPANY]
company_name = $CompanyName
company_address =
company_phone =
company_email =
company_website =
logo_path = $LogoPath
version = $versionValue
order_template_esp = config/order_template_esp.html
order_template_eng = config/order_template_eng.html
zoom = 0.8
name =
address =
phone =
email =
website =

[SERVER]
url = http://127.0.0.1:5000
"@

    $configDir = Join-Path $InstallPath "config"
    if (-not (Test-Path $configDir)) {
        New-Item -ItemType Directory -Path $configDir -Force | Out-Null
    }
    $configPath = Join-Path $configDir "config.ini"
    $configContent | Out-File -FilePath $configPath -Encoding UTF8
}

function Copy-LogoIfProvided {
    param(
        [string]$InstallPath,
        [string]$LogoPath,
        [string]$BasePath = $null
    )

    if ([string]::IsNullOrWhiteSpace($LogoPath)) {
        return ""
    }

    if ($LogoPath -match '^https?://') {
        return $LogoPath
    }

    $resolvedPath = $LogoPath
    if (-not [string]::IsNullOrWhiteSpace($BasePath) -and -not [System.IO.Path]::IsPathRooted($LogoPath)) {
        $candidate = Join-Path $BasePath $LogoPath
        if (Test-Path $candidate) {
            $resolvedPath = $candidate
        }
    }

    Write-Host "DEBUG: Copy-LogoIfProvided - LogoPath: '$LogoPath', resolvedPath: '$resolvedPath', exists: $(Test-Path $resolvedPath)" -ForegroundColor Yellow

    if (Test-Path $resolvedPath) {
        $logoExt = [System.IO.Path]::GetExtension($resolvedPath)
        if ([string]::IsNullOrWhiteSpace($logoExt)) {
            $logoExt = ".png"
        }
        $destName = "logo$logoExt"
        $destPath = Join-Path $InstallPath "api\static\$destName"
        Copy-Item -Path $resolvedPath -Destination $destPath -Force -ErrorAction SilentlyContinue
        Write-Host "DEBUG: Logo copied to: '$destName'" -ForegroundColor Yellow
        return $destName
    } else {
        Write-Host "[ADVERTENCIA] La ruta del logo no existe: $resolvedPath. Se usara el logo por defecto." -ForegroundColor Yellow
        # Return the original path so it's stored in config even if file doesn't exist
        Write-Host "DEBUG: Returning original path: '$LogoPath'" -ForegroundColor Yellow
        return $LogoPath
    }

    return ""
}

function Test-InstallIntegrity {
    param([string]$InstallPath)

    $requiredItems = @(
        "api\app.py",
        "api\database.py",
        "api\models.py",
        "api\init_users.py",
        "api\templates\index.html",
        "api\templates\login.html",
        "api\static\script.js",
        "api\static\style.css",
        "requirements.txt",
        "VERSION",
        "LICENSE",
        "bin\run.bat",
        "scripts\cleanup_installation.ps1",
        "scripts\cleanup_database.py"
    )

    $missing = @()
    foreach ($item in $requiredItems) {
        $path = Join-Path $InstallPath $item
        if (-not (Test-Path $path)) {
            $missing += $item
        }
    }

    return $missing
}

function Create-DesktopShortcut {
    param(
        [string]$Name,
        [string]$TargetPath,
        [string]$WorkingDirectory,
        [string]$Description
    )

    try {
        $desktop = [Environment]::GetFolderPath('Desktop')
        $shortcutPath = Join-Path $desktop "$Name.lnk"

        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut($shortcutPath)
        $Shortcut.TargetPath = $TargetPath
        $Shortcut.WorkingDirectory = $WorkingDirectory
        $Shortcut.Description = $Description
        $Shortcut.Save()
        return $true
    }
    catch {
        return $false
    }
}

# Create desktop shortcuts for service management
function Create-ServiceShortcuts {
    param(
        [string]$InstallDir
    )
    
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $serviceScript = Join-Path $InstallDir "utilities\service\service.bat"
    
    $shortcuts = @(
        @{
            Name = "Sistema Proveedores - Iniciar Servicio"
            Arguments = "start"
            Description = "Inicia el servicio de Sistema Proveedores"
        },
        @{
            Name = "Sistema Proveedores - Detener Servicio"
            Arguments = "stop"
            Description = "Detiene el servicio de Sistema Proveedores"
        },
        @{
            Name = "Sistema Proveedores - Reiniciar Servicio"
            Arguments = "restart"
            Description = "Reinicia el servicio de Sistema Proveedores"
        },
        @{
            Name = "Sistema Proveedores - Estado del Servicio"
            Arguments = "status"
            Description = "Muestra el estado del servicio de Sistema Proveedores"
        }
    )
    
    $shell = New-Object -ComObject WScript.Shell
    
    foreach ($shortcut in $shortcuts) {
        $shortcutPath = Join-Path $desktopPath "$($shortcut.Name).lnk"
        
        try {
            $shortcutObj = $shell.CreateShortcut($shortcutPath)
            $shortcutObj.TargetPath = $serviceScript
            $shortcutObj.Arguments = $shortcut.Arguments
            $shortcutObj.WorkingDirectory = $InstallDir
            $shortcutObj.Description = $shortcut.Description
            $shortcutObj.IconLocation = "shell32.dll,1"  # Default icon
            $shortcutObj.Save()
            
            Write-Host "  ✓ $($shortcut.Name)" -ForegroundColor Green
        } catch {
            Write-Host "  ✗ $($shortcut.Name) - Error: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
}

function Create-ManualShortcut {
    param(
        [string]$InstallDir
    )
    
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $runScript = Join-Path $InstallDir "run.bat"
    
    $shortcutPath = Join-Path $desktopPath "Sistema Proveedores - Ejecutar Manual.lnk"
    
    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcutObj = $shell.CreateShortcut($shortcutPath)
        $shortcutObj.TargetPath = $runScript
        $shortcutObj.WorkingDirectory = $InstallDir
        $shortcutObj.Description = "Ejecuta el Sistema de Proveedores manualmente"
        $shortcutObj.IconLocation = "shell32.dll,1"  # Default icon
        $shortcutObj.Save()
        
        Write-Host "  ✓ Sistema Proveedores - Ejecutar Manual" -ForegroundColor Green
    } catch {
        Write-Host "  ✗ Sistema Proveedores - Ejecutar Manual - Error: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

function Install-Service {
    param(
        [string]$InstallPath
    )
    
    Write-Host "Instalando servicio de Windows..." -ForegroundColor Gray
    
    $serviceScript = Join-Path $InstallPath "utilities\service\service.ps1"
    if (Test-Path $serviceScript) {
        try {
            # First, try to remove any existing service
            Write-Host "Verificando y removiendo servicio existente..." -ForegroundColor Gray
            $serviceName = "SistemaProveedores"
            
            # Try to stop and remove with sc.exe (with elevation)
            try {
                Start-Process -FilePath "sc.exe" -ArgumentList "stop $serviceName" -Wait -Verb RunAs 2>$null
                Start-Sleep -Seconds 2
                Start-Process -FilePath "sc.exe" -ArgumentList "delete $serviceName" -Wait -Verb RunAs 2>$null
                Write-Host "Servicio existente removido con sc.exe" -ForegroundColor Gray
            } catch {
                # Ignore errors
            }
            
            Start-Sleep -Seconds 2
            
            Write-Host "Ejecutando instalacion del servicio..." -ForegroundColor Gray
            # Run service installation with admin privileges
            # Note: Cannot combine -Verb RunAs with output redirection, so we rely on service script's internal logging
            $serviceResult = Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$serviceScript`" -Action install -ProjectRoot `"$InstallPath`"" -WorkingDirectory $InstallPath -Wait -PassThru -Verb RunAs
            if ($serviceResult.ExitCode -eq 0) {
                Write-Host "Servicio instalado correctamente" -ForegroundColor Green
                $installLog = Join-Path $InstallPath "utilities\logs\service.log"
                if (Test-Path $installLog) {
                    Write-Host "  Log: $installLog" -ForegroundColor Gray
                }
                
                # Start the service with admin privileges
                Write-Host "Iniciando servicio..." -ForegroundColor Gray
                $startResult = Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$serviceScript`" -Action start -ProjectRoot `"$InstallPath`"" -WorkingDirectory $InstallPath -Wait -PassThru -Verb RunAs
                if ($startResult.ExitCode -eq 0) {
                    Write-Host "Servicio iniciado correctamente" -ForegroundColor Green
                    $startLog = Join-Path $InstallPath "utilities\logs\service.log"
                    if (Test-Path $startLog) {
                        Write-Host "  Log: $startLog" -ForegroundColor Gray
                    }
                    
                    # Verify the service is actually running
                    Write-Host "Verificando que el servicio este ejecutandose..." -ForegroundColor Gray
                    Start-Sleep -Seconds 5
                    
                    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
                    if ($service -and $service.Status -eq "Running") {
                        Write-Host "Servicio confirmado ejecutandose" -ForegroundColor Green
                        
                        # Test web service health
                        Write-Host "Verificando conectividad web..." -ForegroundColor Gray
                        try {
                            $webResponse = Invoke-WebRequest -Uri "http://localhost:5000" -TimeoutSec 10 -ErrorAction Stop
                            if ($webResponse.StatusCode -eq 200) {
                                Write-Host "Aplicacion web respondiendo correctamente" -ForegroundColor Green
                                
                                # Create desktop shortcuts
                                Write-Host "Creando accesos directos..." -ForegroundColor Gray
                                Create-ServiceShortcuts -InstallDir $InstallPath
                                
                                return $true
                            } else {
                                Write-Host "Aplicacion web respondio con codigo $($webResponse.StatusCode)" -ForegroundColor Yellow
                                return $false
                            }
                        } catch {
                            Write-Host "Aplicacion web no responde: $($_.Exception.Message)" -ForegroundColor Red
                            return $false
                        }
                    } else {
                        Write-Host "Servicio no esta ejecutandose despues del inicio" -ForegroundColor Red
                        return $false
                    }
                } else {
                    Write-Host "Fallo al iniciar el servicio (codigo: $($startResult.ExitCode))" -ForegroundColor Red
                    Write-Host "  Log: $startLog" -ForegroundColor Yellow
                    return $false
                }
            } else {
                Write-Host "Fallo al instalar el servicio (codigo: $($serviceResult.ExitCode))" -ForegroundColor Red
                # Show the service log contents to help with debugging
                $installLog = Join-Path $InstallPath "utilities\logs\service.log"
                if (Test-Path $installLog) {
                    Write-Host "  Contenido del log de servicio:" -ForegroundColor Yellow
                    Write-Host "  --------------------------------" -ForegroundColor Yellow
                    try {
                        $logContent = Get-Content $installLog -Tail 20  # Show last 20 lines
                        foreach ($line in $logContent) {
                            Write-Host "  $line" -ForegroundColor Gray
                        }
                    } catch {
                        Write-Host "  No se pudo leer el log: $($_.Exception.Message)" -ForegroundColor Red
                    }
                    Write-Host "  --------------------------------" -ForegroundColor Yellow
                    Write-Host "  Log completo: $installLog" -ForegroundColor Yellow
                } else {
                    Write-Host "  Log de servicio no encontrado en: $installLog" -ForegroundColor Red
                }
                return $false
            }
        } catch {
            Write-Host "Error al instalar el servicio: $($_.Exception.Message)" -ForegroundColor Red
            return $false
        }
    } else {
        Write-Host "Script de servicio no encontrado: $serviceScript" -ForegroundColor Red
        return $false
    }
}

# Banner
Write-Host ""
Write-Host "===========================================================" -ForegroundColor Cyan
Write-Host "  SISTEMA DE PROVEEDORES E INVENTARIO v$VERSION" -ForegroundColor Cyan
Write-Host "  Instalacion Automatica con Migracion Inteligente" -ForegroundColor Cyan
Write-Host "===========================================================" -ForegroundColor Cyan
Write-Host ""

# ============================================================
# STEP 1: Verify Python
# ============================================================
Show-Step 1 8 "Verificando Python"

$pythonCmd = $null
$pythonVersions = @("python3", "python")

foreach ($cmd in $pythonVersions) {
    try {
        $versionOutput = & $cmd --version 2>&1
        if ($versionOutput -match "Python 3\.(\d+)\.(\d+)") {
            $major = [int]$Matches[1]
            if ($major -ge $MIN_PYTHON_VERSION[1]) {
                $pythonCmd = $cmd
                Show-Success "Python encontrado: $versionOutput"
                break
            }
        }
    } catch {
        continue
    }
}

if (-not $pythonCmd) {
    Show-Error "Python 3.8+ no encontrado"
    Write-Host ""
    Write-Host "Descarga Python desde: https://www.python.org/downloads/" -ForegroundColor Yellow
    Write-Host "Asegurate de marcar 'Add Python to PATH' durante la instalacion" -ForegroundColor Yellow
    Write-Host ""
    if (-not $Silent) { Read-HostDefault "Presiona Enter para salir" "" }
    exit 1
}

# ============================================================
# STEP 2: Get Installation Path
# ============================================================
Show-Step 2 8 "Configuración de Instalación"

# Installation will automatically stop any running instances
Write-Host ""

if ($InstallPath) {
    $installPath = Normalize-PathInput $InstallPath
    Write-Host "  Ubicacion especificada: $installPath" -ForegroundColor Gray
} else {
    $defaultPath = "C:\SistemaProveedores"
    Write-Host ""
    Write-Host "  Ubicacion por defecto: $defaultPath" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Presiona ENTER para usar por defecto, o escribe una nueva ruta:" -ForegroundColor White
    $installPath = Normalize-PathInput (Read-HostDefault "  " $defaultPath)
}

# Stop any running instances before installation
Stop-RunningApp -InstallPath $installPath

Show-Info "Instalando en: $installPath"

# ============================================================
# STEP 3: Detect Existing Installation
# ============================================================
Show-Step 3 8 "Detectando Instalación Existente"

$installInfo = Get-InstallationInfo -Path $installPath -CurrentVersion $VERSION

if ($installInfo.Exists) {
    Write-Host ""
    Write-Host "  |==================================================|" -ForegroundColor Yellow
    Write-Host "  |  INSTALACION EXISTENTE DETECTADA                 |" -ForegroundColor Yellow
    Write-Host "  |==================================================|" -ForegroundColor Yellow
    Write-Host ""
    Show-Info "Versión detectada: v$($installInfo.Version)"
    Show-Info "Estructura: $($installInfo.Structure)"
    
    if ($installInfo.HasData) {
        $dbSizeKB = [math]::Round($installInfo.DatabaseSize / 1KB, 2)
        $msg = "Base de datos encontrada ($dbSizeKB KB)"
        Show-Success $msg
    }
    
    if ($installInfo.ConfigPath) {
        Show-Success "Configuracion encontrada"
    }
    
    Write-Host ""
    Write-Host "  Se realizara:" -ForegroundColor White
    Show-Info "1. Backup completo automatico"
    Show-Info "2. Instalacion de nueva estructura v$VERSION"
    Show-Info "3. Migracion inteligente de datos"
    Show-Info "4. Inicializacion del sistema"
    Write-Host ""
    Write-Host "  ATENCION: Tus datos NO se perderan - se creara backup" -ForegroundColor Cyan
    Write-Host ""
    
    # Auto-continue after 5 seconds or user input (skip in silent mode)
    if (-not $Silent) {
        Write-Host "  Continuando en 5 segundos (presiona cualquier tecla para continuar ahora)..." -ForegroundColor Gray
        $timeout = 5
        $startTime = Get-Date
        while (((Get-Date) - $startTime).TotalSeconds -lt $timeout) {
            try {
                if ([Console]::KeyAvailable) {
                    [Console]::ReadKey($true) | Out-Null
                    break
                }
            } catch {
                # Console input not available (redirected or no console)
                break
            }
            Start-Sleep -Milliseconds 100
        }
    } else {
        Write-Host "  Modo silencioso - continuando automaticamente..." -ForegroundColor Gray
        Start-Sleep -Seconds 1
    }
    
} else {
    # ============================================================
    # STEP 4: New Installation
    # ============================================================
    Show-Step 4 8 "Preparando Instalación Nueva"
    
    Show-Info "Instalacion nueva (no se encontro instalacion previa)"
    
    # Create directory
    if (-not (Test-Path $installPath)) {
        New-Item -ItemType Directory -Path $installPath -Force | Out-Null
        $script:installationChanges.DirectoriesCreated += $installPath
        Show-Success "Directorio creado: $installPath"
    } else {
        Show-Info "Directorio ya existe"
    }
}

# ============================================================
# Company & Logo Configuration
# ============================================================

# Initialize variables from command line parameters
$companyName = $CompanyName
$logoPath = $LogoPath
$useExistingConfig = $false

# Try to read parameters from installer parameter file (only if not provided via command line)
$paramFile = Join-Path $PSScriptRoot "installer_params.txt"
$altParamFile = Join-Path (Split-Path $PSScriptRoot -Parent) "installer_params.txt"
$paramFiles = @($paramFile, $altParamFile)

Write-Host "=== DEBUG: Parameter File ===" -ForegroundColor Cyan
Write-Host "Parameter file paths:" -ForegroundColor Gray
Write-Host "  Primary: '$paramFile'" -ForegroundColor Gray
Write-Host "  Alternate: '$altParamFile'" -ForegroundColor Gray

$foundParamFile = $null
foreach ($pf in $paramFiles) {
    Write-Host "  Checking: '$pf' - Exists: $(Test-Path $pf)" -ForegroundColor Gray
    if (Test-Path $pf) {
        $foundParamFile = $pf
        break
    }
}

if ($foundParamFile) {
    Write-Host "Using parameter file: '$foundParamFile'" -ForegroundColor Gray
    $paramContent = Get-Content $foundParamFile -Raw
    Write-Host "Parameter file content:" -ForegroundColor Gray
    Write-Host $paramContent -ForegroundColor Gray
} else {
    Write-Host "Parameter file not found in any location" -ForegroundColor Gray
}
Write-Host "===========================" -ForegroundColor Cyan
Write-Host ""

if ($foundParamFile) {
    try {
        $paramContent = Get-Content $foundParamFile -Raw
        $paramLines = $paramContent -split "`r`n" | Where-Object { $_ -match "^(\w+)=(.*)$" }
        foreach ($line in $paramLines) {
            if ($line -match "^COMPANYNAME=(.*)$" -and -not $companyName) {
                $companyName = $matches[1]
            } elseif ($line -match "^LOGOPATH=(.*)$" -and -not $logoPath) {
                $logoPath = $matches[1]
            }
        }
        # Clean up the parameter file after reading
        try {
            Remove-Item $foundParamFile -Force -ErrorAction SilentlyContinue
            Write-Host "Cleaned up parameter file: '$foundParamFile'" -ForegroundColor Gray
        } catch {
            Write-Host "Warning: Could not clean up parameter file: '$foundParamFile'" -ForegroundColor Yellow
        }
    } catch {
        # Ignore parameter file errors
    }
}

# Also check environment variables as fallback
if ([string]::IsNullOrEmpty($companyName) -and $env:PROVEEDORES_COMPANYNAME) {
    $companyName = $env:PROVEEDORES_COMPANYNAME
    Write-Host "Company name from environment: '$companyName'" -ForegroundColor Gray
}
if ([string]::IsNullOrEmpty($logoPath) -and $env:PROVEEDORES_LOGOPATH) {
    $logoPath = $env:PROVEEDORES_LOGOPATH
    Write-Host "Logo path from environment: '$logoPath'" -ForegroundColor Gray
}

# Debug: Show parameters being used
Write-Host "=== DEBUG: Parameters ===" -ForegroundColor Cyan
Write-Host "Company Name: '$companyName'" -ForegroundColor Gray
Write-Host "Logo Path: '$logoPath'" -ForegroundColor Gray
Write-Host "Install Path: '$installPath'" -ForegroundColor Gray
Write-Host "Silent Mode: $Silent" -ForegroundColor Gray
Write-Host "No Shortcuts: $NoShortcuts" -ForegroundColor Gray
Write-Host "No Service: $NoService" -ForegroundColor Gray
Write-Host "Cleanup: $Cleanup" -ForegroundColor Gray
Write-Host "Remove Backups: $RemoveBackups" -ForegroundColor Gray
Write-Host "Service Install Only: $ServiceInstallOnly" -ForegroundColor Gray
Write-Host "Upgrade Mode: $Upgrade" -ForegroundColor Gray
Write-Host "Fresh Install Mode: $FreshInstall" -ForegroundColor Gray
Write-Host "========================" -ForegroundColor Cyan
Write-Host ""

# ============================================================
# STEP 3.5: Fresh Install Cleanup (if requested)
# ============================================================

if ($FreshInstall -and $installInfo.Exists) {
    Write-Host ""
    Show-Info "Modo instalacion nueva - eliminando instalacion existente"
    
    try {
        # Stop any running services or processes before wiping
        Write-Host "Deteniendo servicios y procesos existentes..." -ForegroundColor Yellow
        
        # Stop Windows service if it exists
        $serviceName = "SistemaProveedores"
        $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if ($service) {
            if ($service.Status -eq "Running") {
                Stop-Service -Name $serviceName -Force -ErrorAction Stop
                Write-Host "  Servicio '$serviceName' detenido" -ForegroundColor Green
            }
        }
        
        # Stop Python processes
        $pythonProcesses = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object {
            $_.CommandLine -like "*app.py*" -or $_.CommandLine -like "*api/app.py*"
        }
        if ($pythonProcesses) {
            $pythonProcesses | Stop-Process -Force -ErrorAction Stop
            Write-Host "  Procesos Python detenidos" -ForegroundColor Green
        }
        
        Start-Sleep -Seconds 2  # Give time for cleanup
        
        # Remove all files and directories from install path
        Write-Host "Eliminando archivos existentes..." -ForegroundColor Yellow
        Get-ChildItem -Path $installPath -Recurse -Force | Remove-Item -Recurse -Force -ErrorAction Stop
        Write-Host "Instalacion existente eliminada completamente" -ForegroundColor Green
        
        # Reset installInfo since we wiped everything
        $installInfo.Exists = $false
        $installInfo.Version = $null
        $installInfo.ConfigPath = $null
        $installInfo.DatabasePath = $null
        
    } catch {
        Write-Host "ERROR: No se pudo eliminar la instalacion existente: $($_.Exception.Message)" -ForegroundColor Red
        if (-not $Silent) {
            $continue = Read-HostDefault "¿Continuar de todos modos? (S/N): " "N"
            if ($continue -notin @('S', 's')) {
                Write-Host "Instalacion cancelada." -ForegroundColor Yellow
                exit 1
            }
        } else {
            Write-Host "Modo silencioso: continuando..." -ForegroundColor Yellow
        }
    }
}

# ============================================================
# STEP 4: Create Backup (only for upgrades, not fresh installs)
# ============================================================
if ($installInfo.Exists -and -not $FreshInstall) {
    Show-Step 4 8 "Creando Backup de Seguridad"
    
    Write-Host "DEBUG: InstallInfo before backup:" -ForegroundColor Yellow
    Write-Host "  Version: $($installInfo.Version)" -ForegroundColor Yellow
    Write-Host "  ConfigPath: $($installInfo.ConfigPath)" -ForegroundColor Yellow
    Write-Host "  DatabasePath: $($installInfo.DatabasePath)" -ForegroundColor Yellow

    $backup = New-InstallationBackup -InstallPath $installPath -InstallInfo $installInfo

    if ($backup.Success) {
        $script:installationChanges.BackupPath = $backup.Path
        Show-Success ("Backup creado: " + (Split-Path $backup.Path -Leaf))
        foreach ($file in $backup.Files) {
            Show-Info $file
        }
        
        # Read existing config from backup to prompt user
        $backupConfigPath = Join-Path $backup.Path "config\config.ini"
        if (Test-Path $backupConfigPath) {
            $existingConfig = Read-ConfigFile -Path $backupConfigPath
            if ($existingConfig -and (Is-MeaningfulConfig -Config $existingConfig)) {
                Write-Host ""
                Show-Info "Configuracion existente encontrada en backup"
                Write-Host "Se detecto configuracion existente:" -ForegroundColor Yellow
                Write-Host "  Empresa: " -NoNewline -ForegroundColor White
                Write-Host ($(if ($existingConfig.CompanyName) { $existingConfig.CompanyName } else { "(vacio)" })) -ForegroundColor Gray
                Write-Host "  Logo:    " -NoNewline -ForegroundColor White
                Write-Host ($(if ($existingConfig.LogoPath) { $existingConfig.LogoPath } else { "(vacio)" })) -ForegroundColor Gray

                if ($Upgrade) {
                    # In upgrade mode, use existing config if no parameters provided
                    if (-not $CompanyName -or [string]::IsNullOrWhiteSpace($CompanyName)) {
                        $companyName = $existingConfig.CompanyName
                    }
                    if (-not $LogoPath -or [string]::IsNullOrWhiteSpace($LogoPath)) {
                        $logoPath = $existingConfig.LogoPath
                    }
                    $useExistingConfig = $true
                    Write-Host "Modo actualizacion: usando configuracion existente donde no se especifico" -ForegroundColor Green
                } elseif ((-not $CompanyName -or [string]::IsNullOrWhiteSpace($CompanyName)) -and (-not $LogoPath -or [string]::IsNullOrWhiteSpace($LogoPath)) -and $companyName -eq "" -and $logoPath -eq "" -and -not $Silent) {
                    $keepConfig = (Read-HostDefault "Deseas conservarla? (S/N): " "S") -in @('S', 's')
                    if ($keepConfig) {
                        $companyName = $existingConfig.CompanyName
                        $logoPath = $existingConfig.LogoPath
                        $useExistingConfig = $true
                        Write-Host "Configuracion existente conservada" -ForegroundColor Green
                    }
                } elseif (($CompanyName -and (-not ([string]::IsNullOrWhiteSpace($CompanyName)))) -or ($LogoPath -and (-not ([string]::IsNullOrWhiteSpace($LogoPath))))) {
                    Write-Host "Parametros de linea de comandos detectados, usando configuracion nueva..." -ForegroundColor Gray
                }
            }
        }
    } else {
        Invoke-Rollback "Fallo al crear backup: $($backup.Error)"
    }
} else {
    if ($FreshInstall) {
        Show-Step 4 8 "Instalacion Nueva (instalacion previa eliminada)"
        Write-Host "  [-] Instalacion fresca completada (instalacion previa eliminada)" -ForegroundColor Gray
    } else {
        Show-Step 4 8 "Instalacion Nueva (sin backup necesario)"
        Write-Host "  [-] Instalacion nueva (no se encontro instalacion previa)" -ForegroundColor Gray
    }
}

# ============================================================
# STEP 4.5: Configure Company Settings (if not using existing config)
# ============================================================

if (-not $useExistingConfig) {
    Write-Host ""
    Show-Info "Configuracion de empresa"

    if ($CompanyName -and -not [string]::IsNullOrWhiteSpace($CompanyName)) {
        $companyName = $CompanyName
        Write-Host "Nombre de empresa: $companyName" -ForegroundColor Gray
    } elseif (-not $Silent) {
        $companyName = Read-HostDefault "Nombre de tu empresa (opcional, ENTER para omitir)" ""
    } elseif ($env:PROVEEDORES_COMPANYNAME) {
        $companyName = $env:PROVEEDORES_COMPANYNAME
        Write-Host "Nombre de empresa (desde variable de entorno): $companyName" -ForegroundColor Gray
    } else {
        $companyName = ""
        Write-Host "Nombre de empresa: (omitido en modo silencioso)" -ForegroundColor Gray
    }

    if ($LogoPath -and -not [string]::IsNullOrWhiteSpace($LogoPath)) {
        $logoPath = Normalize-PathInput $LogoPath
        Write-Host "Logo: $logoPath" -ForegroundColor Gray
    } elseif (-not $Silent) {
        Write-Host "Logo de la empresa (opcional):" -ForegroundColor White
        Write-Host "Proporciona la ruta a tu logo (PNG/JPG/SVG)" -ForegroundColor Gray
        Write-Host "Si no tienes uno, presiona ENTER para omitir" -ForegroundColor Gray
        $logoPath = Normalize-PathInput (Read-HostDefault "Ruta completa al logo (o ENTER para omitir)" "")
    } elseif ($env:PROVEEDORES_LOGOPATH) {
        $logoPath = Normalize-PathInput $env:PROVEEDORES_LOGOPATH
        Write-Host "Logo (desde variable de entorno): $logoPath" -ForegroundColor Gray
    } else {
        $logoPath = ""
        Write-Host "Logo: (omitido en modo silencioso)" -ForegroundColor Gray
    }

    if (-not [string]::IsNullOrWhiteSpace($logoPath)) {
        if ($logoPath -match '^https?://') {
            # Keep URL as-is
        } elseif (-not (Test-Path $logoPath)) {
            Write-Host "[ADVERTENCIA] La ruta del logo no existe. Se usara el logo por defecto." -ForegroundColor Yellow
            $logoPath = ""
        }
    }
}

# ============================================================
# STEP 5: Install New Structure
# ============================================================
Show-Step 5 8 "Instalando Estructura Modular"

# Determine source path
# If -SourcePath was passed explicitly (e.g. from NSIS where files are already
# deployed to $INSTDIR), use it directly.  Otherwise derive from the ISS temp
# folder layout: {tmp}\installers\setup-auto.ps1 -> {tmp}\source
$currentDir = Get-Location
if ($SourcePath -and (Test-Path $SourcePath)) {
    $sourcePath = $SourcePath
} else {
    $tempDir = Split-Path $PSScriptRoot -Parent
    $sourcePath = Join-Path $tempDir "source"
}

if (-not (Test-Path (Join-Path $sourcePath "api\app.py"))) {
    Show-Error "No se encontraron archivos de instalacion en: $sourcePath"
    if (-not $Silent) { Read-HostDefault "Presiona Enter para salir" "" }
    exit 1
}

Show-Info "Fuente: $sourcePath"

# Install modular structure
$isUpgrade = [bool]$installInfo.Exists
$install = Install-ModularStructure -SourcePath $sourcePath -DestPath $installPath -IsUpgrade $isUpgrade

if ($install.Success) {
    # Track created directories
    foreach ($dir in $install.DirectoriesCreated) {
        $script:installationChanges.DirectoriesCreated += (Join-Path $installPath $dir)
    }
    Show-Success "$($install.DirectoriesCreated.Count) directorios creados"
    Show-Success "$($install.FilesCopied) archivos copiados"
} else {
    $errors = ($install.Errors -join ", ")
    Invoke-Rollback "Fallo al instalar estructura: $errors"
}

# Configure company name and logo
Write-Host "DEBUG: Writing config - companyName: '$companyName', logoPath: '$logoPath'" -ForegroundColor Yellow
$finalLogoPath = Copy-LogoIfProvided -InstallPath $installPath -LogoPath $logoPath
# If copy failed, use the original path
if ([string]::IsNullOrEmpty($finalLogoPath) -and -not [string]::IsNullOrEmpty($logoPath)) {
    $finalLogoPath = $logoPath
}
Write-Host "=== DEBUG: Final Config Values ===" -ForegroundColor Cyan
Write-Host "Company Name: '$companyName'" -ForegroundColor Gray
Write-Host "Logo Path: '$finalLogoPath'" -ForegroundColor Gray
Write-Host "================================" -ForegroundColor Cyan
Write-ConfigFile -InstallPath $installPath -CompanyName $companyName -LogoPath $finalLogoPath

# Update InstallInfo to include the new config path for backup
$configPath = Join-Path $installPath "config\config.ini"
if (Test-Path $configPath) {
    $installInfo.ConfigPath = $configPath
}

# ============================================================
# STEP 6: Initialize System
# ============================================================
Show-Step 6 8 "Inicializando Sistema"
Show-Info "Creando entorno virtual Python..."
$pyEnv = Initialize-PythonEnvironment -InstallPath $installPath -PythonCmd $pythonCmd

if ($pyEnv.Success) {
    Show-Success "Entorno virtual creado"
    Show-Success "Dependencias instaladas"
} else {
    $errors = ($pyEnv.Errors -join ", ")
    Invoke-Rollback "Fallo al crear entorno Python: $errors"
}
Show-Info "Inicializando base de datos..."
$dbInit = Initialize-Database -InstallPath $installPath -CreateDefaultAdmin $true

if ($dbInit.Success) {
    Show-Success "Base de datos inicializada"
    
    if ($dbInit.AdminCreated) {
        Show-Success "Usuario administrador creado"
    }
} else {
    $errors = ($dbInit.Errors -join ", ")
    Invoke-Rollback "Fallo al inicializar base de datos: $errors"
}

# ============================================================
# STEP 7: Migrate Data (if upgrading)
# ============================================================
if ($installInfo.Exists -and $installInfo.HasData) {
    Show-Step 7 8 "Migrando Datos"
    
    Show-Info "Migrando datos desde v$($installInfo.Version)..."
    
    $sourceDb = $installInfo.DatabasePath
    $destDb = Join-Path $installPath "data\suppliers.db"
    
    # Resolve both paths to detect in-place upgrades (source == dest).
    # Running migrate_database.py with the same file for both source and
    # destination causes DELETE to commit before INSERT can, wiping all data.
    $resolvedSource = if ($sourceDb -and (Test-Path $sourceDb)) { (Resolve-Path $sourceDb).Path } else { $sourceDb }
    $resolvedDest   = if ($destDb   -and (Test-Path $destDb))   { (Resolve-Path $destDb).Path   } else { $destDb }
    $isSameDb = $resolvedSource -and $resolvedDest -and ($resolvedSource.TrimEnd('\') -ieq $resolvedDest.TrimEnd('\'))
    
    if ($isSameDb) {
        Show-Info "Base de datos ya esta en la ubicacion correcta (actualizacion en sitio) - omitiendo migracion de datos"

        # In-place upgrade: apply any new schema changes and seed new LOV data.
        # These scripts are fully idempotent (add_column_if_not_exists / insert-if-empty).
        $pythonExe = Join-Path $installPath "venv\Scripts\python.exe"

        $schemaScript = Join-Path $installPath "api\migrate_db_schema.py"
        if (Test-Path $schemaScript) {
            Show-Info "Aplicando cambios de esquema..."
            Push-Location $installPath
            & $pythonExe $schemaScript 2>&1 | ForEach-Object { Write-Host "  [schema] $_" -ForegroundColor Gray }
            Pop-Location
            if ($LASTEXITCODE -eq 0) { Show-Success "Esquema actualizado" } else { Show-Warning "migrate_db_schema.py termino con codigo $LASTEXITCODE" }
        }

        $lovsScript = Join-Path $installPath "api\init_lovs.py"
        if (Test-Path $lovsScript) {
            Show-Info "Verificando datos LOV..."
            Push-Location $installPath
            & $pythonExe $lovsScript 2>&1 | ForEach-Object { Write-Host "  [lovs] $_" -ForegroundColor Gray }
            Pop-Location
            if ($LASTEXITCODE -eq 0) { Show-Success "Datos LOV verificados" } else { Show-Warning "init_lovs.py termino con codigo $LASTEXITCODE" }
        }

    } else {
    
    # Ensure destination DB schema exists before migrating data into it.
    # Initialize-Database already ran in Step 6, but guard here in case it was
    # skipped or the data dir was created after the fact.
    $pythonExe = Join-Path $installPath "venv\Scripts\python.exe"
    if (-not (Test-Path $destDb)) {
        Show-Info "Destino no existe aun - inicializando esquema antes de migrar..."
        Push-Location $installPath
        $initOut = & $pythonExe -c @"
import sys, os
sys.path.insert(0, os.getcwd())
from api.database import init_db
init_db()
print('DB_SCHEMA_OK')
"@ 2>&1
        $initOut | ForEach-Object { Write-Host "  [init] $_" -ForegroundColor Gray }
        Pop-Location
        if (-not (Test-Path $destDb)) {
            Show-Error "No se pudo crear el esquema de destino. Migracion cancelada."
            Show-Info "Los datos del backup siguen disponibles en: $($script:installationChanges.BackupPath)"
            # Skip migration but don't rollback - app will create fresh DB on first run
        }
    }

    $migration = Invoke-DatabaseMigration -SourceDb $sourceDb -DestDb $destDb -PythonCmd $pythonExe

    if ($migration.Success) {
        Show-Success "$($migration.RowsMigrated) registros migrados"
        foreach ($table in $migration.TablesProcessed) {
            Show-Info $table
        }
    } else {
        $errors=($migration.Errors -join ", ")
        Show-Error "Advertencia en migracion: $($errors)"
        Show-Info "Los datos del backup siguen disponibles"
    }

    } # end if -not isSameDb

    # --- Always: migrate/verify supplier contacts ---
    # Idempotent: skips suppliers that already have contacts; backfills
    # contact_type_id for v1.2.1 rows that still carry the legacy text column.
    # Runs for ALL upgrade scenarios: v0.1→v1.3, v1.0→v1.3, v1.2.1→v1.3, etc.
    $pythonExeContacts = Join-Path $installPath "venv\Scripts\python.exe"
    $contactsScript = Join-Path $installPath "scripts\migrate_supplier_contacts.py"
    if (Test-Path $contactsScript) {
        Show-Info "Migrando / verificando contactos de proveedores..."
        Push-Location $installPath
        $contactsOut = & $pythonExeContacts $contactsScript 2>&1
        $contactsOut | ForEach-Object { Write-Host "  [contacts] $_" -ForegroundColor Gray }
        Pop-Location
        if ($LASTEXITCODE -eq 0) {
            Show-Success "Contactos de proveedores actualizados"
        } else {
            Show-Warning "Migracion de contactos termino con advertencias (codigo: $LASTEXITCODE)"
        }
    } else {
        Show-Warning "Script de migracion de contactos no encontrado: $contactsScript"
    }
}

# ============================================================
# Installation Complete
# ============================================================

# Cleanup old structure files if this was an upgrade
if ($installInfo.Exists) {
    Write-Host ""
    Show-Info "Se detecto una instalacion previa."

    $cleanupScript = Join-Path $installPath "scripts\cleanup_installation.ps1"

    # Old structure (v0.1 flat layout) → always clean up leftover files automatically.
    # Same structure (v1.x in-place) → only run cleanup if user/NSIS requested it.
    $isOldStructure = ($installInfo.Structure -eq 'flat')  # v0.1

    if ($isOldStructure) {
        # Auto-cleanup old v0.1 artifacts (no prompt needed - they are superseded files)
        $doCleanup = $true
        Write-Host "[INFO] Estructura v0.1 detectada - limpiando archivos antiguos automaticamente" -ForegroundColor Yellow
        # Backup removal: still ask (in silent mode honour -RemoveBackups flag)
        if ($Silent) {
            $removeBackups = $RemoveBackups
        } else {
            $removeBackups = (Read-HostDefault "Eliminar respaldos antiguos? (S/N): " "N") -in @('S', 's')
        }
    } else {
        # Same-structure upgrade: use NSIS/caller flags, prompt interactively if needed
        if ($Silent) {
            $doCleanup = $Cleanup
            $removeBackups = $RemoveBackups
        } else {
            $doCleanup = (Read-HostDefault "Deseas ejecutar la limpieza de archivos antiguos? (S/N): " "S") -in @('S', 's')
            $removeBackups = $false
            if ($doCleanup) {
                $removeBackups = (Read-HostDefault "Eliminar respaldos antiguos tambien? (S/N): " "N") -in @('S', 's')
            }
        }
    }

    Write-Host "Cleanup de estructura antigua: $doCleanup" -ForegroundColor Gray
    Write-Host "Eliminar backups:             $removeBackups" -ForegroundColor Gray
    Write-Host ""

    if ($doCleanup) {
        if (Test-Path $cleanupScript) {
            Show-Info "Ejecutando limpieza de instalacion..."
            $cleanArgs = @('-ExecutionPolicy', 'Bypass', '-File', $cleanupScript, '-InstallPath', $installPath, '-SkipSizeScan', '-Force')
            if ($removeBackups) { $cleanArgs += '-RemoveBackups' }
            & powershell @cleanArgs
        } else {
            Show-Error "No se encontro la utilidad de limpieza: $cleanupScript"
        }
    }
}

Write-Host ""
Write-Host "===========================================================" -ForegroundColor Green
Write-Host "  OK INSTALACION COMPLETADA EXITOSAMENTE" -ForegroundColor Green
Write-Host "===========================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Ubicacion: $installPath" -ForegroundColor White
Write-Host ""

# ============================================================
# SERVICE SETUP (Optional)
# ============================================================
Write-Host "==================================================================================" -ForegroundColor Cyan
Write-Host "  CONFIGURACION DE SERVICIO WINDOWS (OPCIONAL)" -ForegroundColor Cyan
Write-Host "==================================================================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "El sistema puede ejecutarse como un servicio de Windows que:" -ForegroundColor White
Write-Host "  - Se inicia automaticamente al encender la PC" -ForegroundColor Gray
Write-Host "  - Se reinicia automaticamente si falla" -ForegroundColor Gray
Write-Host "  - Maneja el despertar del modo suspension" -ForegroundColor Gray
Write-Host "  - Se ejecuta de forma invisible en segundo plano" -ForegroundColor Gray
Write-Host ""

if ($NoService) {
    $setupService = $false
    Write-Host "Servicio de Windows: No se instalara" -ForegroundColor Gray
} elseif ($Silent) {
    $setupService = $true
    Write-Host "Servicio de Windows: Se instalara automaticamente" -ForegroundColor Gray
} else {
    $setupService = (Read-HostDefault "Instalar como servicio de Windows? (S/N): " "S") -in @('S', 's')
}

Write-Host "=== DEBUG: Installation Decisions ===" -ForegroundColor Cyan
Write-Host "Setup Service: $setupService" -ForegroundColor Gray
Write-Host "===================================" -ForegroundColor Cyan
Write-Host ""

if ($setupService) {
    Write-Host ""
    Show-Info "Instalando servicio de Windows..."
    
    # Check if running as administrator
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    
    if (-not $isAdmin) {
        Show-Warning "Se requieren permisos de administrador para instalar el servicio"
        Write-Host ""
        if ($Silent) {
            $elevate = $true
            Write-Host "Modo silencioso: intentando elevar privilegios automaticamente..." -ForegroundColor Gray
        } else {
            $elevate = (Read-HostDefault "Elevar privilegios ahora? (S/N): " "S") -in @('S', 's')
        }
        
        if ($elevate) {
            Write-Host "Solicitando permisos de administrador..." -ForegroundColor Yellow
            
            # Get the current script path and arguments
            $scriptPath = $MyInvocation.MyCommand.Path
            $scriptArgs = "-ServiceInstallOnly -InstallPath `"$installPath`""
            
            try {
                # Restart the script with elevation
                $process = Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$scriptPath`" $scriptArgs" -Verb RunAs -Wait -PassThru
                
                if ($process.ExitCode -eq 0) {
                    Show-Success "Servicio instalado correctamente"
                    $serviceInstalled = $true
                } else {
                    Show-Error "Fallo al instalar el servicio (codigo: $($process.ExitCode))"
                    Show-Info "El resto de la instalacion continuara sin el servicio"
                    $serviceInstalled = $false
                }
            } catch {
                Show-Error "Error al solicitar elevacion: $($_.Exception.Message)"
                Show-Info "El resto de la instalacion continuara sin el servicio"
                $serviceInstalled = $false
            }
        } else {
            Show-Info "Continuando sin instalar el servicio"
            $serviceInstalled = $false
        }
    } else {
        # Already running as admin, install service directly
        $serviceInstalled = Install-Service -InstallPath $installPath
    }

Write-Host ""

# Check if service was installed and show appropriate instructions
$serviceExists = Get-Service -Name "SistemaProveedores" -ErrorAction SilentlyContinue

if ($serviceExists) {
    Write-Host "  Modo de ejecucion: " -NoNewline -ForegroundColor White
    Write-Host "Servicio Windows (Automatico)" -ForegroundColor Green
    Write-Host ""
    Write-Host "  El sistema se ejecuta automaticamente como servicio." -ForegroundColor Gray
    Write-Host "  Usa los accesos directos del escritorio para gestionar el servicio." -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Accesos directos creados:" -ForegroundColor White
    Write-Host "    - Sistema Proveedores - Iniciar Servicio" -ForegroundColor Cyan
    Write-Host "    - Sistema Proveedores - Detener Servicio" -ForegroundColor Cyan
    Write-Host "    - Sistema Proveedores - Reiniciar Servicio" -ForegroundColor Cyan
    Write-Host "    - Sistema Proveedores - Estado del Servicio" -ForegroundColor Cyan
} else {
    Write-Host "  Modo de ejecucion: " -NoNewline -ForegroundColor White
    Write-Host "Manual" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Para iniciar el servicio (manual):" -ForegroundColor White
    Write-Host "    1. Ejecuta: " -NoNewline -ForegroundColor Gray
    Write-Host "run.bat" -ForegroundColor Yellow
    Write-Host "    2. (Opcional) Usa el acceso directo del escritorio" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Creando acceso directo para ejecucion manual..." -ForegroundColor Yellow
    try {
        Create-ManualShortcut -InstallDir $installPath
        Show-Success "Acceso directo creado"
    } catch {
        Show-Warning "No se pudo crear el acceso directo: $($_.Exception.Message)"
    }
}
}

Write-Host "    3. Abre: " -NoNewline -ForegroundColor Gray
Write-Host "http://localhost:5000/login" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Credenciales por defecto:" -ForegroundColor White
Write-Host "    Email:    " -NoNewline -ForegroundColor Gray
Write-Host "admin@proveedores.com" -ForegroundColor Yellow
Write-Host "    Password: " -NoNewline -ForegroundColor Gray
Write-Host "admin123" -ForegroundColor Yellow
Write-Host ""
Write-Host "  ATENCION: Cambia la contrasena despues del primer login" -ForegroundColor Cyan
Write-Host ""

if ($installInfo.Exists) {
    Write-Host "  Backup disponible en:" -ForegroundColor White
    Write-Host ("    " + (Split-Path $backup.Path -Leaf)) -ForegroundColor Gray
    Write-Host ""
}

# Remove obsolete root start.bat if present
$rootStartBat = Join-Path $installPath "start.bat"
if (Test-Path $rootStartBat) {
    Remove-Item $rootStartBat -Force -ErrorAction SilentlyContinue
}

# Remove unused installer copy in bin
$binInstaller = Join-Path $installPath "bin\INSTALAR.bat"
if (Test-Path $binInstaller) {
    Remove-Item $binInstaller -Force -ErrorAction SilentlyContinue
}

# Remove old root run.bat if present
$rootRunBat = Join-Path $installPath "run.bat"
if (Test-Path $rootRunBat) {
    Remove-Item $rootRunBat -Force -ErrorAction SilentlyContinue
}

if ($NoShortcuts) {
    $createAppShortcut = $false
    Write-Host "Acceso directo de aplicacion: No se creara" -ForegroundColor Gray
} elseif ($Silent) {
    $createAppShortcut = $true
    Write-Host "Acceso directo de aplicacion: Se creara automaticamente" -ForegroundColor Gray
} else {
    $createAppShortcut = (Read-HostDefault "Deseas crear/actualizar acceso directo de la aplicacion? (S/N): " "S") -in @('S', 's')
}

Write-Host "=== DEBUG: Shortcut Decisions ===" -ForegroundColor Cyan
Write-Host "Create App Shortcut: $createAppShortcut" -ForegroundColor Gray
Write-Host "==============================" -ForegroundColor Cyan
Write-Host ""

if ($createAppShortcut) {
    $shortcutTarget = Join-Path $installPath "bin\run.bat"
    $desktop = @([Environment]::GetFolderPath('Desktop'))[0]
    $oldLinks = @(
        (Join-Path $desktop "Sistema Proveedores.lnk")
        (Join-Path $desktop "Sistema de Proveedores.lnk")
    )
    foreach ($link in $oldLinks) {
        if (Test-Path $link) { Remove-Item $link -Force -ErrorAction SilentlyContinue }
    }

    if (Create-DesktopShortcut -Name "Sistema Proveedores" -TargetPath $shortcutTarget -WorkingDirectory $installPath -Description "Sistema de Gestion de Proveedores") {
        Show-Success "Acceso directo de la aplicacion creado/actualizado"
    } else {
        Show-Error "No se pudo crear el acceso directo de la aplicacion"
    }
    Write-Host ""
}

if ($NoShortcuts) {
    $createWebShortcut = $false
    Write-Host "Acceso directo web: No se creara" -ForegroundColor Gray
} elseif ($Silent) {
    $createWebShortcut = $true
    Write-Host "Acceso directo web: Se creara automaticamente" -ForegroundColor Gray
} else {
    $createWebShortcut = (Read-HostDefault "Deseas crear/actualizar acceso directo de la web? (S/N): " "S") -in @('S', 's')
}

Write-Host "=== DEBUG: Web Shortcut Decision ===" -ForegroundColor Cyan
Write-Host "Create Web Shortcut: $createWebShortcut" -ForegroundColor Gray
Write-Host "=================================" -ForegroundColor Cyan
Write-Host ""

if ($createWebShortcut) {
    $desktop = @([Environment]::GetFolderPath('Desktop'))[0]
    $webShortcut = Join-Path $desktop "Sistema Proveedores Web.url"
    @(
        '[InternetShortcut]',
        'URL=http://localhost:5000/login'
    ) | Out-File -FilePath $webShortcut -Encoding ASCII -Force
    Show-Success "Acceso directo web creado/actualizado"
    Write-Host ""
}

Write-Host "==================================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "=== INSTALLER LOG ENDED $(Get-Date) ===" -ForegroundColor Yellow
Write-Host "COMPLETED"
Stop-Transcript

if (-not $Silent) {
    Read-HostDefault "Presiona Enter para salir" ""
}


# -*- coding: utf-8 -*-
"""Data import / export routes blueprint.

Covers:
  - Full database export/import  (/api/export/full, /api/import/full)
  - Supplier CSV / Excel import  (/api/suppliers/import/*)
"""
import os
import tempfile
from datetime import datetime
from io import BytesIO
from zipfile import ZipFile

import pandas as pd
from flask import Blueprint, jsonify, request, send_file, session
from sqlalchemy import select

from ..database import SessionLocal
from ..models import Item, Order, Supplier, SupplierContact, supplier_items
from .decorators import permission_required

data_io_bp = Blueprint('data_io', __name__)


# ---------------------------------------------------------------------------
# Full database export / import
# ---------------------------------------------------------------------------

@data_io_bp.route('/api/export/full', methods=['GET'])
@permission_required('export')
def export_full():
    """Export all data as Excel (multi-sheet) or CSV zip."""
    db = SessionLocal()
    try:
        fmt = request.args.get('format', 'excel').lower()

        from ..models import supplier_items as si_table
        suppliers = db.query(Supplier).all()
        items = db.query(Item).all()
        contacts = db.query(SupplierContact).all()
        orders = db.query(Order).all()
        supplier_items_rows = db.execute(select(si_table)).fetchall()

        df_suppliers = pd.DataFrame([s.to_dict(include_items=False, include_contacts=False) for s in suppliers])
        df_items = pd.DataFrame([i.to_dict(include_suppliers=False) for i in items])
        df_contacts = pd.DataFrame([c.to_dict() for c in contacts])
        df_orders = pd.DataFrame([o.to_dict() for o in orders])
        df_supplier_items = pd.DataFrame([dict(row._mapping) for row in supplier_items_rows])

        if fmt == 'excel':
            output = BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df_suppliers.to_excel(writer, sheet_name='suppliers', index=False)
                df_items.to_excel(writer, sheet_name='items', index=False)
                df_contacts.to_excel(writer, sheet_name='contacts', index=False)
                df_supplier_items.to_excel(writer, sheet_name='supplier_items', index=False)
                df_orders.to_excel(writer, sheet_name='orders', index=False)
            output.seek(0)
            return send_file(
                output,
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                as_attachment=True,
                download_name=f'proveedores_full_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
            )

        if fmt == 'csv':
            with tempfile.TemporaryDirectory() as tmpdir:
                paths = {}
                for name, df in [
                    ('suppliers', df_suppliers), ('items', df_items),
                    ('contacts', df_contacts), ('supplier_items', df_supplier_items),
                    ('orders', df_orders)
                ]:
                    path = os.path.join(tmpdir, f'{name}.csv')
                    df.to_csv(path, index=False)
                    paths[name] = path

                zip_name = f'proveedores_full_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.zip'
                zip_path = os.path.join(tmpdir, zip_name)
                with ZipFile(zip_path, 'w') as zipf:
                    for name, path in paths.items():
                        zipf.write(path, arcname=os.path.basename(path))
                with open(zip_path, 'rb') as f:
                    data = f.read()
                return send_file(
                    BytesIO(data),
                    mimetype='application/zip',
                    as_attachment=True,
                    download_name=zip_name
                )

        return jsonify({'error': 'Invalid format. Use excel or csv.'}), 400
    finally:
        db.close()


@data_io_bp.route('/api/import/full', methods=['POST'])
@permission_required('import')
def import_full():
    """Import all data from Excel (multi-sheet) or CSV zip."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    db = SessionLocal()
    try:
        from ..models import supplier_items as si_table
        filename = file.filename.lower()

        if filename.endswith('.xlsx') or filename.endswith('.xls'):
            excel = pd.ExcelFile(file)
            dfs = {sheet: excel.parse(sheet) for sheet in excel.sheet_names}
        elif filename.endswith('.zip'):
            with tempfile.TemporaryDirectory() as tmpdir:
                zip_path = os.path.join(tmpdir, file.filename)
                file.save(zip_path)
                dfs = {}
                with ZipFile(zip_path, 'r') as zipf:
                    for name in ['suppliers', 'items', 'contacts', 'supplier_items', 'orders']:
                        fname = f'{name}.csv'
                        if fname in zipf.namelist():
                            with zipf.open(fname) as fp:
                                dfs[name] = pd.read_csv(fp)
        else:
            return jsonify({'error': 'Unsupported file type'}), 400

        supplier_map = {}
        if 'suppliers' in dfs:
            for _, row in dfs['suppliers'].iterrows():
                supplier = None
                tax_id = row.get('tax_id')
                if pd.notna(tax_id) and str(tax_id).strip():
                    supplier = db.query(Supplier).filter(Supplier.tax_id == str(tax_id).strip()).first()
                if not supplier:
                    supplier = db.query(Supplier).filter(Supplier.name == str(row.get('name')).strip()).first()
                if not supplier:
                    supplier = Supplier()
                for col in row.index:
                    if hasattr(supplier, col):
                        setattr(supplier, col, row[col])
                db.add(supplier)
                db.flush()
                supplier_map[row['id']] = supplier.id

        item_map = {}
        if 'items' in dfs:
            for _, row in dfs['items'].iterrows():
                item = db.query(Item).filter(Item.item_code == str(row.get('item_code')).strip()).first()
                if not item:
                    item = Item()
                for col in row.index:
                    if hasattr(item, col):
                        setattr(item, col, row[col])
                db.add(item)
                db.flush()
                item_map[row['id']] = item.id

        if 'contacts' in dfs:
            for _, row in dfs['contacts'].iterrows():
                contact = SupplierContact()
                for col in row.index:
                    if hasattr(contact, col):
                        setattr(contact, col, row[col])
                if 'supplier_id' in row and row['supplier_id'] in supplier_map:
                    contact.supplier_id = supplier_map[row['supplier_id']]
                db.add(contact)

        if 'orders' in dfs:
            for _, row in dfs['orders'].iterrows():
                order = Order()
                for col in row.index:
                    if hasattr(order, col):
                        setattr(order, col, row[col])
                if 'supplier_id' in row and row['supplier_id'] in supplier_map:
                    order.supplier_id = supplier_map[row['supplier_id']]
                db.add(order)

        if 'supplier_items' in dfs:
            for _, row in dfs['supplier_items'].iterrows():
                sid = supplier_map.get(row['supplier_id'], row['supplier_id'])
                iid = item_map.get(row['item_id'], row['item_id'])
                stmt = select(si_table).where(
                    si_table.c.supplier_id == sid,
                    si_table.c.item_id == iid
                )
                if not db.execute(stmt).first():
                    db.execute(si_table.insert().values(
                        supplier_id=sid,
                        item_id=iid,
                        price=row.get('price'),
                        supplier_item_code=row.get('supplier_item_code'),
                        lead_time_days=row.get('lead_time_days'),
                        minimum_order_quantity=row.get('minimum_order_quantity'),
                        notes=row.get('notes'),
                        created_at=row.get('created_at'),
                        updated_at=row.get('updated_at')
                    ))

        db.commit()
        return jsonify({'success': True, 'message': 'Full import completed.'})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Supplier import routes
# ---------------------------------------------------------------------------

@data_io_bp.route('/api/suppliers/import/csv', methods=['POST'])
def import_csv():
    """Import suppliers from CSV file (legacy endpoint)."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    db = SessionLocal()
    try:
        df = pd.read_csv(file)
        count = 0
        errors = []

        for index, row in df.iterrows():
            try:
                name = row.get('name')
                if pd.isna(name) or not str(name).strip():
                    continue

                supplier = Supplier(
                    name=str(name).strip(),
                    contact_person=str(row.get('contact_person')).strip() if pd.notna(row.get('contact_person')) else None,
                    email=str(row.get('email')).strip() if pd.notna(row.get('email')) else None,
                    phone=str(row.get('phone')).strip() if pd.notna(row.get('phone')) else None,
                    address=str(row.get('address')).strip() if pd.notna(row.get('address')) else None,
                    city=str(row.get('city')).strip() if pd.notna(row.get('city')) else None,
                    country=str(row.get('country')).strip() if pd.notna(row.get('country')) else None,
                    tax_id=str(row.get('tax_id')).strip() if pd.notna(row.get('tax_id')) else None,
                    category=str(row.get('category')).strip() if pd.notna(row.get('category')) else None,
                    rating=float(row.get('rating', 0.0)) if pd.notna(row.get('rating')) else 0.0,
                    payment_terms=str(row.get('payment_terms')).strip() if pd.notna(row.get('payment_terms')) else None,
                    notes=str(row.get('notes')).strip() if pd.notna(row.get('notes')) else None,
                    active=int(row.get('active', 1))
                )
                db.add(supplier)
                count += 1
            except Exception as e:
                errors.append(f'Row {index + 2}: {str(e)}')

        db.commit()
        result = {'message': f'{count} suppliers imported successfully', 'count': count}
        if errors:
            result['errors'] = errors
        return jsonify(result)
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


@data_io_bp.route('/api/suppliers/import/excel', methods=['POST'])
@permission_required('import')
def import_excel():
    """Import suppliers from Excel or CSV with de-duplication and contact updates."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    db = SessionLocal()
    try:
        df = pd.read_csv(file) if file.filename.endswith('.csv') else pd.read_excel(file)

        created_count = 0
        updated_count = 0
        errors = []

        for index, row in df.iterrows():
            try:
                name = row.get('name')
                if pd.isna(name) or not str(name).strip():
                    continue

                name = str(name).strip()
                existing = None

                tax_id = row.get('tax_id')
                if pd.notna(tax_id) and str(tax_id).strip():
                    existing = db.query(Supplier).filter(Supplier.tax_id == str(tax_id).strip()).first()
                if not existing:
                    existing = db.query(Supplier).filter(Supplier.name == name).first()
                if not existing:
                    email = row.get('email')
                    if pd.notna(email) and str(email).strip():
                        existing = db.query(Supplier).filter(Supplier.email == str(email).strip()).first()

                # Helper: update field if non-empty and changed
                def _maybe_update(obj, attr, raw_val):
                    if pd.notna(raw_val) and str(raw_val).strip():
                        new_val = str(raw_val).strip()
                        if getattr(obj, attr) != new_val:
                            setattr(obj, attr, new_val)
                            return True
                    return False

                if existing:
                    updated = any([
                        _maybe_update(existing, 'contact_person', row.get('contact_person')),
                        _maybe_update(existing, 'email', row.get('email')),
                        _maybe_update(existing, 'phone', row.get('phone')),
                        _maybe_update(existing, 'address', row.get('address')),
                        _maybe_update(existing, 'city', row.get('city')),
                        _maybe_update(existing, 'country', row.get('country')),
                        _maybe_update(existing, 'category', row.get('category')),
                        _maybe_update(existing, 'payment_terms', row.get('payment_terms')),
                        _maybe_update(existing, 'notes', row.get('notes')),
                    ])
                    rating = row.get('rating')
                    if pd.notna(rating) and existing.rating != float(rating):
                        existing.rating = float(rating)
                        updated = True
                    active = row.get('active')
                    if pd.notna(active) and existing.active != int(active):
                        existing.active = int(active)
                        updated = True

                    existing.updated_at = datetime.utcnow()
                    existing.updated_by = session.get('user_id')
                    if updated:
                        updated_count += 1
                else:
                    def _str(v):
                        return str(v).strip() if pd.notna(v) else None

                    supplier = Supplier(
                        name=name,
                        contact_person=_str(row.get('contact_person')),
                        email=_str(row.get('email')),
                        phone=_str(row.get('phone')),
                        address=_str(row.get('address')),
                        city=_str(row.get('city')),
                        country=_str(row.get('country')),
                        tax_id=_str(tax_id),
                        category=_str(row.get('category')),
                        rating=float(row['rating']) if pd.notna(row.get('rating')) else 0.0,
                        payment_terms=_str(row.get('payment_terms')),
                        notes=_str(row.get('notes')),
                        active=int(row['active']) if pd.notna(row.get('active')) else 1,
                        created_by=session.get('user_id')
                    )
                    db.add(supplier)
                    created_count += 1

            except Exception as e:
                errors.append(f'Row {index + 2}: {str(e)}')

        db.commit()
        result = {
            'message': f'Import completed: {created_count} created, {updated_count} updated',
            'created': created_count,
            'updated': updated_count
        }
        if errors:
            result['errors'] = errors
        return jsonify(result)
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


@data_io_bp.route('/api/suppliers/import/items-excel', methods=['POST'])
@data_io_bp.route('/api/suppliers/import/with-items', methods=['POST'])
@permission_required('import')
def import_suppliers_with_items():
    """Import suppliers and their items from CSV or Excel.

    Required columns: supplier_name, item_code, item_name
    Optional: supplier_email, supplier_phone, supplier_city, supplier_country,
              item_description, item_category, unit, supplier_item_code,
              lead_time_days, minimum_order_quantity, notes, price
    """
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    db = SessionLocal()
    try:
        df = pd.read_csv(file) if file.filename.endswith('.csv') else pd.read_excel(file)

        required_columns = ['supplier_name', 'item_code', 'item_name']
        if not all(col in df.columns for col in required_columns):
            return jsonify({'error': f'File must contain columns: {", ".join(required_columns)}'}), 400

        imported_count = 0
        errors = []

        for index, row in df.iterrows():
            try:
                supplier = db.query(Supplier).filter(Supplier.name == row['supplier_name']).first()
                if not supplier:
                    supplier = Supplier(
                        name=row['supplier_name'],
                        email=row.get('supplier_email'),
                        phone=row.get('supplier_phone'),
                        address=row.get('supplier_address'),
                        city=row.get('supplier_city'),
                        country=row.get('supplier_country'),
                        tax_id=row.get('supplier_tax_id'),
                        created_by=session.get('user_id')
                    )
                    db.add(supplier)
                    db.flush()
                else:
                    # Update contact fields if provided
                    for attr, col in [
                        ('email', 'supplier_email'), ('phone', 'supplier_phone'),
                        ('address', 'supplier_address'), ('city', 'supplier_city'),
                        ('country', 'supplier_country'), ('tax_id', 'supplier_tax_id'),
                    ]:
                        val = row.get(col)
                        if pd.notna(val) and str(val).strip():
                            new_val = str(val).strip()
                            if getattr(supplier, attr) != new_val:
                                setattr(supplier, attr, new_val)
                    supplier.updated_at = datetime.utcnow()
                    supplier.updated_by = session.get('user_id')

                item = db.query(Item).filter(Item.item_code == row['item_code']).first()
                if not item:
                    item = Item(
                        item_code=row['item_code'],
                        name=row['item_name'],
                        description=row.get('item_description'),
                        category=row.get('item_category'),
                        unit=row.get('unit')
                    )
                    db.add(item)
                    db.flush()

                stmt = select(supplier_items).where(
                    (supplier_items.c.supplier_id == supplier.id) &
                    (supplier_items.c.item_id == item.id)
                )
                if not db.execute(stmt).first():
                    db.execute(supplier_items.insert().values(
                        supplier_id=supplier.id,
                        item_id=item.id,
                        price=float(row['price']) if pd.notna(row.get('price')) else None,
                        supplier_item_code=row.get('supplier_item_code'),
                        lead_time_days=int(row['lead_time_days']) if pd.notna(row.get('lead_time_days')) else None,
                        minimum_order_quantity=int(row['minimum_order_quantity']) if pd.notna(row.get('minimum_order_quantity')) else None,
                        notes=row.get('notes')
                    ))

                imported_count += 1
            except Exception as e:
                errors.append(f'Row {index + 2}: {str(e)}')

        db.commit()
        return jsonify({
            'message': f'Successfully imported {imported_count} supplier-item relationships',
            'errors': errors if errors else None
        })
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@data_io_bp.route('/api/suppliers/import/custom-excel', methods=['POST'])
def import_custom_excel():
    """Import suppliers and items from a custom multi-sheet Excel format.

    Expected sheets:
      - Materials sheet (e.g., Hoja4): No., item/Material, Proveedor, Costo
      - Suppliers sheet (e.g., Hoja2): Proveedor, Tipo de proveedor, Telefonos, Correo, Direccion
    """
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    db = SessionLocal()
    try:
        materials_sheet = request.form.get('materials_sheet', 'Hoja4')
        suppliers_sheet = request.form.get('suppliers_sheet', 'Hoja2')

        excel_file = pd.ExcelFile(file)
        available_sheets = excel_file.sheet_names

        # Resolve sheet names
        def _find_sheet(preferred, keywords):
            if preferred in available_sheets:
                return preferred
            for sheet in available_sheets:
                if any(kw in sheet.lower() for kw in keywords):
                    return sheet
            return None

        mat_sheet = _find_sheet(materials_sheet, ['hoja', 'material', 'item'])
        if not mat_sheet:
            return jsonify({'error': f'Materials sheet not found. Available: {", ".join(available_sheets)}'}), 400

        sup_sheet = _find_sheet(suppliers_sheet, ['proveedor'])

        imported_suppliers = 0
        imported_items = 0
        errors = []

        if sup_sheet:
            try:
                df_suppliers = pd.read_excel(excel_file, sheet_name=sup_sheet)
                for index, row in df_suppliers.iterrows():
                    try:
                        supplier_name = row.get('Proveedor')
                        if supplier_name is None or pd.isna(supplier_name) or not str(supplier_name).strip():
                            continue
                        supplier_name = str(supplier_name).strip()

                        existing = db.query(Supplier).filter(Supplier.name == supplier_name).first()
                        if not existing:
                            db.add(Supplier(
                                name=supplier_name,
                                category=str(row.get('Tipo de proveedor')).strip() if pd.notna(row.get('Tipo de proveedor')) else None,
                                phone=str(row.get('Telefonos')).strip() if pd.notna(row.get('Telefonos')) else None,
                                email=str(row.get('Correo')).strip() if pd.notna(row.get('Correo')) else None,
                                address=str(row.get('Direccion')).strip() if pd.notna(row.get('Direccion')) else None,
                                notes=str(row.get('Relacion Comercial')).strip() if pd.notna(row.get('Relacion Comercial')) else None,
                                active=1,
                                created_by=session.get('user_id')
                            ))
                            imported_suppliers += 1
                        else:
                            for attr, col in [
                                ('phone', 'Telefonos'), ('email', 'Correo'),
                                ('address', 'Direccion'), ('category', 'Tipo de proveedor'),
                                ('notes', 'Relacion Comercial'),
                            ]:
                                val = row.get(col)
                                if pd.notna(val) and str(val).strip():
                                    new_val = str(val).strip()
                                    if getattr(existing, attr) != new_val:
                                        setattr(existing, attr, new_val)
                            existing.updated_at = datetime.utcnow()
                            existing.updated_by = session.get('user_id')
                    except Exception as e:
                        errors.append(f'Supplier row {index + 2}: {str(e)}')
                db.commit()
            except Exception as e:
                errors.append(f'Error reading suppliers sheet: {str(e)}')

        try:
            df_materials = pd.read_excel(excel_file, sheet_name=mat_sheet)
            for index, row in df_materials.iterrows():
                try:
                    item_no = row.get('No.')
                    item_name = row.get('item/Material') or row.get('Material') or row.get('Item')
                    supplier_name = row.get('Proveedor')
                    price_str = row.get('Costo')

                    if item_name is None or pd.isna(item_name) or not str(item_name).strip():
                        continue
                    if supplier_name is None or pd.isna(supplier_name) or not str(supplier_name).strip():
                        continue

                    item_name = str(item_name).strip()
                    supplier_name = str(supplier_name).strip()

                    price = None
                    if pd.notna(price_str):
                        try:
                            price = float(str(price_str).replace('$', '').replace(',', '').strip())
                        except Exception:
                            pass

                    supplier = db.query(Supplier).filter(Supplier.name == supplier_name).first()
                    if not supplier:
                        supplier = Supplier(name=supplier_name, active=1)
                        db.add(supplier)
                        db.flush()
                        imported_suppliers += 1

                    item_code = f"ITEM-{int(item_no)}" if pd.notna(item_no) else f"ITEM-{index + 1}"

                    item = db.query(Item).filter(Item.item_code == item_code).first()
                    if not item:
                        item = Item(
                            item_code=item_code,
                            name=item_name,
                            description=row.get('Descripciòn/codigo') or row.get('Descripcion'),
                            category=row.get('Categoria') or 'General',
                            unit=row.get('Unidad') or 'pza'
                        )
                        db.add(item)
                        db.flush()
                        imported_items += 1

                    stmt = select(supplier_items).where(
                        (supplier_items.c.supplier_id == supplier.id) &
                        (supplier_items.c.item_id == item.id)
                    )
                    if not db.execute(stmt).first():
                        db.execute(supplier_items.insert().values(
                            supplier_id=supplier.id,
                            item_id=item.id,
                            price=price,
                            supplier_item_code=None,
                            lead_time_days=None,
                            minimum_order_quantity=None,
                            notes=None
                        ))

                except Exception as e:
                    errors.append(f'Material row {index + 2}: {str(e)}')

            db.commit()

        except Exception as e:
            return jsonify({'error': f'Error reading materials sheet: {str(e)}'}), 400

        return jsonify({
            'message': f'Import complete: {imported_suppliers} suppliers, {imported_items} items',
            'suppliers_imported': imported_suppliers,
            'items_imported': imported_items,
            'sheets_used': {'materials': mat_sheet, 'suppliers': sup_sheet},
            'available_sheets': available_sheets,
            'errors': errors if errors else None
        })

    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

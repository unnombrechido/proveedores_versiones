@echo off
REM Add audit "who" columns to database tables
cd /d "%~dp0\.."

echo ============================================================
echo IMPORTANTE: Esta migracion agrega columnas de auditoria
echo ============================================================
echo.
echo Esta operacion agregara las columnas created_by y updated_by
echo a las tablas: items, suppliers, supplier_contacts, orders
echo.
echo Presione Ctrl+C para cancelar, o cualquier tecla para continuar...
pause >nul

venv\Scripts\python.exe scripts\add_who_columns.py

if %ERRORLEVEL% EQU 0 (
    echo.
    echo [OK] Migracion completada exitosamente
) else (
    echo.
    echo [ERROR] La migracion fallo. Revise los mensajes anteriores.
)

echo.
pause

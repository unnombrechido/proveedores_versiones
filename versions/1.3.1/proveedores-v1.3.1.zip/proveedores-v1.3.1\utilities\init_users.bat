@echo off
REM Initialize Users Table and Create Default Admin
echo ========================================
echo  Inicializar Tabla de Usuarios
echo ========================================
echo.

cd /d "%~dp0\.."

if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
    echo [OK] Entorno virtual activado
) else (
    echo [ERROR] No se encontro el entorno virtual
    echo Por favor ejecute INSTALAR.bat primero
    pause
    exit /b 1
)

echo.
echo Inicializando usuarios...
python api\init_users.py

echo.
echo ========================================
pause

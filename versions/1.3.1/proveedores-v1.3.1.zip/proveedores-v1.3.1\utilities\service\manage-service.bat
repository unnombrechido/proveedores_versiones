@echo off
REM Windows Service Management for Sistema de Proveedores
REM Usage: manage-service.bat <install|remove|start|stop|status|restart>

if "%1"=="" (
    echo Usage: manage-service.bat ^<install^|remove^|start^|stop^|status^|restart^>
    echo.
    echo Actions:
    echo   install  - Install and start the service
    echo   remove   - Stop and remove the service
    echo   start    - Start the service
    echo   stop     - Stop the service
    echo   status   - Show service status
    echo   restart  - Restart the service
    echo.
    echo The service will run in the background and start automatically
    echo on system boot and wake from sleep.
    goto :eof
)

echo === Sistema de Proveedores - Service Management ===
echo Action: %1
echo.

REM Handle simple operations directly, complex ones via PowerShell
if "%1"=="start" goto :start_service
if "%1"=="stop" goto :stop_service
if "%1"=="status" goto :service_status
if "%1"=="restart" goto :restart_service
if "%1"=="install" goto :install_service
if "%1"=="remove" goto :remove_service

echo ERROR: Unknown action '%1'
goto :eof

:start_service
echo Starting service...
sc start SistemaProveedores
goto :end

:stop_service
echo Stopping service...
sc stop SistemaProveedores
goto :end

:service_status
echo Checking service status...
sc query SistemaProveedores
goto :end

:restart_service
echo Restarting service...
sc stop SistemaProveedores
timeout /t 2 /nobreak >nul
sc start SistemaProveedores
goto :end

:install_service
echo Installing service...
powershell.exe -ExecutionPolicy Bypass -File "%~dp0service.ps1" -Action install
goto :end

:remove_service
echo Removing service...
powershell.exe -ExecutionPolicy Bypass -File "%~dp0service.ps1" -Action remove
goto :end

:end
echo.
echo Press any key to continue...
pause >nul
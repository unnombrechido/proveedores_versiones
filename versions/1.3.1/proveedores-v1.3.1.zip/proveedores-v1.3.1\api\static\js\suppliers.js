﻿// ===== SUPPLIERS/VENDORS =====
async function loadSuppliers() {
    console.log('loadSuppliers() called');
    try {
        showLoading('Cargando proveedores...');
        const search = document.getElementById('suppliers-search')?.value || '';
        const category = document.getElementById('category-filter')?.value || '';
        const country = document.getElementById('country-filter')?.value || '';
        
        let url = `${API_BASE}/suppliers?`;
        if (search) url += `search=${encodeURIComponent(search)}&`;
        if (category) url += `category_id=${encodeURIComponent(category)}&`;
        if (country) url += `country_id=${encodeURIComponent(country)}`;
        
        const response = await fetch(url);
        
        if (!response.ok) {
            if (response.status === 401) {
                console.error('Authentication required for suppliers');
                window.location.href = '/login';
                return;
            } else if (response.status === 403) {
                console.error('Access denied for suppliers');
                alert('No tienes permisos para ver proveedores');
                return;
            } else {
                console.error('Error loading suppliers:', response.status, response.statusText);
                return;
            }
        }
        
        suppliers = await response.json();
        console.log('Loaded', suppliers.length, 'suppliers');
        console.log('First supplier sample:', suppliers[0]);
        console.log('Supplier properties:', Object.keys(suppliers[0] || {}));
        
        // Load contacts for each supplier
        for (let supplier of suppliers) {
            const contactsResponse = await fetch(`${API_BASE}/suppliers/${supplier.id}/contacts`);
            if (contactsResponse.ok) {
                supplier.contacts = await contactsResponse.json();
                // Get primary contact for display
                supplier.primaryContact = supplier.contacts.find(c => c.is_primary) || supplier.contacts[0] || null;
            }
        }
        
        displaySuppliers();
    } catch (error) {
        console.error('Error loading suppliers:', error);
    } finally {
        hideLoading();
    }
}

function displaySuppliers() {
    console.log('displaySuppliers() called with', suppliers.length, 'suppliers');
    const tbody = document.getElementById('suppliers-tbody');
    console.log('suppliers-tbody element:', tbody);
    if (!tbody) {
        console.error('suppliers-tbody element not found!');
        return;
    }
    
    // Check if user has edit permissions (not compras role)
    const canEdit = currentUser && (currentUser.rol === 'sysadmin' || currentUser.rol === 'admin');
    
    console.log('About to set suppliers tbody.innerHTML with', suppliers.length, 'rows');
    try {
        tbody.innerHTML = suppliers.map(s => `
            <tr>
                <td>${s.name}</td>
                <td>${s.primaryContact ? s.primaryContact.contact_name : ''}</td>
                <td>${s.primaryContact ? s.primaryContact.email || '' : ''}</td>
                <td>${s.primaryContact ? s.primaryContact.phone || '' : ''}</td>
                <td>${s.city || ''}</td>
                <td>${s.category || ''}</td>
                <td>${s.rating ? '⭐ ' + s.rating : ''}</td>
                <td style="white-space: nowrap;">
                    ${canEdit ? `<button onclick="editSupplier(${s.id})" class="btn btn-warning btn-sm" title="Editar Proveedor">✏️</button>` : ''}
                    <button onclick="createOrderForVendor(${s.id}, '${escapeHtml(s.name)}')" class="btn btn-primary btn-sm" title="Crear Orden">📝</button>
                </td>
            </tr>
        `).join('');
        console.log('tbody.innerHTML length after setting suppliers:', tbody.innerHTML.length);
        console.log('tbody.children.length for suppliers:', tbody.children.length);
        
        console.log('Successfully set suppliers tbody.innerHTML');
    } catch (error) {
        console.error('Error setting suppliers tbody.innerHTML:', error);
    }
}

async function loadCategories() {
    console.log('loadCategories() called');
    try {
        const response = await fetch(`${API_BASE}/suppliers/categories`);
        
        if (!response.ok) {
            console.error('Error loading categories:', response.status, response.statusText);
            return;
        }
        
        const categories = await response.json();
        console.log('Loaded', categories.length, 'categories');
        const select = document.getElementById('category-filter');
        if (select) {
            select.innerHTML = '<option value="">Todas las Categorías</option>' +
                categories.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function loadCountries() {
    console.log('loadCountries() called');
    try {
        const response = await fetch(`${API_BASE}/suppliers/countries`);
        
        if (!response.ok) {
            console.error('Error loading countries:', response.status, response.statusText);
            return;
        }
        
        const countries = await response.json();
        console.log('Loaded', countries.length, 'countries');
        const select = document.getElementById('country-filter');
        if (select) {
            select.innerHTML = '<option value="">Todos los Países</option>' +
                countries.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
        }
    } catch (error) {
        console.error('Error loading countries:', error);
    }
}


# -*- coding: utf-8 -*-
"""Config, About, Logo, and Release routes blueprint, plus shared config helpers."""
import configparser
import os

from flask import Blueprint, Response, jsonify, redirect, request, send_file
from flask_login import login_required

config_bp = Blueprint('config', __name__)


# ---------------------------------------------------------------------------
# Shared helper utilities (imported by other blueprints such as orders)
# ---------------------------------------------------------------------------

def _config_path():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    return os.path.join(base_dir, 'config', 'config.ini')


def _safe_read_text(path, max_bytes=512_000):
    try:
        with open(path, 'rb') as f:
            data = f.read(max_bytes)
        return data.decode('utf-8', errors='replace')
    except Exception:
        return ''


def _load_config_map():
    config = {}
    config_path = _config_path()
    if os.path.exists(config_path):
        cfg = configparser.ConfigParser()
        cfg.read(config_path, encoding='utf-8-sig')

        if cfg.sections():
            if cfg.has_section('COMPANY'):
                for key in cfg.options('COMPANY'):
                    config[key.upper()] = cfg.get('COMPANY', key)
            if cfg.has_section('SERVER'):
                for key in cfg.options('SERVER'):
                    config[key.upper()] = cfg.get('SERVER', key)
        else:
            for section_name in cfg.sections() or [None]:
                if section_name is None:
                    for key, value in cfg.defaults().items():
                        config[key.upper()] = value
                else:
                    for key in cfg.options(section_name):
                        config[key.upper()] = cfg.get(section_name, key)

    # Backward-compatibility key mapping
    old_to_new = {
        'NAME': 'COMPANY_NAME',
        'ADDRESS': 'COMPANY_ADDRESS',
        'PHONE': 'COMPANY_PHONE',
        'EMAIL': 'COMPANY_EMAIL',
        'WEBSITE': 'COMPANY_WEBSITE',
        'COMPANY': 'COMPANY_NAME',
        'URL': 'URL',
    }
    for old_key, new_key in old_to_new.items():
        if old_key in config and new_key not in config:
            config[new_key] = config[old_key]

    return config


def _write_config_map(config):
    config_path = _config_path()
    config_dir = os.path.dirname(config_path)
    if config_dir and not os.path.exists(config_dir):
        os.makedirs(config_dir, exist_ok=True)

    cfg = configparser.ConfigParser()

    cfg.add_section('COMPANY')
    cfg.set('COMPANY', 'company_name', config.get('COMPANY_NAME', ''))
    cfg.set('COMPANY', 'company_address', config.get('COMPANY_ADDRESS', ''))
    cfg.set('COMPANY', 'company_phone', config.get('COMPANY_PHONE', ''))
    cfg.set('COMPANY', 'company_email', config.get('COMPANY_EMAIL', ''))
    cfg.set('COMPANY', 'company_website', config.get('COMPANY_WEBSITE', ''))
    cfg.set('COMPANY', 'logo_path', config.get('LOGO_PATH', ''))
    cfg.set('COMPANY', 'version', config.get('VERSION', '1.3.0'))
    cfg.set('COMPANY', 'order_template_esp', config.get('ORDER_TEMPLATE_ESP', 'config/order_template_esp.html'))
    cfg.set('COMPANY', 'order_template_eng', config.get('ORDER_TEMPLATE_ENG', 'config/order_template_eng.html'))
    cfg.set('COMPANY', 'zoom', config.get('ZOOM', '1.0'))
    cfg.set('COMPANY', 'debug', config.get('DEBUG', 'false'))

    cfg.add_section('SERVER')
    cfg.set('SERVER', 'url', config.get('URL', 'http://127.0.0.0:5000'))

    with open(config_path, 'w', encoding='utf-8') as configfile:
        cfg.write(configfile)


def _read_version_file():
    local_version = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'VERSION'))
    if os.path.exists(local_version):
        return _safe_read_text(local_version).strip()
    return 'unknown'


def _get_app_version():
    config = _load_config_map()
    if config.get('VERSION'):
        return config.get('VERSION').strip()
    return _read_version_file()


def _get_release_repo_path():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
    candidate = os.path.join(base_dir, 'Release', 'proveedores_versiones')
    return candidate if os.path.exists(candidate) else None


def _release_base_url():
    base_url = _load_config_map().get('RELEASE_BASE_URL', '').strip()
    if base_url:
        return base_url.rstrip('/')
    return 'https://raw.githubusercontent.com/unnombrechido/proveedores_versiones/refs/heads/main'


def _get_release_notes_path(version):
    release_repo = _get_release_repo_path()
    if release_repo:
        candidate = os.path.join(release_repo, 'versions', version, 'RELEASE_NOTES.md')
        if os.path.exists(candidate):
            return candidate
    return None


def _get_release_license_path():
    release_repo = _get_release_repo_path()
    if release_repo:
        candidate = os.path.join(release_repo, 'LICENSE')
        if os.path.exists(candidate):
            return candidate
    return None


def _resolve_logo_path():
    config = _load_config_map()
    logo_path = (config.get('LOGO_PATH') or '').strip()
    if not logo_path:
        logo_path = 'logo.png'

    if logo_path.startswith('http://') or logo_path.startswith('https://'):
        return {'type': 'url', 'value': logo_path}

    if os.path.isabs(logo_path) and os.path.exists(logo_path):
        return {'type': 'file', 'value': logo_path}

    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    static_path = os.path.join(base_dir, 'api', 'static', logo_path)
    if os.path.exists(static_path):
        return {'type': 'file', 'value': static_path}

    config_path = os.path.join(base_dir, 'config', logo_path)
    if os.path.exists(config_path):
        return {'type': 'file', 'value': config_path}

    fallback_logo = os.path.join(base_dir, 'api', 'static', 'logo.png')
    if os.path.exists(fallback_logo):
        return {'type': 'file', 'value': fallback_logo}

    return None


def _allowed_file(filename, allowed_extensions):
    """Check if file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@config_bp.route('/api/database/info', methods=['GET'])
def get_database_info():
    """Get database connection information."""
    try:
        from ..database import get_database_url
        db_url = get_database_url()
        db_type = os.getenv('DATABASE_TYPE', 'sqlite')
        return jsonify({
            'type': db_type,
            'url': db_url.split('@')[-1] if '@' in db_url else db_url
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@config_bp.route('/api/config', methods=['GET'])
def get_config():
    """Get configuration (company details, logo, etc.)."""
    try:
        config = _load_config_map()
        return jsonify({
            'companyName': config.get('COMPANY_NAME', ''),
            'companyAddress': config.get('COMPANY_ADDRESS', ''),
            'companyPhone': config.get('COMPANY_PHONE', ''),
            'companyEmail': config.get('COMPANY_EMAIL', ''),
            'companyWebsite': config.get('COMPANY_WEBSITE', ''),
            'logoPath': config.get('LOGO_PATH', ''),
            'zoom': float(config.get('ZOOM', '1.0')),
            'debug': config.get('DEBUG', 'false').lower() == 'true'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@config_bp.route('/api/config', methods=['POST'])
def save_config():
    """Save configuration (company details, logo, etc.)."""
    try:
        data = request.json
        config = _load_config_map()
        if not config.get('VERSION'):
            config['VERSION'] = _read_version_file()
        config['COMPANY_NAME'] = data.get('companyName', '')
        config['COMPANY_ADDRESS'] = data.get('companyAddress', '')
        config['COMPANY_PHONE'] = data.get('companyPhone', '')
        config['COMPANY_EMAIL'] = data.get('companyEmail', '')
        config['COMPANY_WEBSITE'] = data.get('companyWebsite', '')
        if 'logoPath' in data:
            config['LOGO_PATH'] = data.get('logoPath', '')
        config['ZOOM'] = str(data.get('zoom', 1.0))
        config['DEBUG'] = 'true' if data.get('debug', False) else 'false'
        _write_config_map(config)
        return jsonify({'success': True, 'message': 'Configuration saved successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@config_bp.route('/api/about', methods=['GET'])
def get_about_info():
    """Get about/version information."""
    version = _get_app_version()
    developer = 'Sistema de Gestión de Proveedores - Equipo de Desarrollo'
    release_base = _release_base_url()
    release_notes_url = f"{release_base}/versions/{version}/RELEASE_NOTES.md"
    license_url = f"{release_base}/LICENSE"

    return jsonify({
        'version': version,
        'developer': developer,
        'releaseNotesUrl': release_notes_url,
        'licenseUrl': license_url,
        'hasReleaseNotes': True,
        'hasLicense': True
    })


@config_bp.route('/api/logo', methods=['GET'])
def get_logo():
    """Serve the company logo."""
    resolved = _resolve_logo_path()
    if not resolved:
        return Response('Logo not found', status=404)
    if resolved['type'] == 'url':
        return redirect(resolved['value'])
    return send_file(resolved['value'])


@config_bp.route('/api/logo', methods=['POST'])
def upload_logo():
    """Upload company logo."""
    try:
        if 'logo' not in request.files:
            return jsonify({'error': 'No logo file provided'}), 400

        file = request.files['logo']
        if file.filename == '':
            return jsonify({'error': 'No logo file selected'}), 400

        if file and _allowed_file(file.filename, {'png', 'jpg', 'jpeg', 'gif', 'ico'}):
            from flask import current_app
            static_dir = os.path.join(current_app.root_path, 'static')
            os.makedirs(static_dir, exist_ok=True)

            filename = 'company_logo.' + file.filename.rsplit('.', 1)[1].lower()
            filepath = os.path.join(static_dir, filename)
            file.save(filepath)

            config = _load_config_map()
            config['LOGO_PATH'] = filename
            _write_config_map(config)

            return jsonify({'success': True, 'filename': filename})
        else:
            return jsonify({'error': 'Invalid file type. Allowed: png, jpg, jpeg, gif, ico'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@config_bp.route('/favicon.ico')
def favicon():
    """Serve favicon (falls back to logo)."""
    resolved = _resolve_logo_path()
    if not resolved:
        return Response(status=204)
    if resolved['type'] == 'url':
        return redirect(resolved['value'])
    return send_file(resolved['value'])


@config_bp.route('/release/notes/<version>', methods=['GET'])
def get_release_notes(version):
    """Return release notes content from release repository if available."""
    notes_path = _get_release_notes_path(version)
    if not notes_path or not os.path.exists(notes_path):
        return Response('Release notes not found', status=404)
    content = _safe_read_text(notes_path)
    return Response(content, mimetype='text/plain; charset=utf-8')


@config_bp.route('/release/license/<version>', methods=['GET'])
def get_release_license(version):
    """Return license content from release repository if available."""
    license_path = _get_release_license_path()
    if not license_path or not os.path.exists(license_path):
        return Response('License not found', status=404)
    content = _safe_read_text(license_path)
    return Response(content, mimetype='text/plain; charset=utf-8')

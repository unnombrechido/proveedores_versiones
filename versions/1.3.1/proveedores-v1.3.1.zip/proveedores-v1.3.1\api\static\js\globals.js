// API Base URL
const API_BASE = '/api';

// Global state
let suppliers = [];
let orders = [];
let items = [];
let currentPriceItem = null; // For price management page
let allPriceSuppliersData = []; // All suppliers for filtering
let currentUser = null; // Current authenticated user
let currentUserId = null; // For editing users
let aboutInfoCache = null;
let appConfigCache = null;

// Search state
let selectedItems = [];
let currentSearchResults = [];
let currentVendorResults = [];

// LOV Data
let lovData = {
    itemCategories: [],
    supplierCategories: [],
    unitsOfMeasure: [],
    itemConditions: [],
    locations: [],
    orderStatuses: [],
    paymentMethods: [],
    paymentTerms: [],
    taxTypes: [],
    countries: [],
    states: []
};

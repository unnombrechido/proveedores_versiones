# -*- coding: utf-8 -*-
"""Supplier routes blueprint."""
import os
from datetime import datetime

import pandas as pd
from flask import Blueprint, jsonify, request, session
from flask_login import login_required
from sqlalchemy import select

from ..database import SessionLocal
from ..models import Country, Supplier, SupplierCategory, SupplierContact, supplier_items
from .decorators import permission_required

suppliers_bp = Blueprint('suppliers', __name__)


@suppliers_bp.route('/api/suppliers', methods=['GET'])
@permission_required('search')
def get_suppliers():
    """Get all suppliers with optional search and filter."""
    db = SessionLocal()
    try:
        query = db.query(Supplier).outerjoin(SupplierCategory).outerjoin(Country)

        search = request.args.get('search', '')
        if search:
            search_pattern = f'%{search}%'
            query = query.filter(
                (Supplier.name.ilike(search_pattern)) |
                (Supplier.email.ilike(search_pattern)) |
                (SupplierCategory.name_es.ilike(search_pattern)) |
                (SupplierCategory.name_en.ilike(search_pattern)) |
                (Supplier.city.ilike(search_pattern))
            )

        category_id = request.args.get('category_id', '')
        if category_id:
            query = query.filter(Supplier.category_id == int(category_id))

        active = request.args.get('active', '')
        if active:
            query = query.filter(Supplier.active == int(active))

        country_id = request.args.get('country_id', '')
        if country_id:
            query = query.filter(Supplier.country_id == int(country_id))

        suppliers = query.all()
        return jsonify([s.to_dict() for s in suppliers])
    finally:
        db.close()


@suppliers_bp.route('/api/suppliers/<int:supplier_id>', methods=['GET'])
def get_supplier(supplier_id):
    """Get a specific supplier."""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404
        return jsonify(supplier.to_dict())
    finally:
        db.close()


@suppliers_bp.route('/api/suppliers', methods=['POST'])
@permission_required('create')
def create_supplier():
    """Create a new supplier."""
    db = SessionLocal()
    try:
        data = request.json
        supplier = Supplier(
            name=data.get('name'),
            contact_person=data.get('contact_person'),
            email=data.get('email'),
            phone=data.get('phone'),
            address=data.get('address'),
            city=data.get('city'),
            state_id=data.get('state_id'),
            country_id=data.get('country_id'),
            tax_id=data.get('tax_id'),
            category_id=data.get('category_id'),
            rating=data.get('rating', 0.0),
            payment_term_id=data.get('payment_term_id'),
            notes=data.get('notes'),
            active=data.get('active', 1),
            created_by=session.get('user_id')
        )
        db.add(supplier)
        db.commit()
        db.refresh(supplier)
        return jsonify(supplier.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


@suppliers_bp.route('/api/suppliers/<int:supplier_id>', methods=['PUT'])
@permission_required('modify')
def update_supplier(supplier_id):
    """Update a supplier."""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404

        data = request.json
        for key, value in data.items():
            if hasattr(supplier, key):
                setattr(supplier, key, value)

        supplier.updated_at = datetime.utcnow()
        supplier.updated_by = session.get('user_id')
        db.commit()
        db.refresh(supplier)
        return jsonify(supplier.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


@suppliers_bp.route('/api/suppliers/<int:supplier_id>', methods=['DELETE'])
@permission_required('modify')
def delete_supplier(supplier_id):
    """Delete a supplier."""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404

        db.delete(supplier)
        db.commit()
        return jsonify({'message': 'Supplier deleted successfully'})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


# --- Supplier Contacts ---

@suppliers_bp.route('/api/suppliers/<int:supplier_id>/contacts', methods=['GET'])
@login_required
def get_supplier_contacts(supplier_id):
    """Get all contacts for a supplier."""
    db = SessionLocal()
    try:
        contacts = db.query(SupplierContact).filter(
            SupplierContact.supplier_id == supplier_id
        ).order_by(SupplierContact.is_primary.desc(), SupplierContact.id).all()
        return jsonify([c.to_dict() for c in contacts])
    finally:
        db.close()


@suppliers_bp.route('/api/suppliers/<int:supplier_id>/contacts', methods=['POST'])
@permission_required('modify')
def create_supplier_contact(supplier_id):
    """Create a new contact for a supplier."""
    db = SessionLocal()
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404

        data = request.json

        if data.get('is_primary'):
            db.query(SupplierContact).filter(
                SupplierContact.supplier_id == supplier_id,
                SupplierContact.is_primary == 1
            ).update({'is_primary': 0})

        contact = SupplierContact(
            supplier_id=supplier_id,
            contact_name=data.get('contact_name', ''),
            position=data.get('position', ''),
            phone=data.get('phone', ''),
            email=data.get('email', ''),
            is_primary=1 if data.get('is_primary') else 0,
            contact_type=data.get('contact_type', 'general'),
            notes=data.get('notes', ''),
            created_by=session.get('user_id')
        )

        db.add(contact)
        db.commit()
        db.refresh(contact)
        return jsonify(contact.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


@suppliers_bp.route('/api/suppliers/<int:supplier_id>/contacts/<int:contact_id>', methods=['PUT'])
@permission_required('modify')
def update_supplier_contact(supplier_id, contact_id):
    """Update a supplier contact."""
    db = SessionLocal()
    try:
        contact = db.query(SupplierContact).filter(
            SupplierContact.id == contact_id,
            SupplierContact.supplier_id == supplier_id
        ).first()

        if not contact:
            return jsonify({'error': 'Contact not found'}), 404

        data = request.json

        if data.get('is_primary') and not contact.is_primary:
            db.query(SupplierContact).filter(
                SupplierContact.supplier_id == supplier_id,
                SupplierContact.is_primary == 1
            ).update({'is_primary': 0})

        for key, value in data.items():
            if hasattr(contact, key):
                if key == 'is_primary':
                    setattr(contact, key, 1 if value else 0)
                else:
                    setattr(contact, key, value)

        contact.updated_at = datetime.utcnow()
        contact.updated_by = session.get('user_id')
        db.commit()
        db.refresh(contact)
        return jsonify(contact.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


@suppliers_bp.route('/api/suppliers/<int:supplier_id>/contacts/<int:contact_id>', methods=['DELETE'])
@permission_required('modify')
def delete_supplier_contact(supplier_id, contact_id):
    """Delete a supplier contact."""
    db = SessionLocal()
    try:
        contact = db.query(SupplierContact).filter(
            SupplierContact.id == contact_id,
            SupplierContact.supplier_id == supplier_id
        ).first()

        if not contact:
            return jsonify({'error': 'Contact not found'}), 404

        contact_count = db.query(SupplierContact).filter(
            SupplierContact.supplier_id == supplier_id
        ).count()

        if contact_count <= 1:
            return jsonify({'error': 'Cannot delete the last contact. At least one contact is required.'}), 400

        if contact.is_primary:
            next_contact = db.query(SupplierContact).filter(
                SupplierContact.supplier_id == supplier_id,
                SupplierContact.id != contact_id
            ).first()
            if next_contact:
                next_contact.is_primary = 1

        db.delete(contact)
        db.commit()
        return jsonify({'message': 'Contact deleted successfully'})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


# --- Legacy LOV helpers (kept for backward-compat, prefer /api/lovs/* routes) ---

@suppliers_bp.route('/api/suppliers/categories', methods=['GET'])
def get_categories():
    """Get all supplier categories from LOV."""
    db = SessionLocal()
    try:
        categories = db.query(SupplierCategory).all()
        return jsonify([{'id': c.id, 'name': c.name_es} for c in categories])
    finally:
        db.close()


@suppliers_bp.route('/api/suppliers/countries', methods=['GET'])
def get_supplier_countries():
    """Get all countries from LOV."""
    db = SessionLocal()
    try:
        countries = db.query(Country).all()
        return jsonify([{'id': c.id, 'name': c.name_es} for c in countries])
    finally:
        db.close()


# --- Export ---

@suppliers_bp.route('/api/suppliers/export/csv', methods=['GET'])
def export_csv():
    """Export suppliers to CSV file."""
    from io import BytesIO
    from flask import send_file
    db = SessionLocal()
    try:
        suppliers = db.query(Supplier).all()
        df = pd.DataFrame([s.to_dict() for s in suppliers])

        output = BytesIO()
        df.to_csv(output, index=False)
        output.seek(0)

        return send_file(
            output,
            mimetype='text/csv',
            as_attachment=True,
            download_name=f'suppliers_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        )
    finally:
        db.close()


@suppliers_bp.route('/api/suppliers/export/excel', methods=['GET'])
@permission_required('export')
def export_excel():
    """Export suppliers to Excel file."""
    db = SessionLocal()
    try:
        suppliers = db.query(Supplier).all()
        df = pd.DataFrame([s.to_dict() for s in suppliers])

        filename = f'suppliers_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        export_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'exports')
        os.makedirs(export_dir, exist_ok=True)
        file_path = os.path.abspath(os.path.join(export_dir, filename))
        df.to_excel(file_path, index=False, engine='openpyxl')
    finally:
        db.close()

@echo off
REM ===================================================================
REM  Web Service Troubleshooting Script
REM  Diagnoses when service runs but web interface is inaccessible
REM ===================================================================

echo.
echo ===================================================================
echo   DIAGNOSTICO: Servicio ejecutandose pero web no responde
echo ===================================================================
echo.

powershell -ExecutionPolicy Bypass -Command "
    $serviceName = 'SistemaProveedores'
    $webUrl = 'http://localhost:5000'
    Write-Host '=== ANALISIS DEL PROBLEMA ===' -ForegroundColor Cyan
    Write-Host 'Servicio Windows: SistemaProveedores' -ForegroundColor White
    Write-Host 'Interfaz Web: http://localhost:5000' -ForegroundColor White
    Write-Host ''

    # 1. Check Windows Service Status
    Write-Host '1. Verificando estado del servicio Windows...' -ForegroundColor Yellow
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service) {
        Write-Host '   ✓ Servicio encontrado' -ForegroundColor Green
        Write-Host \"   Estado: $($service.Status)\" -ForegroundColor White
        if ($service.Status -ne 'Running') {
            Write-Host '   ✗ Servicio NO esta ejecutandose' -ForegroundColor Red
            Write-Host ''
            Write-Host 'SOLUCION: Inicia el servicio' -ForegroundColor Yellow
            Write-Host '   utilities\service\manage-service.bat start' -ForegroundColor White
            exit 1
        }
    } else {
        Write-Host '   ✗ Servicio NO instalado' -ForegroundColor Red
        Write-Host ''
        Write-Host 'SOLUCION: Instala el servicio' -ForegroundColor Yellow
        Write-Host '   utilities\service\manage-service.bat install' -ForegroundColor White
        exit 1
    }
    Write-Host ''

    # 2. Check for running Python processes
    Write-Host '2. Verificando procesos Python relacionados...' -ForegroundColor Yellow
    $pythonProcesses = Get-Process -Name 'python' -ErrorAction SilentlyContinue | Where-Object {
        $_.CommandLine -like '*flask*' -or $_.CommandLine -like '*app.py*' -or $_.CommandLine -like '*run.py*'
    }
    if ($pythonProcesses) {
        Write-Host '   ✓ Procesos Python encontrados:' -ForegroundColor Green
        $pythonProcesses | ForEach-Object {
            Write-Host \"      PID: $($_.Id) - $($_.CommandLine)\" -ForegroundColor White
        }
    } else {
        Write-Host '   ✗ NO se encontraron procesos Python de Flask' -ForegroundColor Red
        Write-Host ''
        Write-Host 'PROBLEMA: El servicio esta ejecutandose pero Flask no responde' -ForegroundColor Red
        Write-Host 'SOLUCION: Reinicia el servicio' -ForegroundColor Yellow
        Write-Host '   utilities\service\manage-service.bat restart' -ForegroundColor White
        exit 1
    }
    Write-Host ''

    # 3. Test web service connectivity
    Write-Host '3. Probando conectividad del servicio web...' -ForegroundColor Yellow
    try {
        $webResponse = Invoke-WebRequest -Uri $webUrl -TimeoutSec 10 -ErrorAction Stop
        Write-Host '   ✓ Servicio web responde correctamente' -ForegroundColor Green
        Write-Host \"   Codigo HTTP: $($webResponse.StatusCode)\" -ForegroundColor White
        Write-Host ''
        Write-Host 'RESULTADO: Todo parece funcionar correctamente' -ForegroundColor Green
        Write-Host 'Si aun no puedes acceder, verifica:' -ForegroundColor Yellow
        Write-Host '   - Firewall bloqueando puerto 5000' -ForegroundColor White
        Write-Host '   - Usando el navegador correcto' -ForegroundColor White
        Write-Host '   - URL correcta: http://localhost:5000' -ForegroundColor White
    } catch {
        Write-Host '   ✗ Servicio web NO responde' -ForegroundColor Red
        Write-Host \"   Error: $($_.Exception.Message)\" -ForegroundColor Red
        Write-Host ''
        Write-Host '=== DIAGNOSTICO AVANZADO ===' -ForegroundColor Cyan

        # Check port usage
        Write-Host 'Verificando uso del puerto 5000...' -ForegroundColor Yellow
        $portUsage = netstat -ano | findstr ':5000'
        if ($portUsage) {
            Write-Host '   Puerto 5000 en uso:' -ForegroundColor Red
            $portUsage | ForEach-Object {
                $parts = $_.Trim() -split '\s+'
                $pid = $parts[-1]
                $process = Get-Process -Id $pid -ErrorAction SilentlyContinue
                if ($process) {
                    Write-Host \"      PID $pid - $($process.Name) - $($process.Path)\" -ForegroundColor White
                } else {
                    Write-Host \"      PID $pid - Proceso desconocido\" -ForegroundColor White
                }
            }
        } else {
            Write-Host '   Puerto 5000 esta libre' -ForegroundColor Green
        }
        Write-Host ''

        # Check service logs
        Write-Host 'Revisando logs del servicio...' -ForegroundColor Yellow
        $logPath = 'logs\service.log'
        if (Test-Path $logPath) {
            $recentLogs = Get-Content $logPath -Tail 10 -ErrorAction SilentlyContinue
            if ($recentLogs) {
                Write-Host '   Ultimas 10 lineas del log:' -ForegroundColor White
                $recentLogs | ForEach-Object {
                    Write-Host \"      $_\" -ForegroundColor Gray
                }
            } else {
                Write-Host '   Log existe pero esta vacio' -ForegroundColor Yellow
            }
        } else {
            Write-Host '   Archivo de log no encontrado' -ForegroundColor Yellow
        }
        Write-Host ''

        Write-Host '=== SOLUCIONES RECOMENDADAS ===' -ForegroundColor Cyan
        Write-Host 'OPCION 1 - Reinicio simple:' -ForegroundColor Yellow
        Write-Host '   utilities\service\manage-service.bat restart' -ForegroundColor White
        Write-Host ''
        Write-Host 'OPCION 2 - Limpieza forzada (como administrador):' -ForegroundColor Yellow
        Write-Host '   utilities\cleanup_service_admin.bat' -ForegroundColor White
        Write-Host '   utilities\service\manage-service.bat install' -ForegroundColor White
        Write-Host ''
        Write-Host 'OPCION 3 - Inicio manual para pruebas:' -ForegroundColor Yellow
        Write-Host '   INSTALAR.bat (se ejecuta en ventana visible)' -ForegroundColor White
    }
"

echo.
echo Presiona cualquier tecla para continuar...
pause >nul
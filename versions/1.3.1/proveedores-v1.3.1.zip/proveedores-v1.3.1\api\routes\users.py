# -*- coding: utf-8 -*-
"""User management routes blueprint."""
from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user

from ..database import SessionLocal
from ..models import User
from .decorators import role_required

users_bp = Blueprint('users', __name__)


@users_bp.route('/api/users', methods=['GET'])
@role_required('sysadmin')
def get_users():
    """Get all users (sysadmin only)."""
    db = SessionLocal()
    try:
        query = db.query(User)

        search = request.args.get('search', '')
        if search:
            query = query.filter(
                (User.email.ilike(f'%{search}%')) |
                (User.nombre.ilike(f'%{search}%')) |
                (User.apellido.ilike(f'%{search}%'))
            )

        rol = request.args.get('rol', '')
        if rol:
            query = query.filter(User.rol == rol)

        status = request.args.get('status', '')
        if status:
            query = query.filter(User.status == status)

        users = query.all()
        return jsonify({
            'success': True,
            'users': [user.to_dict() for user in users],
            'total': len(users)
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@users_bp.route('/api/users/<int:user_id>', methods=['GET'])
@role_required('sysadmin')
def get_user(user_id):
    """Get specific user by ID (sysadmin only)."""
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'error': 'Usuario no encontrado'}), 404

        return jsonify({
            'success': True,
            'user': user.to_dict()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@users_bp.route('/api/users', methods=['POST'])
@role_required('sysadmin')
def create_user():
    """Create new user (sysadmin only)."""
    data = request.get_json()

    required_fields = ['email', 'password', 'nombre', 'apellido', 'rol']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'error': f'Campo requerido: {field}'}), 400

    valid_roles = ['sysadmin', 'admin', 'compras']
    if data['rol'] not in valid_roles:
        return jsonify({'error': f'Rol inválido. Use: {", ".join(valid_roles)}'}), 400

    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.email == data['email']).first()
        if existing:
            return jsonify({'error': 'El email ya está registrado'}), 409

        user = User(
            email=data['email'].strip().lower(),
            nombre=data['nombre'].strip(),
            apellido=data['apellido'].strip(),
            telefono=data.get('telefono', '').strip(),
            rol=data['rol'],
            status=data.get('status', 'activo')
        )
        user.set_password(data['password'])

        db.add(user)
        db.commit()
        db.refresh(user)

        return jsonify({
            'success': True,
            'message': 'Usuario creado exitosamente',
            'user': user.to_dict()
        }), 201

    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@users_bp.route('/api/users/<int:user_id>', methods=['PUT'])
@role_required('sysadmin')
def update_user(user_id):
    """Update user (sysadmin only)."""
    data = request.get_json()

    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'error': 'Usuario no encontrado'}), 404

        if 'email' in data:
            existing = db.query(User).filter(
                User.email == data['email'],
                User.id != user_id
            ).first()
            if existing:
                return jsonify({'error': 'El email ya está registrado'}), 409
            user.email = data['email'].strip().lower()

        if 'nombre' in data:
            user.nombre = data['nombre'].strip()

        if 'apellido' in data:
            user.apellido = data['apellido'].strip()

        if 'telefono' in data:
            user.telefono = data['telefono'].strip()

        if 'rol' in data:
            valid_roles = ['sysadmin', 'admin', 'compras']
            if data['rol'] not in valid_roles:
                return jsonify({'error': f'Rol inválido. Use: {", ".join(valid_roles)}'}), 400
            user.rol = data['rol']

        if 'status' in data:
            valid_statuses = ['activo', 'inactivo']
            if data['status'] not in valid_statuses:
                return jsonify({'error': f'Estado inválido. Use: {", ".join(valid_statuses)}'}), 400
            user.status = data['status']

        db.commit()
        db.refresh(user)

        return jsonify({
            'success': True,
            'message': 'Usuario actualizado exitosamente',
            'user': user.to_dict()
        })

    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@users_bp.route('/api/users/<int:user_id>/password', methods=['PUT'])
@login_required
def change_password(user_id):
    """Change user password (sysadmin can change any, users can change own)."""
    data = request.get_json()

    if user_id != current_user.id and not current_user.is_sysadmin:
        return jsonify({'error': 'Acceso denegado'}), 403

    if not data.get('new_password'):
        return jsonify({'error': 'Nueva contraseña requerida'}), 400

    if user_id == current_user.id and not current_user.is_sysadmin:
        if not data.get('current_password'):
            return jsonify({'error': 'Contraseña actual requerida'}), 400
        if not current_user.check_password(data['current_password']):
            return jsonify({'error': 'Contraseña actual incorrecta'}), 401

    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'error': 'Usuario no encontrado'}), 404

        user.set_password(data['new_password'])
        db.commit()

        return jsonify({
            'success': True,
            'message': 'Contraseña actualizada exitosamente'
        })

    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@users_bp.route('/api/users/<int:user_id>', methods=['DELETE'])
@role_required('sysadmin')
def delete_user(user_id):
    """Delete user (sysadmin only)."""
    if user_id == current_user.id:
        return jsonify({'error': 'No puede eliminar su propia cuenta'}), 400

    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'error': 'Usuario no encontrado'}), 404

        db.delete(user)
        db.commit()

        return jsonify({
            'success': True,
            'message': 'Usuario eliminado exitosamente'
        })

    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

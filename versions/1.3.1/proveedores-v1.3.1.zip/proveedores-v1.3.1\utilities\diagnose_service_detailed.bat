@echo off
REM Service Diagnostic Tool
REM Helps diagnose service installation and runtime issues

echo.
echo ============================================================
echo   DIAGNOSTICO DETALLADO DEL SERVICIO
echo ============================================================
echo.

powershell -ExecutionPolicy Bypass -Command "
    $serviceName = 'SistemaProveedores'
    Write-Host '=== DIAGNOSTICO COMPLETO DEL SERVICIO ===' -ForegroundColor Cyan
    Write-Host \"Servicio: $serviceName\" -ForegroundColor White
    Write-Host '' -ForegroundColor White
    
    # Check if service exists in Windows Services
    Write-Host '1. Verificando en Administrador de Servicios...' -ForegroundColor Yellow
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service) {
        Write-Host '   ✓ Servicio encontrado en Windows' -ForegroundColor Green
        Write-Host \"   Estado: $($service.Status)\" -ForegroundColor White
        Write-Host \"   Tipo de inicio: $($service.StartType)\" -ForegroundColor White
        
        # Check if service can be queried
        try {
            $serviceDetails = Get-WmiObject -Class Win32_Service -Filter \"Name='$serviceName'\" -ErrorAction Stop
            Write-Host \"   Ruta del ejecutable: $($serviceDetails.PathName)\" -ForegroundColor White
            Write-Host \"   Cuenta de servicio: $($serviceDetails.StartName)\" -ForegroundColor White
        } catch {
            Write-Host '   ✗ Error obteniendo detalles del servicio WMI' -ForegroundColor Red
            Write-Host \"   Error: $($_.Exception.Message)\" -ForegroundColor Red
        }
    } else {
        Write-Host '   ✗ Servicio NO encontrado en Windows' -ForegroundColor Red
    }
    Write-Host '' -ForegroundColor White
    
    # Check NSSM configuration
    Write-Host '2. Verificando configuracion NSSM...' -ForegroundColor Yellow
    $nssmPaths = @(
        \"`$env:ProgramFiles\nssm\nssm.exe\",
        \".\\utilities\\service\\nssm.exe\"
    )
    
    $nssmFound = $false
    $nssmPath = $null
    
    foreach ($path in $nssmPaths) {
        $expandedPath = $ExecutionContext.InvokeCommand.ExpandString($path)
        if (Test-Path $expandedPath) {
            $nssmFound = $true
            $nssmPath = $expandedPath
            Write-Host \"   ✓ NSSM encontrado: $expandedPath\" -ForegroundColor Green
            break
        }
    }
    
    if (-not $nssmFound) {
        Write-Host '   ✗ NSSM no encontrado en rutas esperadas' -ForegroundColor Red
        Write-Host '   Buscando NSSM en el sistema...' -ForegroundColor Yellow
        $nssmSystem = Get-Command nssm.exe -ErrorAction SilentlyContinue
        if ($nssmSystem) {
            $nssmPath = $nssmSystem.Source
            Write-Host \"   ✓ NSSM encontrado en PATH: $($nssmSystem.Source)\" -ForegroundColor Green
            $nssmFound = $true
        }
    }
    
    if ($nssmFound -and $nssmPath) {
        Write-Host '   Probando comandos NSSM...' -ForegroundColor Gray
        
        # Test NSSM status
        try {
            $nssmStatus = & $nssmPath status $serviceName 2>&1
            $nssmExitCode = $LASTEXITCODE
            Write-Host \"   NSSM status exit code: $nssmExitCode\" -ForegroundColor White
            
            if ($nssmExitCode -eq 0) {
                Write-Host '   ✓ NSSM reporta servicio OK' -ForegroundColor Green
            } elseif ($nssmExitCode -eq 3) {
                Write-Host '   ✗ NSSM reporta: Servicio no encontrado' -ForegroundColor Red
            } else {
                Write-Host \"   ⚠ NSSM reporta codigo desconocido: $nssmExitCode\" -ForegroundColor Yellow
            }
        } catch {
            Write-Host '   ✗ Error ejecutando NSSM status' -ForegroundColor Red
            Write-Host \"   Error: $($_.Exception.Message)\" -ForegroundColor Red
        }
        
        # Test NSSM get application
        try {
            $nssmApp = & $nssmPath get $serviceName Application 2>&1
            if ($LASTEXITCODE -eq 0 -and $nssmApp) {
                Write-Host \"   Aplicacion configurada: $nssmApp\" -ForegroundColor White
                if (Test-Path $nssmApp) {
                    Write-Host '   ✓ Archivo ejecutable existe' -ForegroundColor Green
                } else {
                    Write-Host '   ✗ Archivo ejecutable NO existe' -ForegroundColor Red
                }
            }
        } catch {
            Write-Host '   ✗ Error obteniendo aplicacion NSSM' -ForegroundColor Red
        }
    }
    Write-Host '' -ForegroundColor White
    
    # Check for running processes
    Write-Host '3. Verificando procesos en ejecucion...' -ForegroundColor Yellow
    
    $pythonProcs = Get-Process -Name 'python' -ErrorAction SilentlyContinue
    if ($pythonProcs) {
        Write-Host '   Procesos Python encontrados:' -ForegroundColor White
        $relatedProcs = 0
        foreach ($proc in $pythonProcs) {
            $procPath = $proc.Path
            if ($procPath -and ($procPath -like '*proveedores*' -or $procPath -like '*SistemaProveedores*')) {
                Write-Host \"     PID: $($proc.Id) - $procPath\" -ForegroundColor Yellow
                Write-Host \"       Comando: $($proc.CommandLine)\" -ForegroundColor Gray
                $relatedProcs++
            }
        }
        if ($relatedProcs -eq 0) {
            Write-Host '     (Ningun proceso relacionado con la aplicacion)' -ForegroundColor Gray
        }
    } else {
        Write-Host '   ✓ No hay procesos Python ejecutandose' -ForegroundColor Green
    }
    
    $cmdProcs = Get-Process -Name 'cmd' -ErrorAction SilentlyContinue | Where-Object {
        $_.CommandLine -like '*run.bat*' -or $_.CommandLine -like '*SistemaProveedores*'
    }
    if ($cmdProcs) {
        Write-Host '   Procesos CMD relacionados:' -ForegroundColor White
        foreach ($proc in $cmdProcs) {
            Write-Host \"     PID: $($proc.Id) - $($proc.CommandLine)\" -ForegroundColor Yellow
        }
    } else {
        Write-Host '   ✓ No hay procesos CMD relacionados' -ForegroundColor Green
    }
    Write-Host '' -ForegroundColor White
    
    # Check service logs
    Write-Host '4. Verificando logs del servicio...' -ForegroundColor Yellow
    $logPath = '.\\logs\\service.log'
    if (Test-Path $logPath) {
        Write-Host '   ✓ Log del servicio encontrado' -ForegroundColor Green
        $logContent = Get-Content $logPath -Tail 10 -ErrorAction SilentlyContinue
        if ($logContent) {
            Write-Host '   Ultimas 10 lineas del log:' -ForegroundColor Gray
            foreach ($line in $logContent) {
                Write-Host \"     $line\" -ForegroundColor DarkGray
            }
        }
    } else {
        Write-Host '   ✗ Log del servicio no encontrado' -ForegroundColor Yellow
        Write-Host '   Ubicacion esperada: $logPath' -ForegroundColor Gray
    }
    Write-Host '' -ForegroundColor White
    
    # Summary and recommendations
    Write-Host '=== DIAGNOSTICO Y RECOMENDACIONES ===' -ForegroundColor Cyan
    
    $issues = @()
    
    if (-not $service) {
        $issues += 'Servicio no registrado en Windows'
    } elseif ($service.Status -ne 'Running') {
        $issues += \"Servicio en estado '$($service.Status)' en lugar de 'Running'\"
    }
    
    if (-not $nssmFound) {
        $issues += 'NSSM no encontrado'
    }
    
    if ($pythonProcs.Count -eq 0) {
        $issues += 'No hay procesos Python ejecutandose'
    }
    
    if ($issues.Count -eq 0) {
        Write-Host '✓ No se encontraron problemas evidentes' -ForegroundColor Green
        Write-Host '' -ForegroundColor White
        Write-Host 'Si la aplicacion web no responde:' -ForegroundColor Yellow
        Write-Host '1. Verifica que el puerto 5000 no este bloqueado' -ForegroundColor White
        Write-Host '2. Revisa el log del servicio para errores' -ForegroundColor White
        Write-Host '3. Intenta acceder desde otro navegador' -ForegroundColor White
    } else {
        Write-Host '✗ Se encontraron los siguientes problemas:' -ForegroundColor Red
        foreach ($issue in $issues) {
            Write-Host \"  - $issue\" -ForegroundColor Red
        }
        Write-Host '' -ForegroundColor White
        Write-Host 'SOLUCIONES RECOMENDADAS:' -ForegroundColor Yellow
        Write-Host '1. Ejecuta cleanup_service_admin.bat como administrador' -ForegroundColor White
        Write-Host '2. Reinstala el servicio: utilities\\service\\setup-service.bat' -ForegroundColor White
        Write-Host '3. Revisa los logs para mas detalles' -ForegroundColor White
        Write-Host '4. Si persiste, reinicia el sistema' -ForegroundColor White
    }
    
    Write-Host '' -ForegroundColor White
    Write-Host '=== FIN DEL DIAGNOSTICO ===' -ForegroundColor Cyan
"

echo.
echo Presiona cualquier tecla para continuar...
pause >nul
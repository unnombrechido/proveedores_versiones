@echo off
REM Proveedores Uninstall Script
REM Run as administrator
REM Usage: uninstall.bat [-backup] [-installpath "path"]

REM Change to the script's directory (fixes admin execution path issue)
cd /d "%~dp0"

if "%1"=="-help" goto :show_usage
if "%1"=="-h" goto :show_usage
if "%1"=="-?" goto :show_usage

echo ============================================================
echo  PROVEEDORES - COMPLETE UNINSTALL
echo ============================================================
echo.

REM Parse command line arguments
set BACKUP_FLAG=
set INSTALL_PATH=

if "%1"=="-backup" (
    set BACKUP_FLAG=-BackupData
    shift
)
if "%1"=="-installpath" (
    set INSTALL_PATH=-InstallPath "%~2"
    shift
    shift
)

REM Check if running as administrator
net session >nul 2>&1
if %errorLevel% == 0 (
    echo Running with administrator privileges.
) else (
    echo This script requires administrator privileges.
    echo Please right-click and "Run as administrator".
    pause
    exit /b 1
)

REM Run the PowerShell script with parameters
REM Try to find the PowerShell script in the same directory first, then in scripts subdirectory
if exist "%~dp0uninstall.ps1" (
    set PS_SCRIPT="%~dp0uninstall.ps1"
) else if exist "%~dp0..\scripts\uninstall.ps1" (
    set PS_SCRIPT="%~dp0..\scripts\uninstall.ps1"
) else (
    echo ERROR: Cannot find uninstall.ps1 script
    echo Looked in: %~dp0uninstall.ps1
    echo And in: %~dp0..\scripts\uninstall.ps1
    pause
    exit /b 1
)

powershell.exe -ExecutionPolicy Bypass -File %PS_SCRIPT% %BACKUP_FLAG% %INSTALL_PATH%

echo.
echo Uninstall completed.
pause
goto :eof

:show_usage
echo Usage: uninstall.bat [options]
echo.
echo Options:
echo   -backup       Automatically backup data and config before uninstalling
echo   -installpath "path"  Specify custom installation path to uninstall
echo   -help, -h, -? Show this help message
echo.
echo Examples:
echo   uninstall.bat                          (interactive mode)
echo   uninstall.bat -backup                  (backup data automatically)
echo   uninstall.bat -installpath "C:\Custom\Path"  (uninstall from custom path)
echo.
pause
goto :eof
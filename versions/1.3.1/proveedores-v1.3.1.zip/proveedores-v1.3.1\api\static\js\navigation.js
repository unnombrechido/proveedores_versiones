﻿// Section Navigation
function showSection(sectionName) {
    console.log('showSection called with:', sectionName);
    
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Remove active from all nav items
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Show selected section
    const section = document.getElementById(sectionName + '-section');
    console.log('Section element found:', section);
    if (section) {
        section.classList.add('active');
        console.log('Added active class to section');
        console.log('Section display style:', window.getComputedStyle(section).display);
        console.log('Section visibility:', window.getComputedStyle(section).visibility);
        
        // // Add a test element to see if the section is visible
        // const testDiv = document.createElement('div');
        // testDiv.textContent = `TEST: ${sectionName} section is visible`;
        // testDiv.style.background = 'red';
        // testDiv.style.color = 'white';
        // testDiv.style.padding = '10px';
        // testDiv.style.position = 'absolute';
        // testDiv.style.top = '100px';
        // testDiv.style.left = '100px';
        // testDiv.style.zIndex = '9999';
        // section.appendChild(testDiv);
        
        // setTimeout(() => {
        //     testDiv.remove();
        // }, 3000);
    } else {
            // console.error('Section element not found for:', sectionName);
    }
    
    // Set active nav item - find the button that was clicked or matches the section
    if (window.event && window.event.target) {
        const target = window.event.target;
        const clickedButton = target.classList?.contains('nav-item') 
            ? target 
            : (target.closest ? target.closest('.nav-item') : target.parentElement?.closest('.nav-item'));
        if (clickedButton) {
            clickedButton.classList.add('active');
        }
    } else {
        // If called programmatically, find the matching nav button
        const navButtons = document.querySelectorAll('.nav-item');
        navButtons.forEach(button => {
            const onclick = button.getAttribute('onclick');
            if (onclick && onclick.includes(sectionName)) {
                button.classList.add('active');
            }
        });
    }
    
    // Update section title
    const titles = {
        'search-items': 'Buscar Items',
        'search-vendors': 'Buscar Proveedores',
        'inventory': 'Gestión de Inventario',
        'vendors': 'Gestión de Proveedores',
        'orders': 'Gestión de Órdenes',
        'price-management': 'Gestión de Precios',
        'settings': 'Configuración',
        'users': 'Gestión de Usuarios',
        'lovs': 'Listas de Valores',
        'about': 'Acerca de'
    };
    const sectionTitle = document.getElementById('section-title');
    if (sectionTitle) {
        sectionTitle.textContent = titles[sectionName] || '';
    }
    
    // Load data when switching sections
    console.log('Loading section:', sectionName);
    if (sectionName === 'users') {
        loadUsers();
    } else if (sectionName === 'settings') {
        loadCompanySettings();
        // Update zoom controls with current zoom level
        const currentZoom = localStorage.getItem('app-zoom-level') || 1.0;
        const zoomSlider = document.getElementById('zoom-level');
        const zoomValue = document.getElementById('zoom-value');
        if (zoomSlider) zoomSlider.value = currentZoom;
        if (zoomValue) zoomValue.textContent = Math.round(currentZoom * 100) + '%';
    }
    // Load data for section
    if (sectionName === 'inventory') {
        console.log('Calling loadInventory()');
        loadInventory();
    } else if (sectionName === 'vendors') {
        console.log('Calling loadSuppliers(), loadCategories(), loadCountries()');
        loadSuppliers();
        loadCategories();
        loadCountries();
    } else if (sectionName === 'orders') {
        console.log('Calling loadOrders(), loadSuppliersForDropdown()');
        loadOrders();
        loadSuppliersForDropdown();
    } else if (sectionName === 'price-management') {
        if (currentPriceItem) {
            loadPriceManagement(currentPriceItem.id);
        }
    } else if (sectionName === 'about') {
        loadAboutInfo();
    }
}


﻿// ===== ORDERS =====
// ===== ORDERS =====
async function loadOrders() {
    console.log('loadOrders() called');
    
    // Populate status filter from LOV - ensure LOVs are loaded
    const populateStatusFilter = async () => {
        if (!lovData.orderStatuses || lovData.orderStatuses.length === 0) {
            console.log('LOV data not loaded, loading now...');
            await loadLOV('orderStatuses', '/api/lovs/order-statuses');
        }
        
        const statusFilter = document.getElementById('order-status-filter');
        if (statusFilter) {
            const currentStatus = statusFilter.value;
            statusFilter.innerHTML = '<option value="">Todos los Estados</option>';
            lovData.orderStatuses.forEach(status => {
                const option = document.createElement('option');
                option.value = status.id;
                option.textContent = status.name_es;
                if (status.id == currentStatus) option.selected = true;
                statusFilter.appendChild(option);
            });
        }
    };
    
    await populateStatusFilter();
    
    try {
        const status = document.getElementById('order-status-filter')?.value || '';
        let url = `${API_BASE}/orders`;
        if (status) url += `?status_id=${status}`;
        
        const response = await fetch(url);
        
        if (!response.ok) {
            if (response.status === 401) {
                console.error('Authentication required for orders');
                window.location.href = '/login';
                return;
            } else if (response.status === 403) {
                console.error('Access denied for orders');
                alert('No tienes permisos para ver órdenes');
                return;
            } else {
                console.error('Error loading orders:', response.status, response.statusText);
                return;
            }
        }
        
        orders = await response.json();
        console.log('Loaded', orders.length, 'orders');
        console.log('First order sample:', orders[0]);
        console.log('Order properties:', Object.keys(orders[0] || {}));
        displayOrders();
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

function displayOrders() {
    console.log('displayOrders() called with', orders.length, 'orders');
    const tbody = document.getElementById('orders-tbody');
    console.log('orders-tbody element:', tbody);
    if (!tbody) {
        console.error('orders-tbody element not found!');
        return;
    }
    
    console.log('About to set orders tbody.innerHTML with', orders.length, 'rows');
    try {
        tbody.innerHTML = orders.map(o => `
            <tr>
                <td>${o.order_number}</td>
                <td>${o.supplier_name}</td>
                <td>${new Date(o.order_date).toLocaleDateString()}</td>
                <td>${o.delivery_date ? new Date(o.delivery_date).toLocaleDateString() : ''}</td>
                <td>$${o.total_amount?.toFixed(2) || '0.00'}</td>
                <td><span class="status-badge status-${o.status_code || o.status}">${o.status || 'N/A'}</span></td>
                <td style="white-space: nowrap;">
                    <button onclick="viewOrder(${o.id})" class="btn btn-secondary btn-sm" title="Ver Orden">👁️</button>
                    <button onclick="printOrder(${o.id}, 'internal')" class="btn btn-warning btn-sm" title="Imprimir (Interna)">🖨️</button>
                    <button onclick="printOrder(${o.id}, 'vendor')" class="btn btn-warning btn-sm" title="Imprimir (Proveedor)">🧾</button>
                </td>
            </tr>
        `).join('');
        console.log('tbody.innerHTML length after setting orders:', tbody.innerHTML.length);
        console.log('tbody.children.length for orders:', tbody.children.length);
        
        console.log('Successfully set orders tbody.innerHTML');
    } catch (error) {
        console.error('Error setting orders tbody.innerHTML:', error);
    }
}

function parseItemsToTable(itemsText) {
    if (!itemsText || !itemsText.trim()) {
        return '<tr><td colspan="4">No hay items especificados</td></tr>';
    }
    
    const lines = itemsText.trim().split('\n');
    let html = '';
    
    for (const line of lines) {
        if (!line.trim()) continue;
        
        // Try to parse different formats
        if (line.includes('|')) {
            // Pipe-separated format: ID|Name|Qty|Price
            const parts = line.split('|').map(p => p.trim());
            if (parts.length >= 3) {
                const id = parts[0];
                const name = parts[1];
                const qty = parts[2];
                const price = parts[3] || '';
                html += `<tr><td>${escapeHtml(id)}</td><td>${escapeHtml(name)}</td><td>${escapeHtml(qty)}</td><td>${escapeHtml(price)}</td></tr>`;
            }
        } else {
            // Try "qty x name @ price" format
            const match = line.match(/(\d+)\s*x\s*(.+?)(?:\s*@\s*(.+))?$/i);
            if (match) {
                const qty = match[1];
                const name = match[2].trim();
                const price = match[3] ? match[3].trim() : '';
                html += `<tr><td>-</td><td>${escapeHtml(name)}</td><td>${escapeHtml(qty)}</td><td>${escapeHtml(price)}</td></tr>`;
            } else {
                // Fallback: display as-is
                html += `<tr><td colspan="4">${escapeHtml(line.trim())}</td></tr>`;
            }
        }
    }
    
    return html;
}

async function viewOrder(orderId) {
    try {
        // Fetch order details
        const response = await fetch(`${API_BASE}/orders/${orderId}`);
        if (!response.ok) {
            throw new Error('Failed to load order');
        }
        
        const order = await response.json();
        
        // Ensure order statuses LOV is loaded
        if (!lovData.orderStatuses || lovData.orderStatuses.length === 0) {
            await loadLOV('orderStatuses', '/api/lovs/order-statuses');
        }
        
        // Generate status options from LOV
        const statusOptions = lovData.orderStatuses.map(status => 
            `<option value="${status.code}" ${order.status_code === status.code ? 'selected' : ''}>${status.name_es}</option>`
        ).join('');
        
        // Fetch config for letterhead
        const configResponse = await fetch(`${API_BASE}/config`);
        const config = configResponse.ok ? await configResponse.json() : {};
        
        // Build letterhead HTML
        let letterheadHtml = '';
        if (config.logoPath) {
            letterheadHtml += `<img src="${API_BASE}/logo" class="letterhead-logo" alt="Logo" style="max-height: 80px; margin-bottom: 10px;">`;
        }
        letterheadHtml += `<div class="letterhead-text"><h1>${config.companyName || 'Mi Empresa'}</h1></div>`;
        
        // Get supplier details and contacts
        const supplierResponse = await fetch(`${API_BASE}/suppliers`);
        const suppliers = await supplierResponse.json();
        const supplier = suppliers.find(s => s.name === order.supplier_name);
        
        let contactsInfo = '';
        if (supplier) {
            const contactsResponse = await fetch(`${API_BASE}/suppliers/${supplier.id}/contacts`);
            const contacts = await contactsResponse.json();
            
            if (contacts.length > 0) {
                const primaryContact = contacts.find(c => c.is_primary) || contacts[0];
                contactsInfo = `
                    <div style="background: #f0f8ff; padding: 12px; border-radius: 4px; margin-top: 10px;">
                        <strong style="font-size: 13px; color: #666;">Contacto Principal:</strong><br>
                        <span style="font-size: 14px;">${primaryContact.is_primary ? '⭐ ' : ''}${escapeHtml(primaryContact.contact_name || 'Sin nombre')}</span>
                        ${primaryContact.position ? '<br><span style="font-size: 13px; color: #666;">' + escapeHtml(primaryContact.position) + '</span>' : ''}
                        ${primaryContact.phone ? '<br><span style="font-size: 13px;">📱 ' + escapeHtml(primaryContact.phone) + '</span>' : ''}
                        ${primaryContact.email ? '<br><span style="font-size: 13px;">📧 ' + escapeHtml(primaryContact.email) + '</span>' : ''}
                    </div>
                `;
            }
        }
        
        // Fetch parsed items with SKU information
        const itemsResponse = await fetch(`${API_BASE}/orders/${orderId}/items-parsed`);
        let itemsTableRows = '';
        
        if (itemsResponse.ok) {
            const itemsData = await itemsResponse.json();
            if (itemsData.success && itemsData.items) {
                itemsTableRows = itemsData.items.map(item => `
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${escapeHtml(item.internal_sku)}</td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${escapeHtml(item.vendor_sku)}</td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${escapeHtml(item.name)}</td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${escapeHtml(item.qty)}</td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${escapeHtml(item.price)}</td>
                    </tr>
                `).join('');
            }
        }
        
        if (!itemsTableRows) {
            itemsTableRows = '<tr><td colspan="5" style="padding: 8px;">No hay items especificados</td></tr>';
        }
        
        // Create view order modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'view-order-modal';
        modal.innerHTML = `
            <div class="modal-content modal-large">
                <div class="modal-header">
                    <h2>Orden ${order.order_number}</h2>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <!-- Company Letterhead -->
                    <div class="letterhead" style="border-bottom: 2px solid #667eea; padding-bottom: 20px; margin-bottom: 20px; text-align: center;">
                        ${letterheadHtml}
                    </div>
                    
                    <div class="order-details-header" style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                            <div style="grid-column: 1 / -1;">
                                <strong>Proveedor:</strong><br>
                                <span style="font-size: 18px;">${order.supplier_name}</span>
                                ${contactsInfo}
                            </div>
                            <div>
                                <strong>Número de Orden:</strong><br>
                                <span style="font-size: 18px;">${order.order_number}</span>
                            </div>
                            <div>
                                <strong>Fecha de Orden:</strong><br>
                                ${new Date(order.order_date).toLocaleDateString()}
                            </div>
                            <div>
                                <strong>Fecha de Entrega:</strong><br>
                                ${order.delivery_date ? new Date(order.delivery_date).toLocaleDateString() : 'No especificada'}
                            </div>
                            <div>
                                <strong>Monto Total:</strong><br>
                                <span style="font-size: 20px; color: #667eea;">$${order.total_amount?.toFixed(2) || '0.00'}</span>
                            </div>
                            <div>
                                <strong>Estado:</strong><br>
                                <select id="order-status-select" class="form-control" style="max-width: 200px;">
                                    ${statusOptions}
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><strong>Items:</strong></label>
                        <div style="overflow-x: auto; border: 1px solid #ddd; border-radius: 4px;">
                            <table style="width: 100%; border-collapse: collapse;">
                                <thead>
                                    <tr style="background: #667eea; color: white;">
                                        <th style="padding: 10px; text-align: left; font-size: 13px;">SKU Interno</th>
                                        <th style="padding: 10px; text-align: left; font-size: 13px;">SKU Proveedor</th>
                                        <th style="padding: 10px; text-align: left; font-size: 13px;">Nombre</th>
                                        <th style="padding: 10px; text-align: left; font-size: 13px;">Cantidad</th>
                                        <th style="padding: 10px; text-align: left; font-size: 13px;">Precio</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${itemsTableRows}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    ${order.notes ? `
                        <div class="form-group">
                            <label><strong>Notas:</strong></label>
                            <textarea class="form-control" rows="3" readonly style="background: white;">${order.notes}</textarea>
                        </div>
                    ` : ''}
                    
                    <div class="form-actions">
                        <button onclick="updateOrderStatus(${order.id})" class="btn btn-success">
                            💾 Actualizar Estado
                        </button>
                        <button onclick="printOrderFromModal(${order.id}, 'internal')" class="btn btn-warning">
                            🖨️ Imprimir Interna
                        </button>
                        <button onclick="printOrder(${order.id}, 'vendor')" class="btn btn-primary">
                            🧾 Imprimir para Proveedor
                        </button>
                        <button onclick="this.closest('.modal').remove()" class="btn btn-secondary">
                            Cerrar
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar la orden');
    }
}

async function updateOrderStatus(orderId) {
    const newStatus = document.getElementById('order-status-select').value;
    
    try {
        const response = await fetch(`${API_BASE}/orders/${orderId}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: newStatus })
        });
        
        if (!response.ok) {
            throw new Error('Failed to update status');
        }
        
        showSuccess('Estado actualizado correctamente');
        
        // Reload orders list
        await loadOrders();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al actualizar el estado');
    }
}

function printOrderFromModal(orderId, mode) {
    printOrder(orderId, mode);
}

async function shareOrderWithVendor(orderId, supplierName, orderNumber) {
    try {
        // Get supplier details and contacts
        const suppliersResponse = await fetch(`${API_BASE}/suppliers`);
        const suppliers = await suppliersResponse.json();
        const supplier = suppliers.find(s => s.name === supplierName);
        
        if (!supplier) {
            showError('Proveedor no encontrado');
            return;
        }
        
        // Get supplier contacts
        const contactsResponse = await fetch(`${API_BASE}/suppliers/${supplier.id}/contacts`);
        const contacts = await contactsResponse.json();
        
        if (contacts.length === 0) {
            showError('Este proveedor no tiene contactos registrados');
            return;
        }
        
        // Get primary contact or first contact
        const primaryContact = contacts.find(c => c.is_primary) || contacts[0];
        
        const orderUrl = `${window.location.origin}/api/orders/${orderId}/print?mode=vendor&lang=esp`;
        
        // Create share modal with user instructions
        const shareModal = document.createElement('div');
        shareModal.className = 'modal';
        shareModal.id = 'share-order-modal';
        shareModal.innerHTML = `
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h2>Compartir Orden ${orderNumber}</h2>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <p style="margin-bottom: 15px; color: #666;">Compartir con <strong>${escapeHtml(supplierName)}</strong>:</p>
                    <div style="background: #e9f5e9; border-left: 4px solid #25D366; padding: 12px 16px; margin-bottom: 18px; border-radius: 4px; color: #222; font-size: 15px;">
                        <b>Instrucciones:</b><br>
                        1. Haga clic en <b>Imprimir</b> y seleccione "Guardar como PDF".<br>
                        2. Adjunte el archivo PDF al correo electrónico o mensaje de WhatsApp.<br>
                        <span style="color:#888; font-size:13px;">No envíe enlaces ni instrucciones técnicas al proveedor.</span>
                    </div>
                    ${contacts.length > 1 ? `
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label for="contact-selector">Seleccionar Contacto:</label>
                            <select id="contact-selector" class="form-control" onchange="updateShareButtons()">
                                ${contacts.map(c => `
                                    <option value="${c.id}" ${c.is_primary ? 'selected' : ''}>
                                        ${c.is_primary ? '⭐ ' : ''}${escapeHtml(c.contact_name || 'Sin nombre')} 
                                        ${c.position ? '(' + escapeHtml(c.position) + ')' : ''}
                                        ${c.phone ? '- ' + escapeHtml(c.phone) : ''} 
                                        ${c.email ? '- ' + escapeHtml(c.email) : ''}
                                    </option>
                                `).join('')}
                            </select>
                        </div>
                    ` : ''}
                    <div id="share-contact-info" style="padding: 12px; background: #f5f5f5; border-radius: 4px; margin-bottom: 15px;">
                        <div style="font-size: 14px;">
                            <strong>${primaryContact.is_primary ? '⭐ ' : ''}${escapeHtml(primaryContact.contact_name || 'Contacto')}</strong>
                            ${primaryContact.position ? '<br><span style="color: #666;">' + escapeHtml(primaryContact.position) + '</span>' : ''}
                            ${primaryContact.phone ? `<br>📱 ${escapeHtml(primaryContact.phone)} <a href='https://wa.me/${primaryContact.phone.replace(/\D/g, '')}' target='_blank' title='Abrir en WhatsApp' style='margin-left:6px;font-size:18px;text-decoration:none;'>🟢</a>` : ''}
                            ${primaryContact.email ? `<br>📧 ${escapeHtml(primaryContact.email)} <a href='mailto:${escapeHtml(primaryContact.email)}' title='Abrir en Email' style='margin-left:6px;font-size:18px;text-decoration:none;'>✉️</a>` : ''}
                        </div>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 12px;">
                        <button id="share-email-btn" class="btn btn-primary" style="width: 100%; padding: 12px; font-size: 15px;" ${!primaryContact.email ? 'disabled' : ''}>
                            📧 Enviar por Email
                            ${primaryContact.email ? '<br><small style="font-size: 12px; opacity: 0.8;">' + escapeHtml(primaryContact.email) + '</small>' : '<br><small style="font-size: 12px;">Sin email</small>'}
                        </button>
                        <button id="share-whatsapp-btn" class="btn btn-success" style="width: 100%; padding: 12px; font-size: 15px; background: #25D366;" ${!primaryContact.phone ? 'disabled' : ''}>
                            📱 Enviar por WhatsApp
                            ${primaryContact.phone ? '<br><small style="font-size: 12px; opacity: 0.8;">' + escapeHtml(primaryContact.phone) + '</small>' : '<br><small style="font-size: 12px;">Sin teléfono</small>'}
                        </button>
                        <button onclick="copyOrderLink('${orderUrl}')" class="btn btn-warning" style="width: 100%; padding: 12px; font-size: 15px;">
                            🔗 Copiar Enlace
                        </button>
                        <button onclick="printOrder(${orderId}, 'vendor')" class="btn btn-secondary" style="width: 100%; padding: 12px; font-size: 15px;">
                            🖨️ Imprimir
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(shareModal);
        shareModal.style.display = 'flex';
        
        // Store data for updateShareButtons function
        window.shareOrderData = { contacts, orderNumber, orderUrl };
        
        // Add event listeners
        document.getElementById('share-email-btn').addEventListener('click', () => {
            const selectedContactId = document.getElementById('contact-selector')?.value || primaryContact.id;
            const selectedContact = contacts.find(c => c.id == selectedContactId);
            if (selectedContact?.email) {
                shareViaEmail(selectedContact.email, orderNumber, orderUrl);
            }
        });
        
        document.getElementById('share-whatsapp-btn').addEventListener('click', () => {
            const selectedContactId = document.getElementById('contact-selector')?.value || primaryContact.id;
            const selectedContact = contacts.find(c => c.id == selectedContactId);
            if (selectedContact?.phone) {
                shareViaWhatsApp(selectedContact.phone, orderNumber, orderUrl);
            }
        });
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al preparar opciones de compartir');
    }
}

function updateShareButtons() {
    const selectedContactId = document.getElementById('contact-selector')?.value;
    const { contacts, orderNumber, orderUrl } = window.shareOrderData;
    const selectedContact = contacts.find(c => c.id == selectedContactId);
    
    if (!selectedContact) return;
    
    // Update contact info display
    const infoDiv = document.getElementById('share-contact-info');
    infoDiv.innerHTML = `
        <div style="font-size: 14px;">
            <strong>${selectedContact.is_primary ? '⭐ ' : ''}${escapeHtml(selectedContact.contact_name || 'Contacto')}</strong>
            ${selectedContact.position ? '<br><span style="color: #666;">' + escapeHtml(selectedContact.position) + '</span>' : ''}
            ${selectedContact.phone ? `<br>📱 ${escapeHtml(selectedContact.phone)} <a href='https://wa.me/${selectedContact.phone.replace(/\D/g, '')}' target='_blank' title='Abrir en WhatsApp' style='margin-left:6px;font-size:18px;text-decoration:none;'>🟢</a>` : ''}
            ${selectedContact.email ? `<br>📧 ${escapeHtml(selectedContact.email)} <a href='mailto:${escapeHtml(selectedContact.email)}' title='Abrir en Email' style='margin-left:6px;font-size:18px;text-decoration:none;'>✉️</a>` : ''}
        </div>
    `;
    
    // Update email button
    const emailBtn = document.getElementById('share-email-btn');
    emailBtn.disabled = !selectedContact.email;
    emailBtn.innerHTML = `📧 Enviar por Email${selectedContact.email ? '<br><small style="font-size: 12px; opacity: 0.8;">' + escapeHtml(selectedContact.email) + '</small>' : '<br><small style="font-size: 12px;">Sin email</small>'}`;
    
    // Update WhatsApp button
    const whatsappBtn = document.getElementById('share-whatsapp-btn');
    whatsappBtn.disabled = !selectedContact.phone;
    whatsappBtn.innerHTML = `📱 Enviar por WhatsApp${selectedContact.phone ? '<br><small style="font-size: 12px; opacity: 0.8;">' + escapeHtml(selectedContact.phone) + '</small>' : '<br><small style="font-size: 12px;">Sin teléfono</small>'}`;
}

function shareViaEmail(email, orderNumber, orderUrl) {
    const subject = encodeURIComponent(`Orden de Compra ${orderNumber}`);
    const body = encodeURIComponent(`Estimado proveedor,\n\nAdjuntamos la orden de compra ${orderNumber}.\n\nSaludos cordiales`);
    window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
    // Show helpful tip
    setTimeout(() => {
        alert('💡 Consejo: Imprima la orden como PDF y adjunte el archivo al correo.');
    }, 1500);
}

function shareViaWhatsApp(phone, orderNumber, orderUrl) {
    // Clean phone number (remove spaces, dashes, etc.)
    const cleanPhone = phone.replace(/\D/g, '');
    const message = encodeURIComponent(`Hola! Le enviamos la orden de compra ${orderNumber}.`);
    // Open WhatsApp Web or app
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
    // Show helpful tip
    setTimeout(() => {
        alert('💡 Consejo: Imprima la orden como PDF y adjunte el archivo en WhatsApp.');
    }, 1500);
}

function copyOrderLink(url) {
    navigator.clipboard.writeText(url).then(() => {
        showSuccess('✓ Enlace copiado al portapapeles');
    }).catch(err => {
        console.error('Error copying link:', err);
        // Fallback method
        const textarea = document.createElement('textarea');
        textarea.value = url;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showSuccess('✓ Enlace copiado al portapapeles');
    });
}

async function printOrder(orderId, mode = 'internal', lang = 'esp') {
    try {
        // Create modal for print preview
        const url = `${API_BASE}/orders/${orderId}/print?mode=${mode}&lang=${lang}`;
        let modal = document.getElementById('print-modal');
        if (modal) modal.remove();
        modal = document.createElement('div');
        modal.id = 'print-modal';
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content modal-large" style="width: 900px; max-width: 100vw; height: 90vh; display: flex; flex-direction: column;">
                <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center;">
                    <h2>Vista previa de impresión</h2>
                    <span class="close" onclick="document.getElementById('print-modal').remove()">&times;</span>
                </div>
                <div class="modal-body" style="flex: 1; overflow: auto;">
                    <iframe id="print-iframe" src="${url}" style="width: 100%; height: 100%; border: none; background: #fff;"></iframe>
                </div>
                <div class="modal-footer" style="display: flex; justify-content: flex-end; gap: 10px; padding: 10px 0;">
                    <button class="btn btn-primary" onclick="printIframe()">Imprimir</button>
                    <button class="btn btn-secondary" onclick="document.getElementById('print-modal').remove()">Cerrar</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        // Optionally auto-print after load
        const iframe = modal.querySelector('#print-iframe');
        iframe.addEventListener('load', () => {
            // Uncomment to auto-print:
            // setTimeout(() => printIframe(), 500);
        });
    } catch (error) {
        console.error('Error printing order:', error);
        showError('Error al imprimir la orden');
    }
}

function printIframe() {
    const iframe = document.getElementById('print-iframe');
    if (iframe && iframe.contentWindow) {
        // Wait for iframe to load if not ready
        if (iframe.contentDocument.readyState === 'complete') {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
        } else {
            iframe.onload = function() {
                iframe.contentWindow.focus();
                iframe.contentWindow.print();
            };
        }
    } else {
        showError('No se pudo imprimir la vista previa');
    }
}

function exportOrders() {
    window.location.href = `${API_BASE}/orders/export`;
}


﻿// ===== SEARCH ITEMS =====

async function searchItems() {
    const searchTerm = document.getElementById('items-search').value.trim();
    const resultsDiv = document.getElementById('items-results');
    
    if (!searchTerm) {
        resultsDiv.innerHTML = '<p class="placeholder-text">Ingrese un término de búsqueda</p>';
        currentSearchResults = [];
        return;
    }
    
    try {
        showLoading('Buscando items...');
        resultsDiv.innerHTML = '<p class="placeholder-text">Buscando...</p>';
        const response = await fetch(`${API_BASE}/items/search?search=${encodeURIComponent(searchTerm)}`);
        
        if (!response.ok) {
            if (response.status === 401) {
                console.error('Authentication required for item search');
                window.location.href = '/login';
                return;
            } else if (response.status === 403) {
                console.error('Access denied for item search');
                resultsDiv.innerHTML = '<p class="placeholder-text">No tienes permisos para buscar items</p>';
                return;
            } else {
                console.error('Error searching items:', response.status, response.statusText);
                resultsDiv.innerHTML = '<p class="placeholder-text">Error al buscar items</p>';
                return;
            }
        }
        
        const results = await response.json();
        
        if (results.length === 0) {
            resultsDiv.innerHTML = '<p class="placeholder-text">No se encontraron resultados</p>';
            currentSearchResults = [];
            return;
        }
        
        // Store results globally
        currentSearchResults = results;
        
        // Consolidate items by name (same SKU for same item name)
        const consolidatedItems = consolidateItemsByName(results);
        
        // Populate filter dropdowns
        populateItemFilters(consolidatedItems);
        
        // Display results
        displaySearchResults(consolidatedItems);
        
    } catch (error) {
        console.error('Error searching items:', error);
        resultsDiv.innerHTML = '<p class="placeholder-text">Error al buscar items</p>';
    } finally {
        hideLoading();
    }
}

function populateItemFilters(consolidatedItems) {
    // Populate category filter from LOV - ensure LOVs are loaded
    const populateCategoryFilter = async () => {
        if (!lovData.itemCategories || lovData.itemCategories.length === 0) {
            console.log('LOV data not loaded, loading now...');
            await loadLOV('itemCategories', '/api/lovs/item-categories');
        }
        
        const categoryFilter = document.getElementById('items-category-filter');
        if (categoryFilter) {
            const currentCategory = categoryFilter.value;
            categoryFilter.innerHTML = '<option value="">Todas las Categorías</option>';
            lovData.itemCategories.forEach(cat => {
                const option = document.createElement('option');
                option.value = cat.id;
                option.textContent = cat.name_es;
                if (cat.id == currentCategory) option.selected = true;
                categoryFilter.appendChild(option);
            });
        }
    };
    
    populateCategoryFilter();
    
    // Update vendor filter (still from data)
    const vendorFilter = document.getElementById('items-vendor-filter');
    if (vendorFilter) {
        const currentVendor = vendorFilter.value;
        vendorFilter.innerHTML = '<option value="">Todos los Proveedores</option>';
        // Extract unique vendors from consolidatedItems
        const allVendors = new Set();
        consolidatedItems.forEach(itemData => {
            itemData.suppliers.forEach(s => {
                allVendors.add(s.supplier_name);
            });
        });
        Array.from(allVendors).sort().forEach(vendor => {
            const option = document.createElement('option');
            option.value = vendor;
            option.textContent = vendor;
            if (vendor === currentVendor) option.selected = true;
            vendorFilter.appendChild(option);
        });
    }
}

function applyItemFilters() {
    if (currentSearchResults.length === 0) return;
    
    const categoryFilter = document.getElementById('items-category-filter').value;
    const vendorFilter = document.getElementById('items-vendor-filter').value;
    const sortBy = document.getElementById('items-sort').value;
    
    // Consolidate items
    let consolidatedItems = consolidateItemsByName(currentSearchResults);
    
    // Apply category filter
    if (categoryFilter) {
        consolidatedItems = consolidatedItems.filter(itemData => 
            itemData.item.category_id == categoryFilter
        );
    }
    
    // Apply vendor filter
    if (vendorFilter) {
        consolidatedItems = consolidatedItems.filter(itemData =>
            itemData.suppliers.some(s => s.supplier_name === vendorFilter)
        );
        // Filter suppliers within each item
        consolidatedItems = consolidatedItems.map(itemData => ({
            ...itemData,
            suppliers: itemData.suppliers.filter(s => s.supplier_name === vendorFilter)
        }));
    }
    
    // Apply sorting
    consolidatedItems.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return a.item.name.localeCompare(b.item.name);
            case 'vendor':
                const vendorA = a.suppliers[0]?.supplier_name || '';
                const vendorB = b.suppliers[0]?.supplier_name || '';
                return vendorA.localeCompare(vendorB);
            case 'price-asc':
                const minPriceA = Math.min(...a.suppliers.map(s => s.price || Infinity));
                const minPriceB = Math.min(...b.suppliers.map(s => s.price || Infinity));
                return minPriceA - minPriceB;
            case 'price-desc':
                const maxPriceA = Math.min(...a.suppliers.map(s => s.price || Infinity));
                const maxPriceB = Math.min(...b.suppliers.map(s => s.price || Infinity));
                return maxPriceB - maxPriceA;
            default:
                return 0;
        }
    });
    
    displaySearchResults(consolidatedItems);
}

function displaySearchResults(consolidatedItems) {
    const resultsDiv = document.getElementById('items-results');
    let html = '<div class="items-selection-container">';
        
        consolidatedItems.forEach(itemData => {
            const item = itemData.item;
            const suppliers = itemData.suppliers || [];
            
            // Find cheapest price
            const cheapestSupplier = suppliers.reduce((min, s) => 
                !min || (s.price && (!min.price || s.price < min.price)) ? s : min, null);
            
            html += `
                <div class="item-card">
                    <div class="item-header">
                        <label class="item-checkbox-label">
                            <input type="checkbox" class="item-checkbox" 
                                   data-item-id="${item.id}" 
                                   data-item-name="${item.name}"
                                   data-item-code="${item.item_code}"
                                   onchange="updateSelectedItems()">
                            <h3>${item.name}</h3>
                        </label>
                    </div>
                    <div class="item-info">
                        <div class="info-item">
                            <span class="info-label">Código (SKU)</span>
                            <span class="info-value">${item.item_code}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Categoría</span>
                            <span class="info-value">${item.category || 'N/A'}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Unidad</span>
                            <span class="info-value">${item.unit || 'N/A'}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Precio más bajo</span>
                            <span class="info-value">${cheapestSupplier && cheapestSupplier.price ? '$' + cheapestSupplier.price.toFixed(2) : 'N/A'}</span>
                        </div>
                    </div>
                    ${item.description ? `<p><strong>Descripción:</strong> ${item.description}</p>` : ''}
                    
                    <div class="suppliers-list">
                        <h4>Proveedores disponibles (${suppliers.length})</h4>
                        <div class="suppliers-grid">
                            ${suppliers.map(s => `
                                <div class="supplier-item ${cheapestSupplier && s.supplier_id === cheapestSupplier.supplier_id ? 'cheapest' : ''}">
                                    <div class="supplier-info">
                                        <strong>${s.supplier_name}</strong>
                                        ${cheapestSupplier && s.supplier_id === cheapestSupplier.supplier_id ? '<span class="badge-cheapest">Más Económico</span>' : ''}
                                        <br>
                                        <small>${s.email || ''} ${s.phone ? '| ' + s.phone : ''}</small>
                                        ${s.supplier_item_code ? `<br><small>Código: ${s.supplier_item_code}</small>` : ''}
                                    </div>
                                    <div class="supplier-price">
                                        ${s.price ? `<strong>$${s.price.toFixed(2)}</strong>` : 'N/A'}
                                        ${s.lead_time_days ? `<br><small>${s.lead_time_days} días</small>` : ''}
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        
        // Add single order button
        html += `
            <div class="order-action-bar">
                <div class="selected-items-summary" id="selected-summary">
                    <span>Seleccione items para crear orden</span>
                </div>
                <button onclick="createBulkOrder()" class="btn btn-primary btn-lg" id="create-order-btn" disabled>
                    📦 Crear Orden
                </button>
            </div>
        `;
        
        resultsDiv.innerHTML = html;
        selectedItems = [];
}

function consolidateItemsByName(results) {
    const itemsMap = new Map();
    
    results.forEach(result => {
        const item = result.item;
        const suppliers = result.suppliers || [];
        
        // Use item name as key to consolidate
        if (!itemsMap.has(item.name)) {
            itemsMap.set(item.name, {
                item: item,
                suppliers: []
            });
        }
        
        const consolidated = itemsMap.get(item.name);
        
        // Add suppliers from this result
        suppliers.forEach(supplier => {
            // Avoid duplicates
            if (!consolidated.suppliers.find(s => s.supplier_id === supplier.supplier_id)) {
                consolidated.suppliers.push(supplier);
            }
        });
    });
    
    return Array.from(itemsMap.values());
}

function updateSelectedItems() {
    const checkboxes = document.querySelectorAll('.item-checkbox:checked');
    selectedItems = Array.from(checkboxes).map(cb => ({
        id: parseInt(cb.dataset.itemId),
        name: cb.dataset.itemName,
        code: cb.dataset.itemCode
    }));
    
    const summary = document.getElementById('selected-summary');
    const orderBtn = document.getElementById('create-order-btn');
    
    if (selectedItems.length === 0) {
        summary.innerHTML = '<span>Seleccione items para crear orden</span>';
        orderBtn.disabled = true;
    } else {
        summary.innerHTML = `<span><strong>${selectedItems.length}</strong> item(s) seleccionado(s)</span>`;
        orderBtn.disabled = false;
    }
}

async function createBulkOrder() {
    if (selectedItems.length === 0) {
        showError('Seleccione al menos un item');
        return;
    }
    
    try {
        // Get common suppliers for selected items
        const itemIds = selectedItems.map(item => item.id);
        const response = await fetch(`${API_BASE}/items/common-suppliers`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ item_ids: itemIds })
        });
        
        const data = await response.json();
        
        if (data.common_suppliers && data.common_suppliers.length > 0) {
            // Has common suppliers - show modal to select supplier and quantities
            showBulkOrderModal(data.common_suppliers, selectedItems);
        } else if (data.supplier_groups && data.supplier_groups.length > 0) {
            // No common supplier - need multiple orders
            showMultipleOrdersModal(data.supplier_groups, selectedItems);
        } else {
            showError('No se encontraron proveedores para los items seleccionados');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al procesar la orden');
    }
}

function showBulkOrderModal(commonSuppliers, items) {
    // Sort by total cost (cheapest first)
    commonSuppliers.sort((a, b) => (a.total_cost || Infinity) - (b.total_cost || Infinity));
    
    const selectedSupplier = commonSuppliers[0]; // Default to cheapest
    
    let html = `
        <div id="bulk-order-modal" class="modal active">
            <div class="modal-content modal-large">
                <span class="close" onclick="closeBulkOrderModal()">&times;</span>
                <h2>Crear Orden - ${items.length} Items</h2>
                
                <div class="form-group">
                    <label>Proveedor</label>
                    <select id="bulk-supplier-select" onchange="updateBulkOrderSupplier()">
                        ${commonSuppliers.map((s, idx) => `
                            <option value="${idx}" ${idx === 0 ? 'selected' : ''}>
                                ${s.supplier_name} - Total: $${s.total_cost?.toFixed(2) || 'N/A'}
                                ${idx === 0 ? ' (Más Económico)' : ''}
                            </option>
                        `).join('')}
                    </select>
                </div>
                
                <div class="items-order-list">
                    <table>
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Código</th>
                                <th>Precio Unit.</th>
                                <th>Cantidad</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody id="bulk-order-items">
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4"><strong>Total:</strong></td>
                                <td><strong id="bulk-order-total">$0.00</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <div class="form-group">
                    <label>Fecha de Entrega *</label>
                    <input type="date" id="bulk-delivery-date" required>
                </div>
                
                <div class="form-group">
                    <label>Notas</label>
                    <textarea id="bulk-order-notes" rows="3"></textarea>
                </div>
                
                <div class="form-actions">
                    <button onclick="submitBulkOrder()" class="btn btn-primary">Crear Orden</button>
                    <button onclick="closeBulkOrderModal()" class="btn btn-secondary">Cancelar</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', html);
    
    // Store data in global for access
    window.bulkOrderData = { commonSuppliers, items };
    updateBulkOrderSupplier();
}

function updateBulkOrderSupplier() {
    const selectIdx = parseInt(document.getElementById('bulk-supplier-select').value);
    const supplier = window.bulkOrderData.commonSuppliers[selectIdx];
    const items = window.bulkOrderData.items;
    
    let html = '';
    let total = 0;
    
    items.forEach(item => {
        const itemPrice = supplier.items.find(i => i.item_id === item.id);
        const price = itemPrice?.price || 0;
        
        html += `
            <tr>
                <td>${item.name}</td>
                <td>${item.code}</td>
                <td>$${price.toFixed(2)}</td>
                <td>
                    <input type="number" class="qty-input" 
                           data-price="${price}" 
                           value="1" min="1" 
                           onchange="updateBulkOrderTotal()">
                </td>
                <td class="subtotal">$${price.toFixed(2)}</td>
            </tr>
        `;
        total += price;
    });
    
    document.getElementById('bulk-order-items').innerHTML = html;
    document.getElementById('bulk-order-total').textContent = '$' + total.toFixed(2);
}

function updateBulkOrderTotal() {
    let total = 0;
    document.querySelectorAll('.qty-input').forEach((input, idx) => {
        const price = parseFloat(input.dataset.price);
        const qty = parseInt(input.value) || 0;
        const subtotal = price * qty;
        
        const subtotalCell = input.closest('tr').querySelector('.subtotal');
        subtotalCell.textContent = '$' + subtotal.toFixed(2);
        
        total += subtotal;
    });
    
    document.getElementById('bulk-order-total').textContent = '$' + total.toFixed(2);
}

async function submitBulkOrder() {
    const selectIdx = parseInt(document.getElementById('bulk-supplier-select').value);
    const supplier = window.bulkOrderData.commonSuppliers[selectIdx];
    const deliveryDate = document.getElementById('bulk-delivery-date').value;
    const notes = document.getElementById('bulk-order-notes').value;
    
    if (!deliveryDate) {
        showError('Fecha de entrega requerida');
        return;
    }
    
    // Build items list
    const itemsText = [];
    let totalAmount = 0;
    
    document.querySelectorAll('.qty-input').forEach((input, idx) => {
        const qty = parseInt(input.value) || 0;
        const price = parseFloat(input.dataset.price);
        const itemName = window.bulkOrderData.items[idx].name;
        
        itemsText.push(`${qty} x ${itemName} @ $${price.toFixed(2)}`);
        totalAmount += qty * price;
    });
    
    const orderData = {
        supplier_id: supplier.supplier_id,
        delivery_date: deliveryDate,
        total_amount: totalAmount,
        items: itemsText.join('\n'),
        notes: notes
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        
        if (response.ok) {
            closeBulkOrderModal();
            showSuccess('Orden creada exitosamente');
            
            // Clear selections
            document.querySelectorAll('.item-checkbox').forEach(cb => cb.checked = false);
            updateSelectedItems();
        } else {
            showError('Error al crear orden');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear orden');
    }
}

function closeBulkOrderModal() {
    const modal = document.getElementById('bulk-order-modal');
    if (modal) {
        modal.remove();
    }
    window.bulkOrderData = null;
}

function showMultipleOrdersModal(supplierGroups, items) {
    let html = `
        <div id="bulk-order-modal" class="modal active">
            <div class="modal-content modal-large">
                <span class="close" onclick="closeBulkOrderModal()">&times;</span>
                <h2>Crear Órdenes Múltiples</h2>
                
                <div class="alert alert-info">
                    <strong>ℹ️ No hay un proveedor común para todos los items.</strong><br>
                    Se crearán ${supplierGroups.length} órdenes separadas:
                </div>
                
                <div class="orders-preview">
                    ${supplierGroups.map((group, idx) => `
                        <div class="order-group">
                            <h4>Orden ${idx + 1}: ${group.supplier_name}</h4>
                            <ul>
                                ${group.items.map(item => `
                                    <li>${item.item_name} - $${item.price?.toFixed(2) || 'N/A'}</li>
                                `).join('')}
                            </ul>
                            <p><strong>Total: $${group.total_cost?.toFixed(2) || 'N/A'}</strong></p>
                        </div>
                    `).join('')}
                </div>
                
                <div class="form-group">
                    <label>Fecha de Entrega (todas las órdenes) *</label>
                    <input type="date" id="multi-delivery-date" required>
                </div>
                
                <div class="form-actions">
                    <button onclick="submitMultipleOrders()" class="btn btn-primary">Crear ${supplierGroups.length} Órdenes</button>
                    <button onclick="closeBulkOrderModal()" class="btn btn-secondary">Cancelar</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', html);
    window.bulkOrderData = { supplierGroups };
}

async function submitMultipleOrders() {
    const deliveryDate = document.getElementById('multi-delivery-date').value;
    
    if (!deliveryDate) {
        showError('Fecha de entrega requerida');
        return;
    }
    
    const supplierGroups = window.bulkOrderData.supplierGroups;
    
    try {
        let successCount = 0;
        
        for (const group of supplierGroups) {
            const itemsText = group.items.map(item => 
                `1 x ${item.item_name} @ $${item.price?.toFixed(2) || '0.00'}`
            ).join('\n');
            
            const orderData = {
                supplier_id: group.supplier_id,
                delivery_date: deliveryDate,
                total_amount: group.total_cost,
                items: itemsText,
                notes: `Orden múltiple (${successCount + 1}/${supplierGroups.length})`
            };
            
            const response = await fetch(`${API_BASE}/orders`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderData)
            });
            
            if (response.ok) {
                successCount++;
            }
        }
        
        closeBulkOrderModal();
        showSuccess(`${successCount} órdenes creadas exitosamente`);
        
        // Clear selections
        document.querySelectorAll('.item-checkbox').forEach(cb => cb.checked = false);
        updateSelectedItems();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear órdenes');
    }
}

# Initialize-System.ps1
# Initializes Python environment and database

function Initialize-PythonEnvironment {
    param(
        [string]$InstallPath,
        [string]$PythonCmd
    )
    
    Write-Host "=== Initializing Python Environment ===" -ForegroundColor Cyan
    Write-Host "Install Path: $InstallPath" -ForegroundColor Gray
    Write-Host "Python Command: $PythonCmd" -ForegroundColor Gray
    
    $result = @{
        Success = $false
        VenvCreated = $false
        DependenciesInstalled = $false
        Errors = @()
    }
    
    Push-Location $InstallPath
    
    try {
        Write-Host "Creating virtual environment..." -ForegroundColor Yellow
        # Create virtual environment
        if (Test-Path "venv") {
            Write-Host "  Removing existing venv" -ForegroundColor Gray
            Remove-Item -Recurse -Force venv -ErrorAction SilentlyContinue
        }
        
        Write-Host "  Running: $PythonCmd -m venv venv" -ForegroundColor Gray
        $venvOut = & $PythonCmd -m venv venv 2>&1
        $venvOut | ForEach-Object { Write-Host "  [venv] $_" -ForegroundColor Gray }
        
        if ($LASTEXITCODE -eq 0) {
            $result.VenvCreated = $true
            Write-Host "  Virtual environment created successfully" -ForegroundColor Green
        } else {
            $result.Errors += "Failed to create virtual environment"
            Write-Host "  Failed to create virtual environment" -ForegroundColor Red
            Pop-Location
            return $result
        }
        
        # Install dependencies
        if (Test-Path "requirements.txt") {
            Write-Host "Installing Python dependencies..." -ForegroundColor Yellow
            $pipPath = "venv\Scripts\pip.exe"
            
            Write-Host "  Upgrading pip..." -ForegroundColor Gray
            $pipUpOut = & $pipPath install --upgrade pip --quiet 2>&1
            if ($LASTEXITCODE -ne 0) { $pipUpOut | ForEach-Object { Write-Host "  [pip] $_" -ForegroundColor Yellow } }
            
            Write-Host "  Installing requirements from requirements.txt..." -ForegroundColor Gray
            # Run without --quiet so every package install line flows into the transcript
            $pipOut = & $pipPath install -r requirements.txt 2>&1
            $pipOut | ForEach-Object { Write-Host "  [pip] $_" -ForegroundColor Gray }
            
            if ($LASTEXITCODE -eq 0) {
                $result.DependenciesInstalled = $true
                $result.Success = $true
                Write-Host "  Dependencies installed successfully" -ForegroundColor Green
            } else {
                $result.Errors += "Failed to install dependencies"
                Write-Host "  Failed to install dependencies" -ForegroundColor Red
            }
        } else {
            $result.Errors += "requirements.txt not found"
        }
        
    } catch {
        $result.Errors += $_.Exception.Message
    }
    
    Pop-Location
    return $result
}

function Initialize-Database {
    param(
        [string]$InstallPath,
        [bool]$CreateDefaultAdmin = $true
    )
    
    Write-Host "=== Initializing Database ===" -ForegroundColor Cyan
    Write-Host "Install Path: $InstallPath" -ForegroundColor Gray
    Write-Host "Create Default Admin: $CreateDefaultAdmin" -ForegroundColor Gray
    
    $result = @{
        Success = $false
        DatabaseCreated = $false
        AdminCreated = $false
        Errors = @()
    }
    
    Push-Location $InstallPath
    
    try {
        $pythonExe = "venv\Scripts\python.exe"
        
        # Check if database already exists
        $dbPath = "data\suppliers.db"
        $dbExists = Test-Path $dbPath
        
        Write-Host "Checking database..." -ForegroundColor Yellow
        if (-not $dbExists) {
            Write-Host "  Database does not exist, creating schema..." -ForegroundColor Gray
            # Use init_db() directly - reliable, no need to start/stop Flask
            # Import via package path (api.database) so relative imports in models.py work
            $initScript = @"
import sys, os
install_root = os.getcwd()
sys.path.insert(0, install_root)
from api.database import init_db
init_db()
print('DB_INIT_OK')
"@
            $initScript | & $pythonExe 2>&1 | ForEach-Object { Write-Host "  $_" -ForegroundColor Gray }
            
            if (Test-Path $dbPath) {
                $result.DatabaseCreated = $true
                Write-Host "  Database created successfully" -ForegroundColor Green
            } else {
                Write-Host "  Could not create database - will continue, migration may supply it" -ForegroundColor Yellow
                # Non-fatal: for upgrades the migrate step restores data;
                # for fresh installs the app creates it on first run
                $result.DatabaseCreated = $true
            }
        } else {
            $result.DatabaseCreated = $true
            Write-Host "  Database already exists" -ForegroundColor Green
        }
        
        # Create default admin user if requested
        if ($CreateDefaultAdmin) {
            Write-Host "Creating default admin user..." -ForegroundColor Yellow
            if (Test-Path "api\init_users.py") {
                Write-Host "  Running init_users.py..." -ForegroundColor Gray
                $output = & $pythonExe "api\init_users.py" 2>&1
                $output | ForEach-Object { Write-Host "  [init_users] $_" -ForegroundColor Gray }
                if ($LASTEXITCODE -eq 0) {
                    $result.AdminCreated = $true
                    Write-Host "  Admin user created successfully" -ForegroundColor Green
                } else {
                    Write-Host "  Failed to create admin user" -ForegroundColor Red
                }
            } else {
                Write-Host "  init_users.py not found" -ForegroundColor Red
            }
        }
        
        $result.Success = $result.DatabaseCreated
        Write-Host "Database initialization completed" -ForegroundColor Green

        # Seed LOV data (idempotent: inserts only if tables are empty).
        # Runs for every install/upgrade so new LOV types (e.g. contact_types) are
        # always present regardless of which version is being upgraded from.
        $lovsScript = Join-Path $InstallPath "api\init_lovs.py"
        if (Test-Path $lovsScript) {
            Write-Host "Initializing LOV data..." -ForegroundColor Yellow
            $lovsOut = & $pythonExe $lovsScript 2>&1
            $lovsOut | ForEach-Object { Write-Host "  [lovs] $_" -ForegroundColor Gray }
            if ($LASTEXITCODE -eq 0) {
                Write-Host "  LOV data initialized successfully" -ForegroundColor Green
            } else {
                Write-Host "  Warning: init_lovs.py exited with code $LASTEXITCODE" -ForegroundColor Yellow
            }
        } else {
            Write-Host "  init_lovs.py not found, skipping LOV initialization" -ForegroundColor Yellow
        }
        
    } catch {
        $result.Errors += $_.Exception.Message
        Write-Host "Database initialization failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    Pop-Location
    return $result
}

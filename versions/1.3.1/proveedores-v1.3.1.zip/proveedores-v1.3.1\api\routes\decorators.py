# -*- coding: utf-8 -*-
"""Shared authentication and permission decorators."""
from functools import wraps
from flask import jsonify, request
from flask_login import login_required, current_user


def permission_required(permission):
    """Decorator to check if user has required permission."""
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            if not current_user.has_permission(permission):
                return jsonify({'error': 'Acceso denegado. Permisos insuficientes.'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def role_required(*roles):
    """Decorator to check if user has one of the required roles."""
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            if current_user.rol not in roles:
                return jsonify({'error': 'Acceso denegado. Rol insuficiente.'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@echo off
REM ============================================================
REM  Service Diagnostic Tool
REM ============================================================

echo.
echo ============================================================
echo   DIAGNOSTICO DE SERVICIOS
echo ============================================================
echo.

powershell -ExecutionPolicy Bypass -Command "
    $serviceName = 'SistemaProveedores'
    Write-Host '=== DIAGNOSTICO DEL SERVICIO ===' -ForegroundColor Cyan
    Write-Host \"Servicio: $serviceName\" -ForegroundColor White
    Write-Host ''
    
    # Check if service exists
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service) {
        Write-Host 'Estado del servicio:' -ForegroundColor Yellow
        Write-Host \"  Nombre: $($service.Name)\" -ForegroundColor White
        Write-Host \"  Estado: $($service.Status)\" -ForegroundColor White
        Write-Host \"  Tipo de inicio: $($service.StartType)\" -ForegroundColor White
        Write-Host ''
    } else {
        Write-Host 'Servicio NO encontrado en el Administrador de Servicios' -ForegroundColor Yellow
        Write-Host ''
    }
    
    # Check NSSM status
    $nssmPath = Join-Path (Get-Location) 'utilities\service\nssm.exe'
    if (Test-Path $nssmPath) {
        Write-Host 'Estado NSSM:' -ForegroundColor Yellow
        $nssmStatus = & $nssmPath status $serviceName 2>$null
        $exitCode = $LASTEXITCODE
        Write-Host \"  Codigo de salida: $exitCode\" -ForegroundColor White
        if ($exitCode -eq 0) {
            Write-Host '  NSSM reporta: Servicio OK' -ForegroundColor Green
        } elseif ($exitCode -eq 3) {
            Write-Host '  NSSM reporta: Servicio no encontrado' -ForegroundColor Yellow
        } else {
            Write-Host '  NSSM reporta: Estado desconocido' -ForegroundColor Yellow
        }
        Write-Host ''
    } else {
        Write-Host 'NSSM no encontrado' -ForegroundColor Yellow
        Write-Host ''
    }
    
    # Check for running processes
    Write-Host 'Procesos relacionados:' -ForegroundColor Yellow
    
    $pythonProcs = Get-Process -Name 'python' -ErrorAction SilentlyContinue
    if ($pythonProcs) {
        Write-Host '  Procesos Python encontrados:' -ForegroundColor White
        $pythonProcs | ForEach-Object {
            $path = $_.Path
            if ($path -and ($path -like '*proveedores*' -or $path -like '*SistemaProveedores*')) {
                Write-Host \"    PID: $($_.Id) - $path\" -ForegroundColor Red
            } else {
                Write-Host \"    PID: $($_.Id) - $path\" -ForegroundColor Gray
            }
        }
    } else {
        Write-Host '  No se encontraron procesos Python' -ForegroundColor Green
    }
    
    $cmdProcs = Get-Process -Name 'cmd' -ErrorAction SilentlyContinue | Where-Object {
        $_.CommandLine -like '*run.bat*' -or $_.CommandLine -like '*SistemaProveedores*'
    }
    if ($cmdProcs) {
        Write-Host '  Procesos CMD relacionados:' -ForegroundColor White
        $cmdProcs | ForEach-Object {
            Write-Host \"    PID: $($_.Id) - $($_.CommandLine)\" -ForegroundColor Red
        }
    } else {
        Write-Host '  No se encontraron procesos CMD relacionados' -ForegroundColor Green
    }
    
    Write-Host ''
    Write-Host '=== RECOMENDACIONES ===' -ForegroundColor Cyan
    
    if ($service -and $service.Status -eq 'Running') {
        Write-Host '• El servicio esta ejecutandose. Si no funciona:' -ForegroundColor Yellow
        Write-Host '  - Ejecuta cleanup_service_admin.bat como administrador' -ForegroundColor White
    } elseif ($pythonProcs -or $cmdProcs) {
        Write-Host '• Hay procesos relacionados ejecutandose. Ejecuta:' -ForegroundColor Yellow
        Write-Host '  - cleanup_service_admin.bat como administrador' -ForegroundColor White
    } else {
        Write-Host '• No se encontraron problemas evidentes.' -ForegroundColor Green
        Write-Host '  - Intenta reinstalar el servicio' -ForegroundColor White
    }
    
    Write-Host ''
    Write-Host 'Archivos de diagnostico disponibles:' -ForegroundColor Gray
    Write-Host '  logs\service.log - Log del servicio' -ForegroundColor White
    Write-Host '  utilities\cleanup_service_admin.bat - Limpieza forzada' -ForegroundColor White
"

echo.
echo Presiona cualquier tecla para continuar...
pause >nul
# Troubleshooting: Service Running but Web Interface Not Accessible

## Problem Description

The Windows service "SistemaProveedores" appears to be running in the background, but the web interface at `http://localhost:5000` is not accessible. This typically occurs when:

- The Windows service wrapper is running, but the Flask application inside it has crashed
- The Flask app encountered an error during startup
- Port 5000 is blocked or in use by another process
- Database connection issues prevent the app from starting properly

## Quick Diagnosis

Run the diagnostic script:
- **Batch version:** `utilities\troubleshoot_web_service.bat`
- **PowerShell version:** `powershell -ExecutionPolicy Bypass -File scripts\troubleshoot_web_service.ps1`

This script will:
1. Check if the Windows service is running
2. Test if the web service responds on localhost:5000
3. Identify the root cause
4. Provide specific recovery steps

## Manual Troubleshooting Steps

### Step 1: Check Service Status
```batch
utilities\diagnose_service.bat
```

Look for:
- Service status should be "Running"
- No orphaned Python processes
- NSSM reports service as OK

### Step 2: Check Web Service Response
Open a browser and navigate to: `http://localhost:5000`

**Expected Results:**
- ✅ Page loads with login screen
- ❌ "Connection refused" or "Site cannot be reached"

### Step 3: Check Service Logs
```batch
notepad logs\service.log
```

Look for recent error messages, especially:
- Flask startup errors
- Database connection failures
- Port binding issues

### Step 4: Check for Port Conflicts
```powershell
# In PowerShell, check what's using port 5000
netstat -ano | findstr :5000
```

If another process is using port 5000, note the PID and terminate it.

## Recovery Procedures

### Option 1: Service Restart (Recommended)
```batch
# Stop and restart the service
utilities\service\manage-service.bat stop
utilities\service\manage-service.bat start
```

Wait 30 seconds, then test `http://localhost:5000`

### Option 2: Force Cleanup and Reinstall
If restart doesn't work:
```batch
# Run as administrator
utilities\cleanup_service_admin.bat
utilities\service\manage-service.bat install
```

### Option 3: Manual Flask Startup (Temporary)
For immediate access while troubleshooting:
```batch
# Start Flask manually to test
INSTALAR.bat
```

This runs the app in console mode for testing.

## Common Causes and Solutions

### Database Connection Issues
**Symptoms:** Service starts but web interface shows database errors
**Solution:**
```batch
# Check database file
dir data\suppliers.db

# Restore from backup if corrupted
utilities\restore_backup.bat
```

### Port Already in Use
**Symptoms:** "Address already in use" in logs
**Solution:**
```powershell
# Find and kill process using port 5000
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

### Python Environment Issues
**Symptoms:** Import errors in service.log
**Solution:**
```batch
# Reinstall Python dependencies
pip install -r requirements.txt
```

### Firewall Blocking Port
**Symptoms:** Service runs but external access fails
**Solution:**
```powershell
# Allow port 5000 through firewall
New-NetFirewallRule -DisplayName "SistemaProveedores" -Direction Inbound -LocalPort 5000 -Protocol TCP -Action Allow
```

## Advanced Diagnostics

### Check Flask Process Health
```powershell
# Look for Python processes with Flask
Get-Process python | Where-Object {$_.CommandLine -like "*flask*"} | Select-Object Id, CommandLine
```

### Test Internal Service Communication
```powershell
# Test if Flask app responds internally
Invoke-WebRequest -Uri "http://127.0.0.1:5000" -TimeoutSec 5
```

### Service Configuration Check
```powershell
# Check NSSM service configuration
& "utilities\service\nssm.exe" dump "SistemaProveedores"
```

## Prevention

- **Monitor Logs Regularly:** Check `logs\service.log` weekly
- **Database Backups:** Run automated backups
- **Service Health Monitoring:** Use `diagnose_service_detailed.bat` monthly
- **Keep Dependencies Updated:** Update Python packages regularly

## Emergency Contact

If all recovery procedures fail:
1. Export your data: `utilities\export_data.bat`
2. Uninstall completely: `uninstall.bat`
3. Reinstall fresh: Run the installer again

## Related Files

- `utilities\troubleshoot_web_service.bat` - Automated diagnostic script (batch)
- `scripts\troubleshoot_web_service.ps1` - Automated diagnostic script (PowerShell)
- `utilities\diagnose_service.bat` - Basic service diagnostic
- `utilities\cleanup_service_admin.bat` - Force cleanup (admin required)
- `logs\service.log` - Service activity log
- `utilities\service\manage-service.bat` - Service management</content>
<parameter name="filePath">c:\Projects\Proveedores\proveedores\docs\SERVICE_TROUBLESHOOTING.md
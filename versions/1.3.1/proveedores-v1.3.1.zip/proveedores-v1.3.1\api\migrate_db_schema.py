"""
Database migration script to add LOV foreign key columns to existing tables
This script adds the new foreign key columns to existing tables without data loss.

Expected structure:
  project_root/
  ├── api/
  │   ├── app.py
  │   ├── database.py
  │   ├── models.py
  │   └── migrate_db_schema.py (this file)
  ├── data/
  │   └── suppliers.db
  └── venv/
"""
import sys
import os

# Add api directory to path for imports
api_dir = os.path.dirname(os.path.abspath(__file__))
if api_dir not in sys.path:
    sys.path.insert(0, api_dir)

from database import SessionLocal, Base, engine
from sqlalchemy import text, inspect

def add_column_if_not_exists(table_name, column_name, column_type):
    """Add a column to a table if it doesn't already exist"""
    db = SessionLocal()
    try:
        # Check if column exists
        inspector = inspect(engine)
        columns = [col['name'] for col in inspector.get_columns(table_name)]
        if column_name in columns:
            print(f"Column {column_name} already exists in {table_name}")
            return True

        # Add the column
        alter_sql = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}"
        db.execute(text(alter_sql))
        db.commit()
        print(f"Added column {column_name} to {table_name}")
        return True

    except Exception as e:
        print(f"Error adding column {column_name} to {table_name}: {e}")
        db.rollback()
        return False
    finally:
        db.close()

def migrate_items_table():
    """Add LOV foreign key columns to items table"""
    print("Migrating items table...")

    # Add category_id column
    add_column_if_not_exists('items', 'category_id', 'INTEGER REFERENCES item_categories(id)')

    # Add unit_id column
    add_column_if_not_exists('items', 'unit_id', 'INTEGER REFERENCES units_of_measure(id)')

    # Add condition_id column
    add_column_if_not_exists('items', 'condition_id', 'INTEGER REFERENCES item_conditions(id)')

def migrate_suppliers_table():
    """Add LOV foreign key columns to suppliers table"""
    print("Migrating suppliers table...")

    # Add category_id column
    add_column_if_not_exists('suppliers', 'category_id', 'INTEGER REFERENCES supplier_categories(id)')

    # Add country_id column
    add_column_if_not_exists('suppliers', 'country_id', 'INTEGER REFERENCES countries(id)')

    # Add state_id column
    add_column_if_not_exists('suppliers', 'state_id', 'INTEGER REFERENCES states(id)')

    # Add payment_term_id column
    add_column_if_not_exists('suppliers', 'payment_term_id', 'INTEGER REFERENCES payment_terms(id)')

def migrate_supplier_contacts_table():
    """Add LOV foreign key columns to supplier_contacts table"""
    print("Migrating supplier_contacts table...")

    # Add contact_type_id column
    add_column_if_not_exists('supplier_contacts', 'contact_type_id', 'INTEGER REFERENCES contact_types(id)')

def migrate_orders_table():
    """Add LOV foreign key columns to orders table"""
    print("Migrating orders table...")

    # Add status_id column
    add_column_if_not_exists('orders', 'status_id', 'INTEGER REFERENCES order_statuses(id)')
    """Create indexes for the new foreign key columns"""
    print("Creating indexes for new columns...")

    db = SessionLocal()
    try:
        # Create indexes for performance
        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_items_category_id ON items(category_id)",
            "CREATE INDEX IF NOT EXISTS idx_items_unit_id ON items(unit_id)",
            "CREATE INDEX IF NOT EXISTS idx_items_condition_id ON items(condition_id)",
            "CREATE INDEX IF NOT EXISTS idx_suppliers_category_id ON suppliers(category_id)",
            "CREATE INDEX IF NOT EXISTS idx_suppliers_country_id ON suppliers(country_id)",
            "CREATE INDEX IF NOT EXISTS idx_suppliers_state_id ON suppliers(state_id)",
            "CREATE INDEX IF NOT EXISTS idx_suppliers_payment_term_id ON suppliers(payment_term_id)",
            "CREATE INDEX IF NOT EXISTS idx_supplier_contacts_contact_type_id ON supplier_contacts(contact_type_id)",
            "CREATE INDEX IF NOT EXISTS idx_orders_status_id ON orders(status_id)"
        ]

        for index_sql in indexes:
            db.execute(text(index_sql))

        db.commit()
        print("Indexes created successfully")

    except Exception as e:
        print(f"Error creating indexes: {e}")
        db.rollback()
    finally:
        db.close()

def run_migration():
    """Run all database schema migrations"""
    print("=" * 60)
    print("DATABASE SCHEMA MIGRATION")
    print("=" * 60)
    print("This script will:")
    print("  1. Add new LOV foreign key columns to existing tables")
    print("  2. Create indexes for performance")
    print("  3. Preserve all existing data")
    print("=" * 60)

    # Run migrations
    migrate_items_table()
    migrate_suppliers_table()
    migrate_supplier_contacts_table()
    migrate_orders_table()
    create_indexes()

    print("=" * 60)
    print("Database schema migration complete!")
    print("New LOV columns have been added to existing tables.")
    print("=" * 60)

if __name__ == '__main__':
    run_migration()
# -*- coding: utf-8 -*-
"""Main / index route blueprint."""
from flask import Blueprint, render_template
from flask_login import login_required

main_bp = Blueprint('main', __name__)


@main_bp.route('/')
@login_required
def index():
    """Serve the main UI."""
    return render_template('index.html')

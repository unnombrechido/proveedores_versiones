@echo off
REM ============================================================
REM  Sistema de Gestión de Proveedores e Inventario v0.1
REM  Instalador de Dependencias para Windows
REM ============================================================

color 0B

REM Read configuration if exists
if exist "config\config.ini" (
    for /f "tokens=1,2 delims==" %%a in (config\config.ini) do (
        if "%%a"=="company_name" set "COMPANY_NAME=%%b"
        if "%%a"=="logo_path" set "LOGO_PATH=%%b"
    )
)

echo.
echo ========================================================
if not "%COMPANY_NAME%"=="" (
    echo   %COMPANY_NAME%
    echo   Sistema de Gestion de Proveedores v0.1
) else (
    echo   Sistema de Gestion de Proveedores v0.1
)
echo ========================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python no esta instalado en el sistema.
    echo.
    echo Por favor descarga e instala Python 3.8 o superior desde:
    echo https://www.python.org/downloads/
    echo.
    echo Asegurate de marcar "Add Python to PATH" durante la instalacion.
    pause
    exit /b 1
)

echo [OK] Python detectado:
python --version
echo.

REM Check Python version
python -c "import sys; exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Se requiere Python 3.8 o superior.
    echo Por favor actualiza tu version de Python.
    pause
    exit /b 1
)

echo [1/5] Verificando entorno virtual...
if exist venv (
    echo [INFO] Entorno virtual existente detectado. Se eliminara y recreara.
    rmdir /s /q venv
)

echo [2/5] Creando entorno virtual...
python -m venv venv
if %errorlevel% neq 0 (
    echo [ERROR] No se pudo crear el entorno virtual.
    pause
    exit /b 1
)
echo [OK] Entorno virtual creado exitosamente.
echo.

echo [3/5] Activando entorno virtual...
call venv\Scripts\activate.bat
if %errorlevel% neq 0 (
    echo [ERROR] No se pudo activar el entorno virtual.
    pause
    exit /b 1
)
echo [OK] Entorno virtual activado.
echo.

echo [4/5] Instalando dependencias...
echo Este proceso puede tardar algunos minutos...
echo.
venv\Scripts\python.exe -m pip install --upgrade pip
venv\Scripts\python.exe -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERROR] Fallo la instalacion de dependencias.
    echo Verifica tu conexion a internet e intenta nuevamente.
    pause
    exit /b 1
)
echo.
echo [OK] Dependencias instaladas correctamente.
echo.

echo [5/5] Verificando instalacion...
python -c "import flask, sqlalchemy, pandas, openpyxl" >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] La verificacion de modulos fallo.
    pause
    exit /b 1
)
echo [OK] Todos los modulos fueron instalados correctamente.
echo.

REM Create launch script
echo [EXTRA] Creando script de inicio rapido...
(
echo @echo off
echo cd /d "%%~dp0"
echo call venv\Scripts\activate.bat
echo python app.py
echo pause
) > start.bat
echo [OK] Script 'start.bat' creado.
echo.

REM Create database if not exists
if not exist suppliers.db (
    echo [SETUP] Inicializando base de datos...
    python -c "from database import init_db; init_db(); print('Base de datos creada exitosamente.')"
    echo.
)
REM Apply customizations if config exists
if exist "config\config.ini" (
    echo [CUSTOM] Aplicando configuracion personalizada...
    
    if not "%LOGO_PATH%"=="" (
        if exist "%LOGO_PATH%" (
            echo [INFO] Copiando logo personalizado...
            copy /Y "%LOGO_PATH%" "static\logo.png" >nul 2>&1
            if %errorlevel% equ 0 (
                echo [OK] Logo copiado exitosamente
            )
        )
    )
    
    if not "%COMPANY_NAME%"=="" (
        echo [INFO] Configurando nombre de empresa: %COMPANY_NAME%
        REM The company name will be used by the app from config.ini
    )
    echo.
)
echo ========================================================
echo   INSTALACION COMPLETADA EXITOSAMENTE!
echo ========================================================
echo.
echo El sistema esta listo para usar.
echo.
echo Para iniciar la aplicacion:
echo   1. Ejecuta 'start.bat' en esta carpeta, o
echo   2. Ejecuta manualmente:
echo      venv\Scripts\activate.bat
echo      python app.py
echo.
echo Luego abre tu navegador en: http://localhost:5000
echo.
echo Documentacion completa: README.md
echo.
pause

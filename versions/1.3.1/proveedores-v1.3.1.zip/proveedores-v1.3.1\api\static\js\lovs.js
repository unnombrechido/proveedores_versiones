// ============================================================
// LOV (List of Values) Management
// ============================================================

let lovManagementTypes = [];       // [{key, label}]
let lovManagementRecords = [];     // current table data
let lovCurrentType = null;         // selected lov_type key
let lovEditingId = null;           // null = new, number = edit
let lovCountriesCache = null;      // cache for country options in State forms

// Extra field definitions per LOV type (beyond the standard set)
const LOV_EXTRA_FIELDS = {
    'units-of-measure': [
        { name: 'symbol', label: 'Símbolo', type: 'text', placeholder: 'ej. kg, pcs, L' }
    ],
    'locations': [
        { name: 'type',      label: 'Tipo',          type: 'text',   placeholder: 'warehouse, zone, shelf...' },
        { name: 'parent_id', label: 'Padre (ID)',     type: 'number', placeholder: 'ID de la ubicación padre' }
    ],
    'tax-types': [
        { name: 'rate', label: 'Tasa (%)', type: 'number', placeholder: '0.00', step: '0.01' }
    ],
    'states': [
        { name: 'country_id', label: 'País', type: 'select-country' }
    ]
};

// ── Load type list and initialise the selector ──────────────────────────────
async function loadLovTypes() {
    if (!currentUser || !['admin', 'sysadmin'].includes(currentUser.rol)) return;
    if (lovManagementTypes.length > 0) {
        renderLovTypeSelector();
        return;
    }
    try {
        const resp = await fetch(`${API_BASE}/lovs/manage/types`);
        if (!resp.ok) throw new Error(resp.statusText);
        lovManagementTypes = await resp.json();
        renderLovTypeSelector();
    } catch (err) {
        console.error('Error loading LOV types:', err);
        showNotification('Error al cargar tipos de LOV', 'error');
    }
}

function renderLovTypeSelector() {
    const sel = document.getElementById('lov-type-selector');
    if (!sel) return;
    sel.innerHTML = '<option value="">-- Seleccionar tipo --</option>';
    lovManagementTypes.forEach(t => {
        const opt = document.createElement('option');
        opt.value = t.key;
        opt.textContent = t.label;
        sel.appendChild(opt);
    });
    // Restore selection if any
    if (lovCurrentType) sel.value = lovCurrentType;
}

// ── Load records for the selected type ──────────────────────────────────────
async function loadLovRecords() {
    const sel = document.getElementById('lov-type-selector');
    lovCurrentType = sel ? sel.value : null;

    const tbody = document.getElementById('lovs-tbody');
    if (!lovCurrentType) {
        if (tbody) tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#999;">Seleccione un tipo de LOV</td></tr>';
        document.getElementById('lov-add-btn').style.display = 'none';
        return;
    }

    document.getElementById('lov-add-btn').style.display = '';

    if (tbody) tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">Cargando...</td></tr>';

    try {
        const resp = await fetch(`${API_BASE}/lovs/manage/${lovCurrentType}`);
        if (!resp.ok) throw new Error(resp.statusText);
        lovManagementRecords = await resp.json();
        renderLovTable(lovManagementRecords);
    } catch (err) {
        console.error('Error loading LOV records:', err);
        showNotification('Error al cargar registros', 'error');
    }
}

function renderLovTable(records) {
    const tbody = document.getElementById('lovs-tbody');
    if (!tbody) return;

    if (!records.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#999;">Sin registros</td></tr>';
        return;
    }

    tbody.innerHTML = '';
    records.forEach(r => {
        const tr = document.createElement('tr');
        if (!r.active) tr.style.opacity = '0.55';

        const activeBadge = r.active
            ? '<span style="color:green;">● Activo</span>'
            : '<span style="color:#bbb;">● Inactivo</span>';

        const extraInfo = buildExtraInfo(r);

        tr.innerHTML = `
            <td>${escapeHtml(r.code || '')}</td>
            <td>${escapeHtml(r.name_es || '')}</td>
            <td>${escapeHtml(r.name_en || '')}</td>
            <td>${extraInfo}</td>
            <td>${activeBadge}</td>
            <td>
                <button class="btn btn-sm" onclick="openLovModal(${r.id})">✏️ Editar</button>
                <button class="btn btn-sm ${r.active ? 'btn-danger' : 'btn-secondary'}"
                    onclick="toggleLovActive(${r.id})">
                    ${r.active ? '🚫 Desactivar' : '✅ Activar'}
                </button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function buildExtraInfo(r) {
    const extras = LOV_EXTRA_FIELDS[lovCurrentType] || [];
    return extras.map(f => {
        const val = r[f.name];
        if (val === null || val === undefined || val === '') return '';
        return `<small><b>${f.label}:</b> ${escapeHtml(String(val))}</small>`;
    }).filter(Boolean).join(' &nbsp; ') || '—';
}

// ── Modal open/close ─────────────────────────────────────────────────────────
async function openLovModal(recordId = null) {
    lovEditingId = recordId;
    const modal   = document.getElementById('lov-modal');
    const title   = document.getElementById('lov-modal-title');
    const typeLabel = lovManagementTypes.find(t => t.key === lovCurrentType)?.label || lovCurrentType;

    title.textContent = recordId ? `Editar: ${typeLabel}` : `Nuevo: ${typeLabel}`;

    // Build dynamic fields section
    await buildDynamicFields();

    // Populate if editing
    if (recordId) {
        const record = lovManagementRecords.find(r => r.id === recordId);
        if (record) populateLovForm(record);
    } else {
        document.getElementById('lov-form').reset();
        // Default active to true for new records
        document.getElementById('lov-active').checked = true;
    }

    modal.style.display = 'block';
}

function closeLovModal() {
    document.getElementById('lov-modal').style.display = 'none';
    document.getElementById('lov-modal-error').style.display = 'none';
    lovEditingId = null;
}

async function buildDynamicFields() {
    const container = document.getElementById('lov-extra-fields');
    container.innerHTML = '';

    const extras = LOV_EXTRA_FIELDS[lovCurrentType] || [];
    for (const field of extras) {
        const div = document.createElement('div');
        div.className = 'form-group';

        if (field.type === 'select-country') {
            // Country selector (for States)
            const countries = await getCountriesForSelect();
            let options = '<option value="">Seleccionar País</option>';
            countries.forEach(c => {
                options += `<option value="${c.id}">${escapeHtml(c.name_es)}</option>`;
            });
            div.innerHTML = `
                <label for="lov-extra-${field.name}">${field.label}</label>
                <select id="lov-extra-${field.name}" name="${field.name}">${options}</select>
            `;
        } else {
            const stepAttr = field.step ? `step="${field.step}"` : '';
            div.innerHTML = `
                <label for="lov-extra-${field.name}">${field.label}</label>
                <input type="${field.type}" id="lov-extra-${field.name}" name="${field.name}"
                       placeholder="${field.placeholder || ''}" ${stepAttr}>
            `;
        }
        container.appendChild(div);
    }
}

async function getCountriesForSelect() {
    if (lovCountriesCache) return lovCountriesCache;
    try {
        const resp = await fetch(`${API_BASE}/lovs/countries`);
        if (resp.ok) {
            lovCountriesCache = await resp.json();
            return lovCountriesCache;
        }
    } catch (_) {}
    return [];
}

function populateLovForm(record) {
    document.getElementById('lov-code').value    = record.code    || '';
    document.getElementById('lov-name-es').value = record.name_es || '';
    document.getElementById('lov-name-en').value = record.name_en || '';
    document.getElementById('lov-description').value = record.description || '';
    document.getElementById('lov-active').checked = !!record.active;

    const extras = LOV_EXTRA_FIELDS[lovCurrentType] || [];
    extras.forEach(f => {
        const el = document.getElementById(`lov-extra-${f.name}`);
        if (el && record[f.name] !== undefined && record[f.name] !== null) {
            el.value = record[f.name];
        }
    });
}

// ── Save (create / update) ───────────────────────────────────────────────────
async function saveLovRecord(event) {
    event.preventDefault();
    document.getElementById('lov-modal-error').style.display = 'none';

    const payload = {
        code:        document.getElementById('lov-code').value.trim(),
        name_es:     document.getElementById('lov-name-es').value.trim(),
        name_en:     document.getElementById('lov-name-en').value.trim(),
        description: document.getElementById('lov-description').value.trim(),
        active:      document.getElementById('lov-active').checked
    };

    // Collect extra fields
    const extras = LOV_EXTRA_FIELDS[lovCurrentType] || [];
    extras.forEach(f => {
        const el = document.getElementById(`lov-extra-${f.name}`);
        if (el) {
            const val = el.value;
            payload[f.name] = (f.type === 'number' && val !== '') ? parseFloat(val) : (val || null);
        }
    });

    const url    = lovEditingId
        ? `${API_BASE}/lovs/manage/${lovCurrentType}/${lovEditingId}`
        : `${API_BASE}/lovs/manage/${lovCurrentType}`;
    const method = lovEditingId ? 'PUT' : 'POST';

    try {
        const resp = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await resp.json();
        if (!resp.ok) throw new Error(data.error || resp.statusText);

        showNotification(lovEditingId ? 'Registro actualizado' : 'Registro creado', 'success');
        closeLovModal();
        await loadLovRecords();
    } catch (err) {
        const errEl = document.getElementById('lov-modal-error');
        errEl.textContent = err.message;
        errEl.style.display = 'block';
    }
}

// ── Toggle active ────────────────────────────────────────────────────────────
async function toggleLovActive(recordId) {
    if (!lovCurrentType) return;
    try {
        const resp = await fetch(`${API_BASE}/lovs/manage/${lovCurrentType}/${recordId}`, {
            method: 'DELETE'
        });
        const data = await resp.json();
        if (!resp.ok) throw new Error(data.error || resp.statusText);
        const label = data.active ? 'Activado' : 'Desactivado';
        showNotification(`Registro ${label}`, 'success');
        await loadLovRecords();
    } catch (err) {
        showNotification('Error: ' + err.message, 'error');
    }
}

// ── Filter table client-side ─────────────────────────────────────────────────
function filterLovTable() {
    const search   = (document.getElementById('lovs-search')?.value || '').toLowerCase();
    const showAll  = document.getElementById('lov-show-inactive')?.checked;
    const filtered = lovManagementRecords.filter(r => {
        if (!showAll && !r.active) return false;
        if (!search) return true;
        return (r.code || '').toLowerCase().includes(search)
            || (r.name_es || '').toLowerCase().includes(search)
            || (r.name_en || '').toLowerCase().includes(search);
    });
    renderLovTable(filtered);
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

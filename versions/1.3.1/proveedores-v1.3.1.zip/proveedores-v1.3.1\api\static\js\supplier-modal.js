﻿// ===== MODALS - Suppliers, Contacts, Orders, Import =====
// ===== MODALS =====
async function showAddSupplierModal() {
    // Ensure LOV data is loaded
    if (!lovData.supplierCategories || lovData.supplierCategories.length === 0) {
        await loadLOV('supplierCategories', '/api/lovs/supplier-categories');
    }
    if (!lovData.countries || lovData.countries.length === 0) {
        await loadLOV('countries', '/api/lovs/countries');
    }
    if (!lovData.paymentTerms || lovData.paymentTerms.length === 0) {
        await loadLOV('paymentTerms', '/api/lovs/payment-terms');
    }
    
    document.getElementById('supplier-modal-title').textContent = 'Nuevo Proveedor';
    document.getElementById('supplier-form').reset();
    document.getElementById('supplier-id').value = '';
    document.getElementById('contacts-section').style.display = 'none';
    document.getElementById('contacts-list').innerHTML = '';
    
    // Populate LOV dropdowns
    populateSupplierLOVDropdowns();
    
    document.getElementById('supplier-modal').classList.add('active');
}

function closeSupplierModal() {
    document.getElementById('supplier-modal').classList.remove('active');
}

// Populate supplier LOV dropdowns
function populateSupplierLOVDropdowns() {
    // Supplier categories
    const categorySelect = document.getElementById('supplier-category');
    categorySelect.innerHTML = '<option value="">Seleccionar Categoría</option>';
    if (lovData.supplierCategories) {
        lovData.supplierCategories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.id;
            option.textContent = cat.name_es;
            categorySelect.appendChild(option);
        });
    }
    
    // Countries
    const countrySelect = document.getElementById('supplier-country');
    countrySelect.innerHTML = '<option value="">Seleccionar País</option>';
    if (lovData.countries) {
        lovData.countries.forEach(country => {
            const option = document.createElement('option');
            option.value = country.id;
            option.textContent = country.name_es;
            countrySelect.appendChild(option);
        });
    }
    
    // Payment terms
    const paymentTermsSelect = document.getElementById('supplier-payment-terms');
    paymentTermsSelect.innerHTML = '<option value="">Seleccionar Condiciones</option>';
    if (lovData.paymentTerms) {
        lovData.paymentTerms.forEach(term => {
            const option = document.createElement('option');
            option.value = term.id;
            option.textContent = term.name_es;
            paymentTermsSelect.appendChild(option);
        });
    }
    
    // Clear states
    document.getElementById('supplier-state').innerHTML = '<option value="">Seleccionar Estado</option>';
}

// Load states for selected country
async function loadStatesForCountry() {
    const countryId = document.getElementById('supplier-country').value;
    const stateSelect = document.getElementById('supplier-state');
    
    if (!countryId) {
        stateSelect.innerHTML = '<option value="">Seleccionar Estado</option>';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/lovs/states/${countryId}`);
        if (response.ok) {
            const states = await response.json();
            stateSelect.innerHTML = '<option value="">Seleccionar Estado</option>';
            states.forEach(state => {
                const option = document.createElement('option');
                option.value = state.id;
                option.textContent = state.name_es;
                stateSelect.appendChild(option);
            });
        } else {
            stateSelect.innerHTML = '<option value="">Seleccionar Estado</option>';
        }
    } catch (error) {
        console.error('Error loading states:', error);
        stateSelect.innerHTML = '<option value="">Seleccionar Estado</option>';
    }
}

async function editSupplier(id) {
    const supplier = suppliers.find(s => s.id === id);
    if (!supplier) return;
    
    // Ensure LOV data is loaded
    if (!lovData.supplierCategories || lovData.supplierCategories.length === 0) {
        await loadLOV('supplierCategories', '/api/lovs/supplier-categories');
    }
    if (!lovData.countries || lovData.countries.length === 0) {
        await loadLOV('countries', '/api/lovs/countries');
    }
    if (!lovData.paymentTerms || lovData.paymentTerms.length === 0) {
        await loadLOV('paymentTerms', '/api/lovs/payment-terms');
    }
    if (!lovData.contactTypes || lovData.contactTypes.length === 0) {
        await loadLOV('contactTypes', '/api/lovs/contact-types');
    }
    
    document.getElementById('supplier-modal-title').textContent = 'Editar Proveedor';
    document.getElementById('supplier-id').value = supplier.id;
    document.getElementById('supplier-name').value = supplier.name || '';
    document.getElementById('supplier-address').value = supplier.address || '';
    document.getElementById('supplier-city').value = supplier.city || '';
    document.getElementById('supplier-notes').value = supplier.notes || '';
    
    // Populate LOV dropdowns first
    populateSupplierLOVDropdowns();
    
    // Set selected values
    document.getElementById('supplier-category').value = supplier.category_id || '';
    document.getElementById('supplier-country').value = supplier.country_id || '';
    document.getElementById('supplier-payment-terms').value = supplier.payment_term_id || '';
    
    // Load states for the selected country and then set the state value
    if (supplier.country_id) {
        loadStatesForCountry().then(() => {
            const stateSelect = document.getElementById('supplier-state');
            if (stateSelect) {
                stateSelect.value = supplier.state_id || '';
            }
        });
    } else {
        document.getElementById('supplier-state').innerHTML = '<option value="">Seleccionar Estado</option>';
    }
    
    // Show and load contacts
    document.getElementById('contacts-section').style.display = 'block';
    loadSupplierContacts(id);
    
    document.getElementById('supplier-modal').classList.add('active');
}

async function loadSupplierContacts(supplierId) {
    try {
        showLoading('Cargando contactos...');
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/contacts`);
        const contacts = await response.json();
        displayContacts(contacts);
    } catch (error) {
        console.error('Error loading contacts:', error);
    } finally {
        hideLoading();
    }
}

function displayContacts(contacts) {
    const contactsList = document.getElementById('contacts-list');
    contactsList.innerHTML = contacts.map(contact => {
        // Generate contact type options with correct selection
        const contactTypeOptions = lovData.contactTypes ? lovData.contactTypes.map(ct => 
            `<option value="${ct.id}" ${contact.contact_type_id == ct.id ? 'selected' : ''}>${ct.name_es}</option>`
        ).join('') : '<option value="">Cargando...</option>';
        
        return `
        <div class="contact-item" data-contact-id="${contact.id}" style="border: 1px solid #ddd; padding: 12px; margin-bottom: 10px; border-radius: 4px; background: ${contact.is_primary ? '#fff8e1' : 'white'};">
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <div style="flex: 1;">
                    <div style="display: flex; gap: 10px; margin-bottom: 8px;">
                        <input type="text" class="contact-name" value="${escapeHtml(contact.contact_name)}" placeholder="Nombre" style="flex: 2;">
                        <input type="text" class="contact-position" value="${escapeHtml(contact.position || '')}" placeholder="Puesto" style="flex: 1;">
                    </div>
                    <div style="display: flex; gap: 10px; margin-bottom: 8px;">
                        <input type="tel" class="contact-phone" value="${escapeHtml(contact.phone || '')}" placeholder="Teléfono" style="flex: 1;">
                        <input type="email" class="contact-email" value="${escapeHtml(contact.email || '')}" placeholder="Email" style="flex: 2;">
                    </div>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <select class="contact-type" style="flex: 1;">
                            <option value="">Seleccionar Tipo</option>
                            ${contactTypeOptions}
                        </select>
                        <label style="display: flex; align-items: center; gap: 5px;">
                            <input type="checkbox" class="contact-primary" ${contact.is_primary ? 'checked' : ''} onchange="handlePrimaryChange(this)">
                            <span>⭐ Principal</span>
                        </label>
                    </div>
                </div>
                <div style="margin-left: 10px;">
                    <button type="button" onclick="saveContact(${contact.id})" class="btn btn-sm btn-success" title="Guardar">💾</button>
                    <button type="button" onclick="deleteContact(${contact.id})" class="btn btn-sm btn-danger" title="Eliminar">🗑️</button>
                </div>
            </div>
        </div>
        `;
    }).join('');
}

function handlePrimaryChange(checkbox) {
    if (checkbox.checked) {
        // Uncheck all other primary checkboxes
        document.querySelectorAll('.contact-primary').forEach(cb => {
            if (cb !== checkbox) cb.checked = false;
        });
    }
}

function addContactRow() {
    const supplierId = document.getElementById('supplier-id').value;
    if (!supplierId) {
        showError('Guarde el proveedor primero antes de agregar contactos');
        return;
    }
    
    // Generate contact type options from LOV
    const contactTypeOptions = lovData.contactTypes ? lovData.contactTypes.map(ct => 
        `<option value="${ct.id}">${ct.name_es}</option>`
    ).join('') : '<option value="">Cargando...</option>';
    
    const contactsList = document.getElementById('contacts-list');
    const newContact = document.createElement('div');
    newContact.className = 'contact-item';
    newContact.style.cssText = 'border: 1px solid #ddd; padding: 12px; margin-bottom: 10px; border-radius: 4px; background: #f0f8ff;';
    newContact.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: start;">
            <div style="flex: 1;">
                <div style="display: flex; gap: 10px; margin-bottom: 8px;">
                    <input type="text" class="contact-name" placeholder="Nombre" style="flex: 2;">
                    <input type="text" class="contact-position" placeholder="Puesto" style="flex: 1;">
                </div>
                <div style="display: flex; gap: 10px; margin-bottom: 8px;">
                    <input type="tel" class="contact-phone" placeholder="Teléfono" style="flex: 1;">
                    <input type="email" class="contact-email" placeholder="Email" style="flex: 2;">
                </div>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <select class="contact-type" style="flex: 1;">
                        <option value="">Seleccionar Tipo</option>
                        ${contactTypeOptions}
                    </select>
                    <label style="display: flex; align-items: center; gap: 5px;">
                        <input type="checkbox" class="contact-primary" onchange="handlePrimaryChange(this)">
                        <span>⭐ Principal</span>
                    </label>
                </div>
            </div>
            <div style="margin-left: 10px;">
                <button type="button" onclick="createNewContact(this)" class="btn btn-sm btn-success" title="Crear">💾</button>
                <button type="button" onclick="this.closest('.contact-item').remove()" class="btn btn-sm btn-danger" title="Cancelar">✖️</button>
            </div>
        </div>
    `;
    contactsList.appendChild(newContact);
}

async function createNewContact(button) {
    const contactItem = button.closest('.contact-item');
    const supplierId = document.getElementById('supplier-id').value;
    
    const data = {
        contact_name: contactItem.querySelector('.contact-name').value,
        position: contactItem.querySelector('.contact-position').value,
        phone: contactItem.querySelector('.contact-phone').value,
        email: contactItem.querySelector('.contact-email').value,
        contact_type_id: contactItem.querySelector('.contact-type').value,
        is_primary: contactItem.querySelector('.contact-primary').checked
    };
    
    if (!data.contact_name && !data.phone && !data.email) {
        showError('Ingrese al menos el nombre, teléfono o email');
        return;
    }
    
    try {
        showLoading('Creando contacto...');
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/contacts`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showSuccess('Contacto creado');
            loadSupplierContacts(supplierId);
        } else {
            showError('Error al crear contacto');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear contacto');
    } finally {
        hideLoading();
    }
}

async function saveContact(contactId) {
    const contactItem = document.querySelector(`.contact-item[data-contact-id="${contactId}"]`);
    const supplierId = document.getElementById('supplier-id').value;
    
    const data = {
        contact_name: contactItem.querySelector('.contact-name').value,
        position: contactItem.querySelector('.contact-position').value,
        phone: contactItem.querySelector('.contact-phone').value,
        email: contactItem.querySelector('.contact-email').value,
        contact_type_id: contactItem.querySelector('.contact-type').value,
        is_primary: contactItem.querySelector('.contact-primary').checked
    };
    
    try {
        showLoading('Guardando contacto...');
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/contacts/${contactId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showSuccess('Contacto actualizado');
            loadSupplierContacts(supplierId);
        } else {
            showError('Error al actualizar contacto');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al actualizar contacto');
    } finally {
        hideLoading();
    }
}

async function deleteContact(contactId) {
    if (!confirm('¿Eliminar este contacto?')) return;
    
    const supplierId = document.getElementById('supplier-id').value;
    
    try {
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/contacts/${contactId}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (response.ok) {
            showSuccess('Contacto eliminado');
            loadSupplierContacts(supplierId);
        } else {
            showError(result.error || 'Error al eliminar contacto');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al eliminar contacto');
    }
}


async function saveSupplier(event) {
    event.preventDefault();
    
    const id = document.getElementById('supplier-id').value;
    const data = {
        name: document.getElementById('supplier-name').value,
        address: document.getElementById('supplier-address').value,
        city: document.getElementById('supplier-city').value,
        country_id: document.getElementById('supplier-country').value || null,
        state_id: document.getElementById('supplier-state').value || null,
        category_id: document.getElementById('supplier-category').value || null,
        rating: parseFloat(document.getElementById('supplier-rating').value) || 0,
        payment_term_id: document.getElementById('supplier-payment-terms').value || null,
        notes: document.getElementById('supplier-notes').value
    };
    
    try {
        const url = id ? `${API_BASE}/suppliers/${id}` : `${API_BASE}/suppliers`;
        const method = id ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            const result = await response.json();
            
            // If creating new supplier, reload modal with contacts section
            if (!id && result.id) {
                document.getElementById('supplier-id').value = result.id;
                document.getElementById('supplier-modal-title').textContent = 'Editar Proveedor';
                document.getElementById('contacts-section').style.display = 'block';
                showSuccess('Proveedor creado. Ahora puede agregar contactos.');
                return;
            }
            
            closeSupplierModal();
            loadSuppliers();
            showSuccess(id ? 'Proveedor actualizado' : 'Proveedor creado');
        } else {
            showError('Error al guardar proveedor');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al guardar proveedor');
    }
}

async function showCreateOrderModal() {
    try {
        // Load all suppliers
        const response = await fetch(`${API_BASE}/suppliers`);
        const suppliers = await response.json();
        
        if (suppliers.length === 0) {
            showError('No hay proveedores registrados. Agregue proveedores primero.');
            return;
        }
        
        // Create supplier selection modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'supplier-select-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Crear Nueva Orden</h2>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Seleccione un Proveedor <span class="required">*</span></label>
                        <div class="search-filter" style="margin-bottom: 15px;">
                            <input type="text" id="supplier-quick-search" placeholder="🔍 Buscar proveedor..." class="search-input" oninput="filterSupplierSelection()">
                        </div>
                        <div id="supplier-selection-list" style="max-height: 400px; overflow-y: auto; border: 1px solid #ddd; border-radius: 4px;">
                            ${suppliers.map(s => `
                                <div class="supplier-selection-item" data-supplier-name="${escapeHtml(s.name.toLowerCase())}" data-supplier-id="${s.id}" style="padding: 12px; border-bottom: 1px solid #eee; cursor: pointer; transition: background 0.2s;" onmouseover="this.style.background='#f0f0f0'" onmouseout="this.style.background='white'" onclick="selectSupplierForOrder(${s.id}, '${escapeHtml(s.name)}')">
                                    <strong>${escapeHtml(s.name)}</strong><br>
                                    <small style="color: #666;">${s.email || ''} ${s.city ? '- ' + s.city : ''} ${s.category ? '(' + s.category + ')' : ''}</small>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="button" onclick="this.closest('.modal').remove()" class="btn btn-secondary">Cancelar</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        refreshOrderTemplateSelect();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar proveedores');
    }
}

function filterSupplierSelection() {
    const search = document.getElementById('supplier-quick-search').value.toLowerCase();
    const items = document.querySelectorAll('.supplier-selection-item');
    
    items.forEach(item => {
        const name = item.getAttribute('data-supplier-name');
        if (name.includes(search)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

function selectSupplierForOrder(supplierId, supplierName) {
    // Close supplier selection modal
    const modal = document.getElementById('supplier-select-modal');
    if (modal) {
        modal.remove();
    }
    
    // Open the advanced order modal
    createOrderForVendor(supplierId, supplierName);
}

function closeOrderModal() {
    document.getElementById('order-modal').classList.remove('active');
}

async function loadSuppliersForDropdown() {
    try {
        const response = await fetch(`${API_BASE}/suppliers`);
        const suppliers = await response.json();
        const select = document.getElementById('order-supplier');
        select.innerHTML = '<option value="">Seleccionar Proveedor</option>' +
            suppliers.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
    } catch (error) {
        console.error('Error loading suppliers:', error);
    }
}

function createOrderForSupplier(supplierId, itemName) {
    showCreateOrderModal();
    document.getElementById('order-supplier').value = supplierId;
    if (itemName) {
        document.getElementById('order-items').value = itemName;
    }
}

async function saveOrder(event) {
    event.preventDefault();
    
    const data = {
        supplier_id: parseInt(document.getElementById('order-supplier').value),
        delivery_date: document.getElementById('order-delivery-date').value,
        total_amount: parseFloat(document.getElementById('order-amount').value),
        items: document.getElementById('order-items').value,
        notes: document.getElementById('order-notes').value
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeOrderModal();
            loadOrders();
            showSuccess('Orden creada exitosamente');
        } else {
            showError('Error al crear orden');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear orden');
    }
}

// Import Modal
function showImportModal(type) {
    document.getElementById('import-modal').classList.add('active');
    if (type) {
        document.getElementById('import-type').value = type;
        updateImportInstructions();
    }
}

function closeImportModal() {
    document.getElementById('import-modal').classList.remove('active');
    document.getElementById('import-form').reset();
    document.getElementById('import-instructions').style.display = 'none';
}

function updateImportInstructions() {
    const importType = document.getElementById('import-type').value;
    const instructions = document.getElementById('import-instructions');
    const suppliersFormat = document.getElementById('suppliers-format');
    const itemsFormat = document.getElementById('items-format');
    
    if (importType) {
        instructions.style.display = 'block';
        if (importType === 'suppliers') {
            suppliersFormat.style.display = 'block';
            itemsFormat.style.display = 'none';
        } else if (importType === 'items') {
            suppliersFormat.style.display = 'none';
            itemsFormat.style.display = 'block';
        }
    } else {
        instructions.style.display = 'none';
    }
}

async function importFile(event) {
    event.preventDefault();
    
    const importType = document.getElementById('import-type').value;
    const fileInput = document.getElementById('import-file');
    const file = fileInput.files[0];
    
    if (!importType) {
        showError('Por favor seleccione el tipo de importación');
        return;
    }
    
    if (!file) {
        showError('Por favor seleccione un archivo');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    
    let endpoint;
    if (importType === 'suppliers') {
        endpoint = file.name.endsWith('.csv') ? 'csv' : 'excel';
        endpoint = `suppliers/import/${endpoint}`;
    } else if (importType === 'items') {
        // Check if CSV or Excel
        if (file.name.endsWith('.csv')) {
            endpoint = 'suppliers/import/with-items';
        } else {
            endpoint = 'suppliers/import/custom-excel';
        }
    }
    
    try {
        const response = await fetch(`${API_BASE}/${endpoint}`, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (response.ok) {
            closeImportModal();
            
            let message = result.message;
            if (importType === 'items') {
                message += `\n- Proveedores: ${result.suppliers_imported || 0}\n- Items: ${result.items_imported || 0}`;
            }
            showSuccess(message);
            
            // Reload appropriate data
            if (importType === 'suppliers') {
                loadSuppliers();
            } else {
                loadInventory();
                loadSuppliers();
            }
        } else {
            showError(result.error || 'Error al importar archivo');
        }
    } catch (error) {
        console.error('Error importing file:', error);
        showError('Error al importar archivo');
    }
}

function exportSuppliers(format) {
    window.location.href = `${API_BASE}/suppliers/export/${format}`;
}


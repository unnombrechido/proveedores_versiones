"""
Initialize LOV (List of Values) tables with default data
SAFE: This script only ADDS LOV data.
It does NOT delete or modify existing data.

Expected structure:
  project_root/
  ├── api/
  │   ├── app.py
  │   ├── database.py
  │   ├── models.py
  │   └── init_lovs.py (this file)
  ├── data/
  │   └── suppliers.db
  └── venv/
"""
import sys
import os

# Add api directory to path for imports
api_dir = os.path.dirname(os.path.abspath(__file__))
if api_dir not in sys.path:
    sys.path.insert(0, api_dir)

from database import SessionLocal, Base, engine
from models import (
    ItemCategory, SupplierCategory, UnitOfMeasure, ItemCondition, Location,
    OrderStatus, PaymentMethod, PaymentTerm, TaxType, Country, State, ContactType
)
from sqlalchemy import inspect

def create_lov_tables():
    """Create LOV tables if they don't exist"""
    inspector = inspect(engine)
    existing_tables = inspector.get_table_names()
    
    lov_tables = [
        'item_categories', 'supplier_categories', 'units_of_measure', 'item_conditions',
        'locations', 'order_statuses', 'payment_methods', 'payment_terms', 'tax_types',
        'countries', 'states', 'contact_types'
    ]
    
    for table in lov_tables:
        if table not in existing_tables:
            print(f"Creating {table} table...")
            # Create the specific table
            if table == 'item_categories':
                ItemCategory.__table__.create(bind=engine, checkfirst=True)
            elif table == 'supplier_categories':
                SupplierCategory.__table__.create(bind=engine, checkfirst=True)
            elif table == 'units_of_measure':
                UnitOfMeasure.__table__.create(bind=engine, checkfirst=True)
            elif table == 'item_conditions':
                ItemCondition.__table__.create(bind=engine, checkfirst=True)
            elif table == 'locations':
                Location.__table__.create(bind=engine, checkfirst=True)
            elif table == 'order_statuses':
                OrderStatus.__table__.create(bind=engine, checkfirst=True)
            elif table == 'payment_methods':
                PaymentMethod.__table__.create(bind=engine, checkfirst=True)
            elif table == 'payment_terms':
                PaymentTerm.__table__.create(bind=engine, checkfirst=True)
            elif table == 'tax_types':
                TaxType.__table__.create(bind=engine, checkfirst=True)
            elif table == 'countries':
                Country.__table__.create(bind=engine, checkfirst=True)
            elif table == 'states':
                State.__table__.create(bind=engine, checkfirst=True)
            elif table == 'contact_types':
                ContactType.__table__.create(bind=engine, checkfirst=True)
            print(f"{table} table created successfully.")
        else:
            print(f"{table} table already exists. Skipping creation.")

def insert_default_lovs():
    """Insert default LOV data if tables are empty"""
    db = SessionLocal()
    try:
        # Item Categories
        if not db.query(ItemCategory).first():
            categories = [
                ItemCategory(code='ELECTRONICS', name_es='Electrónicos', name_en='Electronics'),
                ItemCategory(code='MECHANICAL', name_es='Mecánicos', name_en='Mechanical'),
                ItemCategory(code='CHEMICAL', name_es='Químicos', name_en='Chemical'),
                ItemCategory(code='CONSUMABLES', name_es='Consumibles', name_en='Consumables'),
                ItemCategory(code='SERVICES', name_es='Servicios', name_en='Services'),
            ]
            db.add_all(categories)
            print("Inserted default item categories")

        # Supplier Categories
        if not db.query(SupplierCategory).first():
            categories = [
                SupplierCategory(code='MANUFACTURER', name_es='Fabricante', name_en='Manufacturer'),
                SupplierCategory(code='DISTRIBUTOR', name_es='Distribuidor', name_en='Distributor'),
                SupplierCategory(code='WHOLESALER', name_es='Mayorista', name_en='Wholesaler'),
                SupplierCategory(code='RETAILER', name_es='Minorista', name_en='Retailer'),
                SupplierCategory(code='SERVICE_PROVIDER', name_es='Proveedor de Servicios', name_en='Service Provider'),
            ]
            db.add_all(categories)
            print("Inserted default supplier categories")

        # Units of Measure
        if not db.query(UnitOfMeasure).first():
            units = [
                UnitOfMeasure(code='PCS', name_es='Piezas', name_en='Pieces', symbol='pcs'),
                UnitOfMeasure(code='KG', name_es='Kilogramos', name_en='Kilograms', symbol='kg'),
                UnitOfMeasure(code='L', name_es='Litros', name_en='Liters', symbol='L'),
                UnitOfMeasure(code='M', name_es='Metros', name_en='Meters', symbol='m'),
                UnitOfMeasure(code='M2', name_es='Metros Cuadrados', name_en='Square Meters', symbol='m²'),
                UnitOfMeasure(code='M3', name_es='Metros Cúbicos', name_en='Cubic Meters', symbol='m³'),
                UnitOfMeasure(code='BOX', name_es='Cajas', name_en='Boxes', symbol='box'),
                UnitOfMeasure(code='PACK', name_es='Paquetes', name_en='Packs', symbol='pack'),
            ]
            db.add_all(units)
            print("Inserted default units of measure")

        # Item Conditions
        if not db.query(ItemCondition).first():
            conditions = [
                ItemCondition(code='NEW', name_es='Nuevo', name_en='New'),
                ItemCondition(code='USED', name_es='Usado', name_en='Used'),
                ItemCondition(code='REFURBISHED', name_es='Reacondicionado', name_en='Refurbished'),
                ItemCondition(code='DAMAGED', name_es='Dañado', name_en='Damaged'),
            ]
            db.add_all(conditions)
            print("Inserted default item conditions")

        # Order Statuses
        if not db.query(OrderStatus).first():
            statuses = [
                OrderStatus(code='DRAFT', name_es='Borrador', name_en='Draft'),
                OrderStatus(code='PENDING_APPROVAL', name_es='Pendiente de Aprobación', name_en='Pending Approval'),
                OrderStatus(code='APPROVED', name_es='Aprobado', name_en='Approved'),
                OrderStatus(code='SENT', name_es='Enviado', name_en='Sent'),
                OrderStatus(code='RECEIVED', name_es='Recibido', name_en='Received'),
                OrderStatus(code='CLOSED', name_es='Cerrado', name_en='Closed'),
                OrderStatus(code='CANCELLED', name_es='Cancelado', name_en='Cancelled'),
            ]
            db.add_all(statuses)
            print("Inserted default order statuses")

        # Payment Methods
        if not db.query(PaymentMethod).first():
            methods = [
                PaymentMethod(code='CASH', name_es='Efectivo', name_en='Cash'),
                PaymentMethod(code='BANK_TRANSFER', name_es='Transferencia Bancaria', name_en='Bank Transfer'),
                PaymentMethod(code='CHECK', name_es='Cheque', name_en='Check'),
                PaymentMethod(code='CREDIT_CARD', name_es='Tarjeta de Crédito', name_en='Credit Card'),
                PaymentMethod(code='DEBIT_CARD', name_es='Tarjeta de Débito', name_en='Debit Card'),
            ]
            db.add_all(methods)
            print("Inserted default payment methods")

        # Payment Terms
        if not db.query(PaymentTerm).first():
            terms = [
                PaymentTerm(code='IMMEDIATE', name_es='Inmediato', name_en='Immediate'),
                PaymentTerm(code='NET_15', name_es='Neto 15 días', name_en='Net 15 days'),
                PaymentTerm(code='NET_30', name_es='Neto 30 días', name_en='Net 30 days'),
                PaymentTerm(code='NET_60', name_es='Neto 60 días', name_en='Net 60 days'),
                PaymentTerm(code='NET_90', name_es='Neto 90 días', name_en='Net 90 days'),
            ]
            db.add_all(terms)
            print("Inserted default payment terms")

        # Tax Types
        if not db.query(TaxType).first():
            taxes = [
                TaxType(code='IVA_0', name_es='IVA 0%', name_en='VAT 0%', rate=0.0),
                TaxType(code='IVA_8', name_es='IVA 8%', name_en='VAT 8%', rate=8.0),
                TaxType(code='IVA_16', name_es='IVA 16%', name_en='VAT 16%', rate=16.0),
                TaxType(code='EXEMPT', name_es='Exento', name_en='Exempt', rate=0.0),
            ]
            db.add_all(taxes)
            print("Inserted default tax types")

        # Countries
        if not db.query(Country).first():
            countries = [
                Country(code='MEX', name_es='México', name_en='Mexico'),
                Country(code='USA', name_es='Estados Unidos', name_en='United States'),
                Country(code='CAN', name_es='Canadá', name_en='Canada'),
                Country(code='ESP', name_es='España', name_en='Spain'),
            ]
            db.add_all(countries)
            print("Inserted default countries")

        # States (for Mexico as example)
        if not db.query(State).first():
            # Get Mexico country ID
            mexico = db.query(Country).filter(Country.code == 'MEX').first()
            if mexico:
                states = [
                    State(country_id=mexico.id, code='CDMX', name_es='Ciudad de México', name_en='Mexico City'),
                    State(country_id=mexico.id, code='JAL', name_es='Jalisco', name_en='Jalisco'),
                    State(country_id=mexico.id, code='NL', name_es='Nuevo León', name_en='Nuevo León'),
                    State(country_id=mexico.id, code='PUE', name_es='Puebla', name_en='Puebla'),
                ]
                db.add_all(states)
                print("Inserted default states")

        # Contact Types
        if not db.query(ContactType).first():
            contact_types = [
                ContactType(code='general',    name_es='General',      name_en='General'),
                ContactType(code='purchasing', name_es='Compras',      name_en='Purchasing'),
                ContactType(code='sales',      name_es='Ventas',       name_en='Sales'),
                ContactType(code='accounting', name_es='Contabilidad', name_en='Accounting'),
                ContactType(code='technical',  name_es='Técnico',      name_en='Technical'),
                ContactType(code='logistics',  name_es='Logística',    name_en='Logistics'),
            ]
            db.add_all(contact_types)
            print("Inserted default contact types")

        db.commit()
        print("All default LOV data inserted successfully")

    except Exception as e:
        print(f"Error inserting default LOVs: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == '__main__':
    print("=" * 60)
    print("INITIALIZING LOV TABLES AND DATA")
    print("=" * 60)
    print("This script will:")
    print("  1. Create LOV tables (if they don't exist)")
    print("  2. Insert default LOV data (if tables are empty)")
    print("  3. Preserve ALL existing data")
    print("=" * 60)
    
    create_lov_tables()
    insert_default_lovs()
    
    print("=" * 60)
    print("LOV initialization complete!")
    print("=" * 60)
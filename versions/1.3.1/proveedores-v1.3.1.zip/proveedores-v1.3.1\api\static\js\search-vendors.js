﻿// ===== SEARCH VENDORS =====
// ===== SEARCH VENDORS =====

async function searchVendors() {
    const searchTerm = document.getElementById('vendors-search').value.trim();
    const resultsDiv = document.getElementById('vendors-results');
    
    if (!searchTerm) {
        resultsDiv.innerHTML = '<p class="placeholder-text">Ingrese un término de búsqueda</p>';
        currentVendorResults = [];
        return;
    }
    
    try {
        showLoading('Buscando proveedores...');
        resultsDiv.innerHTML = '<p class="placeholder-text">Buscando...</p>';
        const response = await fetch(`${API_BASE}/suppliers?search=${encodeURIComponent(searchTerm)}`);
        const results = await response.json();
        
        if (results.length === 0) {
            resultsDiv.innerHTML = '<p class="placeholder-text">No se encontraron proveedores</p>';
            currentVendorResults = [];
            return;
        }
        
        currentVendorResults = results;
        populateVendorFilters(results);
        displayVendorResults(results);
        
    } catch (error) {
        console.error('Error searching vendors:', error);
        resultsDiv.innerHTML = '<p class="placeholder-text">Error al buscar proveedores</p>';
    } finally {
        hideLoading();
    }
}

function populateVendorFilters(vendors) {
    // Update category filter from LOV - ensure LOVs are loaded
    const populateCategoryFilter = async () => {
        if (!lovData.supplierCategories || lovData.supplierCategories.length === 0) {
            console.log('LOV data not loaded, loading now...');
            await loadLOV('supplierCategories', '/api/lovs/supplier-categories');
        }
        
        const categoryFilter = document.getElementById('vendors-category-filter');
        if (categoryFilter) {
            const currentCategory = categoryFilter.value;
            categoryFilter.innerHTML = '<option value="">Todas las Categorías</option>';
            lovData.supplierCategories.forEach(cat => {
                const option = document.createElement('option');
                option.value = cat.id;
                option.textContent = cat.name_es;
                if (cat.id == currentCategory) option.selected = true;
                categoryFilter.appendChild(option);
            });
        }
    };
    
    populateCategoryFilter();
    
    // Update city filter (still from data)
    const cityFilter = document.getElementById('vendors-city-filter');
    if (cityFilter) {
        const currentCity = cityFilter.value;
        cityFilter.innerHTML = '<option value="">Todas las Ciudades</option>';
        // Extract unique cities from vendors
        const allCities = new Set();
        vendors.forEach(vendor => {
            if (vendor.city) allCities.add(vendor.city);
        });
        Array.from(allCities).sort().forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            if (city === currentCity) option.selected = true;
            cityFilter.appendChild(option);
        });
    }
}

function applyVendorFilters() {
    if (currentVendorResults.length === 0) return;
    
    const categoryFilter = document.getElementById('vendors-category-filter').value;
    const cityFilter = document.getElementById('vendors-city-filter').value;
    const sortBy = document.getElementById('vendors-sort').value;
    
    let filteredVendors = [...currentVendorResults];
    
    // Apply filters
    if (categoryFilter) {
        filteredVendors = filteredVendors.filter(v => v.category_id == categoryFilter);
    }
    if (cityFilter) {
        filteredVendors = filteredVendors.filter(v => v.city === cityFilter);
    }
    
    // Apply sorting
    filteredVendors.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return a.name.localeCompare(b.name);
            case 'category':
                return (a.category || '').localeCompare(b.category || '');
            case 'city':
                return (a.city || '').localeCompare(b.city || '');
            case 'rating-desc':
                return (b.rating || 0) - (a.rating || 0);
            case 'rating-asc':
                return (a.rating || 0) - (b.rating || 0);
            default:
                return 0;
        }
    });
    
    displayVendorResults(filteredVendors);
}

function displayVendorResults(vendors) {
    const resultsDiv = document.getElementById('vendors-results');
    
    if (vendors.length === 0) {
        resultsDiv.innerHTML = '<p class="placeholder-text">No hay proveedores que coincidan con los filtros</p>';
        return;
    }
    
    let html = '';
    vendors.forEach(vendor => {
        // Check if this vendor has price info (from item suppliers view)
        const priceInfo = vendor.price ? `<div class="info-item"><span class="info-label">Precio</span><span class="info-value">$${vendor.price.toFixed(2)}</span></div>` : '';
        
        html += `
            <div class="vendor-card">
                <h3>${vendor.name}</h3>
                <div class="vendor-info">
                    ${priceInfo}
                    <div class="info-item">
                        <span class="info-label">Email</span>
                        <span class="info-value">${vendor.email || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Teléfono</span>
                        <span class="info-value">${vendor.phone || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Ciudad</span>
                        <span class="info-value">${vendor.city || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Categoría</span>
                        <span class="info-value">${vendor.category || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Rating</span>
                        <span class="info-value">${vendor.rating ? '⭐ ' + vendor.rating : 'N/A'}</span>
                    </div>
                </div>
                ${vendor.address ? `<p><strong>Dirección:</strong> ${vendor.address}</p>` : ''}
                ${vendor.supplier_item_code ? `<p><strong>Código del proveedor:</strong> ${vendor.supplier_item_code}</p>` : ''}
                ${vendor.lead_time_days ? `<p><strong>Tiempo de entrega:</strong> ${vendor.lead_time_days} días</p>` : ''}
                <div style="margin-top: 15px; display: flex; gap: 10px;">
                    <button onclick='createOrderForVendor(${vendor.id}, "${vendor.name.replace(/"/g, '&quot;')}")' class="btn btn-primary btn-sm" title="Crear Orden">
                        📝
                    </button>
                    <button onclick="viewSupplierItems(${vendor.id})" class="btn btn-secondary btn-sm" title="Ver Items">
                        �
                    </button>
                </div>
            </div>
        `;
        });
        
        resultsDiv.innerHTML = html;
}

// Create order for specific vendor with items selector
async function createOrderForVendor(vendorId, vendorName) {
    try {
        // Get vendor's items
        const response = await fetch(`${API_BASE}/suppliers/${vendorId}/items`);
        const data = await response.json();
        const items = data.items || [];
        
        if (items.length === 0) {
            showError('Este proveedor no tiene items registrados');
            return;
        }
        
        // Show modal with items selector
        let html = `
            <div id="vendor-order-modal" class="modal active">
                <div class="modal-content modal-large">
                    <span class="close" onclick="closeVendorOrderModal()">&times;</span>
                    <h2>Crear Orden - ${vendorName}</h2>
                    
                    <div class="items-selector">
                        <div class="items-selector-header">
                            <h3>Seleccionar Items (${items.length})</h3>
                            <div class="items-search-box">
                                <input type="text" id="vendor-items-search" placeholder="🔍 Buscar items..." class="search-input-small" oninput="filterVendorItems()">
                            </div>
                        </div>
                        <div class="items-table-wrapper">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Seleccionar</th>
                                        <th>Item</th>
                                        <th>Código</th>
                                        <th>Precio</th>
                                        <th>Cantidad</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody id="vendor-items-tbody">
                                    ${items.map(item => `
                                        <tr class="vendor-item-row" 
                                            data-item-name="${item.name.toLowerCase()}" 
                                            data-item-code="${(item.supplier_item_code || item.item_code || '').toLowerCase()}"
                                            data-item-id="${item.id}">
                                            <td>
                                                <input type="checkbox" class="item-select-checkbox" 
                                                       data-item-id="${item.id}" 
                                                       data-item-name="${item.name}"
                                                       data-price="${item.price || 0}"
                                                       onchange="toggleItemQuantity(this); updateVendorOrderTotal(); filterVendorItems()">
                                            </td>
                                            <td>${item.name}</td>
                                            <td>${item.supplier_item_code || item.item_code || 'N/A'}</td>
                                            <td>$${(item.price || 0).toFixed(2)}</td>
                                            <td>
                                                <input type="number" class="qty-input" 
                                                       data-item-id="${item.id}"
                                                       value="1" min="1" 
                                                       onchange="updateVendorOrderTotal()" disabled>
                                            </td>
                                            <td class="item-subtotal">$${(item.price || 0).toFixed(2)}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="5"><strong>Total:</strong></td>
                                        <td><strong id="vendor-order-total">$0.00</strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Fecha de Entrega *</label>
                        <input type="date" id="vendor-order-delivery-date" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Notas</label>
                        <textarea id="vendor-order-notes" rows="3"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button onclick="submitVendorOrder(${vendorId})" class="btn btn-primary">Crear Orden</button>
                        <button onclick="closeVendorOrderModal()" class="btn btn-secondary">Cancelar</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', html);
        
        // Enable qty inputs when checkbox is selected
        document.querySelectorAll('.item-select-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const itemId = this.dataset.itemId;
                const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
                if (qtyInput) {
                    qtyInput.disabled = !this.checked;
                    if (!this.checked) qtyInput.value = 1;
                }
            });
        });
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar items del proveedor');
    }
}

function toggleItemQuantity(checkbox) {
    const itemId = checkbox.dataset.itemId;
    const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
    if (qtyInput) {
        qtyInput.disabled = !checkbox.checked;
        if (!checkbox.checked) {
            qtyInput.value = 1; // Reset to 1 when unchecked
        }
    }
}

function updateVendorOrderTotal() {
    let total = 0;
    document.querySelectorAll('.item-select-checkbox:checked').forEach(checkbox => {
        const itemId = checkbox.dataset.itemId;
        const price = parseFloat(checkbox.dataset.price);
        const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
        const qty = parseInt(qtyInput?.value || 0);
        const subtotal = price * qty;
        
        // Update subtotal display
        const subtotalCell = qtyInput?.closest('tr')?.querySelector('.item-subtotal');
        if (subtotalCell) {
            subtotalCell.textContent = '$' + subtotal.toFixed(2);
        }
        
        total += subtotal;
    });
    
    const totalElement = document.getElementById('vendor-order-total');
    if (totalElement) {
        totalElement.textContent = '$' + total.toFixed(2);
    }
}

function filterVendorItems() {
    const searchTerm = document.getElementById('vendor-items-search').value.toLowerCase().trim();
    const rows = document.querySelectorAll('.vendor-item-row');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const itemName = row.dataset.itemName || '';
        const itemCode = row.dataset.itemCode || '';
        const checkbox = row.querySelector('.item-select-checkbox');
        const isSelected = checkbox && checkbox.checked;
        
        // Show if matches search OR is selected (persist selected items)
        const matches = itemName.includes(searchTerm) || itemCode.includes(searchTerm);
        
        if (matches || isSelected) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
    // Update counter
    const header = document.querySelector('.items-selector-header h3');
    if (header) {
        const totalItems = rows.length;
        const selectedCount = document.querySelectorAll('.item-select-checkbox:checked').length;
        if (searchTerm) {
            header.textContent = `Seleccionar Items (${visibleCount} de ${totalItems}) - ${selectedCount} seleccionados`;
        } else {
            header.textContent = `Seleccionar Items (${totalItems}) - ${selectedCount} seleccionados`;
        }
    }
}

async function submitVendorOrder(vendorId) {
    const deliveryDate = document.getElementById('vendor-order-delivery-date').value;
    const notes = document.getElementById('vendor-order-notes').value;
    
    if (!deliveryDate) {
        showError('Fecha de entrega requerida');
        return;
    }
    
    const selectedItems = [];
    document.querySelectorAll('.item-select-checkbox:checked').forEach(checkbox => {
        const itemId = checkbox.dataset.itemId;
        const itemName = checkbox.dataset.itemName;
        const price = parseFloat(checkbox.dataset.price);
        const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
        const qty = parseInt(qtyInput?.value || 1);
        
        selectedItems.push({
            name: itemName,
            qty: qty,
            price: price
        });
    });
    
    if (selectedItems.length === 0) {
        showError('Seleccione al menos un item');
        return;
    }
    
    const itemsText = selectedItems.map(item => 
        `${item.qty} x ${item.name} @ $${item.price.toFixed(2)}`
    ).join('\n');
    
    const totalAmount = selectedItems.reduce((sum, item) => sum + (item.qty * item.price), 0);
    
    const orderData = {
        supplier_id: vendorId,
        delivery_date: deliveryDate,
        total_amount: totalAmount,
        items: itemsText,
        notes: notes
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        
        if (response.ok) {
            closeVendorOrderModal();
            showSuccess('Orden creada exitosamente');
        } else {
            showError('Error al crear orden');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear orden');
    }
}

function closeVendorOrderModal() {
    const modal = document.getElementById('vendor-order-modal');
    if (modal) {
        modal.remove();
    }
}

// Enter key search for vendors
document.addEventListener('DOMContentLoaded', function() {
    const vendorsSearch = document.getElementById('vendors-search');
    if (vendorsSearch) {
        vendorsSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchVendors();
            }
        });
    }
});


// Vendor <-> Item cross-navigation
async function viewSupplierItems(supplierId) {
    try {
        // Get supplier info first
        const supplierResponse = await fetch(`${API_BASE}/suppliers/${supplierId}`);
        const supplier = await supplierResponse.json();
        
        // Show confirmation dialog
        showConfirmDialog(
            `¿Desea ver los items que vende "${supplier.name}"?\n\nEsto lo llevará a la sección de búsqueda de items.`,
            async () => {
                try {
                    await loadSupplierItemsConfirmed(supplierId, supplier.name);
                } catch (error) {
                    console.error('Error:', error);
                    showError('Error al cargar items del proveedor');
                }
            }
        );
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar información del proveedor');
    }
}

async function loadSupplierItemsConfirmed(supplierId, supplierName) {
    try {
        // Get supplier info first
        const supplierResponse = await fetch(`${API_BASE}/suppliers/${supplierId}`);
        const supplier = await supplierResponse.json();
        
        // Get supplier's items
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/items`);
        const data = await response.json();
        const items = data.items || [];
        
        if (items.length === 0) {
            showError('Este proveedor no tiene items registrados');
            return;
        }
        
        // Switch to search items section
        showSection('search-items');
        
        // Clear search input
        const searchInput = document.getElementById('items-search');
        if (searchInput) {
            searchInput.value = '';
        }
        
        // Transform the items to match the expected format for display
        const consolidatedItems = items.map(item => ({
            item: {
                id: item.id,
                item_code: item.item_code,
                name: item.name,
                description: item.description,
                category: item.category,
                unit: item.unit
            },
            suppliers: [{
                supplier_id: supplierId,
                supplier_name: supplier.name,
                email: supplier.email,
                phone: supplier.phone,
                price: item.price,
                supplier_item_code: item.supplier_item_code,
                lead_time_days: item.lead_time_days,
                minimum_order_quantity: item.minimum_order_quantity,
                notes: item.notes
            }]
        }));
        
        // Store in currentSearchResults for filtering to work
        currentSearchResults = items.map(item => ({
            item: {
                id: item.id,
                item_code: item.item_code,
                name: item.name,
                description: item.description,
                category: item.category,
                unit: item.unit
            },
            suppliers: [{
                supplier_id: supplierId,
                supplier_name: supplier.name,
                email: supplier.email,
                phone: supplier.phone,
                price: item.price,
                supplier_item_code: item.supplier_item_code,
                lead_time_days: item.lead_time_days,
                minimum_order_quantity: item.minimum_order_quantity,
                notes: item.notes
            }]
        }));
        
        // Display the items using existing function
        displaySearchResults(consolidatedItems);
        
        // Populate filters using existing function
        populateItemFilters(consolidatedItems);
        
        // Show info message
        showSuccess(`Mostrando ${items.length} item(s) vendidos por: ${supplierName}`);
        
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}


# -*- coding: utf-8 -*-
"""Orders routes blueprint."""
import base64
import os
import re
from datetime import datetime

import pandas as pd
from flask import Blueprint, Response, jsonify, request, session, send_file
from flask_login import login_required
from sqlalchemy import select

from ..database import SessionLocal
from ..models import Item, Order, OrderStatus, Supplier, supplier_items
from .config import _load_config_map
from .decorators import permission_required

orders_bp = Blueprint('orders', __name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

STATUS_LABELS = {
    'esp': {
        'pending': 'Pendiente',
        'confirmed': 'Confirmada',
        'shipped': 'Enviada',
        'delivered': 'Entregada',
        'cancelled': 'Cancelada',
    },
    'eng': {
        'pending': 'Pending',
        'confirmed': 'Confirmed',
        'shipped': 'Shipped',
        'delivered': 'Delivered',
        'cancelled': 'Cancelled',
    },
}


def _parse_order_items_html(items_text, supplier, db, mode):
    """Parse the order items string into HTML table rows."""
    rows = ''
    for line in items_text.strip().split('\n'):
        if not line.strip():
            continue

        if '|' in line:
            parts = [p.strip() for p in line.split('|')]
            if len(parts) >= 3:
                item_id, item_name, qty = parts[0], parts[1], parts[2]
                price = parts[3] if len(parts) > 3 else ''
                if mode == 'vendor':
                    rows += f'<tr><td>{item_id}</td><td>{item_name}</td><td>{qty}</td></tr>'
                else:
                    rows += f'<tr><td>{item_id}</td><td>{item_name}</td><td>{qty}</td><td>{price}</td></tr>'
        else:
            match = re.match(r'(\d+)\s*x\s*(.+?)(?:\s*@\s*(.+))?$', line.strip(), re.IGNORECASE)
            if match:
                qty = match.group(1)
                item_name = match.group(2).strip()
                price = match.group(3).strip() if match.group(3) else ''

                item_sku = '-'
                vendor_sku = '-'
                db_item = db.query(Item).filter(Item.name.ilike(f'%{item_name}%')).first()
                if db_item:
                    item_sku = db_item.item_code
                    if supplier:
                        link = db.execute(
                            select(supplier_items).where(
                                supplier_items.c.supplier_id == supplier.id,
                                supplier_items.c.item_id == db_item.id
                            )
                        ).first()
                        if link and link.supplier_item_code:
                            vendor_sku = link.supplier_item_code

                sku_to_show = vendor_sku if mode == 'vendor' else item_sku
                if mode == 'vendor':
                    rows += f'<tr><td>{sku_to_show}</td><td>{item_name}</td><td>{qty}</td></tr>'
                else:
                    rows += f'<tr><td>{sku_to_show}</td><td>{item_name}</td><td>{qty}</td><td>{price}</td></tr>'
            else:
                if mode == 'vendor':
                    rows += f'<tr><td colspan="3">{line.strip()}</td></tr>'
                else:
                    rows += f'<tr><td colspan="4">{line.strip()}</td></tr>'
    return rows


def _build_template_replacements(order, supplier, config_map, lang, mode):
    """Return the placeholder→value dict used by both print and future renderers."""
    payment_terms = (supplier.payment_term.name_es if supplier and supplier.payment_term else 'N/A')
    company_name = config_map.get('COMPANY_NAME', 'Mi Empresa')
    logo_path = config_map.get('LOGO_PATH', '')

    letterhead_html = ''
    if logo_path and os.path.exists(logo_path):
        with open(logo_path, 'rb') as logo_file:
            logo_data = base64.b64encode(logo_file.read()).decode('utf-8')
            logo_ext = os.path.splitext(logo_path)[1].lower().replace('.', '')
            if logo_ext == 'jpg':
                logo_ext = 'jpeg'
            letterhead_html += (
                f'<img src="data:image/{logo_ext};base64,{logo_data}" '
                f'class="letterhead-logo" alt="Logo">'
            )
    letterhead_html += f'<div class="letterhead-text"><h1>{company_name}</h1></div>'

    db_session = None  # caller must pass items rows separately
    items_rows_html = ''  # filled by caller

    status_code = order.status.code if order.status else 'pending'
    status_name_fallback = (
        (order.status.name_es if lang == 'esp' else (order.status.name_en or order.status.name_es))
        if order.status else status_code.title()
    )
    status_label = STATUS_LABELS.get(lang, STATUS_LABELS['esp']).get(status_code, status_name_fallback)

    if mode == 'vendor':
        sku_header = 'SKU Proveedor' if lang == 'esp' else 'Vendor SKU'
        price_header = ''
        total_section = ''
    else:
        sku_header = 'SKU Interno' if lang == 'esp' else 'Internal SKU'
        price_header = '<th>Precio</th>' if lang == 'esp' else '<th>Price</th>'
        total_label = 'Total'
        total_section = f'<div class="total">{total_label}: ${order.total_amount or 0:.2f}</div>'

    notes_section = ''
    if order.notes:
        notes_label = 'Notas' if lang == 'esp' else 'Notes'
        notes_section = (
            f'<div class="notes-section">'
            f'<h3>{notes_label}</h3><div>{order.notes}</div></div>'
        )

    return {
        'letterhead_html': letterhead_html,
        'status_label': status_label,
        'sku_header': sku_header,
        'price_header': price_header,
        'total_section': total_section,
        'notes_section': notes_section,
        'payment_terms': payment_terms,
    }


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@orders_bp.route('/api/orders', methods=['GET'])
@permission_required('view_orders')
def get_orders():
    """Get all orders with optional filters."""
    db = SessionLocal()
    try:
        query = db.query(Order)

        status = request.args.get('status', '')
        if status:
            query = query.join(OrderStatus).filter(OrderStatus.code == status)

        supplier_id = request.args.get('supplier_id', '')
        if supplier_id:
            query = query.filter(Order.supplier_id == int(supplier_id))

        orders = query.all()
        return jsonify([o.to_dict() for o in orders])
    finally:
        db.close()


@orders_bp.route('/api/orders', methods=['POST'])
@permission_required('create_orders')
def create_order():
    """Create a new order."""
    db = SessionLocal()
    try:
        data = request.json

        supplier = db.query(Supplier).filter(Supplier.id == data.get('supplier_id')).first()
        if not supplier:
            return jsonify({'error': 'Supplier not found'}), 404

        last_order = db.query(Order).order_by(Order.id.desc()).first()
        order_number = f"ORD-{(last_order.id + 1 if last_order else 1):06d}"

        status_code = data.get('status', 'pending')
        status_obj = db.query(OrderStatus).filter(OrderStatus.code == status_code).first()
        status_id = status_obj.id if status_obj else None

        order = Order(
            order_number=order_number,
            supplier_id=data.get('supplier_id'),
            supplier_name=supplier.name,
            delivery_date=(
                datetime.fromisoformat(data.get('delivery_date'))
                if data.get('delivery_date') else None
            ),
            status_id=status_id,
            total_amount=data.get('total_amount', 0.0),
            items=data.get('items', ''),
            notes=data.get('notes', ''),
            created_by=session.get('user_id')
        )
        db.add(order)
        db.commit()
        db.refresh(order)
        return jsonify(order.to_dict()), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


@orders_bp.route('/api/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    """Get a single order by ID."""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        return jsonify(order.to_dict())
    finally:
        db.close()


@orders_bp.route('/api/orders/<int:order_id>/items-parsed', methods=['GET'])
@login_required
def get_order_items_parsed(order_id):
    """Get order items with SKU information parsed."""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404

        supplier = db.query(Supplier).filter(Supplier.id == order.supplier_id).first()
        parsed_items = []
        items_text = order.items or ''

        for line in items_text.strip().split('\n'):
            if not line.strip():
                continue

            item_data = {
                'internal_sku': '-',
                'vendor_sku': '-',
                'name': '',
                'qty': '',
                'price': ''
            }

            if '|' in line:
                parts = [p.strip() for p in line.split('|')]
                if len(parts) >= 3:
                    item_data['internal_sku'] = parts[0]
                    item_data['name'] = parts[1]
                    item_data['qty'] = parts[2]
                    item_data['price'] = parts[3] if len(parts) > 3 else ''
            else:
                match = re.match(r'(\d+)\s*x\s*(.+?)(?:\s*@\s*(.+))?$', line.strip(), re.IGNORECASE)
                if match:
                    item_data['qty'] = match.group(1)
                    item_data['name'] = match.group(2).strip()
                    item_data['price'] = match.group(3).strip() if match.group(3) else ''

                    db_item = db.query(Item).filter(Item.name.ilike(f'%{item_data["name"]}%')).first()
                    if db_item:
                        item_data['internal_sku'] = db_item.item_code
                        if supplier:
                            link = db.execute(
                                select(supplier_items).where(
                                    supplier_items.c.supplier_id == supplier.id,
                                    supplier_items.c.item_id == db_item.id
                                )
                            ).first()
                            if link and link.supplier_item_code:
                                item_data['vendor_sku'] = link.supplier_item_code
                else:
                    item_data['name'] = line.strip()

            parsed_items.append(item_data)

        return jsonify({'success': True, 'items': parsed_items})

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@orders_bp.route('/api/orders/<int:order_id>/status', methods=['PUT'])
@permission_required('update_orders')
def update_order_status(order_id):
    """Update order status."""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404

        data = request.json
        new_status = data.get('status')

        if not new_status:
            return jsonify({'error': 'Status is required'}), 400

        status_obj = db.query(OrderStatus).filter(OrderStatus.code == new_status).first()
        if not status_obj:
            return jsonify({'error': f'Invalid status code: {new_status}'}), 400

        order.status_id = status_obj.id
        order.updated_by = session.get('user_id')
        db.commit()

        return jsonify(order.to_dict())
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        db.close()


@orders_bp.route('/api/orders/<int:order_id>/print', methods=['GET'])
def print_order(order_id):
    """Render order using HTML template with placeholders."""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404

        supplier = db.query(Supplier).filter(Supplier.id == order.supplier_id).first()

        lang = request.args.get('lang', 'esp').lower()
        mode = request.args.get('mode', 'internal')

        config_map = _load_config_map()
        template_key = f'ORDER_TEMPLATE_{lang.upper()}'
        template_name = f'order_template_{lang.lower()}.html'
        template_path = config_map.get(template_key, f'config/{template_name}')

        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
        full_template_path = os.path.join(base_dir, template_path)

        if not os.path.exists(full_template_path):
            return jsonify({'error': f'Template not found: {template_path}'}), 404

        with open(full_template_path, 'r', encoding='utf-8') as f:
            template_html = f.read()

        parts = _build_template_replacements(order, supplier, config_map, lang, mode)
        items_rows_html = _parse_order_items_html(order.items or '', supplier, db, mode)

        replacements = {
            '##letterhead##': parts['letterhead_html'],
            '##order_number##': order.order_number or '',
            '##status##': (order.status.code if order.status else 'pending'),
            '##status_label##': parts['status_label'],
            '##supplier_name##': order.supplier_name or '',
            '##order_date##': order.order_date.strftime('%Y-%m-%d') if order.order_date else '',
            '##delivery_date##': order.delivery_date.strftime('%Y-%m-%d') if order.delivery_date else 'N/A',
            '##payment_terms##': parts['payment_terms'],
            '##items_rows##': items_rows_html,
            '##sku_header##': parts['sku_header'],
            '##price_header##': parts['price_header'],
            '##total_section##': parts['total_section'],
            '##notes_section##': parts['notes_section'],
        }

        for placeholder, value in replacements.items():
            template_html = template_html.replace(placeholder, str(value))

        return Response(template_html, mimetype='text/html')

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()


@orders_bp.route('/api/orders/export', methods=['GET'])
@permission_required('export')
def export_orders():
    """Export orders to Excel file."""
    db = SessionLocal()
    try:
        orders = db.query(Order).all()
        data = [o.to_dict() for o in orders]
        df = pd.DataFrame(data)

        filename = f'orders_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        export_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'exports')
        os.makedirs(export_dir, exist_ok=True)
        file_path = os.path.abspath(os.path.join(export_dir, filename))
        df.to_excel(file_path, index=False, engine='openpyxl')
    finally:
        db.close()

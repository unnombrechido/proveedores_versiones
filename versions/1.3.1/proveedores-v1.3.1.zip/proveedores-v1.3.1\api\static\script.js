// API Base URL
const API_BASE = '/api';

// Global state
let suppliers = [];
let orders = [];
let items = [];
let currentPriceItem = null; // For price management page
let allPriceSuppliersData = []; // All suppliers for filtering
let currentUser = null; // Current authenticated user
let currentUserId = null; // For editing users
let aboutInfoCache = null;

// LOV Data
let lovData = {
    itemCategories: [],
    supplierCategories: [],
    unitsOfMeasure: [],
    itemConditions: [],
    locations: [],
    orderStatuses: [],
    paymentMethods: [],
    paymentTerms: [],
    taxTypes: [],
    countries: [],
    states: []
};

// Check authentication on page load
document.addEventListener('DOMContentLoaded', async () => {
    await checkAuth();
    loadInitialData();
    initZoom();
});

// Load initial data after authentication
async function loadInitialData() {
    // Load LOV data first
    await loadLOVs();
    
    // Show default section (search-items)
    showSection('search-items');
}

// Load all LOV data
async function loadLOVs() {
    try {
        const lovPromises = [
            loadLOV('itemCategories', '/api/lovs/item-categories'),
            loadLOV('supplierCategories', '/api/lovs/supplier-categories'),
            loadLOV('unitsOfMeasure', '/api/lovs/units-of-measure'),
            loadLOV('itemConditions', '/api/lovs/item-conditions'),
            loadLOV('locations', '/api/lovs/locations'),
            loadLOV('orderStatuses', '/api/lovs/order-statuses'),
            loadLOV('paymentMethods', '/api/lovs/payment-methods'),
            loadLOV('paymentTerms', '/api/lovs/payment-terms'),
            loadLOV('taxTypes', '/api/lovs/tax-types'),
            loadLOV('countries', '/api/lovs/countries')
        ];
        
        await Promise.all(lovPromises);
        console.log('All LOVs loaded successfully');
    } catch (error) {
        console.error('Error loading LOVs:', error);
    }
}

// Load a specific LOV
async function loadLOV(lovKey, url) {
    try {
        const response = await fetch(url);
        if (response.ok) {
            lovData[lovKey] = await response.json();
            console.log(`Loaded ${lovKey}:`, lovData[lovKey].length, 'items');
        } else {
            console.error(`Failed to load ${lovKey}:`, response.status);
            // Set empty array as fallback
            lovData[lovKey] = [];
        }
    } catch (error) {
        console.error(`Error loading ${lovKey}:`, error);
        // Set empty array as fallback
        lovData[lovKey] = [];
    }
}

// Authentication Functions
async function checkAuth() {
    try {
        const response = await fetch(`${API_BASE}/auth/check`);
        
        if (!response.ok) {
                // console.error('Auth check failed:', response.status);
            window.location.href = '/login';
            return;
        }
        
        const data = await response.json();
        
        if (!data.authenticated) {
            window.location.href = '/login';
            return;
        }
        
        currentUser = data.user;
        updateUIForUser(currentUser);
    } catch (error) {
            // console.error('Auth check error:', error);
        window.location.href = '/login';
    }
}

function updateUIForUser(user) {
    // Update user info in sidebar
    document.getElementById('current-user-name').textContent = `${user.nombre} ${user.apellido}`;
    document.getElementById('current-user-role').textContent = `Rol: ${user.rol}`;
    
    // Show/hide navigation items based on role
    const userManagementNav = document.getElementById('user-management-nav');
    const settingsNav = document.getElementById('settings-nav');
    
    if (user.rol === 'sysadmin') {
        userManagementNav.style.display = 'block';
        settingsNav.style.display = 'block';
    } else if (user.rol === 'admin') {
        userManagementNav.style.display = 'none';
        settingsNav.style.display = 'block';
    } else if (user.rol === 'compras') {
        userManagementNav.style.display = 'none';
        settingsNav.style.display = 'none';
        
        // Hide management navigation buttons for compras role
        const inventoryNav = document.querySelector('[onclick="showSection(\'inventory\')"]');
        const vendorsNav = document.querySelector('[onclick="showSection(\'vendors\')"]');
        if (inventoryNav) inventoryNav.style.display = 'none';
        if (vendorsNav) vendorsNav.style.display = 'none';
    }
    
    // Apply permission-based restrictions
    applyPermissionRestrictions(user.rol);
}

function applyPermissionRestrictions(rol) {
    // Hide all buttons with data-permission="edit" for compras users
    if (rol === 'compras') {
        const restrictedButtons = document.querySelectorAll('[data-permission="edit"]');
        restrictedButtons.forEach(button => {
            button.style.display = 'none';
        });
        
        // Also disable edit/delete actions in tables
        hideTableActions();
    }
}

function hideTableActions() {
    // This will hide edit/delete buttons in inventory and vendor tables
    // Will be called after tables are loaded
    const editButtons = document.querySelectorAll('button[onclick*="edit"], button[onclick*="Edit"]');
    const deleteButtons = document.querySelectorAll('button[onclick*="delete"], button[onclick*="Delete"]');
    
    editButtons.forEach(btn => {
        if (currentUser && currentUser.rol === 'compras') {
            // Check if it's not an order-related button
            const onclick = btn.getAttribute('onclick') || '';
            if (!onclick.includes('Order') && !onclick.includes('order')) {
                btn.style.display = 'none';
            }
        }
    });
    
    deleteButtons.forEach(btn => {
        if (currentUser && currentUser.rol === 'compras') {
            const onclick = btn.getAttribute('onclick') || '';
            if (!onclick.includes('Order') && !onclick.includes('order')) {
                btn.style.display = 'none';
            }
        }
    });
}

async function logout() {
    try {
        await fetch(`${API_BASE}/auth/logout`, { method: 'POST' });
        window.location.href = '/login';
    } catch (error) {
        console.error('Logout error:', error);
        window.location.href = '/login';
    }
}

// User Management Functions
async function loadUsers() {
    if (!currentUser || currentUser.rol !== 'sysadmin') {
        return;
    }
    
    try {
        const search = document.getElementById('users-search').value;
        const rol = document.getElementById('role-filter').value;
        const status = document.getElementById('status-filter').value;
        
        let url = `${API_BASE}/users?`;
        if (search) url += `search=${encodeURIComponent(search)}&`;
        if (rol) url += `rol=${rol}&`;
        if (status) url += `status=${status}&`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            displayUsers(data.users);
        }
    } catch (error) {
        console.error('Error loading users:', error);
        showNotification('Error al cargar usuarios', 'error');
    }
}

function displayUsers(users) {
    const tbody = document.getElementById('users-tbody');
    tbody.innerHTML = '';
    
    users.forEach(user => {
        const tr = document.createElement('tr');
        const statusBadge = user.status === 'activo' 
            ? '<span style="color: green;">●</span> Activo' 
            : '<span style="color: red;">●</span> Inactivo';
        
        const roleBadge = {
            'sysadmin': '👑 Sysadmin',
            'admin': '⭐ Admin',
            'compras': '📦 Compras'
        }[user.rol] || user.rol;
        
        tr.innerHTML = `
            <td>${user.email}</td>
            <td>${user.nombre}</td>
            <td>${user.apellido}</td>
            <td>${user.telefono || '-'}</td>
            <td>${roleBadge}</td>
            <td>${statusBadge}</td>
            <td>${new Date(user.fecha_registro).toLocaleDateString()}</td>
            <td>
                <button class="btn btn-sm" onclick="editUser(${user.id})">✏️ Editar</button>
                <button class="btn btn-sm" onclick="changeUserPassword(${user.id})">🔑 Cambiar Contraseña</button>
                ${user.id !== currentUser.id ? `<button class="btn btn-sm btn-danger" onclick="deleteUser(${user.id})">🗑️ Eliminar</button>` : ''}
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function openUserModal(userId = null) {
    currentUserId = userId;
    const modal = document.getElementById('user-modal');
    const title = document.getElementById('user-modal-title');
    const form = document.getElementById('user-form');
    
    form.reset();
    
    if (userId) {
        title.textContent = 'Editar Usuario';
        document.getElementById('user-password').required = false;
        document.querySelector('label[for="user-password"] small').textContent = '(dejar vacío para mantener actual)';
        loadUserData(userId);
    } else {
        title.textContent = 'Nuevo Usuario';
        document.getElementById('user-password').required = true;
        document.querySelector('label[for="user-password"] small').textContent = '';
    }
    
    modal.style.display = 'block';
}

async function loadUserData(userId) {
    try {
        const response = await fetch(`${API_BASE}/users/${userId}`);
        const data = await response.json();
        
        if (data.success) {
            const user = data.user;
            document.getElementById('user-email').value = user.email;
            document.getElementById('user-nombre').value = user.nombre;
            document.getElementById('user-apellido').value = user.apellido;
            document.getElementById('user-telefono').value = user.telefono || '';
            document.getElementById('user-rol').value = user.rol;
            document.getElementById('user-status').value = user.status;
        }
    } catch (error) {
        console.error('Error loading user:', error);
        showNotification('Error al cargar usuario', 'error');
    }
}

async function saveUser(event) {
    event.preventDefault();
    
    const userData = {
        email: document.getElementById('user-email').value,
        nombre: document.getElementById('user-nombre').value,
        apellido: document.getElementById('user-apellido').value,
        telefono: document.getElementById('user-telefono').value,
        rol: document.getElementById('user-rol').value,
        status: document.getElementById('user-status').value
    };
    
    const password = document.getElementById('user-password').value;
    if (password) {
        userData.password = password;
    }
    
    try {
        let response;
        if (currentUserId) {
            response = await fetch(`${API_BASE}/users/${currentUserId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
        } else {
            response = await fetch(`${API_BASE}/users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
        }
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(data.message, 'success');
            closeUserModal();
            loadUsers();
        } else {
            showNotification(data.error, 'error');
        }
    } catch (error) {
        console.error('Error saving user:', error);
        showNotification('Error al guardar usuario', 'error');
    }
}

async function editUser(userId) {
    openUserModal(userId);
}

async function changeUserPassword(userId) {
    const newPassword = prompt('Ingrese la nueva contraseña (mínimo 6 caracteres):');
    
    if (!newPassword) return;
    
    if (newPassword.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/users/${userId}/password`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ new_password: newPassword })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Contraseña actualizada exitosamente', 'success');
        } else {
            showNotification(data.error, 'error');
        }
    } catch (error) {
        console.error('Error changing password:', error);
        showNotification('Error al cambiar contraseña', 'error');
    }
}

async function deleteUser(userId) {
    if (!confirm('¿Está seguro de eliminar este usuario? Esta acción no se puede deshacer.')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/users/${userId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Usuario eliminado exitosamente', 'success');
            loadUsers();
        } else {
            showNotification(data.error, 'error');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        showNotification('Error al eliminar usuario', 'error');
    }
}

function closeUserModal() {
    document.getElementById('user-modal').style.display = 'none';
    currentUserId = null;
}

// Notification helper function
function showNotification(message, type = 'info') {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('notification-toast');
    if (!notification) {
        notification = document.createElement('div');
        notification.id = 'notification-toast';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            z-index: 10000;
            box-shadow: 0 4px 6px rgba(0,0,0,0.2);
            max-width: 400px;
            animation: slideIn 0.3s ease-out;
        `;
        document.body.appendChild(notification);
    }
    
    // Set color based on type
    const colors = {
        'success': '#28a745',
        'error': '#dc3545',
        'warning': '#ffc107',
        'info': '#17a2b8'
    };
    
    notification.style.backgroundColor = colors[type] || colors['info'];
    notification.textContent = message;
    notification.style.display = 'block';
    
    // Auto-hide after 4 seconds
    setTimeout(() => {
        notification.style.display = 'none';
    }, 4000);
}

function loadInitialData() {
    // Load database info, company name, etc.
    loadDatabaseInfo();
    loadCompanyName();
    showSection('search-items'); // Show first section by default
    
    // Enter key search for items
    const itemsSearch = document.getElementById('items-search');
    if (itemsSearch) {
        itemsSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchItems();
            }
        });
    }
}

// Predefined Lists
// (Now loaded from LOV APIs)

// Utility Functions
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Loading indicator functions
function showLoading(message = 'Cargando...') {
    let overlay = document.getElementById('loading-overlay');
    if (!overlay) {
        // Create overlay dynamically if it doesn't exist
        overlay = document.createElement('div');
        overlay.id = 'loading-overlay';
        overlay.className = 'loading-overlay';
        overlay.innerHTML = `
            <div class="loading-spinner">
                <div class="spinner"></div>
                <div class="loading-text">${message}</div>
            </div>
        `;
        document.body.appendChild(overlay);
    }
    const textElement = overlay.querySelector('.loading-text');
    if (textElement) {
        textElement.textContent = message;
    }
    overlay.style.display = 'flex';
}

function hideLoading() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

let appConfigCache = null;

async function getAppConfig() {
    if (appConfigCache) {
        return appConfigCache;
    }
    try {
        const response = await fetch('/api/config');
        const data = await response.json();
        appConfigCache = data || {};
        return appConfigCache;
    } catch (error) {
        console.error('Error loading config:', error);
        return {};
    }
}

function normalizeLogoPath(logoPath) {
    if (!logoPath) return '';
    let logoUrl = logoPath.trim();
    if (!logoUrl) return '';
    if (!logoUrl.startsWith('http://') && !logoUrl.startsWith('https://') && !logoUrl.startsWith('/')) {
        logoUrl = '/static/' + logoUrl;
    }
    return logoUrl;
}

function stripPricesFromItems(itemsText) {
    if (!itemsText) return '';
    let cleaned = itemsText;
    cleaned = cleaned.replace(/@\s*\$?\d+(?:[.,]\d{1,2})?/g, '');
    cleaned = cleaned.replace(/\$\s*\d+(?:[.,]\d{1,2})?/g, '');
    cleaned = cleaned.replace(/\b(?:USD|MXN)\s*\d+(?:[.,]\d{1,2})?/gi, '');
    cleaned = cleaned.replace(/\s{2,}/g, ' ');
    return cleaned.trim();
}

// Company Name Management
function loadCompanyName() {
    // Load from server config.ini
    fetch('/api/config')
        .then(response => response.json())
        .then(data => {
            const input = document.getElementById('company-name');
            if (input) {
                input.value = data.companyName || 'Mi Empresa';
            }
            
            // Load logo if path is provided
            if (data.logoPath !== undefined) {
                const logoImg = document.getElementById('company-logo');
                const logoPlaceholder = document.getElementById('logo-placeholder');
                if (logoImg) {
                    logoImg.src = '/api/logo';
                    logoImg.style.display = 'block';
                    if (logoPlaceholder) {
                        logoPlaceholder.style.display = 'none';
                    }
                }
            }

            // Store config for later use
            window.appConfig = data;
        })
        .catch(error => {
            console.error('Error loading company name:', error);
            // Fallback to default
            const input = document.getElementById('company-name');
            if (input) {
                input.value = 'Mi Empresa';
            }
        });
}

function saveCompanyName() {
    const input = document.getElementById('company-name');
    if (input && input.value.trim()) {
        const companyName = input.value.trim();
        
        // Save to server config.ini
        fetch('/api/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                companyName: companyName,
                logoPath: '' // Logo path can be added later
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Company name saved successfully');
            } else {
                console.error('Error saving company name:', data.error);
            }
        })
        .catch(error => {
            console.error('Error saving company name:', error);
        });
    }
}

function loadCompanySettings() {
    fetch('/api/config')
        .then(response => response.json())
        .then(data => {
            // Populate form fields
            document.getElementById('settings-company-name').value = data.companyName || '';
            document.getElementById('settings-company-address').value = data.companyAddress || '';
            document.getElementById('settings-company-phone').value = data.companyPhone || '';
            document.getElementById('settings-company-email').value = data.companyEmail || '';
            document.getElementById('settings-company-website').value = data.companyWebsite || '';

            // Handle logo preview
            const logoPreview = document.getElementById('settings-logo-preview');
            const logoPlaceholder = document.getElementById('settings-logo-placeholder');
            
            if (data.logoPath) {
                logoPreview.src = '/api/logo';
                logoPreview.style.display = 'block';
                logoPlaceholder.style.display = 'none';
            } else {
                logoPreview.style.display = 'none';
                logoPlaceholder.style.display = 'flex';
            }
        })
        .catch(error => {
            console.error('Error loading company settings:', error);
            showError('Error al cargar la configuración');
        });
}

function saveCompanySettings() {
    const settings = {
        companyName: document.getElementById('settings-company-name').value.trim(),
        companyAddress: document.getElementById('settings-company-address').value.trim(),
        companyPhone: document.getElementById('settings-company-phone').value.trim(),
        companyEmail: document.getElementById('settings-company-email').value.trim(),
        companyWebsite: document.getElementById('settings-company-website').value.trim(),
        logoPath: '' // Will be handled by file upload
    };

    fetch('/api/config', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(settings)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccess('Configuración guardada exitosamente');
            // Update the sidebar company name
            loadCompanyName();
        } else {
            showError('Error al guardar la configuración: ' + (data.error || 'Error desconocido'));
        }
    })
    .catch(error => {
        console.error('Error saving company settings:', error);
        showError('Error al guardar la configuración');
    });
}

function handleLogoUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
        showError('Por favor selecciona un archivo de imagen válido');
        return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
        showError('El archivo es demasiado grande. Máximo 5MB permitido');
        return;
    }

    const formData = new FormData();
    formData.append('logo', file);

    // Show loading
    const logoPreview = document.getElementById('settings-logo-preview');
    const logoPlaceholder = document.getElementById('settings-logo-placeholder');
    logoPlaceholder.innerHTML = 'Subiendo...';

    fetch('/api/logo', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update preview
            logoPreview.src = '/api/logo?t=' + Date.now(); // Cache busting
            logoPreview.style.display = 'block';
            logoPlaceholder.style.display = 'none';
            showSuccess('Logo subido exitosamente');
            
            // Update sidebar logo
            loadCompanyName();
        } else {
            showError('Error al subir el logo: ' + (data.error || 'Error desconocido'));
            logoPlaceholder.innerHTML = 'Sin logo';
        }
    })
    .catch(error => {
        console.error('Error uploading logo:', error);
        showError('Error al subir el logo');
        logoPlaceholder.innerHTML = 'Sin logo';
    });
}

async function loadAboutInfo() {
    if (aboutInfoCache) {
        renderAboutInfo(aboutInfoCache);
        return;
    }

    try {
        const response = await fetch('/api/about');
        const data = await response.json();
        aboutInfoCache = data;
        renderAboutInfo(data);
    } catch (error) {
        console.error('Error loading about info:', error);
    }
}

function renderAboutInfo(data) {
    const versionBadge = document.getElementById('about-version');
    const developer = document.getElementById('about-developer');
    const releaseNotes = document.getElementById('about-release-notes');
    const licenseLink = document.getElementById('about-license');

    if (versionBadge) {
        versionBadge.textContent = `Versión: ${data.version || '-'}`;
    }
    if (developer) {
        developer.textContent = data.developer || '-';
    }
    if (releaseNotes) {
        if (data.hasReleaseNotes) {
            releaseNotes.href = data.releaseNotesUrl || '#';
            releaseNotes.style.pointerEvents = 'auto';
            releaseNotes.style.opacity = '1';
        } else {
            releaseNotes.href = '#';
            releaseNotes.style.pointerEvents = 'none';
            releaseNotes.style.opacity = '0.5';
        }
    }
    if (licenseLink) {
        if (data.hasLicense) {
            licenseLink.href = data.licenseUrl || '#';
            licenseLink.style.pointerEvents = 'auto';
            licenseLink.style.opacity = '1';
        } else {
            licenseLink.href = '#';
            licenseLink.style.pointerEvents = 'none';
            licenseLink.style.opacity = '0.5';
        }
    }
}

// Section Navigation
function showSection(sectionName) {
    console.log('showSection called with:', sectionName);
    
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Remove active from all nav items
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Show selected section
    const section = document.getElementById(sectionName + '-section');
    console.log('Section element found:', section);
    if (section) {
        section.classList.add('active');
        console.log('Added active class to section');
        console.log('Section display style:', window.getComputedStyle(section).display);
        console.log('Section visibility:', window.getComputedStyle(section).visibility);
        
        // // Add a test element to see if the section is visible
        // const testDiv = document.createElement('div');
        // testDiv.textContent = `TEST: ${sectionName} section is visible`;
        // testDiv.style.background = 'red';
        // testDiv.style.color = 'white';
        // testDiv.style.padding = '10px';
        // testDiv.style.position = 'absolute';
        // testDiv.style.top = '100px';
        // testDiv.style.left = '100px';
        // testDiv.style.zIndex = '9999';
        // section.appendChild(testDiv);
        
        // setTimeout(() => {
        //     testDiv.remove();
        // }, 3000);
    } else {
            // console.error('Section element not found for:', sectionName);
    }
    
    // Set active nav item - find the button that was clicked or matches the section
    if (window.event && window.event.target) {
        const target = window.event.target;
        const clickedButton = target.classList?.contains('nav-item') 
            ? target 
            : (target.closest ? target.closest('.nav-item') : target.parentElement?.closest('.nav-item'));
        if (clickedButton) {
            clickedButton.classList.add('active');
        }
    } else {
        // If called programmatically, find the matching nav button
        const navButtons = document.querySelectorAll('.nav-item');
        navButtons.forEach(button => {
            const onclick = button.getAttribute('onclick');
            if (onclick && onclick.includes(sectionName)) {
                button.classList.add('active');
            }
        });
    }
    
    // Update section title
    const titles = {
        'search-items': 'Buscar Items',
        'search-vendors': 'Buscar Proveedores',
        'inventory': 'Gestión de Inventario',
        'vendors': 'Gestión de Proveedores',
        'orders': 'Gestión de Órdenes',
        'price-management': 'Gestión de Precios',
        'settings': 'Configuración',
        'users': 'Gestión de Usuarios',
        'about': 'Acerca de'
    };
    const sectionTitle = document.getElementById('section-title');
    if (sectionTitle) {
        sectionTitle.textContent = titles[sectionName] || '';
    }
    
    // Load data when switching sections
    console.log('Loading section:', sectionName);
    if (sectionName === 'users') {
        loadUsers();
    } else if (sectionName === 'settings') {
        loadCompanySettings();
        // Update zoom controls with current zoom level
        const currentZoom = localStorage.getItem('app-zoom-level') || 1.0;
        const zoomSlider = document.getElementById('zoom-level');
        const zoomValue = document.getElementById('zoom-value');
        if (zoomSlider) zoomSlider.value = currentZoom;
        if (zoomValue) zoomValue.textContent = Math.round(currentZoom * 100) + '%';
    }
    // Load data for section
    if (sectionName === 'inventory') {
        console.log('Calling loadInventory()');
        loadInventory();
    } else if (sectionName === 'vendors') {
        console.log('Calling loadSuppliers(), loadCategories(), loadCountries()');
        loadSuppliers();
        loadCategories();
        loadCountries();
    } else if (sectionName === 'orders') {
        console.log('Calling loadOrders(), loadSuppliersForDropdown()');
        loadOrders();
        loadSuppliersForDropdown();
    } else if (sectionName === 'price-management') {
        if (currentPriceItem) {
            loadPriceManagement(currentPriceItem.id);
        }
    } else if (sectionName === 'about') {
        loadAboutInfo();
    }
}

// Database info
async function loadDatabaseInfo() {
    try {
        const response = await fetch(`${API_BASE}/database/info`);
        const data = await response.json();
        document.getElementById('db-type').textContent = `DB: ${data.type}`;
    } catch (error) {
        console.error('Error loading database info:', error);
    }
}

// ===== SEARCH ITEMS =====
let selectedItems = [];
let currentSearchResults = [];

async function searchItems() {
    const searchTerm = document.getElementById('items-search').value.trim();
    const resultsDiv = document.getElementById('items-results');
    
    if (!searchTerm) {
        resultsDiv.innerHTML = '<p class="placeholder-text">Ingrese un término de búsqueda</p>';
        currentSearchResults = [];
        return;
    }
    
    try {
        showLoading('Buscando items...');
        resultsDiv.innerHTML = '<p class="placeholder-text">Buscando...</p>';
        const response = await fetch(`${API_BASE}/items/search?search=${encodeURIComponent(searchTerm)}`);
        
        if (!response.ok) {
            if (response.status === 401) {
                console.error('Authentication required for item search');
                window.location.href = '/login';
                return;
            } else if (response.status === 403) {
                console.error('Access denied for item search');
                resultsDiv.innerHTML = '<p class="placeholder-text">No tienes permisos para buscar items</p>';
                return;
            } else {
                console.error('Error searching items:', response.status, response.statusText);
                resultsDiv.innerHTML = '<p class="placeholder-text">Error al buscar items</p>';
                return;
            }
        }
        
        const results = await response.json();
        
        if (results.length === 0) {
            resultsDiv.innerHTML = '<p class="placeholder-text">No se encontraron resultados</p>';
            currentSearchResults = [];
            return;
        }
        
        // Store results globally
        currentSearchResults = results;
        
        // Consolidate items by name (same SKU for same item name)
        const consolidatedItems = consolidateItemsByName(results);
        
        // Populate filter dropdowns
        populateItemFilters(consolidatedItems);
        
        // Display results
        displaySearchResults(consolidatedItems);
        
    } catch (error) {
        console.error('Error searching items:', error);
        resultsDiv.innerHTML = '<p class="placeholder-text">Error al buscar items</p>';
    } finally {
        hideLoading();
    }
}

function populateItemFilters(consolidatedItems) {
    // Populate category filter from LOV - ensure LOVs are loaded
    const populateCategoryFilter = async () => {
        if (!lovData.itemCategories || lovData.itemCategories.length === 0) {
            console.log('LOV data not loaded, loading now...');
            await loadLOV('itemCategories', '/api/lovs/item-categories');
        }
        
        const categoryFilter = document.getElementById('items-category-filter');
        if (categoryFilter) {
            const currentCategory = categoryFilter.value;
            categoryFilter.innerHTML = '<option value="">Todas las Categorías</option>';
            lovData.itemCategories.forEach(cat => {
                const option = document.createElement('option');
                option.value = cat.id;
                option.textContent = cat.name_es;
                if (cat.id == currentCategory) option.selected = true;
                categoryFilter.appendChild(option);
            });
        }
    };
    
    populateCategoryFilter();
    
    // Update vendor filter (still from data)
    const vendorFilter = document.getElementById('items-vendor-filter');
    if (vendorFilter) {
        const currentVendor = vendorFilter.value;
        vendorFilter.innerHTML = '<option value="">Todos los Proveedores</option>';
        // Extract unique vendors from consolidatedItems
        const allVendors = new Set();
        consolidatedItems.forEach(itemData => {
            itemData.suppliers.forEach(s => {
                allVendors.add(s.supplier_name);
            });
        });
        Array.from(allVendors).sort().forEach(vendor => {
            const option = document.createElement('option');
            option.value = vendor;
            option.textContent = vendor;
            if (vendor === currentVendor) option.selected = true;
            vendorFilter.appendChild(option);
        });
    }
}

function applyItemFilters() {
    if (currentSearchResults.length === 0) return;
    
    const categoryFilter = document.getElementById('items-category-filter').value;
    const vendorFilter = document.getElementById('items-vendor-filter').value;
    const sortBy = document.getElementById('items-sort').value;
    
    // Consolidate items
    let consolidatedItems = consolidateItemsByName(currentSearchResults);
    
    // Apply category filter
    if (categoryFilter) {
        consolidatedItems = consolidatedItems.filter(itemData => 
            itemData.item.category_id == categoryFilter
        );
    }
    
    // Apply vendor filter
    if (vendorFilter) {
        consolidatedItems = consolidatedItems.filter(itemData =>
            itemData.suppliers.some(s => s.supplier_name === vendorFilter)
        );
        // Filter suppliers within each item
        consolidatedItems = consolidatedItems.map(itemData => ({
            ...itemData,
            suppliers: itemData.suppliers.filter(s => s.supplier_name === vendorFilter)
        }));
    }
    
    // Apply sorting
    consolidatedItems.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return a.item.name.localeCompare(b.item.name);
            case 'vendor':
                const vendorA = a.suppliers[0]?.supplier_name || '';
                const vendorB = b.suppliers[0]?.supplier_name || '';
                return vendorA.localeCompare(vendorB);
            case 'price-asc':
                const minPriceA = Math.min(...a.suppliers.map(s => s.price || Infinity));
                const minPriceB = Math.min(...b.suppliers.map(s => s.price || Infinity));
                return minPriceA - minPriceB;
            case 'price-desc':
                const maxPriceA = Math.min(...a.suppliers.map(s => s.price || Infinity));
                const maxPriceB = Math.min(...b.suppliers.map(s => s.price || Infinity));
                return maxPriceB - maxPriceA;
            default:
                return 0;
        }
    });
    
    displaySearchResults(consolidatedItems);
}

function displaySearchResults(consolidatedItems) {
    const resultsDiv = document.getElementById('items-results');
    let html = '<div class="items-selection-container">';
        
        consolidatedItems.forEach(itemData => {
            const item = itemData.item;
            const suppliers = itemData.suppliers || [];
            
            // Find cheapest price
            const cheapestSupplier = suppliers.reduce((min, s) => 
                !min || (s.price && (!min.price || s.price < min.price)) ? s : min, null);
            
            html += `
                <div class="item-card">
                    <div class="item-header">
                        <label class="item-checkbox-label">
                            <input type="checkbox" class="item-checkbox" 
                                   data-item-id="${item.id}" 
                                   data-item-name="${item.name}"
                                   data-item-code="${item.item_code}"
                                   onchange="updateSelectedItems()">
                            <h3>${item.name}</h3>
                        </label>
                    </div>
                    <div class="item-info">
                        <div class="info-item">
                            <span class="info-label">Código (SKU)</span>
                            <span class="info-value">${item.item_code}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Categoría</span>
                            <span class="info-value">${item.category || 'N/A'}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Unidad</span>
                            <span class="info-value">${item.unit || 'N/A'}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Precio más bajo</span>
                            <span class="info-value">${cheapestSupplier && cheapestSupplier.price ? '$' + cheapestSupplier.price.toFixed(2) : 'N/A'}</span>
                        </div>
                    </div>
                    ${item.description ? `<p><strong>Descripción:</strong> ${item.description}</p>` : ''}
                    
                    <div class="suppliers-list">
                        <h4>Proveedores disponibles (${suppliers.length})</h4>
                        <div class="suppliers-grid">
                            ${suppliers.map(s => `
                                <div class="supplier-item ${cheapestSupplier && s.supplier_id === cheapestSupplier.supplier_id ? 'cheapest' : ''}">
                                    <div class="supplier-info">
                                        <strong>${s.supplier_name}</strong>
                                        ${cheapestSupplier && s.supplier_id === cheapestSupplier.supplier_id ? '<span class="badge-cheapest">Más Económico</span>' : ''}
                                        <br>
                                        <small>${s.email || ''} ${s.phone ? '| ' + s.phone : ''}</small>
                                        ${s.supplier_item_code ? `<br><small>Código: ${s.supplier_item_code}</small>` : ''}
                                    </div>
                                    <div class="supplier-price">
                                        ${s.price ? `<strong>$${s.price.toFixed(2)}</strong>` : 'N/A'}
                                        ${s.lead_time_days ? `<br><small>${s.lead_time_days} días</small>` : ''}
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        
        // Add single order button
        html += `
            <div class="order-action-bar">
                <div class="selected-items-summary" id="selected-summary">
                    <span>Seleccione items para crear orden</span>
                </div>
                <button onclick="createBulkOrder()" class="btn btn-primary btn-lg" id="create-order-btn" disabled>
                    📦 Crear Orden
                </button>
            </div>
        `;
        
        resultsDiv.innerHTML = html;
        selectedItems = [];
}

function consolidateItemsByName(results) {
    const itemsMap = new Map();
    
    results.forEach(result => {
        const item = result.item;
        const suppliers = result.suppliers || [];
        
        // Use item name as key to consolidate
        if (!itemsMap.has(item.name)) {
            itemsMap.set(item.name, {
                item: item,
                suppliers: []
            });
        }
        
        const consolidated = itemsMap.get(item.name);
        
        // Add suppliers from this result
        suppliers.forEach(supplier => {
            // Avoid duplicates
            if (!consolidated.suppliers.find(s => s.supplier_id === supplier.supplier_id)) {
                consolidated.suppliers.push(supplier);
            }
        });
    });
    
    return Array.from(itemsMap.values());
}

function updateSelectedItems() {
    const checkboxes = document.querySelectorAll('.item-checkbox:checked');
    selectedItems = Array.from(checkboxes).map(cb => ({
        id: parseInt(cb.dataset.itemId),
        name: cb.dataset.itemName,
        code: cb.dataset.itemCode
    }));
    
    const summary = document.getElementById('selected-summary');
    const orderBtn = document.getElementById('create-order-btn');
    
    if (selectedItems.length === 0) {
        summary.innerHTML = '<span>Seleccione items para crear orden</span>';
        orderBtn.disabled = true;
    } else {
        summary.innerHTML = `<span><strong>${selectedItems.length}</strong> item(s) seleccionado(s)</span>`;
        orderBtn.disabled = false;
    }
}

async function createBulkOrder() {
    if (selectedItems.length === 0) {
        showError('Seleccione al menos un item');
        return;
    }
    
    try {
        // Get common suppliers for selected items
        const itemIds = selectedItems.map(item => item.id);
        const response = await fetch(`${API_BASE}/items/common-suppliers`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ item_ids: itemIds })
        });
        
        const data = await response.json();
        
        if (data.common_suppliers && data.common_suppliers.length > 0) {
            // Has common suppliers - show modal to select supplier and quantities
            showBulkOrderModal(data.common_suppliers, selectedItems);
        } else if (data.supplier_groups && data.supplier_groups.length > 0) {
            // No common supplier - need multiple orders
            showMultipleOrdersModal(data.supplier_groups, selectedItems);
        } else {
            showError('No se encontraron proveedores para los items seleccionados');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al procesar la orden');
    }
}

function showBulkOrderModal(commonSuppliers, items) {
    // Sort by total cost (cheapest first)
    commonSuppliers.sort((a, b) => (a.total_cost || Infinity) - (b.total_cost || Infinity));
    
    const selectedSupplier = commonSuppliers[0]; // Default to cheapest
    
    let html = `
        <div id="bulk-order-modal" class="modal active">
            <div class="modal-content modal-large">
                <span class="close" onclick="closeBulkOrderModal()">&times;</span>
                <h2>Crear Orden - ${items.length} Items</h2>
                
                <div class="form-group">
                    <label>Proveedor</label>
                    <select id="bulk-supplier-select" onchange="updateBulkOrderSupplier()">
                        ${commonSuppliers.map((s, idx) => `
                            <option value="${idx}" ${idx === 0 ? 'selected' : ''}>
                                ${s.supplier_name} - Total: $${s.total_cost?.toFixed(2) || 'N/A'}
                                ${idx === 0 ? ' (Más Económico)' : ''}
                            </option>
                        `).join('')}
                    </select>
                </div>
                
                <div class="items-order-list">
                    <table>
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Código</th>
                                <th>Precio Unit.</th>
                                <th>Cantidad</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody id="bulk-order-items">
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4"><strong>Total:</strong></td>
                                <td><strong id="bulk-order-total">$0.00</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <div class="form-group">
                    <label>Fecha de Entrega *</label>
                    <input type="date" id="bulk-delivery-date" required>
                </div>
                
                <div class="form-group">
                    <label>Notas</label>
                    <textarea id="bulk-order-notes" rows="3"></textarea>
                </div>
                
                <div class="form-actions">
                    <button onclick="submitBulkOrder()" class="btn btn-primary">Crear Orden</button>
                    <button onclick="closeBulkOrderModal()" class="btn btn-secondary">Cancelar</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', html);
    
    // Store data in global for access
    window.bulkOrderData = { commonSuppliers, items };
    updateBulkOrderSupplier();
}

function updateBulkOrderSupplier() {
    const selectIdx = parseInt(document.getElementById('bulk-supplier-select').value);
    const supplier = window.bulkOrderData.commonSuppliers[selectIdx];
    const items = window.bulkOrderData.items;
    
    let html = '';
    let total = 0;
    
    items.forEach(item => {
        const itemPrice = supplier.items.find(i => i.item_id === item.id);
        const price = itemPrice?.price || 0;
        
        html += `
            <tr>
                <td>${item.name}</td>
                <td>${item.code}</td>
                <td>$${price.toFixed(2)}</td>
                <td>
                    <input type="number" class="qty-input" 
                           data-price="${price}" 
                           value="1" min="1" 
                           onchange="updateBulkOrderTotal()">
                </td>
                <td class="subtotal">$${price.toFixed(2)}</td>
            </tr>
        `;
        total += price;
    });
    
    document.getElementById('bulk-order-items').innerHTML = html;
    document.getElementById('bulk-order-total').textContent = '$' + total.toFixed(2);
}

function updateBulkOrderTotal() {
    let total = 0;
    document.querySelectorAll('.qty-input').forEach((input, idx) => {
        const price = parseFloat(input.dataset.price);
        const qty = parseInt(input.value) || 0;
        const subtotal = price * qty;
        
        const subtotalCell = input.closest('tr').querySelector('.subtotal');
        subtotalCell.textContent = '$' + subtotal.toFixed(2);
        
        total += subtotal;
    });
    
    document.getElementById('bulk-order-total').textContent = '$' + total.toFixed(2);
}

async function submitBulkOrder() {
    const selectIdx = parseInt(document.getElementById('bulk-supplier-select').value);
    const supplier = window.bulkOrderData.commonSuppliers[selectIdx];
    const deliveryDate = document.getElementById('bulk-delivery-date').value;
    const notes = document.getElementById('bulk-order-notes').value;
    
    if (!deliveryDate) {
        showError('Fecha de entrega requerida');
        return;
    }
    
    // Build items list
    const itemsText = [];
    let totalAmount = 0;
    
    document.querySelectorAll('.qty-input').forEach((input, idx) => {
        const qty = parseInt(input.value) || 0;
        const price = parseFloat(input.dataset.price);
        const itemName = window.bulkOrderData.items[idx].name;
        
        itemsText.push(`${qty} x ${itemName} @ $${price.toFixed(2)}`);
        totalAmount += qty * price;
    });
    
    const orderData = {
        supplier_id: supplier.supplier_id,
        delivery_date: deliveryDate,
        total_amount: totalAmount,
        items: itemsText.join('\n'),
        notes: notes
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        
        if (response.ok) {
            closeBulkOrderModal();
            showSuccess('Orden creada exitosamente');
            
            // Clear selections
            document.querySelectorAll('.item-checkbox').forEach(cb => cb.checked = false);
            updateSelectedItems();
        } else {
            showError('Error al crear orden');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear orden');
    }
}

function closeBulkOrderModal() {
    const modal = document.getElementById('bulk-order-modal');
    if (modal) {
        modal.remove();
    }
    window.bulkOrderData = null;
}

function showMultipleOrdersModal(supplierGroups, items) {
    let html = `
        <div id="bulk-order-modal" class="modal active">
            <div class="modal-content modal-large">
                <span class="close" onclick="closeBulkOrderModal()">&times;</span>
                <h2>Crear Órdenes Múltiples</h2>
                
                <div class="alert alert-info">
                    <strong>ℹ️ No hay un proveedor común para todos los items.</strong><br>
                    Se crearán ${supplierGroups.length} órdenes separadas:
                </div>
                
                <div class="orders-preview">
                    ${supplierGroups.map((group, idx) => `
                        <div class="order-group">
                            <h4>Orden ${idx + 1}: ${group.supplier_name}</h4>
                            <ul>
                                ${group.items.map(item => `
                                    <li>${item.item_name} - $${item.price?.toFixed(2) || 'N/A'}</li>
                                `).join('')}
                            </ul>
                            <p><strong>Total: $${group.total_cost?.toFixed(2) || 'N/A'}</strong></p>
                        </div>
                    `).join('')}
                </div>
                
                <div class="form-group">
                    <label>Fecha de Entrega (todas las órdenes) *</label>
                    <input type="date" id="multi-delivery-date" required>
                </div>
                
                <div class="form-actions">
                    <button onclick="submitMultipleOrders()" class="btn btn-primary">Crear ${supplierGroups.length} Órdenes</button>
                    <button onclick="closeBulkOrderModal()" class="btn btn-secondary">Cancelar</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', html);
    window.bulkOrderData = { supplierGroups };
}

async function submitMultipleOrders() {
    const deliveryDate = document.getElementById('multi-delivery-date').value;
    
    if (!deliveryDate) {
        showError('Fecha de entrega requerida');
        return;
    }
    
    const supplierGroups = window.bulkOrderData.supplierGroups;
    
    try {
        let successCount = 0;
        
        for (const group of supplierGroups) {
            const itemsText = group.items.map(item => 
                `1 x ${item.item_name} @ $${item.price?.toFixed(2) || '0.00'}`
            ).join('\n');
            
            const orderData = {
                supplier_id: group.supplier_id,
                delivery_date: deliveryDate,
                total_amount: group.total_cost,
                items: itemsText,
                notes: `Orden múltiple (${successCount + 1}/${supplierGroups.length})`
            };
            
            const response = await fetch(`${API_BASE}/orders`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderData)
            });
            
            if (response.ok) {
                successCount++;
            }
        }
        
        closeBulkOrderModal();
        showSuccess(`${successCount} órdenes creadas exitosamente`);
        
        // Clear selections
        document.querySelectorAll('.item-checkbox').forEach(cb => cb.checked = false);
        updateSelectedItems();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear órdenes');
    }
}

// ===== SEARCH VENDORS =====
let currentVendorResults = [];

async function searchVendors() {
    const searchTerm = document.getElementById('vendors-search').value.trim();
    const resultsDiv = document.getElementById('vendors-results');
    
    if (!searchTerm) {
        resultsDiv.innerHTML = '<p class="placeholder-text">Ingrese un término de búsqueda</p>';
        currentVendorResults = [];
        return;
    }
    
    try {
        showLoading('Buscando proveedores...');
        resultsDiv.innerHTML = '<p class="placeholder-text">Buscando...</p>';
        const response = await fetch(`${API_BASE}/suppliers?search=${encodeURIComponent(searchTerm)}`);
        const results = await response.json();
        
        if (results.length === 0) {
            resultsDiv.innerHTML = '<p class="placeholder-text">No se encontraron proveedores</p>';
            currentVendorResults = [];
            return;
        }
        
        currentVendorResults = results;
        populateVendorFilters(results);
        displayVendorResults(results);
        
    } catch (error) {
        console.error('Error searching vendors:', error);
        resultsDiv.innerHTML = '<p class="placeholder-text">Error al buscar proveedores</p>';
    } finally {
        hideLoading();
    }
}

function populateVendorFilters(vendors) {
    // Update category filter from LOV - ensure LOVs are loaded
    const populateCategoryFilter = async () => {
        if (!lovData.supplierCategories || lovData.supplierCategories.length === 0) {
            console.log('LOV data not loaded, loading now...');
            await loadLOV('supplierCategories', '/api/lovs/supplier-categories');
        }
        
        const categoryFilter = document.getElementById('vendors-category-filter');
        if (categoryFilter) {
            const currentCategory = categoryFilter.value;
            categoryFilter.innerHTML = '<option value="">Todas las Categorías</option>';
            lovData.supplierCategories.forEach(cat => {
                const option = document.createElement('option');
                option.value = cat.id;
                option.textContent = cat.name_es;
                if (cat.id == currentCategory) option.selected = true;
                categoryFilter.appendChild(option);
            });
        }
    };
    
    populateCategoryFilter();
    
    // Update city filter (still from data)
    const cityFilter = document.getElementById('vendors-city-filter');
    if (cityFilter) {
        const currentCity = cityFilter.value;
        cityFilter.innerHTML = '<option value="">Todas las Ciudades</option>';
        // Extract unique cities from vendors
        const allCities = new Set();
        vendors.forEach(vendor => {
            if (vendor.city) allCities.add(vendor.city);
        });
        Array.from(allCities).sort().forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            if (city === currentCity) option.selected = true;
            cityFilter.appendChild(option);
        });
    }
}

function applyVendorFilters() {
    if (currentVendorResults.length === 0) return;
    
    const categoryFilter = document.getElementById('vendors-category-filter').value;
    const cityFilter = document.getElementById('vendors-city-filter').value;
    const sortBy = document.getElementById('vendors-sort').value;
    
    let filteredVendors = [...currentVendorResults];
    
    // Apply filters
    if (categoryFilter) {
        filteredVendors = filteredVendors.filter(v => v.category_id == categoryFilter);
    }
    if (cityFilter) {
        filteredVendors = filteredVendors.filter(v => v.city === cityFilter);
    }
    
    // Apply sorting
    filteredVendors.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return a.name.localeCompare(b.name);
            case 'category':
                return (a.category || '').localeCompare(b.category || '');
            case 'city':
                return (a.city || '').localeCompare(b.city || '');
            case 'rating-desc':
                return (b.rating || 0) - (a.rating || 0);
            case 'rating-asc':
                return (a.rating || 0) - (b.rating || 0);
            default:
                return 0;
        }
    });
    
    displayVendorResults(filteredVendors);
}

function displayVendorResults(vendors) {
    const resultsDiv = document.getElementById('vendors-results');
    
    if (vendors.length === 0) {
        resultsDiv.innerHTML = '<p class="placeholder-text">No hay proveedores que coincidan con los filtros</p>';
        return;
    }
    
    let html = '';
    vendors.forEach(vendor => {
        // Check if this vendor has price info (from item suppliers view)
        const priceInfo = vendor.price ? `<div class="info-item"><span class="info-label">Precio</span><span class="info-value">$${vendor.price.toFixed(2)}</span></div>` : '';
        
        html += `
            <div class="vendor-card">
                <h3>${vendor.name}</h3>
                <div class="vendor-info">
                    ${priceInfo}
                    <div class="info-item">
                        <span class="info-label">Email</span>
                        <span class="info-value">${vendor.email || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Teléfono</span>
                        <span class="info-value">${vendor.phone || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Ciudad</span>
                        <span class="info-value">${vendor.city || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Categoría</span>
                        <span class="info-value">${vendor.category || 'N/A'}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Rating</span>
                        <span class="info-value">${vendor.rating ? '⭐ ' + vendor.rating : 'N/A'}</span>
                    </div>
                </div>
                ${vendor.address ? `<p><strong>Dirección:</strong> ${vendor.address}</p>` : ''}
                ${vendor.supplier_item_code ? `<p><strong>Código del proveedor:</strong> ${vendor.supplier_item_code}</p>` : ''}
                ${vendor.lead_time_days ? `<p><strong>Tiempo de entrega:</strong> ${vendor.lead_time_days} días</p>` : ''}
                <div style="margin-top: 15px; display: flex; gap: 10px;">
                    <button onclick='createOrderForVendor(${vendor.id}, "${vendor.name.replace(/"/g, '&quot;')}")' class="btn btn-primary btn-sm" title="Crear Orden">
                        📝
                    </button>
                    <button onclick="viewSupplierItems(${vendor.id})" class="btn btn-secondary btn-sm" title="Ver Items">
                        �
                    </button>
                </div>
            </div>
        `;
        });
        
        resultsDiv.innerHTML = html;
}

// Create order for specific vendor with items selector
async function createOrderForVendor(vendorId, vendorName) {
    try {
        // Get vendor's items
        const response = await fetch(`${API_BASE}/suppliers/${vendorId}/items`);
        const data = await response.json();
        const items = data.items || [];
        
        if (items.length === 0) {
            showError('Este proveedor no tiene items registrados');
            return;
        }
        
        // Show modal with items selector
        let html = `
            <div id="vendor-order-modal" class="modal active">
                <div class="modal-content modal-large">
                    <span class="close" onclick="closeVendorOrderModal()">&times;</span>
                    <h2>Crear Orden - ${vendorName}</h2>
                    
                    <div class="items-selector">
                        <div class="items-selector-header">
                            <h3>Seleccionar Items (${items.length})</h3>
                            <div class="items-search-box">
                                <input type="text" id="vendor-items-search" placeholder="🔍 Buscar items..." class="search-input-small" oninput="filterVendorItems()">
                            </div>
                        </div>
                        <div class="items-table-wrapper">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Seleccionar</th>
                                        <th>Item</th>
                                        <th>Código</th>
                                        <th>Precio</th>
                                        <th>Cantidad</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody id="vendor-items-tbody">
                                    ${items.map(item => `
                                        <tr class="vendor-item-row" 
                                            data-item-name="${item.name.toLowerCase()}" 
                                            data-item-code="${(item.supplier_item_code || item.item_code || '').toLowerCase()}"
                                            data-item-id="${item.id}">
                                            <td>
                                                <input type="checkbox" class="item-select-checkbox" 
                                                       data-item-id="${item.id}" 
                                                       data-item-name="${item.name}"
                                                       data-price="${item.price || 0}"
                                                       onchange="toggleItemQuantity(this); updateVendorOrderTotal(); filterVendorItems()">
                                            </td>
                                            <td>${item.name}</td>
                                            <td>${item.supplier_item_code || item.item_code || 'N/A'}</td>
                                            <td>$${(item.price || 0).toFixed(2)}</td>
                                            <td>
                                                <input type="number" class="qty-input" 
                                                       data-item-id="${item.id}"
                                                       value="1" min="1" 
                                                       onchange="updateVendorOrderTotal()" disabled>
                                            </td>
                                            <td class="item-subtotal">$${(item.price || 0).toFixed(2)}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="5"><strong>Total:</strong></td>
                                        <td><strong id="vendor-order-total">$0.00</strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Fecha de Entrega *</label>
                        <input type="date" id="vendor-order-delivery-date" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Notas</label>
                        <textarea id="vendor-order-notes" rows="3"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button onclick="submitVendorOrder(${vendorId})" class="btn btn-primary">Crear Orden</button>
                        <button onclick="closeVendorOrderModal()" class="btn btn-secondary">Cancelar</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', html);
        
        // Enable qty inputs when checkbox is selected
        document.querySelectorAll('.item-select-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const itemId = this.dataset.itemId;
                const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
                if (qtyInput) {
                    qtyInput.disabled = !this.checked;
                    if (!this.checked) qtyInput.value = 1;
                }
            });
        });
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar items del proveedor');
    }
}

function toggleItemQuantity(checkbox) {
    const itemId = checkbox.dataset.itemId;
    const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
    if (qtyInput) {
        qtyInput.disabled = !checkbox.checked;
        if (!checkbox.checked) {
            qtyInput.value = 1; // Reset to 1 when unchecked
        }
    }
}

function updateVendorOrderTotal() {
    let total = 0;
    document.querySelectorAll('.item-select-checkbox:checked').forEach(checkbox => {
        const itemId = checkbox.dataset.itemId;
        const price = parseFloat(checkbox.dataset.price);
        const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
        const qty = parseInt(qtyInput?.value || 0);
        const subtotal = price * qty;
        
        // Update subtotal display
        const subtotalCell = qtyInput?.closest('tr')?.querySelector('.item-subtotal');
        if (subtotalCell) {
            subtotalCell.textContent = '$' + subtotal.toFixed(2);
        }
        
        total += subtotal;
    });
    
    const totalElement = document.getElementById('vendor-order-total');
    if (totalElement) {
        totalElement.textContent = '$' + total.toFixed(2);
    }
}

function filterVendorItems() {
    const searchTerm = document.getElementById('vendor-items-search').value.toLowerCase().trim();
    const rows = document.querySelectorAll('.vendor-item-row');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const itemName = row.dataset.itemName || '';
        const itemCode = row.dataset.itemCode || '';
        const checkbox = row.querySelector('.item-select-checkbox');
        const isSelected = checkbox && checkbox.checked;
        
        // Show if matches search OR is selected (persist selected items)
        const matches = itemName.includes(searchTerm) || itemCode.includes(searchTerm);
        
        if (matches || isSelected) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
    // Update counter
    const header = document.querySelector('.items-selector-header h3');
    if (header) {
        const totalItems = rows.length;
        const selectedCount = document.querySelectorAll('.item-select-checkbox:checked').length;
        if (searchTerm) {
            header.textContent = `Seleccionar Items (${visibleCount} de ${totalItems}) - ${selectedCount} seleccionados`;
        } else {
            header.textContent = `Seleccionar Items (${totalItems}) - ${selectedCount} seleccionados`;
        }
    }
}

async function submitVendorOrder(vendorId) {
    const deliveryDate = document.getElementById('vendor-order-delivery-date').value;
    const notes = document.getElementById('vendor-order-notes').value;
    
    if (!deliveryDate) {
        showError('Fecha de entrega requerida');
        return;
    }
    
    const selectedItems = [];
    document.querySelectorAll('.item-select-checkbox:checked').forEach(checkbox => {
        const itemId = checkbox.dataset.itemId;
        const itemName = checkbox.dataset.itemName;
        const price = parseFloat(checkbox.dataset.price);
        const qtyInput = document.querySelector(`.qty-input[data-item-id="${itemId}"]`);
        const qty = parseInt(qtyInput?.value || 1);
        
        selectedItems.push({
            name: itemName,
            qty: qty,
            price: price
        });
    });
    
    if (selectedItems.length === 0) {
        showError('Seleccione al menos un item');
        return;
    }
    
    const itemsText = selectedItems.map(item => 
        `${item.qty} x ${item.name} @ $${item.price.toFixed(2)}`
    ).join('\n');
    
    const totalAmount = selectedItems.reduce((sum, item) => sum + (item.qty * item.price), 0);
    
    const orderData = {
        supplier_id: vendorId,
        delivery_date: deliveryDate,
        total_amount: totalAmount,
        items: itemsText,
        notes: notes
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        
        if (response.ok) {
            closeVendorOrderModal();
            showSuccess('Orden creada exitosamente');
        } else {
            showError('Error al crear orden');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear orden');
    }
}

function closeVendorOrderModal() {
    const modal = document.getElementById('vendor-order-modal');
    if (modal) {
        modal.remove();
    }
}

// Enter key search for vendors
document.addEventListener('DOMContentLoaded', function() {
    const vendorsSearch = document.getElementById('vendors-search');
    if (vendorsSearch) {
        vendorsSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchVendors();
            }
        });
    }
});

// ===== INVENTORY =====
async function loadInventory() {
    console.log('loadInventory() called');
    try {
        showLoading('Cargando inventario...');
        const response = await fetch(`${API_BASE}/items`);
        
        if (!response.ok) {
            if (response.status === 401) {
                console.error('Authentication required for items');
                window.location.href = '/login';
                return;
            } else if (response.status === 403) {
                console.error('Access denied for items');
                alert('No tienes permisos para ver items');
                return;
            } else {
                console.error('Error loading inventory:', response.status, response.statusText);
                return;
            }
        }
        
        items = await response.json();
        console.log('Loaded', items.length, 'items');
        console.log('First item sample:', items[0]);
        console.log('Item properties:', Object.keys(items[0] || {}));
        
        // Populate category filter from LOV - ensure LOVs are loaded
        const populateFilters = async () => {
            if (!lovData.itemCategories || lovData.itemCategories.length === 0) {
                console.log('LOV data not loaded, loading now...');
                await loadLOV('itemCategories', '/api/lovs/item-categories');
            }
            if (!lovData.unitsOfMeasure || lovData.unitsOfMeasure.length === 0) {
                console.log('UOM LOV data not loaded, loading now...');
                await loadLOV('unitsOfMeasure', '/api/lovs/units-of-measure');
            }
            
            const categoryFilter = document.getElementById('inventory-category-filter');
            if (categoryFilter) {
                const currentCategory = categoryFilter.value;
                categoryFilter.innerHTML = '<option value="">Todas las Categorías</option>';
                lovData.itemCategories.forEach(cat => {
                    const option = document.createElement('option');
                    option.value = cat.id;
                    option.textContent = cat.name_es;
                    if (cat.id == currentCategory) option.selected = true;
                    categoryFilter.appendChild(option);
                });
            }
        };
        
        await populateFilters();
        
        displayInventory();
    } catch (error) {
        console.error('Error loading inventory:', error);
    } finally {
        hideLoading();
    }
}

function applyInventoryFilters() {
    const searchTerm = document.getElementById('inventory-search')?.value.toLowerCase() || '';
    displayInventory(searchTerm);
}

function displayInventory(searchTerm = '') {
    console.log('currentUser:', currentUser);
    const categoryFilter = document.getElementById('inventory-category-filter').value;
    const sortBy = document.getElementById('inventory-sort').value;
    
    // Filter items
    let filteredItems = [...items];
    console.log('displayInventory() called with', items.length, 'total items');
    console.log('Starting with', filteredItems.length, 'items');
    
    // Apply search filter
    if (searchTerm) {
        filteredItems = filteredItems.filter(item => 
            item.name.toLowerCase().includes(searchTerm) ||
            item.item_code.toLowerCase().includes(searchTerm) ||
            (item.category && item.category.toLowerCase().includes(searchTerm)) ||
            (item.description && item.description.toLowerCase().includes(searchTerm))
        );
    }
    
    // Apply category filter
    if (categoryFilter) {
        filteredItems = filteredItems.filter(item => item.category_id == categoryFilter);
    }
    
    console.log('After filtering:', filteredItems.length, 'items');
    
    // Sort items
    filteredItems.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return a.name.localeCompare(b.name);
            case 'code':
                return a.item_code.localeCompare(b.item_code);
            case 'category':
                return (a.category || '').localeCompare(b.category || '');
            case 'price-asc':
                // For price, we'd need to fetch supplier prices - simplified for now
                return 0;
            case 'price-desc':
                return 0;
            default:
                return 0;
        }
    });
    
    const tbody = document.getElementById('inventory-tbody');
    console.log('tbody element:', tbody);
    if (!tbody) {
        console.error('inventory-tbody element not found!');
        return;
    }
    
    console.log('About to set tbody.innerHTML with', filteredItems.length, 'rows');
    try {
        const html = filteredItems.map(item => {
            // Check if user has edit permissions (not compras role)
            const canEdit = currentUser && (currentUser.rol === 'sysadmin' || currentUser.rol === 'admin');
            
            return `
            <tr>
                <td>${item.item_code}</td>
                <td>${item.name}</td>
                <td>${item.description || ''}</td>
                <td>${item.category || ''}</td>
                <td>${item.unit || ''}</td>
                <td>
                    <button onclick="viewSuppliersByItem(${item.id}, '${escapeHtml(item.name)}')" class="btn btn-secondary btn-sm" title="Ver Proveedores">
                        👁️
                    </button>
                </td>
                <td style="white-space: nowrap;">
                    ${canEdit ? `
                    <button onclick="editItem(${item.id})" class="btn btn-warning btn-sm" title="Editar Item">✏️</button>
                    <button onclick="manageItemSuppliers(${item.id}, '${escapeHtml(item.name)}')" class="btn btn-primary btn-sm" title="Gestionar Proveedores">
                        🏢
                    </button>
                    ` : '<span style="color: #999;">Solo lectura</span>'}
                </td>
            </tr>
            `;
        }).join('');
        console.log('Generated HTML sample:', html.substring(0, 200) + '...');
        tbody.innerHTML = html;
        console.log('tbody.innerHTML length after setting:', tbody.innerHTML.length);
        console.log('tbody.children.length:', tbody.children.length);
        console.log('First few characters of innerHTML:', tbody.innerHTML.substring(0, 100));
        
        console.log('Successfully set tbody.innerHTML');
    } catch (error) {
        console.error('Error setting tbody.innerHTML:', error);
    }
}

async function manageItemSuppliers(itemId, itemName) {
    const item = items.find(i => i.id === itemId);
    if (!item) {
        showError('Item no encontrado');
        return;
    }
    
    currentPriceItem = item;
    showSection('price-management');
}

async function viewSuppliersByItem(itemId, itemName) {
    // Show confirmation dialog
    showConfirmDialog(
        `¿Desea ver los proveedores que venden "${itemName}"?\n\nEsto lo llevará a la sección de búsqueda de proveedores.`,
        async () => {
            try {
                await loadSuppliersByItemConfirmed(itemId, itemName);
            } catch (error) {
                console.error('Error:', error);
                showError('Error al cargar proveedores del item');
            }
        }
    );
}

async function loadSuppliersByItemConfirmed(itemId, itemName) {
    try {
        // Fetch suppliers for this item
        const response = await fetch(`${API_BASE}/items/${itemId}/suppliers`);
        if (!response.ok) {
            throw new Error('Failed to fetch suppliers');
        }
        
        const suppliers = await response.json();
        
        if (suppliers.length === 0) {
            showError('Este item no tiene proveedores asociados');
            return;
        }
        
        // Switch to search vendors section
        showSection('search-vendors');
        
        // Store current search context
        currentVendorResults = suppliers;
        
        // Clear search input and populate filters
        const searchInput = document.getElementById('vendors-search');
        if (searchInput) {
            searchInput.value = '';
        }
        
        // Display the suppliers directly
        populateVendorFilters(suppliers);
        displayVendorResults(suppliers);
        
        // Show info message
        showSuccess(`Mostrando ${suppliers.length} proveedor(es) que venden: ${itemName}`);
        
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

async function editItem(itemId) {
    const item = items.find(i => i.id === itemId);
    if (!item) {
        showError('Item no encontrado');
        return;
    }
    
    // Ensure LOV data is loaded
    if (!lovData.itemCategories || lovData.itemCategories.length === 0) {
        await loadLOV('itemCategories', '/api/lovs/item-categories');
    }
    if (!lovData.unitsOfMeasure || lovData.unitsOfMeasure.length === 0) {
        await loadLOV('unitsOfMeasure', '/api/lovs/units-of-measure');
    }
    
    // Generate category options from LOV
    const categoryOptions = lovData.itemCategories.map(cat => 
        `<option value="${cat.id}" ${item.category_id == cat.id ? 'selected' : ''}>${cat.name_es}</option>`
    ).join('');
    
    // Generate UOM options from LOV
    const uomOptions = lovData.unitsOfMeasure.map(unit => 
        `<option value="${unit.id}" ${item.unit_id == unit.id ? 'selected' : ''}>${unit.name_es} (${unit.symbol})</option>`
    ).join('');
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'edit-item-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>Editar Item</h2>
                <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="edit-item-form" onsubmit="saveItemEdit(event, ${itemId})">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Código (No editable)</label>
                            <input type="text" value="${item.item_code}" disabled class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Nombre <span class="required">*</span></label>
                            <input type="text" id="edit-item-name" value="${item.name}" required class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea id="edit-item-description" class="form-control" rows="3">${item.description || ''}</textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Categoría</label>
                            <select id="edit-item-category" class="form-control">
                                <option value="">Seleccione una categoría</option>
                                ${categoryOptions}
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Unidad de Medida</label>
                            <select id="edit-item-unit" class="form-control">
                                <option value="">Seleccione una unidad</option>
                                ${uomOptions}
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="this.closest('.modal').remove()" class="btn btn-secondary">Cancelar</button>
                        <button type="submit" class="btn btn-primary">💾 Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
}

async function saveItemEdit(event, itemId) {
    event.preventDefault();
    
    const updatedItem = {
        name: document.getElementById('edit-item-name').value.trim(),
        description: document.getElementById('edit-item-description').value.trim(),
        category_id: document.getElementById('edit-item-category').value || null,
        unit_id: document.getElementById('edit-item-unit').value || null
    };
    
    if (!updatedItem.name) {
        showError('El nombre del item es requerido');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items/${itemId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedItem)
        });
        
        if (!response.ok) {
            throw new Error('Failed to update item');
        }
        
        // Close modal first
        const modal = document.getElementById('edit-item-modal');
        if (modal) {
            modal.remove();
        }
        
        // Then show success and reload
        showSuccess('Item actualizado correctamente');
        await loadInventory();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al actualizar el item');
    }
}

async function openNewItemModal() {
    // Ensure LOV data is loaded
    if (!lovData.itemCategories || lovData.itemCategories.length === 0) {
        await loadLOV('itemCategories', '/api/lovs/item-categories');
    }
    if (!lovData.unitsOfMeasure || lovData.unitsOfMeasure.length === 0) {
        await loadLOV('unitsOfMeasure', '/api/lovs/units-of-measure');
    }
    
    // Generate category options from LOV
    const categoryOptions = lovData.itemCategories.map(cat => 
        `<option value="${cat.id}">${cat.name_es}</option>`
    ).join('');
    
    // Generate UOM options from LOV
    const uomOptions = lovData.unitsOfMeasure.map(unit => 
        `<option value="${unit.id}">${unit.name_es} (${unit.symbol})</option>`
    ).join('');
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'new-item-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>Nuevo Item</h2>
                <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="new-item-form" onsubmit="saveNewItem(event)">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Código <span class="required">*</span></label>
                            <input type="text" id="new-item-code" required class="form-control" placeholder="SKU-001">
                        </div>
                        <div class="form-group">
                            <label>Nombre <span class="required">*</span></label>
                            <input type="text" id="new-item-name" required class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea id="new-item-description" class="form-control" rows="3"></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Categoría</label>
                            <select id="new-item-category" class="form-control">
                                <option value="">Seleccione una categoría</option>
                                ${categoryOptions}
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Unidad de Medida</label>
                            <select id="new-item-unit" class="form-control">
                                <option value="">Seleccione una unidad</option>
                                ${uomOptions}
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="this.closest('.modal').remove()" class="btn btn-secondary">Cancelar</button>
                        <button type="submit" class="btn btn-primary">💾 Crear Item</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
}

async function saveNewItem(event) {
    event.preventDefault();
    
    const newItem = {
        item_code: document.getElementById('new-item-code').value.trim(),
        name: document.getElementById('new-item-name').value.trim(),
        description: document.getElementById('new-item-description').value.trim(),
        category_id: document.getElementById('new-item-category').value || null,
        unit_id: document.getElementById('new-item-unit').value || null
    };
    
    if (!newItem.item_code || !newItem.name) {
        showError('Código y nombre son requeridos');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newItem)
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to create item');
        }
        
        const createdItem = await response.json();
        
        // Close modal first
        const modalToClose = document.getElementById('new-item-modal');
        if (modalToClose) {
            modalToClose.remove();
        }
        
        showSuccess('Item creado correctamente');
        
        // Ask if user wants to add suppliers now
        showConfirmDialog(
            `Item "${createdItem.name}" creado exitosamente.\n\n¿Desea agregar proveedores y precios ahora?`,
            () => {
                currentPriceItem = createdItem;
                showSection('price-management');
            },
            () => {
                loadInventory();
            }
        );
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message || 'Error al crear el item');
    }
}

async function openAddSuppliersModal(item) {
    try {
        // Load all suppliers
        const response = await fetch(`${API_BASE}/suppliers`);
        const allSuppliers = await response.json();
        
        if (allSuppliers.length === 0) {
            showError('No hay proveedores registrados. Agregue proveedores primero.');
            await loadInventory();
            return;
        }
        
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content modal-large">
                <div class="modal-header">
                    <h2>Agregar Proveedores - ${item.name}</h2>
                    <span class="close" onclick="closeAddSuppliersModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <p><strong>Item:</strong> ${item.item_code} - ${item.name}</p>
                    <hr>
                    
                    <div id="suppliers-list">
                        <h3>Seleccione proveedores y establezca precios:</h3>
                        <div class="suppliers-selector">
                            ${allSuppliers.map(supplier => `
                                <div class="supplier-row" data-supplier-id="${supplier.id}">
                                    <div class="supplier-select">
                                        <label>
                                            <input type="checkbox" class="supplier-checkbox" value="${supplier.id}">
                                            <strong>${supplier.name}</strong>
                                            <br>
                                            <small>${supplier.email || ''} ${supplier.city ? '- ' + supplier.city : ''}</small>
                                        </label>
                                    </div>
                                    <div class="supplier-price-fields" style="display: none;">
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label>Precio <span class="required">*</span></label>
                                                <input type="number" step="0.01" class="form-control price-input" placeholder="0.00" disabled>
                                            </div>
                                            <div class="form-group">
                                                <label>Código del Proveedor</label>
                                                <input type="text" class="form-control supplier-code-input" placeholder="Código interno" disabled>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label>Tiempo de Entrega (días)</label>
                                                <input type="number" class="form-control lead-time-input" placeholder="0" disabled>
                                            </div>
                                            <div class="form-group">
                                                <label>Cantidad Mínima</label>
                                                <input type="number" class="form-control min-qty-input" placeholder="1" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Notas</label>
                                            <textarea class="form-control notes-input" rows="2" disabled></textarea>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="closeAddSuppliersModal()" class="btn btn-secondary">
                            Omitir
                        </button>
                        <button type="button" onclick="saveSuppliersToItem(${item.id})" class="btn btn-primary">
                            💾 Guardar Proveedores
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        
        // Add event listeners to checkboxes
        document.querySelectorAll('.supplier-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const row = this.closest('.supplier-row');
                const fieldsDiv = row.querySelector('.supplier-price-fields');
                const inputs = row.querySelectorAll('input, textarea');
                
                if (this.checked) {
                    fieldsDiv.style.display = 'block';
                    inputs.forEach(input => {
                        if (!input.classList.contains('supplier-checkbox')) {
                            input.disabled = false;
                        }
                    });
                } else {
                    fieldsDiv.style.display = 'none';
                    inputs.forEach(input => {
                        if (!input.classList.contains('supplier-checkbox')) {
                            input.disabled = true;
                        }
                    });
                }
            });
        });
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar proveedores');
        await loadInventory();
    }
}

async function saveSuppliersToItem(itemId) {
    const selectedSuppliers = [];
    
    document.querySelectorAll('.supplier-checkbox:checked').forEach(checkbox => {
        const row = checkbox.closest('.supplier-row');
        const supplierId = parseInt(checkbox.value);
        const price = parseFloat(row.querySelector('.price-input').value);
        
        if (!price || price <= 0) {
            showError(`Debe ingresar un precio válido para todos los proveedores seleccionados`);
            return;
        }
        
        selectedSuppliers.push({
            supplier_id: supplierId,
            price: price,
            supplier_item_code: row.querySelector('.supplier-code-input').value.trim(),
            lead_time_days: parseInt(row.querySelector('.lead-time-input').value) || null,
            minimum_order_quantity: parseInt(row.querySelector('.min-qty-input').value) || null,
            notes: row.querySelector('.notes-input').value.trim()
        });
    });
    
    if (selectedSuppliers.length === 0) {
        showConfirmDialog(
            'No ha seleccionado ningún proveedor.\n\n¿Desea crear el item sin proveedores?',
            () => {
                closeAddSuppliersModal();
                loadInventory();
            }
        );
        return;
    }
    
    try {
        // Add each supplier to the item
        const promises = selectedSuppliers.map(supplierData =>
            fetch(`${API_BASE}/items/${itemId}/suppliers`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(supplierData)
            })
        );
        
        await Promise.all(promises);
        
        showSuccess(`Item configurado exitosamente con ${selectedSuppliers.length} proveedor(es)`);
        closeAddSuppliersModal();
        await loadInventory();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al guardar proveedores');
    }
}

function closeAddSuppliersModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.remove();
    }
}

function exportOrders() {
    window.location.href = `${API_BASE}/orders/export`;
}

// ===== SUPPLIERS/VENDORS =====
async function loadSuppliers() {
    console.log('loadSuppliers() called');
    try {
        showLoading('Cargando proveedores...');
        const search = document.getElementById('suppliers-search')?.value || '';
        const category = document.getElementById('category-filter')?.value || '';
        const country = document.getElementById('country-filter')?.value || '';
        
        let url = `${API_BASE}/suppliers?`;
        if (search) url += `search=${encodeURIComponent(search)}&`;
        if (category) url += `category_id=${encodeURIComponent(category)}&`;
        if (country) url += `country_id=${encodeURIComponent(country)}`;
        
        const response = await fetch(url);
        
        if (!response.ok) {
            if (response.status === 401) {
                console.error('Authentication required for suppliers');
                window.location.href = '/login';
                return;
            } else if (response.status === 403) {
                console.error('Access denied for suppliers');
                alert('No tienes permisos para ver proveedores');
                return;
            } else {
                console.error('Error loading suppliers:', response.status, response.statusText);
                return;
            }
        }
        
        suppliers = await response.json();
        console.log('Loaded', suppliers.length, 'suppliers');
        console.log('First supplier sample:', suppliers[0]);
        console.log('Supplier properties:', Object.keys(suppliers[0] || {}));
        
        // Load contacts for each supplier
        for (let supplier of suppliers) {
            const contactsResponse = await fetch(`${API_BASE}/suppliers/${supplier.id}/contacts`);
            if (contactsResponse.ok) {
                supplier.contacts = await contactsResponse.json();
                // Get primary contact for display
                supplier.primaryContact = supplier.contacts.find(c => c.is_primary) || supplier.contacts[0] || null;
            }
        }
        
        displaySuppliers();
    } catch (error) {
        console.error('Error loading suppliers:', error);
    } finally {
        hideLoading();
    }
}

function displaySuppliers() {
    console.log('displaySuppliers() called with', suppliers.length, 'suppliers');
    const tbody = document.getElementById('suppliers-tbody');
    console.log('suppliers-tbody element:', tbody);
    if (!tbody) {
        console.error('suppliers-tbody element not found!');
        return;
    }
    
    // Check if user has edit permissions (not compras role)
    const canEdit = currentUser && (currentUser.rol === 'sysadmin' || currentUser.rol === 'admin');
    
    console.log('About to set suppliers tbody.innerHTML with', suppliers.length, 'rows');
    try {
        tbody.innerHTML = suppliers.map(s => `
            <tr>
                <td>${s.name}</td>
                <td>${s.primaryContact ? s.primaryContact.contact_name : ''}</td>
                <td>${s.primaryContact ? s.primaryContact.email || '' : ''}</td>
                <td>${s.primaryContact ? s.primaryContact.phone || '' : ''}</td>
                <td>${s.city || ''}</td>
                <td>${s.category || ''}</td>
                <td>${s.rating ? '⭐ ' + s.rating : ''}</td>
                <td style="white-space: nowrap;">
                    ${canEdit ? `<button onclick="editSupplier(${s.id})" class="btn btn-warning btn-sm" title="Editar Proveedor">✏️</button>` : ''}
                    <button onclick="createOrderForVendor(${s.id}, '${escapeHtml(s.name)}')" class="btn btn-primary btn-sm" title="Crear Orden">📝</button>
                </td>
            </tr>
        `).join('');
        console.log('tbody.innerHTML length after setting suppliers:', tbody.innerHTML.length);
        console.log('tbody.children.length for suppliers:', tbody.children.length);
        
        console.log('Successfully set suppliers tbody.innerHTML');
    } catch (error) {
        console.error('Error setting suppliers tbody.innerHTML:', error);
    }
}

async function loadCategories() {
    console.log('loadCategories() called');
    try {
        const response = await fetch(`${API_BASE}/suppliers/categories`);
        
        if (!response.ok) {
            console.error('Error loading categories:', response.status, response.statusText);
            return;
        }
        
        const categories = await response.json();
        console.log('Loaded', categories.length, 'categories');
        const select = document.getElementById('category-filter');
        if (select) {
            select.innerHTML = '<option value="">Todas las Categorías</option>' +
                categories.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function loadCountries() {
    console.log('loadCountries() called');
    try {
        const response = await fetch(`${API_BASE}/suppliers/countries`);
        
        if (!response.ok) {
            console.error('Error loading countries:', response.status, response.statusText);
            return;
        }
        
        const countries = await response.json();
        console.log('Loaded', countries.length, 'countries');
        const select = document.getElementById('country-filter');
        if (select) {
            select.innerHTML = '<option value="">Todos los Países</option>' +
                countries.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
        }
    } catch (error) {
        console.error('Error loading countries:', error);
    }
}

// ===== ORDERS =====
async function loadOrders() {
    console.log('loadOrders() called');
    
    // Populate status filter from LOV - ensure LOVs are loaded
    const populateStatusFilter = async () => {
        if (!lovData.orderStatuses || lovData.orderStatuses.length === 0) {
            console.log('LOV data not loaded, loading now...');
            await loadLOV('orderStatuses', '/api/lovs/order-statuses');
        }
        
        const statusFilter = document.getElementById('order-status-filter');
        if (statusFilter) {
            const currentStatus = statusFilter.value;
            statusFilter.innerHTML = '<option value="">Todos los Estados</option>';
            lovData.orderStatuses.forEach(status => {
                const option = document.createElement('option');
                option.value = status.id;
                option.textContent = status.name_es;
                if (status.id == currentStatus) option.selected = true;
                statusFilter.appendChild(option);
            });
        }
    };
    
    await populateStatusFilter();
    
    try {
        const status = document.getElementById('order-status-filter')?.value || '';
        let url = `${API_BASE}/orders`;
        if (status) url += `?status_id=${status}`;
        
        const response = await fetch(url);
        
        if (!response.ok) {
            if (response.status === 401) {
                console.error('Authentication required for orders');
                window.location.href = '/login';
                return;
            } else if (response.status === 403) {
                console.error('Access denied for orders');
                alert('No tienes permisos para ver órdenes');
                return;
            } else {
                console.error('Error loading orders:', response.status, response.statusText);
                return;
            }
        }
        
        orders = await response.json();
        console.log('Loaded', orders.length, 'orders');
        console.log('First order sample:', orders[0]);
        console.log('Order properties:', Object.keys(orders[0] || {}));
        displayOrders();
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

function displayOrders() {
    console.log('displayOrders() called with', orders.length, 'orders');
    const tbody = document.getElementById('orders-tbody');
    console.log('orders-tbody element:', tbody);
    if (!tbody) {
        console.error('orders-tbody element not found!');
        return;
    }
    
    console.log('About to set orders tbody.innerHTML with', orders.length, 'rows');
    try {
        tbody.innerHTML = orders.map(o => `
            <tr>
                <td>${o.order_number}</td>
                <td>${o.supplier_name}</td>
                <td>${new Date(o.order_date).toLocaleDateString()}</td>
                <td>${o.delivery_date ? new Date(o.delivery_date).toLocaleDateString() : ''}</td>
                <td>$${o.total_amount?.toFixed(2) || '0.00'}</td>
                <td><span class="status-badge status-${o.status_code || o.status}">${o.status || 'N/A'}</span></td>
                <td style="white-space: nowrap;">
                    <button onclick="viewOrder(${o.id})" class="btn btn-secondary btn-sm" title="Ver Orden">👁️</button>
                    <button onclick="printOrder(${o.id}, 'internal')" class="btn btn-warning btn-sm" title="Imprimir (Interna)">🖨️</button>
                    <button onclick="printOrder(${o.id}, 'vendor')" class="btn btn-warning btn-sm" title="Imprimir (Proveedor)">🧾</button>
                </td>
            </tr>
        `).join('');
        console.log('tbody.innerHTML length after setting orders:', tbody.innerHTML.length);
        console.log('tbody.children.length for orders:', tbody.children.length);
        
        console.log('Successfully set orders tbody.innerHTML');
    } catch (error) {
        console.error('Error setting orders tbody.innerHTML:', error);
    }
}

function parseItemsToTable(itemsText) {
    if (!itemsText || !itemsText.trim()) {
        return '<tr><td colspan="4">No hay items especificados</td></tr>';
    }
    
    const lines = itemsText.trim().split('\n');
    let html = '';
    
    for (const line of lines) {
        if (!line.trim()) continue;
        
        // Try to parse different formats
        if (line.includes('|')) {
            // Pipe-separated format: ID|Name|Qty|Price
            const parts = line.split('|').map(p => p.trim());
            if (parts.length >= 3) {
                const id = parts[0];
                const name = parts[1];
                const qty = parts[2];
                const price = parts[3] || '';
                html += `<tr><td>${escapeHtml(id)}</td><td>${escapeHtml(name)}</td><td>${escapeHtml(qty)}</td><td>${escapeHtml(price)}</td></tr>`;
            }
        } else {
            // Try "qty x name @ price" format
            const match = line.match(/(\d+)\s*x\s*(.+?)(?:\s*@\s*(.+))?$/i);
            if (match) {
                const qty = match[1];
                const name = match[2].trim();
                const price = match[3] ? match[3].trim() : '';
                html += `<tr><td>-</td><td>${escapeHtml(name)}</td><td>${escapeHtml(qty)}</td><td>${escapeHtml(price)}</td></tr>`;
            } else {
                // Fallback: display as-is
                html += `<tr><td colspan="4">${escapeHtml(line.trim())}</td></tr>`;
            }
        }
    }
    
    return html;
}

async function viewOrder(orderId) {
    try {
        // Fetch order details
        const response = await fetch(`${API_BASE}/orders/${orderId}`);
        if (!response.ok) {
            throw new Error('Failed to load order');
        }
        
        const order = await response.json();
        
        // Ensure order statuses LOV is loaded
        if (!lovData.orderStatuses || lovData.orderStatuses.length === 0) {
            await loadLOV('orderStatuses', '/api/lovs/order-statuses');
        }
        
        // Generate status options from LOV
        const statusOptions = lovData.orderStatuses.map(status => 
            `<option value="${status.code}" ${order.status_code === status.code ? 'selected' : ''}>${status.name_es}</option>`
        ).join('');
        
        // Fetch config for letterhead
        const configResponse = await fetch(`${API_BASE}/config`);
        const config = configResponse.ok ? await configResponse.json() : {};
        
        // Build letterhead HTML
        let letterheadHtml = '';
        if (config.logoPath) {
            letterheadHtml += `<img src="${API_BASE}/logo" class="letterhead-logo" alt="Logo" style="max-height: 80px; margin-bottom: 10px;">`;
        }
        letterheadHtml += `<div class="letterhead-text"><h1>${config.companyName || 'Mi Empresa'}</h1></div>`;
        
        // Get supplier details and contacts
        const supplierResponse = await fetch(`${API_BASE}/suppliers`);
        const suppliers = await supplierResponse.json();
        const supplier = suppliers.find(s => s.name === order.supplier_name);
        
        let contactsInfo = '';
        if (supplier) {
            const contactsResponse = await fetch(`${API_BASE}/suppliers/${supplier.id}/contacts`);
            const contacts = await contactsResponse.json();
            
            if (contacts.length > 0) {
                const primaryContact = contacts.find(c => c.is_primary) || contacts[0];
                contactsInfo = `
                    <div style="background: #f0f8ff; padding: 12px; border-radius: 4px; margin-top: 10px;">
                        <strong style="font-size: 13px; color: #666;">Contacto Principal:</strong><br>
                        <span style="font-size: 14px;">${primaryContact.is_primary ? '⭐ ' : ''}${escapeHtml(primaryContact.contact_name || 'Sin nombre')}</span>
                        ${primaryContact.position ? '<br><span style="font-size: 13px; color: #666;">' + escapeHtml(primaryContact.position) + '</span>' : ''}
                        ${primaryContact.phone ? '<br><span style="font-size: 13px;">📱 ' + escapeHtml(primaryContact.phone) + '</span>' : ''}
                        ${primaryContact.email ? '<br><span style="font-size: 13px;">📧 ' + escapeHtml(primaryContact.email) + '</span>' : ''}
                    </div>
                `;
            }
        }
        
        // Fetch parsed items with SKU information
        const itemsResponse = await fetch(`${API_BASE}/orders/${orderId}/items-parsed`);
        let itemsTableRows = '';
        
        if (itemsResponse.ok) {
            const itemsData = await itemsResponse.json();
            if (itemsData.success && itemsData.items) {
                itemsTableRows = itemsData.items.map(item => `
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${escapeHtml(item.internal_sku)}</td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${escapeHtml(item.vendor_sku)}</td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${escapeHtml(item.name)}</td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${escapeHtml(item.qty)}</td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${escapeHtml(item.price)}</td>
                    </tr>
                `).join('');
            }
        }
        
        if (!itemsTableRows) {
            itemsTableRows = '<tr><td colspan="5" style="padding: 8px;">No hay items especificados</td></tr>';
        }
        
        // Create view order modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'view-order-modal';
        modal.innerHTML = `
            <div class="modal-content modal-large">
                <div class="modal-header">
                    <h2>Orden ${order.order_number}</h2>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <!-- Company Letterhead -->
                    <div class="letterhead" style="border-bottom: 2px solid #667eea; padding-bottom: 20px; margin-bottom: 20px; text-align: center;">
                        ${letterheadHtml}
                    </div>
                    
                    <div class="order-details-header" style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                            <div style="grid-column: 1 / -1;">
                                <strong>Proveedor:</strong><br>
                                <span style="font-size: 18px;">${order.supplier_name}</span>
                                ${contactsInfo}
                            </div>
                            <div>
                                <strong>Número de Orden:</strong><br>
                                <span style="font-size: 18px;">${order.order_number}</span>
                            </div>
                            <div>
                                <strong>Fecha de Orden:</strong><br>
                                ${new Date(order.order_date).toLocaleDateString()}
                            </div>
                            <div>
                                <strong>Fecha de Entrega:</strong><br>
                                ${order.delivery_date ? new Date(order.delivery_date).toLocaleDateString() : 'No especificada'}
                            </div>
                            <div>
                                <strong>Monto Total:</strong><br>
                                <span style="font-size: 20px; color: #667eea;">$${order.total_amount?.toFixed(2) || '0.00'}</span>
                            </div>
                            <div>
                                <strong>Estado:</strong><br>
                                <select id="order-status-select" class="form-control" style="max-width: 200px;">
                                    ${statusOptions}
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><strong>Items:</strong></label>
                        <div style="overflow-x: auto; border: 1px solid #ddd; border-radius: 4px;">
                            <table style="width: 100%; border-collapse: collapse;">
                                <thead>
                                    <tr style="background: #667eea; color: white;">
                                        <th style="padding: 10px; text-align: left; font-size: 13px;">SKU Interno</th>
                                        <th style="padding: 10px; text-align: left; font-size: 13px;">SKU Proveedor</th>
                                        <th style="padding: 10px; text-align: left; font-size: 13px;">Nombre</th>
                                        <th style="padding: 10px; text-align: left; font-size: 13px;">Cantidad</th>
                                        <th style="padding: 10px; text-align: left; font-size: 13px;">Precio</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${itemsTableRows}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    ${order.notes ? `
                        <div class="form-group">
                            <label><strong>Notas:</strong></label>
                            <textarea class="form-control" rows="3" readonly style="background: white;">${order.notes}</textarea>
                        </div>
                    ` : ''}
                    
                    <div class="form-actions">
                        <button onclick="updateOrderStatus(${order.id})" class="btn btn-success">
                            💾 Actualizar Estado
                        </button>
                        <button onclick="printOrderFromModal(${order.id}, 'internal')" class="btn btn-warning">
                            🖨️ Imprimir Interna
                        </button>
                        <button onclick="printOrder(${order.id}, 'vendor')" class="btn btn-primary">
                            🧾 Imprimir para Proveedor
                        </button>
                        <button onclick="this.closest('.modal').remove()" class="btn btn-secondary">
                            Cerrar
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar la orden');
    }
}

async function updateOrderStatus(orderId) {
    const newStatus = document.getElementById('order-status-select').value;
    
    try {
        const response = await fetch(`${API_BASE}/orders/${orderId}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: newStatus })
        });
        
        if (!response.ok) {
            throw new Error('Failed to update status');
        }
        
        showSuccess('Estado actualizado correctamente');
        
        // Reload orders list
        await loadOrders();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al actualizar el estado');
    }
}

function printOrderFromModal(orderId, mode) {
    printOrder(orderId, mode);
}

async function shareOrderWithVendor(orderId, supplierName, orderNumber) {
    try {
        // Get supplier details and contacts
        const suppliersResponse = await fetch(`${API_BASE}/suppliers`);
        const suppliers = await suppliersResponse.json();
        const supplier = suppliers.find(s => s.name === supplierName);
        
        if (!supplier) {
            showError('Proveedor no encontrado');
            return;
        }
        
        // Get supplier contacts
        const contactsResponse = await fetch(`${API_BASE}/suppliers/${supplier.id}/contacts`);
        const contacts = await contactsResponse.json();
        
        if (contacts.length === 0) {
            showError('Este proveedor no tiene contactos registrados');
            return;
        }
        
        // Get primary contact or first contact
        const primaryContact = contacts.find(c => c.is_primary) || contacts[0];
        
        const orderUrl = `${window.location.origin}/api/orders/${orderId}/print?mode=vendor&lang=esp`;
        
        // Create share modal with user instructions
        const shareModal = document.createElement('div');
        shareModal.className = 'modal';
        shareModal.id = 'share-order-modal';
        shareModal.innerHTML = `
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h2>Compartir Orden ${orderNumber}</h2>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <p style="margin-bottom: 15px; color: #666;">Compartir con <strong>${escapeHtml(supplierName)}</strong>:</p>
                    <div style="background: #e9f5e9; border-left: 4px solid #25D366; padding: 12px 16px; margin-bottom: 18px; border-radius: 4px; color: #222; font-size: 15px;">
                        <b>Instrucciones:</b><br>
                        1. Haga clic en <b>Imprimir</b> y seleccione "Guardar como PDF".<br>
                        2. Adjunte el archivo PDF al correo electrónico o mensaje de WhatsApp.<br>
                        <span style="color:#888; font-size:13px;">No envíe enlaces ni instrucciones técnicas al proveedor.</span>
                    </div>
                    ${contacts.length > 1 ? `
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label for="contact-selector">Seleccionar Contacto:</label>
                            <select id="contact-selector" class="form-control" onchange="updateShareButtons()">
                                ${contacts.map(c => `
                                    <option value="${c.id}" ${c.is_primary ? 'selected' : ''}>
                                        ${c.is_primary ? '⭐ ' : ''}${escapeHtml(c.contact_name || 'Sin nombre')} 
                                        ${c.position ? '(' + escapeHtml(c.position) + ')' : ''}
                                        ${c.phone ? '- ' + escapeHtml(c.phone) : ''} 
                                        ${c.email ? '- ' + escapeHtml(c.email) : ''}
                                    </option>
                                `).join('')}
                            </select>
                        </div>
                    ` : ''}
                    <div id="share-contact-info" style="padding: 12px; background: #f5f5f5; border-radius: 4px; margin-bottom: 15px;">
                        <div style="font-size: 14px;">
                            <strong>${primaryContact.is_primary ? '⭐ ' : ''}${escapeHtml(primaryContact.contact_name || 'Contacto')}</strong>
                            ${primaryContact.position ? '<br><span style="color: #666;">' + escapeHtml(primaryContact.position) + '</span>' : ''}
                            ${primaryContact.phone ? `<br>📱 ${escapeHtml(primaryContact.phone)} <a href='https://wa.me/${primaryContact.phone.replace(/\D/g, '')}' target='_blank' title='Abrir en WhatsApp' style='margin-left:6px;font-size:18px;text-decoration:none;'>🟢</a>` : ''}
                            ${primaryContact.email ? `<br>📧 ${escapeHtml(primaryContact.email)} <a href='mailto:${escapeHtml(primaryContact.email)}' title='Abrir en Email' style='margin-left:6px;font-size:18px;text-decoration:none;'>✉️</a>` : ''}
                        </div>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 12px;">
                        <button id="share-email-btn" class="btn btn-primary" style="width: 100%; padding: 12px; font-size: 15px;" ${!primaryContact.email ? 'disabled' : ''}>
                            📧 Enviar por Email
                            ${primaryContact.email ? '<br><small style="font-size: 12px; opacity: 0.8;">' + escapeHtml(primaryContact.email) + '</small>' : '<br><small style="font-size: 12px;">Sin email</small>'}
                        </button>
                        <button id="share-whatsapp-btn" class="btn btn-success" style="width: 100%; padding: 12px; font-size: 15px; background: #25D366;" ${!primaryContact.phone ? 'disabled' : ''}>
                            📱 Enviar por WhatsApp
                            ${primaryContact.phone ? '<br><small style="font-size: 12px; opacity: 0.8;">' + escapeHtml(primaryContact.phone) + '</small>' : '<br><small style="font-size: 12px;">Sin teléfono</small>'}
                        </button>
                        <button onclick="copyOrderLink('${orderUrl}')" class="btn btn-warning" style="width: 100%; padding: 12px; font-size: 15px;">
                            🔗 Copiar Enlace
                        </button>
                        <button onclick="printOrder(${orderId}, 'vendor')" class="btn btn-secondary" style="width: 100%; padding: 12px; font-size: 15px;">
                            🖨️ Imprimir
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(shareModal);
        shareModal.style.display = 'flex';
        
        // Store data for updateShareButtons function
        window.shareOrderData = { contacts, orderNumber, orderUrl };
        
        // Add event listeners
        document.getElementById('share-email-btn').addEventListener('click', () => {
            const selectedContactId = document.getElementById('contact-selector')?.value || primaryContact.id;
            const selectedContact = contacts.find(c => c.id == selectedContactId);
            if (selectedContact?.email) {
                shareViaEmail(selectedContact.email, orderNumber, orderUrl);
            }
        });
        
        document.getElementById('share-whatsapp-btn').addEventListener('click', () => {
            const selectedContactId = document.getElementById('contact-selector')?.value || primaryContact.id;
            const selectedContact = contacts.find(c => c.id == selectedContactId);
            if (selectedContact?.phone) {
                shareViaWhatsApp(selectedContact.phone, orderNumber, orderUrl);
            }
        });
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al preparar opciones de compartir');
    }
}

function updateShareButtons() {
    const selectedContactId = document.getElementById('contact-selector')?.value;
    const { contacts, orderNumber, orderUrl } = window.shareOrderData;
    const selectedContact = contacts.find(c => c.id == selectedContactId);
    
    if (!selectedContact) return;
    
    // Update contact info display
    const infoDiv = document.getElementById('share-contact-info');
    infoDiv.innerHTML = `
        <div style="font-size: 14px;">
            <strong>${selectedContact.is_primary ? '⭐ ' : ''}${escapeHtml(selectedContact.contact_name || 'Contacto')}</strong>
            ${selectedContact.position ? '<br><span style="color: #666;">' + escapeHtml(selectedContact.position) + '</span>' : ''}
            ${selectedContact.phone ? `<br>📱 ${escapeHtml(selectedContact.phone)} <a href='https://wa.me/${selectedContact.phone.replace(/\D/g, '')}' target='_blank' title='Abrir en WhatsApp' style='margin-left:6px;font-size:18px;text-decoration:none;'>🟢</a>` : ''}
            ${selectedContact.email ? `<br>📧 ${escapeHtml(selectedContact.email)} <a href='mailto:${escapeHtml(selectedContact.email)}' title='Abrir en Email' style='margin-left:6px;font-size:18px;text-decoration:none;'>✉️</a>` : ''}
        </div>
    `;
    
    // Update email button
    const emailBtn = document.getElementById('share-email-btn');
    emailBtn.disabled = !selectedContact.email;
    emailBtn.innerHTML = `📧 Enviar por Email${selectedContact.email ? '<br><small style="font-size: 12px; opacity: 0.8;">' + escapeHtml(selectedContact.email) + '</small>' : '<br><small style="font-size: 12px;">Sin email</small>'}`;
    
    // Update WhatsApp button
    const whatsappBtn = document.getElementById('share-whatsapp-btn');
    whatsappBtn.disabled = !selectedContact.phone;
    whatsappBtn.innerHTML = `📱 Enviar por WhatsApp${selectedContact.phone ? '<br><small style="font-size: 12px; opacity: 0.8;">' + escapeHtml(selectedContact.phone) + '</small>' : '<br><small style="font-size: 12px;">Sin teléfono</small>'}`;
}

function shareViaEmail(email, orderNumber, orderUrl) {
    const subject = encodeURIComponent(`Orden de Compra ${orderNumber}`);
    const body = encodeURIComponent(`Estimado proveedor,\n\nAdjuntamos la orden de compra ${orderNumber}.\n\nSaludos cordiales`);
    window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
    // Show helpful tip
    setTimeout(() => {
        alert('💡 Consejo: Imprima la orden como PDF y adjunte el archivo al correo.');
    }, 1500);
}

function shareViaWhatsApp(phone, orderNumber, orderUrl) {
    // Clean phone number (remove spaces, dashes, etc.)
    const cleanPhone = phone.replace(/\D/g, '');
    const message = encodeURIComponent(`Hola! Le enviamos la orden de compra ${orderNumber}.`);
    // Open WhatsApp Web or app
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
    // Show helpful tip
    setTimeout(() => {
        alert('💡 Consejo: Imprima la orden como PDF y adjunte el archivo en WhatsApp.');
    }, 1500);
}

function copyOrderLink(url) {
    navigator.clipboard.writeText(url).then(() => {
        showSuccess('✓ Enlace copiado al portapapeles');
    }).catch(err => {
        console.error('Error copying link:', err);
        // Fallback method
        const textarea = document.createElement('textarea');
        textarea.value = url;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showSuccess('✓ Enlace copiado al portapapeles');
    });
}

async function printOrder(orderId, mode = 'internal', lang = 'esp') {
    try {
        // Create modal for print preview
        const url = `${API_BASE}/orders/${orderId}/print?mode=${mode}&lang=${lang}`;
        let modal = document.getElementById('print-modal');
        if (modal) modal.remove();
        modal = document.createElement('div');
        modal.id = 'print-modal';
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content modal-large" style="width: 900px; max-width: 100vw; height: 90vh; display: flex; flex-direction: column;">
                <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center;">
                    <h2>Vista previa de impresión</h2>
                    <span class="close" onclick="document.getElementById('print-modal').remove()">&times;</span>
                </div>
                <div class="modal-body" style="flex: 1; overflow: auto;">
                    <iframe id="print-iframe" src="${url}" style="width: 100%; height: 100%; border: none; background: #fff;"></iframe>
                </div>
                <div class="modal-footer" style="display: flex; justify-content: flex-end; gap: 10px; padding: 10px 0;">
                    <button class="btn btn-primary" onclick="printIframe()">Imprimir</button>
                    <button class="btn btn-secondary" onclick="document.getElementById('print-modal').remove()">Cerrar</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        // Optionally auto-print after load
        const iframe = modal.querySelector('#print-iframe');
        iframe.addEventListener('load', () => {
            // Uncomment to auto-print:
            // setTimeout(() => printIframe(), 500);
        });
    } catch (error) {
        console.error('Error printing order:', error);
        showError('Error al imprimir la orden');
    }
}

function printIframe() {
    const iframe = document.getElementById('print-iframe');
    if (iframe && iframe.contentWindow) {
        // Wait for iframe to load if not ready
        if (iframe.contentDocument.readyState === 'complete') {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
        } else {
            iframe.onload = function() {
                iframe.contentWindow.focus();
                iframe.contentWindow.print();
            };
        }
    } else {
        showError('No se pudo imprimir la vista previa');
    }
}

function exportOrders() {
    window.location.href = `${API_BASE}/orders/export`;
}

// ===== MODALS =====
async function showAddSupplierModal() {
    // Ensure LOV data is loaded
    if (!lovData.supplierCategories || lovData.supplierCategories.length === 0) {
        await loadLOV('supplierCategories', '/api/lovs/supplier-categories');
    }
    if (!lovData.countries || lovData.countries.length === 0) {
        await loadLOV('countries', '/api/lovs/countries');
    }
    if (!lovData.paymentTerms || lovData.paymentTerms.length === 0) {
        await loadLOV('paymentTerms', '/api/lovs/payment-terms');
    }
    
    document.getElementById('supplier-modal-title').textContent = 'Nuevo Proveedor';
    document.getElementById('supplier-form').reset();
    document.getElementById('supplier-id').value = '';
    document.getElementById('contacts-section').style.display = 'none';
    document.getElementById('contacts-list').innerHTML = '';
    
    // Populate LOV dropdowns
    populateSupplierLOVDropdowns();
    
    document.getElementById('supplier-modal').classList.add('active');
}

function closeSupplierModal() {
    document.getElementById('supplier-modal').classList.remove('active');
}

// Populate supplier LOV dropdowns
function populateSupplierLOVDropdowns() {
    // Supplier categories
    const categorySelect = document.getElementById('supplier-category');
    categorySelect.innerHTML = '<option value="">Seleccionar Categoría</option>';
    if (lovData.supplierCategories) {
        lovData.supplierCategories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.id;
            option.textContent = cat.name_es;
            categorySelect.appendChild(option);
        });
    }
    
    // Countries
    const countrySelect = document.getElementById('supplier-country');
    countrySelect.innerHTML = '<option value="">Seleccionar País</option>';
    if (lovData.countries) {
        lovData.countries.forEach(country => {
            const option = document.createElement('option');
            option.value = country.id;
            option.textContent = country.name_es;
            countrySelect.appendChild(option);
        });
    }
    
    // Payment terms
    const paymentTermsSelect = document.getElementById('supplier-payment-terms');
    paymentTermsSelect.innerHTML = '<option value="">Seleccionar Condiciones</option>';
    if (lovData.paymentTerms) {
        lovData.paymentTerms.forEach(term => {
            const option = document.createElement('option');
            option.value = term.id;
            option.textContent = term.name_es;
            paymentTermsSelect.appendChild(option);
        });
    }
    
    // Clear states
    document.getElementById('supplier-state').innerHTML = '<option value="">Seleccionar Estado</option>';
}

// Load states for selected country
async function loadStatesForCountry() {
    const countryId = document.getElementById('supplier-country').value;
    const stateSelect = document.getElementById('supplier-state');
    
    if (!countryId) {
        stateSelect.innerHTML = '<option value="">Seleccionar Estado</option>';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/lovs/states/${countryId}`);
        if (response.ok) {
            const states = await response.json();
            stateSelect.innerHTML = '<option value="">Seleccionar Estado</option>';
            states.forEach(state => {
                const option = document.createElement('option');
                option.value = state.id;
                option.textContent = state.name_es;
                stateSelect.appendChild(option);
            });
        } else {
            stateSelect.innerHTML = '<option value="">Seleccionar Estado</option>';
        }
    } catch (error) {
        console.error('Error loading states:', error);
        stateSelect.innerHTML = '<option value="">Seleccionar Estado</option>';
    }
}

async function editSupplier(id) {
    const supplier = suppliers.find(s => s.id === id);
    if (!supplier) return;
    
    // Ensure LOV data is loaded
    if (!lovData.supplierCategories || lovData.supplierCategories.length === 0) {
        await loadLOV('supplierCategories', '/api/lovs/supplier-categories');
    }
    if (!lovData.countries || lovData.countries.length === 0) {
        await loadLOV('countries', '/api/lovs/countries');
    }
    if (!lovData.paymentTerms || lovData.paymentTerms.length === 0) {
        await loadLOV('paymentTerms', '/api/lovs/payment-terms');
    }
    if (!lovData.contactTypes || lovData.contactTypes.length === 0) {
        await loadLOV('contactTypes', '/api/lovs/contact-types');
    }
    
    document.getElementById('supplier-modal-title').textContent = 'Editar Proveedor';
    document.getElementById('supplier-id').value = supplier.id;
    document.getElementById('supplier-name').value = supplier.name || '';
    document.getElementById('supplier-address').value = supplier.address || '';
    document.getElementById('supplier-city').value = supplier.city || '';
    document.getElementById('supplier-notes').value = supplier.notes || '';
    
    // Populate LOV dropdowns first
    populateSupplierLOVDropdowns();
    
    // Set selected values
    document.getElementById('supplier-category').value = supplier.category_id || '';
    document.getElementById('supplier-country').value = supplier.country_id || '';
    document.getElementById('supplier-payment-terms').value = supplier.payment_term_id || '';
    
    // Load states for the selected country and then set the state value
    if (supplier.country_id) {
        loadStatesForCountry().then(() => {
            const stateSelect = document.getElementById('supplier-state');
            if (stateSelect) {
                stateSelect.value = supplier.state_id || '';
            }
        });
    } else {
        document.getElementById('supplier-state').innerHTML = '<option value="">Seleccionar Estado</option>';
    }
    
    // Show and load contacts
    document.getElementById('contacts-section').style.display = 'block';
    loadSupplierContacts(id);
    
    document.getElementById('supplier-modal').classList.add('active');
}

async function loadSupplierContacts(supplierId) {
    try {
        showLoading('Cargando contactos...');
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/contacts`);
        const contacts = await response.json();
        displayContacts(contacts);
    } catch (error) {
        console.error('Error loading contacts:', error);
    } finally {
        hideLoading();
    }
}

function displayContacts(contacts) {
    const contactsList = document.getElementById('contacts-list');
    contactsList.innerHTML = contacts.map(contact => {
        // Generate contact type options with correct selection
        const contactTypeOptions = lovData.contactTypes ? lovData.contactTypes.map(ct => 
            `<option value="${ct.id}" ${contact.contact_type_id == ct.id ? 'selected' : ''}>${ct.name_es}</option>`
        ).join('') : '<option value="">Cargando...</option>';
        
        return `
        <div class="contact-item" data-contact-id="${contact.id}" style="border: 1px solid #ddd; padding: 12px; margin-bottom: 10px; border-radius: 4px; background: ${contact.is_primary ? '#fff8e1' : 'white'};">
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <div style="flex: 1;">
                    <div style="display: flex; gap: 10px; margin-bottom: 8px;">
                        <input type="text" class="contact-name" value="${escapeHtml(contact.contact_name)}" placeholder="Nombre" style="flex: 2;">
                        <input type="text" class="contact-position" value="${escapeHtml(contact.position || '')}" placeholder="Puesto" style="flex: 1;">
                    </div>
                    <div style="display: flex; gap: 10px; margin-bottom: 8px;">
                        <input type="tel" class="contact-phone" value="${escapeHtml(contact.phone || '')}" placeholder="Teléfono" style="flex: 1;">
                        <input type="email" class="contact-email" value="${escapeHtml(contact.email || '')}" placeholder="Email" style="flex: 2;">
                    </div>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <select class="contact-type" style="flex: 1;">
                            <option value="">Seleccionar Tipo</option>
                            ${contactTypeOptions}
                        </select>
                        <label style="display: flex; align-items: center; gap: 5px;">
                            <input type="checkbox" class="contact-primary" ${contact.is_primary ? 'checked' : ''} onchange="handlePrimaryChange(this)">
                            <span>⭐ Principal</span>
                        </label>
                    </div>
                </div>
                <div style="margin-left: 10px;">
                    <button type="button" onclick="saveContact(${contact.id})" class="btn btn-sm btn-success" title="Guardar">💾</button>
                    <button type="button" onclick="deleteContact(${contact.id})" class="btn btn-sm btn-danger" title="Eliminar">🗑️</button>
                </div>
            </div>
        </div>
        `;
    }).join('');
}

function handlePrimaryChange(checkbox) {
    if (checkbox.checked) {
        // Uncheck all other primary checkboxes
        document.querySelectorAll('.contact-primary').forEach(cb => {
            if (cb !== checkbox) cb.checked = false;
        });
    }
}

function addContactRow() {
    const supplierId = document.getElementById('supplier-id').value;
    if (!supplierId) {
        showError('Guarde el proveedor primero antes de agregar contactos');
        return;
    }
    
    // Generate contact type options from LOV
    const contactTypeOptions = lovData.contactTypes ? lovData.contactTypes.map(ct => 
        `<option value="${ct.id}">${ct.name_es}</option>`
    ).join('') : '<option value="">Cargando...</option>';
    
    const contactsList = document.getElementById('contacts-list');
    const newContact = document.createElement('div');
    newContact.className = 'contact-item';
    newContact.style.cssText = 'border: 1px solid #ddd; padding: 12px; margin-bottom: 10px; border-radius: 4px; background: #f0f8ff;';
    newContact.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: start;">
            <div style="flex: 1;">
                <div style="display: flex; gap: 10px; margin-bottom: 8px;">
                    <input type="text" class="contact-name" placeholder="Nombre" style="flex: 2;">
                    <input type="text" class="contact-position" placeholder="Puesto" style="flex: 1;">
                </div>
                <div style="display: flex; gap: 10px; margin-bottom: 8px;">
                    <input type="tel" class="contact-phone" placeholder="Teléfono" style="flex: 1;">
                    <input type="email" class="contact-email" placeholder="Email" style="flex: 2;">
                </div>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <select class="contact-type" style="flex: 1;">
                        <option value="">Seleccionar Tipo</option>
                        ${contactTypeOptions}
                    </select>
                    <label style="display: flex; align-items: center; gap: 5px;">
                        <input type="checkbox" class="contact-primary" onchange="handlePrimaryChange(this)">
                        <span>⭐ Principal</span>
                    </label>
                </div>
            </div>
            <div style="margin-left: 10px;">
                <button type="button" onclick="createNewContact(this)" class="btn btn-sm btn-success" title="Crear">💾</button>
                <button type="button" onclick="this.closest('.contact-item').remove()" class="btn btn-sm btn-danger" title="Cancelar">✖️</button>
            </div>
        </div>
    `;
    contactsList.appendChild(newContact);
}

async function createNewContact(button) {
    const contactItem = button.closest('.contact-item');
    const supplierId = document.getElementById('supplier-id').value;
    
    const data = {
        contact_name: contactItem.querySelector('.contact-name').value,
        position: contactItem.querySelector('.contact-position').value,
        phone: contactItem.querySelector('.contact-phone').value,
        email: contactItem.querySelector('.contact-email').value,
        contact_type_id: contactItem.querySelector('.contact-type').value,
        is_primary: contactItem.querySelector('.contact-primary').checked
    };
    
    if (!data.contact_name && !data.phone && !data.email) {
        showError('Ingrese al menos el nombre, teléfono o email');
        return;
    }
    
    try {
        showLoading('Creando contacto...');
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/contacts`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showSuccess('Contacto creado');
            loadSupplierContacts(supplierId);
        } else {
            showError('Error al crear contacto');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear contacto');
    } finally {
        hideLoading();
    }
}

async function saveContact(contactId) {
    const contactItem = document.querySelector(`.contact-item[data-contact-id="${contactId}"]`);
    const supplierId = document.getElementById('supplier-id').value;
    
    const data = {
        contact_name: contactItem.querySelector('.contact-name').value,
        position: contactItem.querySelector('.contact-position').value,
        phone: contactItem.querySelector('.contact-phone').value,
        email: contactItem.querySelector('.contact-email').value,
        contact_type_id: contactItem.querySelector('.contact-type').value,
        is_primary: contactItem.querySelector('.contact-primary').checked
    };
    
    try {
        showLoading('Guardando contacto...');
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/contacts/${contactId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showSuccess('Contacto actualizado');
            loadSupplierContacts(supplierId);
        } else {
            showError('Error al actualizar contacto');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al actualizar contacto');
    } finally {
        hideLoading();
    }
}

async function deleteContact(contactId) {
    if (!confirm('¿Eliminar este contacto?')) return;
    
    const supplierId = document.getElementById('supplier-id').value;
    
    try {
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/contacts/${contactId}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (response.ok) {
            showSuccess('Contacto eliminado');
            loadSupplierContacts(supplierId);
        } else {
            showError(result.error || 'Error al eliminar contacto');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al eliminar contacto');
    }
}


async function saveSupplier(event) {
    event.preventDefault();
    
    const id = document.getElementById('supplier-id').value;
    const data = {
        name: document.getElementById('supplier-name').value,
        address: document.getElementById('supplier-address').value,
        city: document.getElementById('supplier-city').value,
        country_id: document.getElementById('supplier-country').value || null,
        state_id: document.getElementById('supplier-state').value || null,
        category_id: document.getElementById('supplier-category').value || null,
        rating: parseFloat(document.getElementById('supplier-rating').value) || 0,
        payment_term_id: document.getElementById('supplier-payment-terms').value || null,
        notes: document.getElementById('supplier-notes').value
    };
    
    try {
        const url = id ? `${API_BASE}/suppliers/${id}` : `${API_BASE}/suppliers`;
        const method = id ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            const result = await response.json();
            
            // If creating new supplier, reload modal with contacts section
            if (!id && result.id) {
                document.getElementById('supplier-id').value = result.id;
                document.getElementById('supplier-modal-title').textContent = 'Editar Proveedor';
                document.getElementById('contacts-section').style.display = 'block';
                showSuccess('Proveedor creado. Ahora puede agregar contactos.');
                return;
            }
            
            closeSupplierModal();
            loadSuppliers();
            showSuccess(id ? 'Proveedor actualizado' : 'Proveedor creado');
        } else {
            showError('Error al guardar proveedor');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al guardar proveedor');
    }
}

async function showCreateOrderModal() {
    try {
        // Load all suppliers
        const response = await fetch(`${API_BASE}/suppliers`);
        const suppliers = await response.json();
        
        if (suppliers.length === 0) {
            showError('No hay proveedores registrados. Agregue proveedores primero.');
            return;
        }
        
        // Create supplier selection modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'supplier-select-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Crear Nueva Orden</h2>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Seleccione un Proveedor <span class="required">*</span></label>
                        <div class="search-filter" style="margin-bottom: 15px;">
                            <input type="text" id="supplier-quick-search" placeholder="🔍 Buscar proveedor..." class="search-input" oninput="filterSupplierSelection()">
                        </div>
                        <div id="supplier-selection-list" style="max-height: 400px; overflow-y: auto; border: 1px solid #ddd; border-radius: 4px;">
                            ${suppliers.map(s => `
                                <div class="supplier-selection-item" data-supplier-name="${escapeHtml(s.name.toLowerCase())}" data-supplier-id="${s.id}" style="padding: 12px; border-bottom: 1px solid #eee; cursor: pointer; transition: background 0.2s;" onmouseover="this.style.background='#f0f0f0'" onmouseout="this.style.background='white'" onclick="selectSupplierForOrder(${s.id}, '${escapeHtml(s.name)}')">
                                    <strong>${escapeHtml(s.name)}</strong><br>
                                    <small style="color: #666;">${s.email || ''} ${s.city ? '- ' + s.city : ''} ${s.category ? '(' + s.category + ')' : ''}</small>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="button" onclick="this.closest('.modal').remove()" class="btn btn-secondary">Cancelar</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        refreshOrderTemplateSelect();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar proveedores');
    }
}

function filterSupplierSelection() {
    const search = document.getElementById('supplier-quick-search').value.toLowerCase();
    const items = document.querySelectorAll('.supplier-selection-item');
    
    items.forEach(item => {
        const name = item.getAttribute('data-supplier-name');
        if (name.includes(search)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

function selectSupplierForOrder(supplierId, supplierName) {
    // Close supplier selection modal
    const modal = document.getElementById('supplier-select-modal');
    if (modal) {
        modal.remove();
    }
    
    // Open the advanced order modal
    createOrderForVendor(supplierId, supplierName);
}

function closeOrderModal() {
    document.getElementById('order-modal').classList.remove('active');
}

async function loadSuppliersForDropdown() {
    try {
        const response = await fetch(`${API_BASE}/suppliers`);
        const suppliers = await response.json();
        const select = document.getElementById('order-supplier');
        select.innerHTML = '<option value="">Seleccionar Proveedor</option>' +
            suppliers.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
    } catch (error) {
        console.error('Error loading suppliers:', error);
    }
}

function createOrderForSupplier(supplierId, itemName) {
    showCreateOrderModal();
    document.getElementById('order-supplier').value = supplierId;
    if (itemName) {
        document.getElementById('order-items').value = itemName;
    }
}

async function saveOrder(event) {
    event.preventDefault();
    
    const data = {
        supplier_id: parseInt(document.getElementById('order-supplier').value),
        delivery_date: document.getElementById('order-delivery-date').value,
        total_amount: parseFloat(document.getElementById('order-amount').value),
        items: document.getElementById('order-items').value,
        notes: document.getElementById('order-notes').value
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeOrderModal();
            loadOrders();
            showSuccess('Orden creada exitosamente');
        } else {
            showError('Error al crear orden');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error al crear orden');
    }
}

// Import Modal
function showImportModal(type) {
    document.getElementById('import-modal').classList.add('active');
    if (type) {
        document.getElementById('import-type').value = type;
        updateImportInstructions();
    }
}

function closeImportModal() {
    document.getElementById('import-modal').classList.remove('active');
    document.getElementById('import-form').reset();
    document.getElementById('import-instructions').style.display = 'none';
}

function updateImportInstructions() {
    const importType = document.getElementById('import-type').value;
    const instructions = document.getElementById('import-instructions');
    const suppliersFormat = document.getElementById('suppliers-format');
    const itemsFormat = document.getElementById('items-format');
    
    if (importType) {
        instructions.style.display = 'block';
        if (importType === 'suppliers') {
            suppliersFormat.style.display = 'block';
            itemsFormat.style.display = 'none';
        } else if (importType === 'items') {
            suppliersFormat.style.display = 'none';
            itemsFormat.style.display = 'block';
        }
    } else {
        instructions.style.display = 'none';
    }
}

async function importFile(event) {
    event.preventDefault();
    
    const importType = document.getElementById('import-type').value;
    const fileInput = document.getElementById('import-file');
    const file = fileInput.files[0];
    
    if (!importType) {
        showError('Por favor seleccione el tipo de importación');
        return;
    }
    
    if (!file) {
        showError('Por favor seleccione un archivo');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    
    let endpoint;
    if (importType === 'suppliers') {
        endpoint = file.name.endsWith('.csv') ? 'csv' : 'excel';
        endpoint = `suppliers/import/${endpoint}`;
    } else if (importType === 'items') {
        // Check if CSV or Excel
        if (file.name.endsWith('.csv')) {
            endpoint = 'suppliers/import/with-items';
        } else {
            endpoint = 'suppliers/import/custom-excel';
        }
    }
    
    try {
        const response = await fetch(`${API_BASE}/${endpoint}`, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (response.ok) {
            closeImportModal();
            
            let message = result.message;
            if (importType === 'items') {
                message += `\n- Proveedores: ${result.suppliers_imported || 0}\n- Items: ${result.items_imported || 0}`;
            }
            showSuccess(message);
            
            // Reload appropriate data
            if (importType === 'suppliers') {
                loadSuppliers();
            } else {
                loadInventory();
                loadSuppliers();
            }
        } else {
            showError(result.error || 'Error al importar archivo');
        }
    } catch (error) {
        console.error('Error importing file:', error);
        showError('Error al importar archivo');
    }
}

function exportSuppliers(format) {
    window.location.href = `${API_BASE}/suppliers/export/${format}`;
}

function exportInventory() {
    window.location.href = `${API_BASE}/items/export`;
}

// Messages - Custom Toast Notifications
function showSuccess(message) {
    showToast(message, 'success');
}

function showError(message) {
    showToast(message, 'error');
}

function showToast(message, type = 'info') {
    // Remove existing toasts
    const existingToast = document.querySelector('.toast-notification');
    if (existingToast) {
        existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</span>
            <span class="toast-message">${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // Trigger animation
    setTimeout(() => toast.classList.add('show'), 10);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function showConfirmDialog(message, onConfirm, onCancel = null) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content modal-confirm">
            <div class="modal-body">
                <p style="white-space: pre-line; margin: 20px 0; font-size: 15px;">${message}</p>
            </div>
            <div class="form-actions" style="margin-top: 20px;">
                <button type="button" class="btn btn-secondary confirm-cancel">Cancelar</button>
                <button type="button" class="btn btn-primary confirm-ok">Aceptar</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
    
    modal.querySelector('.confirm-ok').addEventListener('click', () => {
        modal.remove();
        if (onConfirm) onConfirm();
    });
    
    modal.querySelector('.confirm-cancel').addEventListener('click', () => {
        modal.remove();
        if (onCancel) onCancel();
    });
    
    // Close on backdrop click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
            if (onCancel) onCancel();
        }
    });
}

async function viewSupplierItems(supplierId) {
    try {
        // Get supplier info first
        const supplierResponse = await fetch(`${API_BASE}/suppliers/${supplierId}`);
        const supplier = await supplierResponse.json();
        
        // Show confirmation dialog
        showConfirmDialog(
            `¿Desea ver los items que vende "${supplier.name}"?\n\nEsto lo llevará a la sección de búsqueda de items.`,
            async () => {
                try {
                    await loadSupplierItemsConfirmed(supplierId, supplier.name);
                } catch (error) {
                    console.error('Error:', error);
                    showError('Error al cargar items del proveedor');
                }
            }
        );
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar información del proveedor');
    }
}

async function loadSupplierItemsConfirmed(supplierId, supplierName) {
    try {
        // Get supplier info first
        const supplierResponse = await fetch(`${API_BASE}/suppliers/${supplierId}`);
        const supplier = await supplierResponse.json();
        
        // Get supplier's items
        const response = await fetch(`${API_BASE}/suppliers/${supplierId}/items`);
        const data = await response.json();
        const items = data.items || [];
        
        if (items.length === 0) {
            showError('Este proveedor no tiene items registrados');
            return;
        }
        
        // Switch to search items section
        showSection('search-items');
        
        // Clear search input
        const searchInput = document.getElementById('items-search');
        if (searchInput) {
            searchInput.value = '';
        }
        
        // Transform the items to match the expected format for display
        const consolidatedItems = items.map(item => ({
            item: {
                id: item.id,
                item_code: item.item_code,
                name: item.name,
                description: item.description,
                category: item.category,
                unit: item.unit
            },
            suppliers: [{
                supplier_id: supplierId,
                supplier_name: supplier.name,
                email: supplier.email,
                phone: supplier.phone,
                price: item.price,
                supplier_item_code: item.supplier_item_code,
                lead_time_days: item.lead_time_days,
                minimum_order_quantity: item.minimum_order_quantity,
                notes: item.notes
            }]
        }));
        
        // Store in currentSearchResults for filtering to work
        currentSearchResults = items.map(item => ({
            item: {
                id: item.id,
                item_code: item.item_code,
                name: item.name,
                description: item.description,
                category: item.category,
                unit: item.unit
            },
            suppliers: [{
                supplier_id: supplierId,
                supplier_name: supplier.name,
                email: supplier.email,
                phone: supplier.phone,
                price: item.price,
                supplier_item_code: item.supplier_item_code,
                lead_time_days: item.lead_time_days,
                minimum_order_quantity: item.minimum_order_quantity,
                notes: item.notes
            }]
        }));
        
        // Display the items using existing function
        displaySearchResults(consolidatedItems);
        
        // Populate filters using existing function
        populateItemFilters(consolidatedItems);
        
        // Show info message
        showSuccess(`Mostrando ${items.length} item(s) vendidos por: ${supplierName}`);
        
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// ===== PRICE MANAGEMENT PAGE =====

function backToInventory() {
    currentPriceItem = null;
    showSection('inventory');
}

async function loadPriceManagement(itemId) {
    try {
        // Get item details
        const itemResponse = await fetch(`${API_BASE}/items/${itemId}`);
        const item = await itemResponse.json();
        currentPriceItem = item;
        
        // Update header
        document.getElementById('price-item-name').textContent = `${item.item_code} - ${item.name}`;
        document.getElementById('price-item-details').textContent = 
            `${item.description || ''} | Categoría: ${item.category || 'N/A'} | Unidad: ${item.unit || 'N/A'}`;
        
        // Get all suppliers
        const suppliersResponse = await fetch(`${API_BASE}/suppliers`);
        const allSuppliers = await suppliersResponse.json();
        
        // Get item-supplier relationships
        const relationshipsResponse = await fetch(`${API_BASE}/items/${itemId}/suppliers`);
        const relationships = await relationshipsResponse.json();
        
        // Merge data
        allPriceSuppliersData = allSuppliers.map(supplier => {
            const relationship = relationships.find(r => r.id === supplier.id);
            return {
                ...supplier,
                hasRelationship: !!relationship,
                price: relationship?.price || null,
                supplier_item_code: relationship?.supplier_item_code || null,
                lead_time_days: relationship?.lead_time_days || null,
                minimum_order_quantity: relationship?.minimum_order_quantity || null,
                notes: relationship?.notes || null
            };
        });
        
        // Populate filter dropdowns
        populatePriceFilters(allPriceSuppliersData);
        
        // Display suppliers
        filterPriceSuppliers();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar gestión de precios');
    }
}

function populatePriceFilters(suppliers) {
    // Categories
    const categories = [...new Set(suppliers.map(s => s.category).filter(Boolean))].sort();
    const categoryFilter = document.getElementById('price-category-filter');
    categoryFilter.innerHTML = '<option value="">Todas</option>' + 
        categories.map(cat => `<option value="${cat}">${cat}</option>`).join('');
    
    // Cities
    const cities = [...new Set(suppliers.map(s => s.city).filter(Boolean))].sort();
    const cityFilter = document.getElementById('price-city-filter');
    cityFilter.innerHTML = '<option value="">Todas</option>' + 
        cities.map(city => `<option value="${city}">${city}</option>`).join('');
}

function filterPriceSuppliers() {
    const searchTerm = document.getElementById('price-supplier-search').value.toLowerCase();
    const relationshipFilter = document.getElementById('price-relationship-filter').value;
    const categoryFilter = document.getElementById('price-category-filter').value;
    const cityFilter = document.getElementById('price-city-filter').value;
    
    let filtered = [...allPriceSuppliersData];
    
    // Filter by search term
    if (searchTerm) {
        filtered = filtered.filter(s => 
            (s.name || '').toLowerCase().includes(searchTerm) ||
            (s.email || '').toLowerCase().includes(searchTerm) ||
            (s.city || '').toLowerCase().includes(searchTerm)
        );
    }
    
    // Filter by relationship status
    if (relationshipFilter === 'active') {
        filtered = filtered.filter(s => s.hasRelationship);
    } else if (relationshipFilter === 'available') {
        filtered = filtered.filter(s => !s.hasRelationship);
    }
    
    // Filter by category
    if (categoryFilter) {
        filtered = filtered.filter(s => s.category === categoryFilter);
    }
    
    // Filter by city
    if (cityFilter) {
        filtered = filtered.filter(s => s.city === cityFilter);
    }
    
    displayPriceSuppliers(filtered);
}

function displayPriceSuppliers(suppliers) {
    const tbody = document.getElementById('price-suppliers-tbody');
    
    if (suppliers.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="placeholder-text">No se encontraron proveedores</td></tr>';
        return;
    }
    
    tbody.innerHTML = suppliers.map(supplier => {
        if (supplier.hasRelationship) {
            // Existing relationship - show in edit mode
            return `
                <tr data-supplier-id="${supplier.id}" class="relationship-active">
                    <td><strong>${supplier.name}</strong></td>
                    <td>${supplier.email || '-'}</td>
                    <td>${supplier.city || '-'}</td>
                    <td>${supplier.category || '-'}</td>
                    <td>
                        <input type="number" step="0.01" class="form-control form-control-sm price-edit" 
                               value="${supplier.price || ''}" placeholder="Precio">
                    </td>
                    <td>
                        <input type="text" class="form-control form-control-sm code-edit" 
                               value="${supplier.supplier_item_code || ''}" placeholder="Código">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm leadtime-edit" 
                               value="${supplier.lead_time_days || ''}" placeholder="Días">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm minqty-edit" 
                               value="${supplier.minimum_order_quantity || ''}" placeholder="Cant.">
                    </td>
                    <td style="white-space: nowrap;">
                        <button onclick="updateSupplierPrice(${supplier.id})" class="btn btn-success btn-sm" title="Guardar Cambios">
                            💾
                        </button>
                        <button onclick="removeSupplierFromItem(${supplier.id}, '${escapeHtml(supplier.name)}')" 
                                class="btn btn-danger btn-sm" title="Eliminar Proveedor">
                            🗑️
                        </button>
                    </td>
                </tr>
            `;
        } else {
            // No relationship - show add mode
            return `
                <tr data-supplier-id="${supplier.id}" class="relationship-available">
                    <td><strong>${supplier.name}</strong></td>
                    <td>${supplier.email || '-'}</td>
                    <td>${supplier.city || '-'}</td>
                    <td>${supplier.category || '-'}</td>
                    <td>
                        <input type="number" step="0.01" class="form-control form-control-sm price-new" 
                               placeholder="Ingrese precio">
                    </td>
                    <td>
                        <input type="text" class="form-control form-control-sm code-new" 
                               placeholder="Código">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm leadtime-new" 
                               placeholder="Días">
                    </td>
                    <td>
                        <input type="number" class="form-control form-control-sm minqty-new" 
                               placeholder="Cant.">
                    </td>
                    <td>
                        <button onclick="addSupplierToItem(${supplier.id}, '${escapeHtml(supplier.name)}')" 
                                class="btn btn-primary btn-sm" title="Agregar Proveedor">
                            ➕
                        </button>
                    </td>
                </tr>
            `;
        }
    }).join('');
}

async function addSupplierToItem(supplierId, supplierName) {
    const row = document.querySelector(`tr[data-supplier-id="${supplierId}"]`);
    const price = parseFloat(row.querySelector('.price-new').value);
    const supplierCode = row.querySelector('.code-new').value;
    const leadTime = parseInt(row.querySelector('.leadtime-new').value) || null;
    const minQty = parseInt(row.querySelector('.minqty-new').value) || null;
    
    if (!price || price <= 0) {
        showError('Debe ingresar un precio válido');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items/${currentPriceItem.id}/suppliers`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                supplier_id: supplierId,
                price: price,
                supplier_item_code: supplierCode || null,
                lead_time_days: leadTime,
                minimum_order_quantity: minQty,
                notes: null
            })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Error al agregar proveedor');
        }
        
        showSuccess(`Proveedor ${supplierName} agregado exitosamente`);
        await loadPriceManagement(currentPriceItem.id);
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message);
    }
}

async function updateSupplierPrice(supplierId) {
    const row = document.querySelector(`tr[data-supplier-id="${supplierId}"]`);
    const price = parseFloat(row.querySelector('.price-edit').value);
    const supplierCode = row.querySelector('.code-edit').value;
    const leadTime = parseInt(row.querySelector('.leadtime-edit').value) || null;
    const minQty = parseInt(row.querySelector('.minqty-edit').value) || null;
    
    if (!price || price <= 0) {
        showError('Debe ingresar un precio válido');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items/${currentPriceItem.id}/suppliers/${supplierId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                price: price,
                supplier_item_code: supplierCode || null,
                lead_time_days: leadTime,
                minimum_order_quantity: minQty,
                notes: null
            })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Error al actualizar precio');
        }
        
        showSuccess('Precio actualizado exitosamente');
        await loadPriceManagement(currentPriceItem.id);
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message);
    }
}

async function removeSupplierFromItem(supplierId, supplierName) {
    showConfirmDialog(
        `¿Está seguro de eliminar a ${supplierName} de este item?`,
        async () => {
            try {
                await removeSupplierFromItemConfirmed(supplierId, supplierName);
            } catch (error) {
                console.error('Error:', error);
                showError(error.message);
            }
        }
    );
}

async function removeSupplierFromItemConfirmed(supplierId, supplierName) {
    try {
        const response = await fetch(`${API_BASE}/items/${currentPriceItem.id}/suppliers/${supplierId}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Error al eliminar proveedor');
        }
        
        showSuccess(`Proveedor ${supplierName} eliminado exitosamente`);
        await loadPriceManagement(currentPriceItem.id);
        
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Zoom Functions
function initZoom() {
    // Load saved zoom level from server config, fallback to localStorage
    fetch(`${API_BASE}/config`)
        .then(response => response.json())
        .then(data => {
            const serverZoom = data.zoom;
            if (serverZoom) {
                setZoom(serverZoom);
            } else {
                // Fallback to localStorage
                const savedZoom = localStorage.getItem('app-zoom-level');
                if (savedZoom) {
                    setZoom(savedZoom);
                } else {
                    setZoom(1.0); // Default zoom
                }
            }
        })
        .catch(error => {
            console.error('Error loading zoom from server:', error);
            // Fallback to localStorage
            const savedZoom = localStorage.getItem('app-zoom-level');
            if (savedZoom) {
                setZoom(savedZoom);
            } else {
                setZoom(1.0); // Default zoom
            }
        });

    // Set up event listener for zoom slider
    const zoomSlider = document.getElementById('zoom-level');
    if (zoomSlider) {
        zoomSlider.addEventListener('input', (e) => {
            const zoom = parseFloat(e.target.value);
            setZoom(zoom);
        });
    }
}

function setZoom(scale) {
    scale = Math.max(0.5, Math.min(2.0, parseFloat(scale))); // Clamp between 0.5 and 2.0
    
    // Update CSS custom properties
    document.documentElement.style.setProperty('--zoom-scale', scale);
    document.documentElement.style.setProperty('--font-scale', scale);
    document.documentElement.style.setProperty('--button-scale', scale);
    
    // Update UI elements
    const zoomSlider = document.getElementById('zoom-level');
    const zoomValue = document.getElementById('zoom-value');
    
    if (zoomSlider) zoomSlider.value = scale;
    if (zoomValue) zoomValue.textContent = Math.round(scale * 100) + '%';
    
    // Save to localStorage
    localStorage.setItem('app-zoom-level', scale);
}

function changeZoom(delta) {
    const currentZoom = parseFloat(document.getElementById('zoom-level').value) || 1.0;
    setZoom(currentZoom + delta);
}

function resetZoom() {
    setZoom(1.0);
    showSuccess('Zoom restablecido al 100%');
}

// Settings Functions
async function loadCompanySettings() {
    try {
        const response = await fetch(`${API_BASE}/config`);
        const data = await response.json();
        
        const nameInput = document.getElementById('settings-company-name');
        const addressInput = document.getElementById('settings-company-address');
        const phoneInput = document.getElementById('settings-company-phone');
        const emailInput = document.getElementById('settings-company-email');
        const websiteInput = document.getElementById('settings-company-website');
        const logoPreview = document.getElementById('settings-logo-preview');
        const logoPlaceholder = document.getElementById('settings-logo-placeholder');

        if (nameInput) nameInput.value = data.companyName || '';
        if (addressInput) addressInput.value = data.companyAddress || '';
        if (phoneInput) phoneInput.value = data.companyPhone || '';
        if (emailInput) emailInput.value = data.companyEmail || '';
        if (websiteInput) websiteInput.value = data.companyWebsite || '';

        // Handle logo
        if (logoPreview && logoPlaceholder) {
            if (data.logoPath) {
                logoPreview.src = '/api/logo';
                logoPreview.style.display = 'block';
                logoPlaceholder.style.display = 'none';
            } else {
                logoPreview.style.display = 'none';
                logoPlaceholder.style.display = 'flex';
            }
        }

        // Handle zoom
        const zoomSlider = document.getElementById('zoom-level');
        const zoomValue = document.getElementById('zoom-value');
        if (zoomSlider && data.zoom) {
            const zoom = parseFloat(data.zoom);
            zoomSlider.value = zoom;
            if (zoomValue) zoomValue.textContent = Math.round(zoom * 100) + '%';
            setZoom(zoom);
        }
    } catch (error) {
        console.error('Error loading company settings:', error);
        showError('Error al cargar la configuración');
    }
}

async function saveCompanySettings() {
    const zoomSlider = document.getElementById('zoom-level');
    const zoom = zoomSlider ? parseFloat(zoomSlider.value) : 1.0;

    const data = {
        companyName: document.getElementById('settings-company-name').value,
        companyAddress: document.getElementById('settings-company-address').value,
        companyPhone: document.getElementById('settings-company-phone').value,
        companyEmail: document.getElementById('settings-company-email').value,
        companyWebsite: document.getElementById('settings-company-website').value,
        zoom: zoom
    };
    
    try {
        const response = await fetch(`${API_BASE}/config`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Configuración guardada exitosamente');
            // Update the sidebar company name
            loadCompanyName();
        } else {
            showError('Error al guardar configuración: ' + (result.error || 'Error desconocido'));
        }
    } catch (error) {
        console.error('Error saving company settings:', error);
        showError('Error al guardar configuración');
    }
}



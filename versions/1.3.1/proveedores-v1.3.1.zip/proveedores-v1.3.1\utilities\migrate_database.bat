@echo off
REM ============================================================
REM  Database Migration Utility
REM  Migrates data from old database to new database structure
REM ============================================================

cd /d "%~dp0\.."

echo.
echo ================================================================
echo   DATABASE MIGRATION UTILITY
echo ================================================================
echo.

REM Check for Python in venv
if exist "venv\Scripts\python.exe" (
    set PYTHON_EXE=venv\Scripts\python.exe
    echo [OK] Using Python from virtual environment
) else (
    set PYTHON_EXE=python
    echo [INFO] Using system Python
)

echo.

REM Check if source database provided
if "%~1"=="" (
    echo [ERROR] Usage: migrate_database.bat ^<source_db_path^>
    echo.
    echo Example:
    echo   migrate_database.bat suppliers.db
    echo   migrate_database.bat ..\old_install\suppliers.db
    echo.
    pause
    exit /b 1
)

set SOURCE_DB=%~1
set DEST_DB=data\suppliers.db

REM Check if source exists
if not exist "%SOURCE_DB%" (
    echo [ERROR] Source database not found: %SOURCE_DB%
    echo.
    pause
    exit /b 1
)

REM Check if destination exists
if not exist "%DEST_DB%" (
    echo [ERROR] Destination database not found: %DEST_DB%
    echo [INFO] Run the application first to create the database
    echo.
    pause
    exit /b 1
)

echo [INFO] Migrating from: %SOURCE_DB%
echo [INFO] Migrating to:   %DEST_DB%
echo.
echo [WARNING] This will replace all data in the destination database
echo           (except users table which will be preserved)
echo.
set /p CONFIRM="Continue with migration? (Y/N): "

if /i not "%CONFIRM%"=="Y" (
    echo Migration cancelled.
    pause
    exit /b 0
)

echo.
echo [Running migration script...]
echo.

%PYTHON_EXE% scripts\migrate_database.py "%SOURCE_DB%" "%DEST_DB%"

if %ERRORLEVEL% EQU 0 (
    echo.
    echo [SUCCESS] Migration completed successfully!
    echo.
) else (
    echo.
    echo [ERROR] Migration failed. Check error messages above.
    echo.
)

pause

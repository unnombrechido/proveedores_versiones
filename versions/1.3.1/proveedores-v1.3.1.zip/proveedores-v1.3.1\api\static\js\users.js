﻿// User Management Functions
async function loadUsers() {
    if (!currentUser || currentUser.rol !== 'sysadmin') {
        return;
    }
    
    try {
        const search = document.getElementById('users-search').value;
        const rol = document.getElementById('role-filter').value;
        const status = document.getElementById('status-filter').value;
        
        let url = `${API_BASE}/users?`;
        if (search) url += `search=${encodeURIComponent(search)}&`;
        if (rol) url += `rol=${rol}&`;
        if (status) url += `status=${status}&`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            displayUsers(data.users);
        }
    } catch (error) {
        console.error('Error loading users:', error);
        showNotification('Error al cargar usuarios', 'error');
    }
}

function displayUsers(users) {
    const tbody = document.getElementById('users-tbody');
    tbody.innerHTML = '';
    
    users.forEach(user => {
        const tr = document.createElement('tr');
        const statusBadge = user.status === 'activo' 
            ? '<span style="color: green;">●</span> Activo' 
            : '<span style="color: red;">●</span> Inactivo';
        
        const roleBadge = {
            'sysadmin': '👑 Sysadmin',
            'admin': '⭐ Admin',
            'compras': '📦 Compras'
        }[user.rol] || user.rol;
        
        tr.innerHTML = `
            <td>${user.email}</td>
            <td>${user.nombre}</td>
            <td>${user.apellido}</td>
            <td>${user.telefono || '-'}</td>
            <td>${roleBadge}</td>
            <td>${statusBadge}</td>
            <td>${new Date(user.fecha_registro).toLocaleDateString()}</td>
            <td>
                <button class="btn btn-sm" onclick="editUser(${user.id})">✏️ Editar</button>
                <button class="btn btn-sm" onclick="changeUserPassword(${user.id})">🔑 Cambiar Contraseña</button>
                ${user.id !== currentUser.id ? `<button class="btn btn-sm btn-danger" onclick="deleteUser(${user.id})">🗑️ Eliminar</button>` : ''}
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function openUserModal(userId = null) {
    currentUserId = userId;
    const modal = document.getElementById('user-modal');
    const title = document.getElementById('user-modal-title');
    const form = document.getElementById('user-form');
    
    form.reset();
    
    if (userId) {
        title.textContent = 'Editar Usuario';
        document.getElementById('user-password').required = false;
        document.querySelector('label[for="user-password"] small').textContent = '(dejar vacío para mantener actual)';
        loadUserData(userId);
    } else {
        title.textContent = 'Nuevo Usuario';
        document.getElementById('user-password').required = true;
        document.querySelector('label[for="user-password"] small').textContent = '';
    }
    
    modal.style.display = 'block';
}

async function loadUserData(userId) {
    try {
        const response = await fetch(`${API_BASE}/users/${userId}`);
        const data = await response.json();
        
        if (data.success) {
            const user = data.user;
            document.getElementById('user-email').value = user.email;
            document.getElementById('user-nombre').value = user.nombre;
            document.getElementById('user-apellido').value = user.apellido;
            document.getElementById('user-telefono').value = user.telefono || '';
            document.getElementById('user-rol').value = user.rol;
            document.getElementById('user-status').value = user.status;
        }
    } catch (error) {
        console.error('Error loading user:', error);
        showNotification('Error al cargar usuario', 'error');
    }
}

async function saveUser(event) {
    event.preventDefault();
    
    const userData = {
        email: document.getElementById('user-email').value,
        nombre: document.getElementById('user-nombre').value,
        apellido: document.getElementById('user-apellido').value,
        telefono: document.getElementById('user-telefono').value,
        rol: document.getElementById('user-rol').value,
        status: document.getElementById('user-status').value
    };
    
    const password = document.getElementById('user-password').value;
    if (password) {
        userData.password = password;
    }
    
    try {
        let response;
        if (currentUserId) {
            response = await fetch(`${API_BASE}/users/${currentUserId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
        } else {
            response = await fetch(`${API_BASE}/users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
        }
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(data.message, 'success');
            closeUserModal();
            loadUsers();
        } else {
            showNotification(data.error, 'error');
        }
    } catch (error) {
        console.error('Error saving user:', error);
        showNotification('Error al guardar usuario', 'error');
    }
}

async function editUser(userId) {
    openUserModal(userId);
}

async function changeUserPassword(userId) {
    const newPassword = prompt('Ingrese la nueva contraseña (mínimo 6 caracteres):')
    
    if (!newPassword) return;
    
    if (newPassword.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/users/${userId}/password`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ new_password: newPassword })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Contraseña actualizada exitosamente', 'success');
        } else {
            showNotification(data.error, 'error');
        }
    } catch (error) {
        console.error('Error changing password:', error);
        showNotification('Error al cambiar contraseña', 'error');
    }
}

async function deleteUser(userId) {
    if (!confirm('¿Está seguro de eliminar este usuario? Esta acción no se puede deshacer.')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/users/${userId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Usuario eliminado exitosamente', 'success');
            loadUsers();
        } else {
            showNotification(data.error, 'error');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        showNotification('Error al eliminar usuario', 'error');
    }
}

function closeUserModal() {
    document.getElementById('user-modal').style.display = 'none';
    currentUserId = null;
}


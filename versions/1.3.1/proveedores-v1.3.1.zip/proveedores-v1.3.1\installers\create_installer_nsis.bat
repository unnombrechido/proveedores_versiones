@echo off
REM ============================================================
REM  Crear Instalador Windows (NSIS)
REM ============================================================

echo.
echo ========================================================
echo   CREAR INSTALADOR WINDOWS (NSIS)
echo   Sistema de Proveedores v1.3.1
echo ========================================================
echo.

REM Check if NSIS is installed
set MAKENSIS_EXE=

if exist "C:\Program Files (x86)\NSIS\makensis.exe" goto :nsis_found_x86
if exist "C:\Program Files\NSIS\makensis.exe" goto :nsis_found_program_files
goto :nsis_not_found

:nsis_found_x86
set MAKENSIS_EXE=C:\Program Files (x86)\NSIS\makensis.exe
goto :nsis_check_done

:nsis_found_program_files
set MAKENSIS_EXE=C:\Program Files\NSIS\makensis.exe
goto :nsis_check_done

:nsis_not_found
echo [ERROR] NSIS Compiler (makensis.exe) no encontrado
echo.
echo Para crear instaladores Windows con NSIS, necesitas instalar NSIS:
echo https://nsis.sourceforge.io/Download
echo.
echo O usar el portable version
echo.
pause
exit /b 1

:nsis_check_done

REM Read version from VERSION file
set "VERSION="
for /f "usebackq delims=" %%v in ("%~dp0..\VERSION") do set "VERSION=%%v"
if "%VERSION%"=="" set "VERSION=1.3.1"
REM Trim whitespace
for /l %%a in (1,1,31) do if "!VERSION:~-1!"==" " set "VERSION=!VERSION:~0,-1!"

echo [INFO] Creando instalador para version %VERSION%
echo.

REM Copy proper icon if it doesn't exist
if not exist "%~dp0..\icon.ico" (
    if exist "%~dp0..\favicon_io\favicon.ico" (
        echo [INFO] Copiando icono profesional...
        copy "%~dp0..\favicon_io\favicon.ico" "%~dp0..\icon.ico" >nul
        if exist "%~dp0..\icon.ico" (
            echo [OK] Icono copiado
        ) else (
            echo [WARNING] No se pudo copiar icono, creando uno basico...
            powershell -ExecutionPolicy Bypass -File "%~dp0create_icon.ps1" -iconPath "%~dp0..\icon.ico" 2>nul
        )
    ) else (
        echo [INFO] Creando icono predeterminado...
        powershell -ExecutionPolicy Bypass -File "%~dp0create_icon.ps1" -iconPath "%~dp0..\icon.ico" 2>nul
        if exist "%~dp0..\icon.ico" (
            echo [OK] Icono creado
        ) else (
            echo [WARNING] No se pudo crear icono, el instalador continuara sin el
        )
    )
)

REM Copy icon to installers directory for NSIS
if exist "%~dp0..\icon.ico" (
    copy "%~dp0..\icon.ico" "%~dp0icon.ico" >nul 2>&1
)

REM Compile the installer
echo [INFO] Compilando instalador con NSIS...
pushd "%~dp0.."
"%MAKENSIS_EXE%" /DVERSION=%VERSION% "installers\proveedores.nsi"
if %errorlevel% equ 0 (
    REM Move the installer to the correct location
    if exist "installers\proveedores-v%VERSION%-setup.exe" (
        move "installers\proveedores-v%VERSION%-setup.exe" "proveedores-v%VERSION%-setup.exe" >nul 2>&1
    )
)
popd
if %errorlevel% neq 0 (
    echo [ERROR] Fallo al compilar el instalador NSIS
    exit /b 1
)

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Fallo al compilar el instalador
    pause
    exit /b 1
)

echo.
echo ========================================================
echo   INSTALADOR CREADO EXITOSAMENTE
echo ========================================================
echo.
echo Archivo: proveedores-v%VERSION%-setup.exe
echo Ubicacion: %~dp0..\proveedores-v%VERSION%-setup.exe
echo.
echo El instalador incluye:
echo - Interfaz grafica moderna
echo - Opcion de instalar para todos los usuarios
echo - Icono en el escritorio (opcional)
echo - Desinstalador integrado
echo - Instalacion en Program Files
echo.
exit /b 0
@echo off
REM ============================================================
REM  Duplicate Contacts Cleanup Utility - Windows Batch Wrapper
REM ============================================================

echo.
echo ============================================================
echo   LIMPIEZA DE CONTACTOS DUPLICADOS
echo ============================================================
echo.

REM Set Python executable path (prefer venv if available)
set PYTHON_EXE=python
if exist "..\venv\Scripts\python.exe" (
    set PYTHON_EXE=..\venv\Scripts\python.exe
    echo [INFO] Usando Python del entorno virtual
    echo.
) else (
    REM Check if Python is available
    where python >nul 2>&1
    if errorlevel 1 (
        echo [ERROR] Python no esta disponible
        echo.
        echo Por favor instala Python o ejecuta desde el entorno virtual:
        echo   ..\venv\Scripts\python.exe ..\scripts\cleanup_duplicate_contacts.py
        pause
        exit /b 1
    )
    echo [INFO] Usando Python del sistema
    echo.
)

REM Show menu
echo Selecciona una opcion:
echo.
echo   1. Verificar estado actual (buscar duplicados)
echo   2. Simulacion (mostrar duplicados sin eliminar)
echo   3. Aplicar limpieza (eliminar duplicados)
echo   4. Salir
echo.

set /p choice="Opcion (1-4): "

if "%choice%"=="1" goto option1
if "%choice%"=="2" goto option2
if "%choice%"=="3" goto option3
if "%choice%"=="4" goto option4

echo.
echo Opcion invalida
pause
exit /b 1

:option1
echo.
echo [INFO] Verificando estado actual...
echo.
%PYTHON_EXE% ..\scripts\cleanup_duplicate_contacts.py --verify-only
echo.
pause
exit /b 0

:option2
echo.
echo [INFO] Ejecutando simulacion (no se eliminan datos)...
echo.
%PYTHON_EXE% ..\scripts\cleanup_duplicate_contacts.py
echo.
pause
exit /b 0

:option3
echo.
echo [ADVERTENCIA] Esta opcion ELIMINARA contactos duplicados permanentemente
echo.
set /p confirm="¿Estas seguro? (si/no): "
if /i "%confirm%"=="si" goto confirm_delete
if /i "%confirm%"=="s" goto confirm_delete
echo.
echo Operacion cancelada.
echo.
pause
exit /b 0

:confirm_delete
echo.
echo [INFO] Aplicando limpieza de duplicados...
echo.
%PYTHON_EXE% ..\scripts\cleanup_duplicate_contacts.py --apply
echo.
pause
exit /b 0

:option4
echo.
echo Saliendo...
exit /b 0
﻿// Utility Functions

function showNotification(message, type = 'info') {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('notification-toast');
    if (!notification) {
        notification = document.createElement('div');
        notification.id = 'notification-toast';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            z-index: 10000;
            box-shadow: 0 4px 6px rgba(0,0,0,0.2);
            max-width: 400px;
            animation: slideIn 0.3s ease-out;
        `;
        document.body.appendChild(notification);
    }
    
    // Set color based on type
    const colors = {
        'success': '#28a745',
        'error': '#dc3545',
        'warning': '#ffc107',
        'info': '#17a2b8'
    };
    
    notification.style.backgroundColor = colors[type] || colors['info'];
    notification.textContent = message;
    notification.style.display = 'block';
    
    // Auto-hide after 4 seconds
    setTimeout(() => {
        notification.style.display = 'none';
    }, 4000);
}

function loadInitialData() {
    // Load database info, company name, etc.
    loadDatabaseInfo();
    loadCompanyName();
    showSection('search-items'); // Show first section by default
    
    // Enter key search for items
    const itemsSearch = document.getElementById('items-search');
    if (itemsSearch) {
        itemsSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchItems();
            }
        });
    }
}

// Predefined Lists
// (Now loaded from LOV APIs)


// Predefined Lists
// (Now loaded from LOV APIs)

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Loading indicator functions
function showLoading(message = 'Cargando...') {
    let overlay = document.getElementById('loading-overlay');
    if (!overlay) {
        // Create overlay dynamically if it doesn't exist
        overlay = document.createElement('div');
        overlay.id = 'loading-overlay';
        overlay.className = 'loading-overlay';
        overlay.innerHTML = `
            <div class="loading-spinner">
                <div class="spinner"></div>
                <div class="loading-text">${message}</div>
            </div>
        `;
        document.body.appendChild(overlay);
    }
    const textElement = overlay.querySelector('.loading-text');
    if (textElement) {
        textElement.textContent = message;
    }
    overlay.style.display = 'flex';
}

function hideLoading() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

async function getAppConfig() {
    if (appConfigCache) {
        return appConfigCache;
    }
    try {
        const response = await fetch('/api/config');
        const data = await response.json();
        appConfigCache = data || {};
        return appConfigCache;
    } catch (error) {
        console.error('Error loading config:', error);
        return {};
    }
}

function normalizeLogoPath(logoPath) {
    if (!logoPath) return '';
    let logoUrl = logoPath.trim();
    if (!logoUrl) return '';
    if (!logoUrl.startsWith('http://') && !logoUrl.startsWith('https://') && !logoUrl.startsWith('/')) {
        logoUrl = '/static/' + logoUrl;
    }
    return logoUrl;
}

function stripPricesFromItems(itemsText) {
    if (!itemsText) return '';
    let cleaned = itemsText;
    cleaned = cleaned.replace(/@\s*\$?\d+(?:[.,]\d{1,2})?/g, '');
    cleaned = cleaned.replace(/\$\s*\d+(?:[.,]\d{1,2})?/g, '');
    cleaned = cleaned.replace(/\b(?:USD|MXN)\s*\d+(?:[.,]\d{1,2})?/gi, '');
    cleaned = cleaned.replace(/\s{2,}/g, ' ');
    return cleaned.trim();
}

// Messages - Custom Toast Notifications
function showSuccess(message) {
    showToast(message, 'success');
}

function showError(message) {
    showToast(message, 'error');
}

function showToast(message, type = 'info') {
    // Remove existing toasts
    const existingToast = document.querySelector('.toast-notification');
    if (existingToast) {
        existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</span>
            <span class="toast-message">${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // Trigger animation
    setTimeout(() => toast.classList.add('show'), 10);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function showConfirmDialog(message, onConfirm, onCancel = null) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content modal-confirm">
            <div class="modal-body">
                <p style="white-space: pre-line; margin: 20px 0; font-size: 15px;">${message}</p>
            </div>
            <div class="form-actions" style="margin-top: 20px;">
                <button type="button" class="btn btn-secondary confirm-cancel">Cancelar</button>
                <button type="button" class="btn btn-primary confirm-ok">Aceptar</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
    
    modal.querySelector('.confirm-ok').addEventListener('click', () => {
        modal.remove();
        if (onConfirm) onConfirm();
    });
    
    modal.querySelector('.confirm-cancel').addEventListener('click', () => {
        modal.remove();
        if (onCancel) onCancel();
    });
    
    // Close on backdrop click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
            if (onCancel) onCancel();
        }
    });
}

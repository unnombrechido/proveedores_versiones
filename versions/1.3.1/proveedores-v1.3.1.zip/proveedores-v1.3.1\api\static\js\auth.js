﻿// Authentication Functions
async function checkAuth() {
    try {
        const response = await fetch(`${API_BASE}/auth/check`);
        
        if (!response.ok) {
                // console.error('Auth check failed:', response.status);
            window.location.href = '/login';
            return;
        }
        
        const data = await response.json();
        
        if (!data.authenticated) {
            window.location.href = '/login';
            return;
        }
        
        currentUser = data.user;
        updateUIForUser(currentUser);
    } catch (error) {
            // console.error('Auth check error:', error);
        window.location.href = '/login';
    }
}

function updateUIForUser(user) {
    // Update user info in sidebar
    document.getElementById('current-user-name').textContent = `${user.nombre} ${user.apellido}`;
    document.getElementById('current-user-role').textContent = `Rol: ${user.rol}`;
    
    // Show/hide navigation items based on role
    const userManagementNav = document.getElementById('user-management-nav');
    const settingsNav = document.getElementById('settings-nav');
    const lovsNav = document.getElementById('lovs-nav');
    
    if (user.rol === 'sysadmin') {
        userManagementNav.style.display = 'block';
        settingsNav.style.display = 'block';
        if (lovsNav) lovsNav.style.display = 'block';
    } else if (user.rol === 'admin') {
        userManagementNav.style.display = 'none';
        settingsNav.style.display = 'block';
        if (lovsNav) lovsNav.style.display = 'block';
    } else if (user.rol === 'compras') {
        userManagementNav.style.display = 'none';
        settingsNav.style.display = 'none';
        if (lovsNav) lovsNav.style.display = 'none';
        
        // Hide management navigation buttons for compras role
        const inventoryNav = document.querySelector('[onclick="showSection(\'inventory\')"]');
        const vendorsNav = document.querySelector('[onclick="showSection(\'vendors\')"]');
        if (inventoryNav) inventoryNav.style.display = 'none';
        if (vendorsNav) vendorsNav.style.display = 'none';
    }
    
    // Apply permission-based restrictions
    applyPermissionRestrictions(user.rol);
}

function applyPermissionRestrictions(rol) {
    // Hide all buttons with data-permission="edit" for compras users
    if (rol === 'compras') {
        const restrictedButtons = document.querySelectorAll('[data-permission="edit"]');
        restrictedButtons.forEach(button => {
            button.style.display = 'none';
        });
        
        // Also disable edit/delete actions in tables
        hideTableActions();
    }
}

function hideTableActions() {
    // This will hide edit/delete buttons in inventory and vendor tables
    // Will be called after tables are loaded
    const editButtons = document.querySelectorAll('button[onclick*="edit"], button[onclick*="Edit"]');
    const deleteButtons = document.querySelectorAll('button[onclick*="delete"], button[onclick*="Delete"]');
    
    editButtons.forEach(btn => {
        if (currentUser && currentUser.rol === 'compras') {
            // Check if it's not an order-related button
            const onclick = btn.getAttribute('onclick') || '';
            if (!onclick.includes('Order') && !onclick.includes('order')) {
                btn.style.display = 'none';
            }
        }
    });
    
    deleteButtons.forEach(btn => {
        if (currentUser && currentUser.rol === 'compras') {
            const onclick = btn.getAttribute('onclick') || '';
            if (!onclick.includes('Order') && !onclick.includes('order')) {
                btn.style.display = 'none';
            }
        }
    });
}

async function logout() {
    try {
        await fetch(`${API_BASE}/auth/logout`, { method: 'POST' });
        window.location.href = '/login';
    } catch (error) {
        console.error('Logout error:', error);
        window.location.href = '/login';
    }
}


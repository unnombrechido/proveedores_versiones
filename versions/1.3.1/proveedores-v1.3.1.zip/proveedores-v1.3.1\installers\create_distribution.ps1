﻿# Create Distribution
param(
    # none  = ZIP only
    # iss   = ZIP + Inno Setup exe  (requires ISCC.exe)
    # nsis  = ZIP + NSIS exe        (requires makensis.exe)
    # both  = ZIP + both exes
    [ValidateSet('none','iss','nsis','both')]
    [string]$Installer = 'none'
)
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

# Read version from VERSION file
$versionFile = "VERSION"
if (Test-Path $versionFile) {
    $VERSION = Get-Content $versionFile -Raw
} else {
    $VERSION = "1.3.0"
}
$VERSION = $VERSION.Trim()

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  CREAR DISTRIBUCION v$VERSION" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

$zipName = "proveedores-v$VERSION.zip"
$tempFolder = "proveedores-v$VERSION"

Write-Host "[1/6] Preparando carpeta temporal..." -ForegroundColor Yellow
if (Test-Path $tempFolder) { Remove-Item -Recurse -Force $tempFolder }
New-Item -ItemType Directory -Path $tempFolder | Out-Null
Write-Host "  OK Carpeta creada" -ForegroundColor Green
Write-Host ""

Write-Host "[2/6] Copiando estructura modular..." -ForegroundColor Yellow
$folders = @("api", "bin", "docs", "examples", "scripts", "installers", "utilities")
$copied = 0
foreach ($folder in $folders) {
    if (Test-Path $folder) {
        Copy-Item -Path $folder -Destination "$tempFolder\$folder" -Recurse -Force
        $copied++
    }
}
# Replace non-ASCII characters with ASCII equivalents
Write-Host "  OK $copied carpetas copiadas" -ForegroundColor Green
Write-Host ""

Write-Host "[3/6] Creando carpetas vacias..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path "$tempFolder\data" -Force | Out-Null
New-Item -ItemType Directory -Path "$tempFolder\logs" -Force | Out-Null
New-Item -ItemType Directory -Path "$tempFolder\config" -Force | Out-Null
Write-Host "  OK data/, logs/, config/ creadas" -ForegroundColor Green
Write-Host ""

# Always copy order templates to config folder
$orderTemplates = @("config/order_template_esp.html", "config/order_template_eng.html")
$templateCopied = 0
foreach ($tpl in $orderTemplates) {
    if (Test-Path $tpl) {
        Copy-Item $tpl "$tempFolder\config\$(Split-Path $tpl -Leaf)" -Force
        $templateCopied++
    }
}
Write-Host "  OK $templateCopied plantillas de orden copiadas a config/" -ForegroundColor Green
Write-Host ""

Write-Host "[4/6] Copiando archivos raiz..." -ForegroundColor Yellow
$files = @("requirements.txt", "VERSION", "LICENSE", "README.md", "LEEME_PRIMERO.txt", "INSTALAR.bat", "icon.ico")
$fileCopied = 0
foreach ($file in $files) {
    if (Test-Path $file) {
        Copy-Item $file "$tempFolder\$file" -Force
        $fileCopied++
    }
}

Write-Host "  OK $fileCopied archivos copiados" -ForegroundColor Green
Write-Host ""

Write-Host "[5/6] Limpiando archivos de desarrollo..." -ForegroundColor Yellow
Get-ChildItem -Path $tempFolder -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force
Get-ChildItem -Path $tempFolder -Recurse -File -Include "*.pyc","*.pyo","*.pyd" -ErrorAction SilentlyContinue | Remove-Item -Force
if (Test-Path "$tempFolder\data") { Get-ChildItem -Path "$tempFolder\data" -Filter "*.db" -ErrorAction SilentlyContinue | Remove-Item -Force }
if (Test-Path "$tempFolder\installers\test_install") { Remove-Item "$tempFolder\installers\test_install" -Recurse -Force }
if (Test-Path "$tempFolder\installers\obsolete") { Remove-Item "$tempFolder\installers\obsolete" -Recurse -Force }
# Remove installer executables from installers folder (they should be distributed separately)
Get-ChildItem -Path "$tempFolder\installers" -File -Filter "*setup*.exe" -ErrorAction SilentlyContinue | Remove-Item -Force
Write-Host "  OK Limpieza completada" -ForegroundColor Green
Write-Host ""

Write-Host "[6/7] Creando archivo ZIP..." -ForegroundColor Yellow
if (Test-Path $zipName) { Remove-Item $zipName -Force }

$maxAttempts = 3
$zipCreated = $false
for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
    try {
        Compress-Archive -Path $tempFolder -DestinationPath $zipName -CompressionLevel Optimal -Force
        $zipCreated = $true
        break
    } catch {
        if ($_.Exception.Message -match "being used by another process") {
            Write-Host "  [ADVERTENCIA] Hay archivos en uso. Cierra la app/editores y reintenta." -ForegroundColor Yellow
            if ($attempt -lt $maxAttempts) {
                Read-Host "Presiona Enter para reintentar ($attempt/$maxAttempts)"
                Start-Sleep -Seconds 1
            }
        } else {
            throw
        }
    }
}

if (-not $zipCreated) {
    throw "No se pudo crear el ZIP. Hay archivos en uso."
}

$sizeMB = [math]::Round((Get-Item $zipName).Length / 1MB, 2)
Write-Host "  OK ZIP creado: $zipName ($sizeMB MB)" -ForegroundColor Green
Write-Host ""

Remove-Item -Recurse -Force $tempFolder

# ----------------------------------------------------------------
Write-Host "[7/7] Compilando instalador(es)..." -ForegroundColor Yellow

$makensis  = "C:\Program Files (x86)\NSIS\makensis.exe"
$iscc      = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
$nsiScript = Join-Path $PSScriptRoot "proveedores.nsi"
$issScript = Join-Path $PSScriptRoot "proveedores.iss"

function Build-NSIS {
    if (-not (Test-Path $makensis)) {
        Write-Host "  [AVISO] makensis.exe no encontrado. Descarga NSIS: https://nsis.sourceforge.io/" -ForegroundColor Yellow
        return
    }
    if (-not (Test-Path $nsiScript)) { Write-Host "  [ERROR] proveedores.nsi no encontrado" -ForegroundColor Red; return }
    Push-Location $PSScriptRoot
    try {
        & $makensis /V2 proveedores.nsi
        if ($LASTEXITCODE -eq 0) {
            $exe = Join-Path (Split-Path $PSScriptRoot -Parent) "proveedores-v$VERSION-nsis-setup.exe"
            if (Test-Path $exe) {
                $mb = [math]::Round((Get-Item $exe).Length / 1MB, 2)
                Write-Host "  OK NSIS: proveedores-v$VERSION-nsis-setup.exe ($mb MB)" -ForegroundColor Green
            } else {
                Write-Host "  OK NSIS exe compilado." -ForegroundColor Green
            }
        } else {
            Write-Host "  [ERROR] makensis termino con codigo $LASTEXITCODE" -ForegroundColor Red
        }
    } finally { Pop-Location }
}

function Build-ISS {
    if (-not (Test-Path $iscc)) {
        Write-Host "  [AVISO] ISCC.exe no encontrado. Descarga Inno Setup: https://jrsoftware.org/isdl.php" -ForegroundColor Yellow
        return
    }
    if (-not (Test-Path $issScript)) { Write-Host "  [ERROR] proveedores.iss no encontrado" -ForegroundColor Red; return }
    Push-Location $PSScriptRoot
    try {
        & $iscc proveedores.iss
        if ($LASTEXITCODE -eq 0) {
            $exe = Join-Path (Split-Path $PSScriptRoot -Parent) "proveedores-v$VERSION-iss-setup.exe"
            if (Test-Path $exe) {
                $mb = [math]::Round((Get-Item $exe).Length / 1MB, 2)
                Write-Host "  OK ISS: proveedores-v$VERSION-iss-setup.exe ($mb MB)" -ForegroundColor Green
            } else {
                Write-Host "  OK Inno Setup exe compilado." -ForegroundColor Green
            }
        } else {
            Write-Host "  [ERROR] ISCC termino con codigo $LASTEXITCODE" -ForegroundColor Red
        }
    } finally { Pop-Location }
}

switch ($Installer) {
    'iss'  { Build-ISS }
    'nsis' { Build-NSIS }
    'both' { Build-ISS; Build-NSIS }
    default { Write-Host "  (Sin instalador .exe solicitado)" -ForegroundColor Gray }
}

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  DISTRIBUCION CREADA: $zipName ($sizeMB MB)" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

@echo off
REM Service Killer for Sistema de Proveedores
REM This batch file runs the PowerShell service killer script

echo.
echo ========================================
echo   SERVICE KILLER - Sistema de Proveedores
echo ========================================
echo.
echo This will forcefully stop and remove the Windows service
echo and terminate all related processes.
echo.

powershell.exe -ExecutionPolicy Bypass -File "%~dp0..\scripts\kill-service.ps1"

echo.
echo Press any key to exit...
pause >nul
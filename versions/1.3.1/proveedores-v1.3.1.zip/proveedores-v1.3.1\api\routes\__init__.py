# -*- coding: utf-8 -*-
"""Routes package – registers all blueprints on the Flask app."""
from .auth import auth_bp
from .config import config_bp
from .data_io import data_io_bp
from .items import items_bp
from .lovs import lovs_bp
from .main import main_bp
from .orders import orders_bp
from .suppliers import suppliers_bp
from .users import users_bp


def register_blueprints(app):
    """Register every blueprint with the Flask application."""
    for bp in (
        auth_bp,
        config_bp,
        data_io_bp,
        items_bp,
        lovs_bp,
        main_bp,
        orders_bp,
        suppliers_bp,
        users_bp,
    ):
        app.register_blueprint(bp)

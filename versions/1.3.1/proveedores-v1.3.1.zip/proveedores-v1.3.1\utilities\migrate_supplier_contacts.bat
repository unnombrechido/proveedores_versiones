@echo off
REM Migration Script: Add Supplier Contacts Table
REM Version: 1.3.0

echo ========================================
echo MIGRACION: Contactos de Proveedores
echo ========================================
echo.
echo IMPORTANTE: Se recomienda hacer un respaldo de la base de datos antes de continuar
echo.
pause

cd /d "%~dp0.."
python scripts\migrate_supplier_contacts.py

if %ERRORLEVEL% EQU 0 (
    echo.
    echo Migracion completada exitosamente
) else (
    echo.
    echo Error durante la migracion
    pause
    exit /b 1
)

pause

param([string]$iconPath)
Add-Type -AssemblyName System.Drawing
$bitmap = New-Object System.Drawing.Bitmap(64,64)
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias

# Background gradient (blue to darker blue)
$rect = New-Object System.Drawing.Rectangle 0, 0, 64, 64
$brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush $rect, [System.Drawing.Color]::FromArgb(59, 130, 246), [System.Drawing.Color]::FromArgb(37, 99, 235), [System.Drawing.Drawing2D.LinearGradientMode]::Vertical
$graphics.FillRectangle($brush, 0, 0, 64, 64)

# Draw a stylized box/supply icon
$boxBrush = [System.Drawing.Brushes]::White
$boxPen = New-Object System.Drawing.Pen ([System.Drawing.Color]::White), 2

# Main box
$graphics.FillRectangle($boxBrush, 16, 20, 32, 24)
$graphics.DrawRectangle($boxPen, 16, 20, 32, 24)

# Box opening at top
$graphics.FillRectangle([System.Drawing.Brushes]::FromArgb(59, 130, 246), 20, 16, 24, 8)
$graphics.DrawRectangle($boxPen, 20, 16, 24, 8)

# Inner lines to suggest content
$innerPen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(59, 130, 246), 1)
$graphics.DrawLine($innerPen, 22, 26, 42, 26)
$graphics.DrawLine($innerPen, 22, 32, 42, 32)
$graphics.DrawLine($innerPen, 22, 38, 42, 38)

# Arrow pointing up (supply chain)
$arrowPen = New-Object System.Drawing.Pen ([System.Drawing.Color]::White), 3
$graphics.DrawLine($arrowPen, 32, 50, 32, 56)  # Arrow shaft
$graphics.DrawLine($arrowPen, 28, 52, 32, 48)  # Left arrowhead
$graphics.DrawLine($arrowPen, 36, 52, 32, 48)  # Right arrowhead

$graphics.Dispose()
$bitmap.Save($iconPath, [System.Drawing.Imaging.ImageFormat]::Icon)
$bitmap.Dispose()
﻿// Company Name Management
function loadCompanyName() {
    // Load from server config.ini
    fetch('/api/config')
        .then(response => response.json())
        .then(data => {
            const input = document.getElementById('company-name');
            if (input) {
                input.value = data.companyName || 'Mi Empresa';
            }
            
            // Load logo if path is provided
            if (data.logoPath !== undefined) {
                const logoImg = document.getElementById('company-logo');
                const logoPlaceholder = document.getElementById('logo-placeholder');
                if (logoImg) {
                    logoImg.src = '/api/logo';
                    logoImg.style.display = 'block';
                    if (logoPlaceholder) {
                        logoPlaceholder.style.display = 'none';
                    }
                }
            }

            // Store config for later use
            window.appConfig = data;
        })
        .catch(error => {
            console.error('Error loading company name:', error);
            // Fallback to default
            const input = document.getElementById('company-name');
            if (input) {
                input.value = 'Mi Empresa';
            }
        });
}


function saveCompanyName() {
    const input = document.getElementById('company-name');
    if (input && input.value.trim()) {
        const companyName = input.value.trim();
        
        // Save to server config.ini
        fetch('/api/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                companyName: companyName,
                logoPath: '' // Logo path can be added later
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Company name saved successfully');
            } else {
                console.error('Error saving company name:', data.error);
            }
        })
        .catch(error => {
            console.error('Error saving company name:', error);
        });
    }
}


function handleLogoUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
        showError('Por favor selecciona un archivo de imagen válido');
        return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
        showError('El archivo es demasiado grande. Máximo 5MB permitido');
        return;
    }

    const formData = new FormData();
    formData.append('logo', file);

    // Show loading
    const logoPreview = document.getElementById('settings-logo-preview');
    const logoPlaceholder = document.getElementById('settings-logo-placeholder');
    logoPlaceholder.innerHTML = 'Subiendo...';

    fetch('/api/logo', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update preview
            logoPreview.src = '/api/logo?t=' + Date.now(); // Cache busting
            logoPreview.style.display = 'block';
            logoPlaceholder.style.display = 'none';
            showSuccess('Logo subido exitosamente');
            
            // Update sidebar logo
            loadCompanyName();
        } else {
            showError('Error al subir el logo: ' + (data.error || 'Error desconocido'));
            logoPlaceholder.innerHTML = 'Sin logo';
        }
    })
    .catch(error => {
        console.error('Error uploading logo:', error);
        showError('Error al subir el logo');
        logoPlaceholder.innerHTML = 'Sin logo';
    });
}


// About Info
async function loadAboutInfo() {
    if (aboutInfoCache) {
        renderAboutInfo(aboutInfoCache);
        return;
    }

    try {
        const response = await fetch('/api/about');
        const data = await response.json();
        aboutInfoCache = data;
        renderAboutInfo(data);
    } catch (error) {
        console.error('Error loading about info:', error);
    }
}

function renderAboutInfo(data) {
    const versionBadge = document.getElementById('about-version');
    const developer = document.getElementById('about-developer');
    const releaseNotes = document.getElementById('about-release-notes');
    const licenseLink = document.getElementById('about-license');

    if (versionBadge) {
        versionBadge.textContent = `Versión: ${data.version || '-'}`;
    }
    if (developer) {
        developer.textContent = data.developer || '-';
    }
    if (releaseNotes) {
        if (data.hasReleaseNotes) {
            releaseNotes.href = data.releaseNotesUrl || '#';
            releaseNotes.style.pointerEvents = 'auto';
            releaseNotes.style.opacity = '1';
        } else {
            releaseNotes.href = '#';
            releaseNotes.style.pointerEvents = 'none';
            releaseNotes.style.opacity = '0.5';
        }
    }
    if (licenseLink) {
        if (data.hasLicense) {
            licenseLink.href = data.licenseUrl || '#';
            licenseLink.style.pointerEvents = 'auto';
            licenseLink.style.opacity = '1';
        } else {
            licenseLink.href = '#';
            licenseLink.style.pointerEvents = 'none';
            licenseLink.style.opacity = '0.5';
        }
    }
}

// Zoom Functions
function initZoom() {
    // Load saved zoom level from server config, fallback to localStorage
    fetch(`${API_BASE}/config`)
        .then(response => response.json())
        .then(data => {
            const serverZoom = data.zoom;
            if (serverZoom) {
                setZoom(serverZoom);
            } else {
                // Fallback to localStorage
                const savedZoom = localStorage.getItem('app-zoom-level');
                if (savedZoom) {
                    setZoom(savedZoom);
                } else {
                    setZoom(1.0); // Default zoom
                }
            }
        })
        .catch(error => {
            console.error('Error loading zoom from server:', error);
            // Fallback to localStorage
            const savedZoom = localStorage.getItem('app-zoom-level');
            if (savedZoom) {
                setZoom(savedZoom);
            } else {
                setZoom(1.0); // Default zoom
            }
        });

    // Set up event listener for zoom slider
    const zoomSlider = document.getElementById('zoom-level');
    if (zoomSlider) {
        zoomSlider.addEventListener('input', (e) => {
            const zoom = parseFloat(e.target.value);
            setZoom(zoom);
        });
    }
}

function setZoom(scale) {
    scale = Math.max(0.5, Math.min(2.0, parseFloat(scale))); // Clamp between 0.5 and 2.0
    
    // Update CSS custom properties
    document.documentElement.style.setProperty('--zoom-scale', scale);
    document.documentElement.style.setProperty('--font-scale', scale);
    document.documentElement.style.setProperty('--button-scale', scale);
    
    // Update UI elements
    const zoomSlider = document.getElementById('zoom-level');
    const zoomValue = document.getElementById('zoom-value');
    
    if (zoomSlider) zoomSlider.value = scale;
    if (zoomValue) zoomValue.textContent = Math.round(scale * 100) + '%';
    
    // Save to localStorage
    localStorage.setItem('app-zoom-level', scale);
}

function changeZoom(delta) {
    const currentZoom = parseFloat(document.getElementById('zoom-level').value) || 1.0;
    setZoom(currentZoom + delta);
}

function resetZoom() {
    setZoom(1.0);
    showSuccess('Zoom restablecido al 100%');
}


// Settings Functions (async - authoritative versions)
async function loadCompanySettings() {
    try {
        const response = await fetch(`${API_BASE}/config`);
        const data = await response.json();
        
        const nameInput = document.getElementById('settings-company-name');
        const addressInput = document.getElementById('settings-company-address');
        const phoneInput = document.getElementById('settings-company-phone');
        const emailInput = document.getElementById('settings-company-email');
        const websiteInput = document.getElementById('settings-company-website');
        const logoPreview = document.getElementById('settings-logo-preview');
        const logoPlaceholder = document.getElementById('settings-logo-placeholder');

        if (nameInput) nameInput.value = data.companyName || '';
        if (addressInput) addressInput.value = data.companyAddress || '';
        if (phoneInput) phoneInput.value = data.companyPhone || '';
        if (emailInput) emailInput.value = data.companyEmail || '';
        if (websiteInput) websiteInput.value = data.companyWebsite || '';

        // Handle logo
        if (logoPreview && logoPlaceholder) {
            if (data.logoPath) {
                logoPreview.src = '/api/logo';
                logoPreview.style.display = 'block';
                logoPlaceholder.style.display = 'none';
            } else {
                logoPreview.style.display = 'none';
                logoPlaceholder.style.display = 'flex';
            }
        }

        // Handle zoom
        const zoomSlider = document.getElementById('zoom-level');
        const zoomValue = document.getElementById('zoom-value');
        if (zoomSlider && data.zoom) {
            const zoom = parseFloat(data.zoom);
            zoomSlider.value = zoom;
            if (zoomValue) zoomValue.textContent = Math.round(zoom * 100) + '%';
            setZoom(zoom);
        }
    } catch (error) {
        console.error('Error loading company settings:', error);
        showError('Error al cargar la configuración');
    }
}

async function saveCompanySettings() {
    const zoomSlider = document.getElementById('zoom-level');
    const zoom = zoomSlider ? parseFloat(zoomSlider.value) : 1.0;

    const data = {
        companyName: document.getElementById('settings-company-name').value,
        companyAddress: document.getElementById('settings-company-address').value,
        companyPhone: document.getElementById('settings-company-phone').value,
        companyEmail: document.getElementById('settings-company-email').value,
        companyWebsite: document.getElementById('settings-company-website').value,
        zoom: zoom
    };
    
    try {
        const response = await fetch(`${API_BASE}/config`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Configuración guardada exitosamente');
            // Update the sidebar company name
            loadCompanyName();
        } else {
            showError('Error al guardar configuración: ' + (result.error || 'Error desconocido'));
        }
    } catch (error) {
        console.error('Error saving company settings:', error);
        showError('Error al guardar configuración');
    }
}



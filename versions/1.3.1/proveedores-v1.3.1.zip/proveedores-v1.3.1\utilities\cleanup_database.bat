@echo off
REM ============================================================
REM  Database Cleanup Utility - Windows Batch Wrapper
REM ============================================================

echo.
echo ============================================================
echo   DATABASE CLEANUP UTILITY
echo ============================================================
echo.

REM Set Python executable path (prefer venv if available)
set PYTHON_EXE=python
if exist "..\venv\Scripts\python.exe" (
    set PYTHON_EXE=..\venv\Scripts\python.exe
    echo [INFO] Usando Python del entorno virtual
    echo.
) else (
    REM Check if Python is available
    where python >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ERROR] Python no esta disponible
        echo.
        echo Por favor instala Python o ejecuta desde el entorno virtual:
        echo   ..\venv\Scripts\python.exe cleanup_database.py
        pause
        exit /b 1
    )
    echo [INFO] Usando Python del sistema
    echo.
)

REM Show menu
echo Selecciona una opcion:
echo.
echo   1. Ver estado actual de la base de datos
echo   2. Limpiar TODO (eliminar y recrear todas las tablas)
echo   3. Limpiar solo Proveedores
echo   4. Limpiar solo Contactos de Proveedores
echo   5. Limpiar solo Items/Materiales
echo   6. Limpiar solo Usuarios
echo   7. Limpiar solo Precios (relaciones proveedor-item)
echo   8. Limpiar solo Ordenes
echo   9. Salir
echo.

set /p choice="Opcion (1-9): "

if "%choice%"=="1" (
    %PYTHON_EXE% ..\scripts\cleanup_database.py --status
    pause
    exit /b 0
)

if "%choice%"=="2" (
    %PYTHON_EXE% ..\scripts\cleanup_database.py --all
    pause
    exit /b 0
)

if "%choice%"=="3" (
    %PYTHON_EXE% ..\scripts\cleanup_database.py --suppliers
    pause
    exit /b 0
)

if "%choice%"=="4" (
    %PYTHON_EXE% ..\scripts\cleanup_database.py --supplier-contacts
    pause
    exit /b 0
)

if "%choice%"=="5" (
    %PYTHON_EXE% ..\scripts\cleanup_database.py --items
    pause
    exit /b 0
)

if "%choice%"=="6" (
    %PYTHON_EXE% ..\scripts\cleanup_database.py --users
    pause
    exit /b 0
)

if "%choice%"=="7" (
    %PYTHON_EXE% ..\scripts\cleanup_database.py --prices
    pause
    exit /b 0
)

if "%choice%"=="8" (
    %PYTHON_EXE% ..\scripts\cleanup_database.py --orders
    pause
    exit /b 0
)

if "%choice%"=="9" (
    echo Saliendo...
    exit /b 0
)

echo.
echo Opcion invalida
pause

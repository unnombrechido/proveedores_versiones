@echo off
REM ============================================================
REM  Force Service Cleanup - Run as Administrator
REM ============================================================

echo.
echo ============================================================
echo   LIMPIEZA FORZADA DE SERVICIOS - ADMINISTRADOR
echo ============================================================
echo.
echo IMPORTANTE: Este script debe ejecutarse como ADMINISTRADOR
echo para poder remover servicios del sistema.
echo.

REM Check if running as administrator
net session >nul 2>&1
if %errorLevel% == 0 (
    echo [OK] Ejecutando como administrador
) else (
    echo [ERROR] Este script debe ejecutarse como ADMINISTRADOR
    echo.
    echo Para ejecutarlo como administrador:
    echo 1. Clic derecho en el archivo .bat
    echo 2. Seleccionar "Ejecutar como administrador"
    echo.
    pause
    exit /b 1
)

echo.
echo Deteniendo y removiendo servicio agresivamente...
echo.

REM Create temporary PowerShell script
set "PSSCRIPT=%TEMP%\cleanup_service.ps1"
echo Write-Host '=== LIMPIEZA FORZADA DEL SERVICIO ===' -ForegroundColor Red > "%PSSCRIPT%"
echo $serviceName = 'SistemaProveedores' >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo # 1. Force stop any running processes first >> "%PSSCRIPT%"
echo Write-Host '1. Forzando terminacion de procesos...' -ForegroundColor Yellow >> "%PSSCRIPT%"
echo $killed = 0 >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo # Kill all python processes >> "%PSSCRIPT%"
echo Get-Process -Name 'python' -ErrorAction SilentlyContinue ^| ForEach-Object { >> "%PSSCRIPT%"
echo     try { >> "%PSSCRIPT%"
echo         Write-Host "   Terminando Python PID: $($_.Id)" -ForegroundColor Red >> "%PSSCRIPT%"
echo         $_.Kill^(^) >> "%PSSCRIPT%"
echo         $killed++ >> "%PSSCRIPT%"
echo     } catch { >> "%PSSCRIPT%"
echo         Write-Host "   Error terminando $($_.Id): $($_.Exception.Message)" -ForegroundColor Yellow >> "%PSSCRIPT%"
echo     } >> "%PSSCRIPT%"
echo } >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo # Kill CMD processes related to the service >> "%PSSCRIPT%"
echo Get-Process -Name 'cmd' -ErrorAction SilentlyContinue ^| Where-Object { >> "%PSSCRIPT%"
echo     $_.CommandLine -like '*run.bat*' -or $_.CommandLine -like '*SistemaProveedores*' >> "%PSSCRIPT%"
echo } ^| ForEach-Object { >> "%PSSCRIPT%"
echo     try { >> "%PSSCRIPT%"
echo         Write-Host "   Terminando CMD PID: $($_.Id)" -ForegroundColor Red >> "%PSSCRIPT%"
echo         $_.Kill^(^) >> "%PSSCRIPT%"
echo         $killed++ >> "%PSSCRIPT%"
echo     } catch { >> "%PSSCRIPT%"
echo         Write-Host "   Error terminando $($_.Id): $($_.Exception.Message)" -ForegroundColor Yellow >> "%PSSCRIPT%"
echo     } >> "%PSSCRIPT%"
echo } >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo Write-Host "   Procesos terminados: $killed" -ForegroundColor Green >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo # 2. Force service removal >> "%PSSCRIPT%"
echo Write-Host '2. Removiendo servicio forzosamente...' -ForegroundColor Yellow >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo # Stop service >> "%PSSCRIPT%"
echo ^& sc.exe stop $serviceName 2^>$null >> "%PSSCRIPT%"
echo ^& sc.exe delete $serviceName 2^>$null >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo # NSSM removal >> "%PSSCRIPT%"
echo $nssmPath = Join-Path ^(Get-Location^) 'utilities\service\nssm.exe' >> "%PSSCRIPT%"
echo if ^(Test-Path $nssmPath^) { >> "%PSSCRIPT%"
echo     ^& $nssmPath stop $serviceName 2^>$null >> "%PSSCRIPT%"
echo     ^& $nssmPath remove $serviceName confirm 2^>$null >> "%PSSCRIPT%"
echo } >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo # 3. Registry cleanup >> "%PSSCRIPT%"
echo Write-Host '3. Limpieza de registro...' -ForegroundColor Yellow >> "%PSSCRIPT%"
echo $regPaths = @( >> "%PSSCRIPT%"
echo     'HKLM:\SYSTEM\CurrentControlSet\Services\SistemaProveedores', >> "%PSSCRIPT%"
echo     'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\SistemaProveedores' >> "%PSSCRIPT%"
echo ^) >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo foreach ^($regPath in $regPaths^) { >> "%PSSCRIPT%"
echo     try { >> "%PSSCRIPT%"
echo         if ^(Test-Path $regPath^) { >> "%PSSCRIPT%"
echo             Remove-Item -Path $regPath -Recurse -Force -ErrorAction Stop >> "%PSSCRIPT%"
echo             Write-Host "   Registro limpiado: $regPath" -ForegroundColor Green >> "%PSSCRIPT%"
echo         } >> "%PSSCRIPT%"
echo     } catch { >> "%PSSCRIPT%"
echo         Write-Host "   Error limpiando registro: $($_.Exception.Message)" -ForegroundColor Yellow >> "%PSSCRIPT%"
echo     } >> "%PSSCRIPT%"
echo } >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo # 4. Final verification >> "%PSSCRIPT%"
echo Write-Host '4. Verificacion final...' -ForegroundColor Yellow >> "%PSSCRIPT%"
echo Start-Sleep -Seconds 2 >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue >> "%PSSCRIPT%"
echo if ^($service^) { >> "%PSSCRIPT%"
echo     Write-Host "   [ADVERTENCIA] Servicio aun existe: $($service.Status)" -ForegroundColor Yellow >> "%PSSCRIPT%"
echo } else { >> "%PSSCRIPT%"
echo     Write-Host '   [OK] Servicio completamente removido' -ForegroundColor Green >> "%PSSCRIPT%"
echo } >> "%PSSCRIPT%"
echo. >> "%PSSCRIPT%"
echo Write-Host '' >> "%PSSCRIPT%"
echo Write-Host '=== LIMPIEZA COMPLETADA ===' -ForegroundColor Green >> "%PSSCRIPT%"
echo Write-Host 'Si aun ves la aplicacion en la barra de tareas:' -ForegroundColor Cyan >> "%PSSCRIPT%"
echo Write-Host '1. Presiona Ctrl+Shift+Esc para abrir el Administrador de Tareas' -ForegroundColor White >> "%PSSCRIPT%"
echo Write-Host '2. Ve a la pestaña Procesos' -ForegroundColor White >> "%PSSCRIPT%"
echo Write-Host '3. Busca procesos de Python o CMD relacionados' -ForegroundColor White >> "%PSSCRIPT%"
echo Write-Host '4. Finalizalos manualmente' -ForegroundColor White >> "%PSSCRIPT%"
echo Write-Host '5. Reinicia el Explorador de Windows si es necesario' -ForegroundColor White >> "%PSSCRIPT%"

REM Execute the PowerShell script
powershell -ExecutionPolicy Bypass -File "%PSSCRIPT%"

REM Clean up temporary file
del "%PSSCRIPT%" 2>nul

echo.
echo === LIMPIEZA COMPLETADA ===
echo.
echo Si el problema persiste:
echo 1. Reinicia tu computadora
echo 2. Vuelve a ejecutar el instalador
echo.
pause
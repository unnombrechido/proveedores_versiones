#define MyAppName "Sistema de Gestion de Proveedores"
#define MyAppVersion "1.3.1"
#define MyAppPublisher "Tu Empresa"
#define MyAppURL "https://github.com/unnombrechido/proveedores_versiones"
#define MyAppExeName "INSTALAR.bat"

[Setup]
AppId={{12345678-1234-1234-1234-123456789ABC}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={commonpf}\{#MyAppName}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
OutputDir=..
OutputBaseFilename=proveedores-v{#MyAppVersion}-iss-setup
SetupIconFile=icon.ico
Compression=lzma
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#MyAppExeName}
UninstallDisplayName={#MyAppName} {#MyAppVersion}
UsePreviousAppDir=no

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"
Name: "installservice"; Description: "Install Windows service"; GroupDescription: "Additional components"
Name: "createshortcuts"; Description: "Create shortcuts"; GroupDescription: "Additional components"

[Files]
Source: "setup-auto.bat"; DestDir: "{tmp}\installers"; Flags: ignoreversion
Source: "setup-auto.ps1"; DestDir: "{tmp}\installers"; Flags: ignoreversion
Source: "..\VERSION"; DestDir: "{tmp}\installers"; Flags: ignoreversion
Source: "modules\*"; DestDir: "{tmp}\installers\modules"; Flags: ignoreversion recursesubdirs
Source: "..\api\*"; DestDir: "{tmp}\source\api"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "*.pyc,*.pyo,__pycache__\,*.tmp,*.log"
Source: "..\bin\*"; DestDir: "{tmp}\source\bin"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "*.pyc,*.pyo,__pycache__\,*.tmp,*.log"
Source: "..\data\*"; DestDir: "{tmp}\source\data"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "*.pyc,*.pyo,__pycache__\,*.tmp,*.log,backups\,*.backup*"
Source: "..\docs\*"; DestDir: "{tmp}\source\docs"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\examples\*"; DestDir: "{tmp}\source\examples"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\scripts\*"; DestDir: "{tmp}\source\scripts"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\utilities\*"; DestDir: "{tmp}\source\utilities"; Flags: ignoreversion
Source: "..\requirements.txt"; DestDir: "{tmp}\source"; Flags: ignoreversion
Source: "..\VERSION"; DestDir: "{tmp}\source"; Flags: ignoreversion
Source: "..\LICENSE"; DestDir: "{tmp}\source"; Flags: ignoreversion
Source: "..\LEEME_PRIMERO.txt"; DestDir: "{tmp}\source"; Flags: ignoreversion
Source: "..\INSTALAR.bat"; DestDir: "{tmp}\source"; Flags: ignoreversion
Source: "..\start.bat"; DestDir: "{tmp}\source"; Flags: ignoreversion
Source: "..\test_migration.ps1"; DestDir: "{tmp}\source"; Flags: ignoreversion
Source: "..\config\config.ini"; DestDir: "{tmp}\source\config"; Flags: ignoreversion onlyifdoesntexist

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\icon.ico"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{commondesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon; IconFilename: "{app}\icon.ico"

[Run]
; Filename: "{tmp}\installers\setup-auto.ps1"; \
;   Parameters: "-InstallPath ""{app}"" -Silent{code:GetSetupParams}"; \
;   Verb: "RunWithPowerShell"; \
;   Flags: postinstall shellexec skipifsilent

[Code]
var
  IsUpgrade: Boolean;
  ExistingCompanyName: string;
  ExistingLogoPath: string;
  UpgradePage: TWizardPage;
  UpgradeCompanyEdit: TEdit;
  UpgradeLogoEdit: TEdit;
  UpgradeLogoButton: TButton;
  CompanyPage: TInputQueryWizardPage;
  LogoPage: TInputQueryWizardPage;

function ReadIniValueUTF8(FileName, Section, Key: string): string;
var
  Lines: TStringList;
  Line, CurSection, SearchKey, SearchSection: string;
  I, P: Integer;
  HasSection: Boolean;
begin
  Result := '';
  HasSection := Section <> '';
  SearchKey := Lowercase(Key);
  SearchSection := Lowercase(Section);

  if not FileExists(FileName) then Exit;

  Lines := TStringList.Create;
  try
    Lines.LoadFromFile(FileName);   // ← this is the correct method

    // Remove BOM if present
    if (Lines.Count > 0) and (Length(Lines[0]) >= 3) and
       (Lines[0][1] = #$EF) and (Lines[0][2] = #$BB) and (Lines[0][3] = #$BF) then
      Lines[0] := Copy(Lines[0], 4, MaxInt);

    CurSection := '';
    for I := 0 to Lines.Count - 1 do
    begin
      Line := Trim(Lines[I]);
      if (Line = '') or (Line[1] in [';', '#']) then Continue;

      if (Line[1] = '[') and (Line[Length(Line)] = ']') then
      begin
        CurSection := Lowercase(Copy(Line, 2, Length(Line)-2));
        Continue;
      end;

      if HasSection and (CurSection <> SearchSection) then Continue;

      P := Pos('=', Line);
      if P > 0 then
        if Lowercase(Trim(Copy(Line, 1, P-1))) = SearchKey then
        begin
          Result := Trim(Copy(Line, P+1, MaxInt));
          Exit;
        end;
    end;
  finally
    Lines.Free;
  end;
end;

procedure UpgradeLogoButtonClick(Sender: TObject);
var
  FileName: string;
begin
  if GetOpenFileName('Seleccionar logo', FileName, '', 'Images|*.png;*.jpg;*.jpeg', 'png') then
  begin
    // Directly set the logo edit text
    if Assigned(UpgradeLogoEdit) then
      UpgradeLogoEdit.Text := FileName;
  end;
end;

function GetSetupParams(Param: string): string;
begin
  Result := '';

  // Company and logo are passed via installer_params.txt, but include here too
  // as a fallback in case the file isn't read before the bat starts.
  if not IsUpgrade then
  begin
    if Assigned(CompanyPage) and (CompanyPage.Values[0] <> '') then
      Result := Result + ' -CompanyName "' + CompanyPage.Values[0] + '"';
    if Assigned(LogoPage) and (LogoPage.Values[0] <> '') then
      Result := Result + ' -LogoPath "' + LogoPage.Values[0] + '"';
  end
  else
  begin
    if Assigned(UpgradeCompanyEdit) and (UpgradeCompanyEdit.Text <> '') then
      Result := Result + ' -CompanyName "' + UpgradeCompanyEdit.Text + '"';
    if Assigned(UpgradeLogoEdit) and (UpgradeLogoEdit.Text <> '') then
      Result := Result + ' -LogoPath "' + UpgradeLogoEdit.Text + '"';
  end;

  // Upgrade vs fresh: setup-auto.ps1 accepts -Upgrade or -FreshInstall
  if IsUpgrade then
    Result := Result + ' -Upgrade'
  else
    Result := Result + ' -FreshInstall';

  // Service: default is install service; pass -NoService to skip
  if not WizardIsTaskSelected('installservice') then
    Result := Result + ' -NoService';

  // Shortcuts: default is create; pass -NoShortcuts to skip
  if not WizardIsTaskSelected('createshortcuts') then
    Result := Result + ' -NoShortcuts';
end;

function DetectExistingInstallation(Dir: string): Boolean;
var
  ConfigPath: string;
begin
  Log('DEBUG: DetectExistingInstallation called, Dir=' + Dir);
  IsUpgrade := False;
  ExistingCompanyName := '';
  ExistingLogoPath := '';

  // Old structure: config.ini + (app.py or desktop_app.py) + suppliers.db in root
  Log('DEBUG: Checking old structure:');
  if FileExists(Dir + 'config.ini') then
    Log('DEBUG:   ' + Dir + 'config.ini exists? True')
  else
    Log('DEBUG:   ' + Dir + 'config.ini exists? False');
  if FileExists(Dir + 'suppliers.db') then
    Log('DEBUG:   ' + Dir + 'suppliers.db exists? True')
  else
    Log('DEBUG:   ' + Dir + 'suppliers.db exists? False');
  if FileExists(Dir + 'app.py') then
    Log('DEBUG:   ' + Dir + 'app.py exists? True')
  else
    Log('DEBUG:   ' + Dir + 'app.py exists? False');
  if FileExists(Dir + 'desktop_app.py') then
    Log('DEBUG:   ' + Dir + 'desktop_app.py exists? True')
  else
    Log('DEBUG:   ' + Dir + 'desktop_app.py exists? False');
  if FileExists(Dir + 'config.ini') and
     FileExists(Dir + 'suppliers.db') and
     (FileExists(Dir + 'app.py') or FileExists(Dir + 'desktop_app.py')) then
  begin
    Log('DEBUG: Old structure detected');
    IsUpgrade := True;
    ConfigPath := Dir + 'config.ini';
    ExistingCompanyName := GetIniString('COMPANY', 'company_name', '', ConfigPath);
    if ExistingCompanyName = '' then
      ExistingCompanyName := GetIniString('', 'company_name', '', ConfigPath);
    ExistingLogoPath := GetIniString('COMPANY', 'logo_path', '', ConfigPath);
    if ExistingLogoPath = '' then
      ExistingLogoPath := GetIniString('', 'logo_path', '', ConfigPath);
  end;

  // New structure
  if not IsUpgrade then
  begin
    Log('DEBUG: Checking new structure:');
    if FileExists(Dir + 'config\config.ini') then
      Log('DEBUG:   ' + Dir + 'config\\config.ini exists? True')
    else
      Log('DEBUG:   ' + Dir + 'config\\config.ini exists? False');
    if FileExists(Dir + 'data\suppliers.db') then
      Log('DEBUG:   ' + Dir + 'data\\suppliers.db exists? True')
    else
      Log('DEBUG:   ' + Dir + 'data\\suppliers.db exists? False');
    if FileExists(Dir + 'api\app.py') then
      Log('DEBUG:   ' + Dir + 'api\\app.py exists? True')
    else
      Log('DEBUG:   ' + Dir + 'api\\app.py exists? False');
    if FileExists(Dir + 'api\desktop_app.py') then
      Log('DEBUG:   ' + Dir + 'api\\desktop_app.py exists? True')
    else
      Log('DEBUG:   ' + Dir + 'api\\desktop_app.py exists? False');
    if FileExists(Dir + 'config\config.ini') or
       FileExists(Dir + 'data\suppliers.db') or
       FileExists(Dir + 'api\app.py') or
       FileExists(Dir + 'api\desktop_app.py') then
    begin
      Log('DEBUG: New structure detected');
      IsUpgrade := True;
      ConfigPath := Dir + 'config\config.ini';
      if FileExists(ConfigPath) then
      begin
        ExistingCompanyName := GetIniString('COMPANY', 'company_name', '', ConfigPath);
        ExistingLogoPath := GetIniString('COMPANY', 'logo_path', '', ConfigPath);
      end;
    end;
  end;

  if IsUpgrade then
    Log('DEBUG: IsUpgrade=True')
  else
    Log('DEBUG: IsUpgrade=False');
  Log('DEBUG: ExistingCompanyName=' + ExistingCompanyName);
  Log('DEBUG: ExistingLogoPath=' + ExistingLogoPath);

  Result := IsUpgrade;
end;
function NextButtonClick(CurPageID: Integer): Boolean;
var
  Dir: string;
  ConfigPath: string;
begin
  Result := True;

  if CurPageID <> wpSelectDir then
    Exit;

  Dir := AddBackslash(WizardDirValue);
  Log('DEBUG: Checking directory: ' + Dir);

  IsUpgrade := False;
  ExistingCompanyName := '';
  ExistingLogoPath := '';


  // Detect config file location and structure
  ConfigPath := '';
  // Old structure (v0.1, v1.0): config.ini in root, keys are COMPANY_NAME, LOGO_PATH
  if FileExists(Dir + 'config.ini') and
     FileExists(Dir + 'suppliers.db') and
     (FileExists(Dir + 'app.py') or FileExists(Dir + 'desktop_app.py')) then
  begin
    IsUpgrade := True;
    ConfigPath := Dir + 'config.ini';
    Log('DEBUG: Old structure detected');
  end
  // New structure (v1.2+, v1.3+): config/config.ini, keys under [COMPANY]
  else if FileExists(Dir + 'config\config.ini') or
          FileExists(Dir + 'data\suppliers.db') or
          FileExists(Dir + 'api\app.py') or
          FileExists(Dir + 'api\desktop_app.py') then
  begin
    IsUpgrade := True;
    ConfigPath := Dir + 'config\config.ini';
    Log('DEBUG: New structure detected');
  end;

  // Try to read company/logo if we have a config file
  if IsUpgrade and (ConfigPath <> '') then
  begin
    Log('DEBUG: Will check config file: ' + ConfigPath);
    if FileExists(ConfigPath) then
    begin
      Log('DEBUG: Config file exists, reading values...');
      ExistingCompanyName := GetIniString('COMPANY', 'company_name', '', ConfigPath);
      Log('DEBUG: [COMPANY]/company_name = ' + ExistingCompanyName);
      if ExistingCompanyName = '' then
      begin
        ExistingCompanyName := ReadIniValueUTF8(ConfigPath, 'COMPANY', 'company_name');
        Log('DEBUG: [COMPANY]/company_name (UTF8) = ' + ExistingCompanyName);
      end;
      ExistingLogoPath := GetIniString('COMPANY', 'logo_path', '', ConfigPath);
      Log('DEBUG: [COMPANY]/logo_path = ' + ExistingLogoPath);
      if ExistingLogoPath = '' then
      begin
        ExistingLogoPath := ReadIniValueUTF8(ConfigPath, 'COMPANY', 'logo_path');
        Log('DEBUG: [COMPANY]/logo_path (UTF8) = ' + ExistingLogoPath);
      end;

      if ExistingCompanyName = '' then
      begin
        ExistingCompanyName := GetIniString('', 'COMPANY_NAME', '', ConfigPath);
        Log('DEBUG: COMPANY_NAME (no section) = ' + ExistingCompanyName);
        if ExistingCompanyName = '' then
        begin
          ExistingCompanyName := ReadIniValueUTF8(ConfigPath, '', 'COMPANY_NAME');
          Log('DEBUG: COMPANY_NAME (no section, UTF8) = ' + ExistingCompanyName);
        end;
      end;
      if ExistingLogoPath = '' then
      begin
        ExistingLogoPath := GetIniString('', 'LOGO_PATH', '', ConfigPath);
        Log('DEBUG: LOGO_PATH (no section) = ' + ExistingLogoPath);
        if ExistingLogoPath = '' then
        begin
          ExistingLogoPath := ReadIniValueUTF8(ConfigPath, '', 'LOGO_PATH');
          Log('DEBUG: LOGO_PATH (no section, UTF8) = ' + ExistingLogoPath);
        end;
      end;

      if ExistingCompanyName = '' then
      begin
        ExistingCompanyName := GetIniString('', 'company_name', '', ConfigPath);
        Log('DEBUG: company_name (no section) = ' + ExistingCompanyName);
        if ExistingCompanyName = '' then
        begin
          ExistingCompanyName := ReadIniValueUTF8(ConfigPath, '', 'company_name');
          Log('DEBUG: company_name (no section, UTF8) = ' + ExistingCompanyName);
        end;
      end;
      if ExistingLogoPath = '' then
      begin
        ExistingLogoPath := GetIniString('', 'logo_path', '', ConfigPath);
        Log('DEBUG: logo_path (no section) = ' + ExistingLogoPath);
        if ExistingLogoPath = '' then
        begin
          ExistingLogoPath := ReadIniValueUTF8(ConfigPath, '', 'logo_path');
          Log('DEBUG: logo_path (no section, UTF8) = ' + ExistingLogoPath);
        end;
      end;
      Log('DEBUG: Final ExistingCompanyName=' + ExistingCompanyName);
      Log('DEBUG: Final ExistingLogoPath=' + ExistingLogoPath);
    end
    else
      Log('DEBUG: Config file does NOT exist: ' + ConfigPath);
  end
  else if IsUpgrade then
    Log('DEBUG: Upgrade detected (files found), but no config.ini to read values from');

  // Pages are created only ONCE — here in NextButtonClick when user clicks Next on SelectDir
  if IsUpgrade and (not Assigned(UpgradePage)) then
  begin
    Log('DEBUG: Creating upgrade config page');
    UpgradePage := CreateCustomPage(wpSelectDir, 'Instalación Existente', 'Configuración Actual');

    with TLabel.Create(UpgradePage) do begin
      Caption := 'Se detectó instalación previa. Puedes mantener o cambiar:';
      Left := 0; Top := 0; AutoSize := True; Parent := UpgradePage.Surface;
    end;

    with TLabel.Create(UpgradePage) do begin
      Caption := 'Empresa:'; Left := 0; Top := 40; Parent := UpgradePage.Surface;
    end;

    UpgradeCompanyEdit := TEdit.Create(UpgradePage);
    UpgradeCompanyEdit.Text := ExistingCompanyName;
    UpgradeCompanyEdit.Left := 0; UpgradeCompanyEdit.Top := 60;
    UpgradeCompanyEdit.Width := UpgradePage.Surface.Width - 10;
    UpgradeCompanyEdit.Parent := UpgradePage.Surface;

    with TLabel.Create(UpgradePage) do begin
      Caption := 'Logo:'; Left := 0; Top := 90; Parent := UpgradePage.Surface;
    end;

    UpgradeLogoEdit := TEdit.Create(UpgradePage);
    UpgradeLogoEdit.Text := ExistingLogoPath;
    UpgradeLogoEdit.Left := 0; UpgradeLogoEdit.Top := 110;
    UpgradeLogoEdit.Width := UpgradePage.Surface.Width - 90;
    UpgradeLogoEdit.Parent := UpgradePage.Surface;

    UpgradeLogoButton := TButton.Create(UpgradePage);
    UpgradeLogoButton.Caption := '...';
    UpgradeLogoButton.Left := UpgradeLogoEdit.Left + UpgradeLogoEdit.Width + 8;
    UpgradeLogoButton.Top := UpgradeLogoEdit.Top - 2;
    UpgradeLogoButton.Width := 60;
    UpgradeLogoButton.OnClick := @UpgradeLogoButtonClick;
    UpgradeLogoButton.Parent := UpgradePage.Surface;
  end
  else
  begin
    Log('DEBUG: Creating fresh install config pages');
    CompanyPage := CreateInputQueryPage(wpSelectDir,
      'Datos de la Empresa', 'Nombre de la empresa (opcional):', '');
    CompanyPage.Add('', False);

    LogoPage := CreateInputQueryPage(CompanyPage.ID,
      'Logo', 'Ruta del archivo logo (opcional):', '');
    LogoPage.Add('', False);
  end;
end;

// ---------------------------------------------------------------------------
// RunConfigScriptOnInstall
// Launches setup-auto.bat asynchronously (ewNoWait) so the UI stays
// responsive.  setup-auto.ps1 uses Start-Transcript to write every output
// line to installer_log.txt as it runs.  We poll that file every 300 ms,
// appending new lines to the built-in DetailsMemo so the user sees live
// progress.  When setup-auto.bat finishes it writes installer_done.txt
// containing the exit code; that is our signal to stop polling.
// ---------------------------------------------------------------------------
var
  LogMemo: TMemo;

procedure InitializeWizard;
begin
  // Create a scrolling memo that fills the inner page area.
  // Shown only during the install / post-install step so the user can
  // read real-time output from setup-auto.bat as it runs.
  LogMemo := TMemo.Create(WizardForm);
  LogMemo.Parent     := WizardForm.InnerPage;
  LogMemo.Align      := alClient;
  LogMemo.ScrollBars := ssVertical;
  LogMemo.ReadOnly   := True;
  LogMemo.Font.Name  := 'Courier New';
  LogMemo.Font.Size  := 8;
  LogMemo.Visible    := False;
end;

procedure RunConfigScriptOnInstall;
var
  Memo: TMemo;
  LogFilePath: string;
  DoneFilePath: string;
  LaunchBat: string;
  LogLines: TArrayOfString;
  DoneContent: string;
  LastLineCount: Integer;
  PollCount: Integer;
  I: Integer;
  ResultCode: Integer;
begin
  Memo := LogMemo;
  Memo.Visible := True;
  LogFilePath  := ExpandConstant('{tmp}\installers\installer_log.txt');
  DoneFilePath := ExpandConstant('{tmp}\installers\installer_done.txt');
  LaunchBat    := ExpandConstant('{tmp}\installers\__launch.bat');

  // Clean up from any previous run
  DeleteFile(LogFilePath);
  DeleteFile(DoneFilePath);
  DeleteFile(LaunchBat);

  Memo.Lines.Add('');
  Memo.Lines.Add('============================================================');
  Memo.Lines.Add('  Configurando el sistema - salida en tiempo real');
  Memo.Lines.Add('============================================================');
  Memo.Lines.Add('');

  // Write a tiny launcher bat so quoting inside paths with spaces is trivial
  SaveStringToFile(LaunchBat,
    '@echo off' + #13#10 +
    'cd /d "%~dp0"' + #13#10 +
    'call "%~dp0setup-auto.bat"' +
    ' -InstallPath "' + ExpandConstant('{app}') + '"' +
    ' -Silent' + GetSetupParams('') + #13#10,
    False);

  // Launch asynchronously — UI stays unfrozen while bat runs
  Exec(ExpandConstant('{sys}\cmd.exe'),
    '/c "' + LaunchBat + '"',
    ExpandConstant('{tmp}\installers'),
    SW_HIDE, ewNoWait, ResultCode);

  // --- Live-output poll loop ---
  // setup-auto.ps1 opens Start-Transcript to installer_log.txt so every
  // Write-Host line lands there immediately.  We re-read the file on each
  // tick and append only the new lines (tracked by LastLineCount).
  LastLineCount := 0;
  PollCount     := 0;

  repeat
    Sleep(300);
    WizardForm.Refresh;   // keep wizard window painting
    Inc(PollCount);

    if LoadStringsFromFile(LogFilePath, LogLines) then
    begin
      if Length(LogLines) > LastLineCount then
      begin
        for I := LastLineCount to High(LogLines) do
          Memo.Lines.Add(LogLines[I]);
        LastLineCount := Length(LogLines);
        // Scroll to last line (EM_LINESCROLL = $B6)
        SendMessage(Memo.Handle, $B6, 0, Memo.Lines.Count);
      end;
    end;

  until FileExists(DoneFilePath) or (PollCount > 2000); // ~10-min safety cap

  // One final read to catch any lines written between last poll and done-file
  if LoadStringsFromFile(LogFilePath, LogLines) then
    for I := LastLineCount to High(LogLines) do
      Memo.Lines.Add(LogLines[I]);

  // --- Report final status ---
  Memo.Lines.Add('');
  if FileExists(DoneFilePath) then
  begin
    // Reuse LogLines to read the single-line exit code written by setup-auto.bat
    if LoadStringsFromFile(DoneFilePath, LogLines) and (GetArrayLength(LogLines) > 0) then
      DoneContent := Trim(LogLines[0])
    else
      DoneContent := '1';   // if unreadable, treat as error
    if DoneContent = '0' then
    begin
      Memo.Lines.Add('============================================================');
      Memo.Lines.Add('  [OK] Configuracion completada exitosamente.');
      Memo.Lines.Add('============================================================');
    end
    else
    begin
      Memo.Lines.Add('============================================================');
      Memo.Lines.Add('  [ERROR] La configuracion termino con codigo: ' + DoneContent);
      Memo.Lines.Add('============================================================');
      MsgBox(
        'La configuracion del sistema termino con errores (codigo: ' + DoneContent + ').' + #13#10 +
        'La aplicacion puede requerir configuracion manual.' + #13#10 +
        'Log completo: ' + LogFilePath,
        mbError, MB_OK);
    end;
  end
  else
  begin
    Memo.Lines.Add('  [TIMEOUT] La configuracion tardo mas de 10 minutos.');
    Memo.Lines.Add('  Verifique el estado de la aplicacion manualmente.');
  end;

  SendMessage(Memo.Handle, $B6, 0, Memo.Lines.Count);
  DeleteFile(LaunchBat);
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    RunConfigScriptOnInstall;
    WizardForm.FinishedLabel.Caption :=
      'Instalacion completada.' + #13#10 +
      'Haga clic en Finalizar para cerrar.';
  end;
end;

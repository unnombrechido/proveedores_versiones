@echo off
REM ============================================================
REM  Installation Cleanup Utility - Batch Wrapper
REM ============================================================

cd /d "%~dp0\.."
powershell -ExecutionPolicy Bypass -File "scripts\cleanup_installation.ps1" -RemoveBackups %*
pause

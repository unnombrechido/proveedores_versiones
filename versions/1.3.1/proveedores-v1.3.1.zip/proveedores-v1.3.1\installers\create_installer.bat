@echo off
setlocal EnableDelayedExpansion
REM ============================================================
REM  Crear Instalador Windows (Inno Setup)
REM ============================================================

echo.
echo ========================================================
echo   CREAR INSTALADOR WINDOWS
echo   Sistema de Proveedores v1.3.1
echo ========================================================
echo.

REM Check if Inno Setup is installed
set "ISCC_EXE="
where iscc >nul 2>&1
if %errorlevel%==0 (
    set "ISCC_EXE=iscc"
) else (
    REM Try common install locations
    if exist "C:\Program Files (x86)\Inno Setup 6\iscc.exe" (
        set "ISCC_EXE=C:\Program Files (x86)\Inno Setup 6\iscc.exe"
    ) else if exist "C:\Program Files\Inno Setup 6\iscc.exe" (
        set "ISCC_EXE=C:\Program Files\Inno Setup 6\iscc.exe"
    ) else if exist "C:\Program Files (x86)\Inno Setup 5\iscc.exe" (
        set "ISCC_EXE=C:\Program Files (x86)\Inno Setup 5\iscc.exe"
    ) else if exist "C:\Program Files\Inno Setup 5\iscc.exe" (
        set "ISCC_EXE=C:\Program Files\Inno Setup 5\iscc.exe"
    ) else if exist "%~dp0tools\iscc.exe" (
        set "ISCC_EXE=%~dp0tools\iscc.exe"
    )
)

if "%ISCC_EXE%"=="" goto :no_inno_setup

goto :inno_setup_ok

:no_inno_setup
echo [ERROR] Inno Setup Compiler (iscc.exe) no encontrado
echo.
echo Para crear instaladores Windows, necesitas instalar Inno Setup:
echo https://jrsoftware.org/isdl.php
echo.
echo O usar el portable version en: installers\tools\
echo.
pause
exit /b 1

:inno_setup_ok

REM Read version from VERSION file
set "VERSION="
for /f "usebackq delims=" %%v in ("%~dp0..\VERSION") do set "VERSION=%%v"
if "%VERSION%"=="" set "VERSION=1.3.1"
REM Trim whitespace
for /l %%a in (1,1,31) do if "!VERSION:~-1!"==" " set "VERSION=!VERSION:~0,-1!"

echo [INFO] Creando instalador para version %VERSION%
echo.

REM Copy proper icon if it doesn't exist
if not exist "%~dp0icon.ico" (
    if exist "%~dp0..\icon.ico" (
        echo [INFO] Copiando icono desde el repositorio...
        copy "%~dp0..\icon.ico" "%~dp0icon.ico" >nul
        if exist "%~dp0icon.ico" (
            echo [OK] Icono copiado
        ) else (
            echo [WARNING] No se pudo copiar icono del repositorio, intentando favicon_io...
            goto :try_favicon
        )
    ) else (
        :try_favicon
        if exist "%~dp0..\favicon_io\favicon.ico" (
            echo [INFO] Copiando icono desde favicon_io...
            copy "%~dp0..\favicon_io\favicon.ico" "%~dp0icon.ico" >nul
            if exist "%~dp0icon.ico" (
                echo [OK] Icono copiado
            ) else (
                echo [WARNING] No se pudo copiar icono, creando uno basico...
                powershell -ExecutionPolicy Bypass -File "%~dp0create_icon.ps1" -iconPath "%~dp0icon.ico" 2>nul
            )
        ) else (
            echo [INFO] Creando icono predeterminado...
            powershell -ExecutionPolicy Bypass -File "%~dp0create_icon.ps1" -iconPath "%~dp0icon.ico" 2>nul
            if exist "%~dp0icon.ico" (
                echo [OK] Icono creado
            ) else (
                echo [WARNING] No se pudo crear icono, el instalador continuara sin el
            )
        )
    )
)

REM Compile the installer
echo [INFO] Compilando instalador...
cd /d "%~dp0"
"%ISCC_EXE%" /DMyAppVersion=%VERSION% "proveedores.iss"

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Fallo al compilar el instalador
    pause
    exit /b 1
)

echo.
echo ========================================================
echo   INSTALADOR CREADO EXITOSAMENTE
echo ========================================================
echo.
echo Archivo: proveedores-v%VERSION%-setup.exe
echo Ubicacion: %~dp0..\proveedores-v%VERSION%-setup.exe
echo.
echo El instalador incluye:
echo - Interfaz grafica moderna
echo - Opcion de instalar para todos los usuarios
echo - Icono en el escritorio (opcional)
echo - Desinstalador integrado
echo.
pause
exit /b 0
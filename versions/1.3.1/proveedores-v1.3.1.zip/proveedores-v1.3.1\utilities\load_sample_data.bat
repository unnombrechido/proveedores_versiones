@echo off
REM ============================================================
REM  Load Sample Data - Windows Batch Wrapper
REM ============================================================

echo.
echo ============================================================
echo   CARGAR DATOS DE EJEMPLO
echo ============================================================
echo.

REM Set Python executable path (prefer venv if available)
set PYTHON_EXE=python
if exist "..\venv\Scripts\python.exe" (
    set PYTHON_EXE=..\venv\Scripts\python.exe
    echo [INFO] Usando Python del entorno virtual
    echo.
) else (
    REM Check if Python is available
    where python >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ERROR] Python no esta disponible
        echo.
        echo Por favor instala Python o ejecuta desde el entorno virtual:
        echo   ..\venv\Scripts\python.exe load_sample_data.py
        pause
        exit /b 1
    )
    echo [INFO] Usando Python del sistema
    echo.
)

REM Show menu
echo Selecciona una opcion:
echo.
echo   1. Cargar TODOS los datos de ejemplo
echo   2. Cargar solo Proveedores (9 proveedores)
echo   3. Cargar solo Items con precios (58 items)
echo   4. LIMPIAR base de datos y cargar todo
echo   5. Salir
echo.

set /p choice="Opcion (1-5): "

if "%choice%"=="1" (
    echo.
    echo Cargando todos los datos de ejemplo...
    echo.
    %PYTHON_EXE% ..\scripts\load_sample_data.py
    pause
    exit /b 0
)

if "%choice%"=="2" (
    echo.
    echo Cargando solo proveedores...
    echo.
    %PYTHON_EXE% ..\scripts\load_sample_data.py --suppliers-only
    pause
    exit /b 0
)

if "%choice%"=="3" (
    echo.
    echo Cargando solo items con precios...
    echo.
    %PYTHON_EXE% ..\scripts\load_sample_data.py --items-only
    pause
    exit /b 0
)

if "%choice%"=="4" (
    echo.
    echo ============================================================
    echo   ADVERTENCIA: Esto eliminara todos los datos existentes!
    echo ============================================================
    echo.
    set /p confirm="Estas seguro? (S/N): "
    if /i "%confirm%"=="S" (
        echo.
        echo Limpiando base de datos y cargando datos de ejemplo...
        echo.
        %PYTHON_EXE% ..\scripts\load_sample_data.py --clean
        pause
        exit /b 0
    ) else (
        echo.
        echo Operacion cancelada
        pause
        exit /b 0
    )
)

if "%choice%"=="5" (
    echo Saliendo...
    exit /b 0
)

echo.
echo Opcion invalida
pause

@echo off
echo ======================================
echo Restore Database from Backup
echo ======================================
echo.
echo This will restore the database from the latest backup.
echo WARNING: This will overwrite the current database!
echo.
pause

cd /d "%~dp0\.."

echo.
echo Looking for backup files...
for /f "delims=" %%i in ('dir /b /od suppliers.db.backup_* 2^>nul') do set LATEST_BACKUP=%%i

if "%LATEST_BACKUP%"=="" (
    echo No backup files found!
    pause
    exit /b 1
)

echo Latest backup: %LATEST_BACKUP%
echo.
echo Copying backup to suppliers.db...
copy /Y "%LATEST_BACKUP%" suppliers.db

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ======================================
    echo Database restored successfully!
    echo ======================================
) else (
    echo.
    echo ERROR: Failed to restore database
)

echo.
pause

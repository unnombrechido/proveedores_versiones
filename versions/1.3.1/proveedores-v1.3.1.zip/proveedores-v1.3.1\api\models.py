from sqlalchemy import Column, Integer, String, Float, DateTime, Text, ForeignKey, Table, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime
try:
    from .database import Base
except ImportError:
    from database import Base  # standalone script context
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

# Association table for many-to-many relationship between suppliers and items
supplier_items = Table('supplier_items', Base.metadata,
    Column('supplier_id', Integer, ForeignKey('suppliers.id'), primary_key=True),
    Column('item_id', Integer, ForeignKey('items.id'), primary_key=True),
    Column('price', Float),
    Column('supplier_item_code', String(100)),
    Column('lead_time_days', Integer),
    Column('minimum_order_quantity', Integer),
    Column('notes', Text),
    Column('created_at', DateTime, default=datetime.utcnow),
    Column('updated_at', DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
)

class Item(Base):
    """Item/Supply model for storing product information"""
    __tablename__ = 'items'
    
    id = Column(Integer, primary_key=True, index=True)
    item_code = Column(String(100), unique=True, nullable=False, index=True)
    name = Column(String(200), nullable=False, index=True)
    description = Column(Text)
    category_id = Column(Integer, ForeignKey('item_categories.id'), index=True)
    unit_id = Column(Integer, ForeignKey('units_of_measure.id'))
    condition_id = Column(Integer, ForeignKey('item_conditions.id'))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    # Relationships
    category = relationship('ItemCategory')
    unit = relationship('UnitOfMeasure')
    condition = relationship('ItemCondition')
    suppliers = relationship('Supplier', secondary=supplier_items, back_populates='items')
    
    def to_dict(self, include_suppliers=False):
        """Convert item object to dictionary"""
        result = {
            'id': self.id,
            'item_code': self.item_code,
            'name': self.name,
            'description': self.description,
            'category_id': self.category_id,
            'category': self.category.name_es if self.category else None,
            'unit_id': self.unit_id,
            'unit': self.unit.symbol if self.unit else None,
            'condition_id': self.condition_id,
            'condition': self.condition.name_es if self.condition else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }
        if include_suppliers:
            result['suppliers'] = [s.to_dict() for s in self.suppliers]
        return result

class Supplier(Base):
    """Supplier model for storing supplier information"""
    __tablename__ = 'suppliers'
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False, index=True)
    contact_person = Column(String(200))  # Legacy field, will be migrated
    email = Column(String(200), index=True)  # Legacy field, will be migrated
    phone = Column(String(50))  # Legacy field, will be migrated
    address = Column(Text)
    city = Column(String(100))
    state_id = Column(Integer, ForeignKey('states.id'))
    country_id = Column(Integer, ForeignKey('countries.id'))
    tax_id = Column(String(50), unique=True, index=True)
    category_id = Column(Integer, ForeignKey('supplier_categories.id'), index=True)
    rating = Column(Float, default=0.0)
    payment_term_id = Column(Integer, ForeignKey('payment_terms.id'))
    notes = Column(Text)
    active = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    # Relationships
    items = relationship('Item', secondary=supplier_items, back_populates='suppliers')
    contacts = relationship('SupplierContact', back_populates='supplier', cascade='all, delete-orphan')
    category = relationship('SupplierCategory')
    payment_term = relationship('PaymentTerm')
    country = relationship('Country')
    state = relationship('State')
    
    def to_dict(self, include_items=False, include_contacts=False):
        """Convert supplier object to dictionary"""
        result = {
            'id': self.id,
            'name': self.name,
            'contact_person': self.contact_person,
            'email': self.email,
            'phone': self.phone,
            'address': self.address,
            'city': self.city,
            'state_id': self.state_id,
            'state': self.state.name_es if self.state else None,
            'country_id': self.country_id,
            'country': self.country.name_es if self.country else None,
            'tax_id': self.tax_id,
            'category_id': self.category_id,
            'category': self.category.name_es if self.category else None,
            'rating': self.rating,
            'payment_term_id': self.payment_term_id,
            'payment_terms': self.payment_term.name_es if self.payment_term else None,
            'notes': self.notes,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }
        if include_items:
            result['items'] = [i.to_dict() for i in self.items]
        if include_contacts:
            result['contacts'] = [c.to_dict() for c in self.contacts]
        return result

class SupplierContact(Base):
    """Contact information for suppliers"""
    __tablename__ = 'supplier_contacts'
    
    id = Column(Integer, primary_key=True, index=True)
    supplier_id = Column(Integer, ForeignKey('suppliers.id'), nullable=False, index=True)
    contact_name = Column(String(200), nullable=False)
    position = Column(String(100))  # Role/title (e.g., "Gerente de Ventas", "Compras")
    phone = Column(String(50))
    email = Column(String(200))
    is_primary = Column(Integer, default=0)  # Boolean flag for primary contact
    contact_type_id = Column(Integer, ForeignKey('contact_types.id'), index=True)
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    # Relationship back to supplier
    supplier = relationship('Supplier', back_populates='contacts')
    # Relationship to contact type
    contact_type_rel = relationship('ContactType')
    
    def to_dict(self):
        """Convert contact object to dictionary"""
        return {
            'id': self.id,
            'supplier_id': self.supplier_id,
            'contact_name': self.contact_name,
            'position': self.position,
            'phone': self.phone,
            'email': self.email,
            'is_primary': bool(self.is_primary),
            'contact_type_id': self.contact_type_id,
            'contact_type': self.contact_type_rel.name_es if self.contact_type_rel else None,
            'contact_type_code': self.contact_type_rel.code if self.contact_type_rel else None,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class Order(Base):
    """Order model for storing order information"""
    __tablename__ = 'orders'
    
    id = Column(Integer, primary_key=True, index=True)
    order_number = Column(String(50), unique=True, nullable=False, index=True)
    supplier_id = Column(Integer, nullable=False, index=True)
    supplier_name = Column(String(200))
    order_date = Column(DateTime, default=datetime.utcnow)
    delivery_date = Column(DateTime)
    status_id = Column(Integer, ForeignKey('order_statuses.id'), index=True)
    total_amount = Column(Float, default=0.0)
    items = Column(Text)
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    # Relationships
    status = relationship('OrderStatus')
    
    def to_dict(self):
        """Convert order object to dictionary"""
        return {
            'id': self.id,
            'order_number': self.order_number,
            'supplier_id': self.supplier_id,
            'supplier_name': self.supplier_name,
            'order_date': self.order_date.isoformat() if self.order_date else None,
            'delivery_date': self.delivery_date.isoformat() if self.delivery_date else None,
            'status_id': self.status_id,
            'status': self.status.name_es if self.status else None,
            'status_code': self.status.code if self.status else None,
            'status_code': self.status.code if self.status else None,
            'total_amount': self.total_amount,
            'items': self.items,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

# List of Values (LOV) Tables for configurable dropdowns

class ItemCategory(Base):
    """Categorías de artículos"""
    __tablename__ = 'item_categories'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    name_es = Column(String(200), nullable=False)
    name_en = Column(String(200))
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class SupplierCategory(Base):
    """Categorías de proveedores"""
    __tablename__ = 'supplier_categories'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    name_es = Column(String(200), nullable=False)
    name_en = Column(String(200))
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class UnitOfMeasure(Base):
    """Unidades de medida (UDM)"""
    __tablename__ = 'units_of_measure'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(20), unique=True, nullable=False, index=True)
    name_es = Column(String(100), nullable=False)
    name_en = Column(String(100))
    symbol = Column(String(10))  # e.g., kg, pcs, L
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'symbol': self.symbol,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class ItemCondition(Base):
    """Estados / Condiciones del artículo"""
    __tablename__ = 'item_conditions'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    name_es = Column(String(100), nullable=False)
    name_en = Column(String(100))
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class Location(Base):
    """Ubicaciones / Almacenes / Zonas / Estanterías"""
    __tablename__ = 'locations'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    name_es = Column(String(200), nullable=False)
    name_en = Column(String(200))
    type = Column(String(50))  # warehouse, zone, shelf, etc.
    parent_id = Column(Integer, ForeignKey('locations.id'), nullable=True)
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    # Self-referential relationship for hierarchy
    parent = relationship('Location', remote_side=[id], backref='children')
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'type': self.type,
            'parent_id': self.parent_id,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class OrderStatus(Base):
    """Estados de orden de compra"""
    __tablename__ = 'order_statuses'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    name_es = Column(String(100), nullable=False)
    name_en = Column(String(100))
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class PaymentMethod(Base):
    """Métodos de pago"""
    __tablename__ = 'payment_methods'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    name_es = Column(String(100), nullable=False)
    name_en = Column(String(100))
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class PaymentTerm(Base):
    """Términos / Condiciones de pago"""
    __tablename__ = 'payment_terms'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    name_es = Column(String(100), nullable=False)
    name_en = Column(String(100))
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class TaxType(Base):
    """Tipos de impuesto"""
    __tablename__ = 'tax_types'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    name_es = Column(String(100), nullable=False)
    name_en = Column(String(100))
    rate = Column(Float, default=0.0)  # Tax rate as percentage
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'rate': self.rate,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class ContactType(Base):
    """Tipos de contacto para proveedores"""
    __tablename__ = 'contact_types'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    name_es = Column(String(100), nullable=False)
    name_en = Column(String(100))
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class Country(Base):
    """Países"""
    __tablename__ = 'countries'
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(3), unique=True, nullable=False, index=True)  # ISO 3166-1 alpha-3
    name_es = Column(String(100), nullable=False)
    name_en = Column(String(100))
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class State(Base):
    """Estados / Provincias / Departamentos"""
    __tablename__ = 'states'
    
    id = Column(Integer, primary_key=True, index=True)
    country_id = Column(Integer, ForeignKey('countries.id'), nullable=False, index=True)
    code = Column(String(10), nullable=False)  # State code
    name_es = Column(String(100), nullable=False)
    name_en = Column(String(100))
    description = Column(Text)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    # Relationship to country
    country = relationship('Country', backref='states')
    
    def to_dict(self):
        return {
            'id': self.id,
            'country_id': self.country_id,
            'code': self.code,
            'name_es': self.name_es,
            'name_en': self.name_en,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

class User(Base, UserMixin):
    """User model for authentication and authorization"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(200), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    nombre = Column(String(100), nullable=False)
    apellido = Column(String(100), nullable=False)
    telefono = Column(String(50))
    rol = Column(String(20), nullable=False, index=True)  # sysadmin, admin, compras
    status = Column(String(20), nullable=False, default='activo', index=True)  # activo, inactivo
    fecha_registro = Column(DateTime, default=datetime.utcnow)
    fecha_actualizacion = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def set_password(self, password):
        """Hash and set the password"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Verify password against hash"""
        return check_password_hash(self.password_hash, password)
    
    def to_dict(self, include_sensitive=False):
        """Convert user object to dictionary"""
        result = {
            'id': self.id,
            'email': self.email,
            'nombre': self.nombre,
            'apellido': self.apellido,
            'telefono': self.telefono,
            'rol': self.rol,
            'status': self.status,
            'fecha_registro': self.fecha_registro.isoformat() if self.fecha_registro else None,
            'fecha_actualizacion': self.fecha_actualizacion.isoformat() if self.fecha_actualizacion else None
        }
        if include_sensitive:
            result['password_hash'] = self.password_hash
        return result
    
    @property
    def is_active(self):
        """Check if user is active"""
        return self.status == 'activo'
    
    @property
    def is_sysadmin(self):
        """Check if user has sysadmin role"""
        return self.rol == 'sysadmin'
    
    @property
    def is_admin(self):
        """Check if user has admin role"""
        return self.rol == 'admin'
    
    @property
    def is_compras(self):
        """Check if user has compras role"""
        return self.rol == 'compras'
    
    def has_permission(self, permission):
        """Check if user has specific permission based on role"""
        permissions = {
            'sysadmin': ['view', 'search', 'create', 'modify', 'import', 'export', 
                        'admin_users', 'change_passwords', 'view_orders', 'create_orders', 
                        'update_orders'],
            'admin': ['view', 'search', 'create', 'modify', 'import', 'export'],
            'compras': ['view', 'search', 'view_orders', 'create_orders', 'update_orders']
        }
        
        if not self.is_active:
            return False
        
        return permission in permissions.get(self.rol, [])

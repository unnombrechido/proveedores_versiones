# Demo del Sistema de Gestión de Proveedores e Inventario v1.3.0

Esta guía demuestra las funcionalidades principales del sistema de gestión de proveedores, inventario y órdenes de compra.

## 🚀 Inicio y Configuración Inicial

### Acceso a la Aplicación
- **Usuario por defecto**: admin@proveedores.com
- **Contraseña**: admin123

### Actualización de Información de Empresa
1. Iniciar sesión con credenciales por defecto
2. En la barra lateral, hacer clic en Configuración
3. Hacer click el campo "Nombre de Empresa" y actualizar a: **FeDSA**
4. Actualizar teléfono y dirección:
   - Teléfono: +52 (811) 482 4915
   - Dirección: Av. Lazaro Cardenas 1007, Residencial Santa Barbara, 66266, San Pedro Garza Garcia, N.L. México

## 👤 Gestión de Usuarios

### Crear Usuario Administrador
1. Ir a "Gestión de Usuarios"
2. Click en Nuevo usuario:
   - Correo: admin@fedoors.com
   - Contraseña: Password1
   - Nombre: Usuario
   - Apellido: Admin
   - Rol: Admin
3. Click en Guardar Usuario

### Crear Usuario de Compras
1. Click en Nuevo usuario:
   - Correo: compras@fedoors.com
   - Contraseña: Password1
   - Nombre: Usuario
   - Apellido: Compras
   - Rol: Compras
2. Click en Guardar Usuario

### Cerrar sesión del usuario por defecto

## 🏢 Gestión de Proveedores

### Agregar Nuevo Proveedor
1. Iniciar sesión como admin@fedoors.com
2. Ir a "Gestión de Proveedores"
3. Hacer clic en "Agregar Proveedor"
4. Completar información:
   - Nombre: Proveedor1
   - Categoría: Metales
   - Dirección: Dirección de proveedor1
   - Ciudad: Monterrey
   - País: México
   - Condiciones de pago: Prepago
   - Calificación: 1 estrella
   - Notas: Compras varias
4- Click en Guardar

### Agregar Contacto al Proveedor
1. En la vista del proveedor
2. Hacer clic en "Agregar Contacto"
3. Completar:
   - Nombre: contacto1
   - Posición: Ventas
   - Teléfono: 1234567890
   - Email: ventas@proveedor1.com
   - Tipo: Ventas
   - Principal: �?(marcar como contacto principal)
4. Click en Guardar

## 📦 Gestión de Inventario

### Crear Nuevo Item
1. Ir a "Gestión de Inventario"
2. Hacer clic en "Crear Item"
3. Completar información:
   - Código: TEST-001
   - Nombre: Artículo de pruebas
   - Descripción: Artículo de pruebas de Proveedor1
   - Categoría: Ferretería
   - Unidad: Pieza
4. Click en Crear Item

### Asignar Proveedor al Item
1. Aparevera un mensaje preguntando si desea agregar proveedores y precios ahora puede haver click en aceptar y lo llevara a la ventana de precios por proveedor o en cancelar y regresa a la pagina de Gestion de Inventario

2. En la vista del item, ir a "Proveedores"
3. Hacer clic en "Agregar Proveedor"
4. Seleccionar Proveedor1
5. Completar detalles:
   - Precio: 99.99
   - Código del proveedor: SKU000001
   - Tiempo de entrega: 1 día
   - Cantidad mínima: 1
6. Agregar Proveedor
7. Cerrar sesión

## 🔍 Funcionalidades de Búsqueda (Usuario Compras)

### Iniciar Sesión como Compras
1. Iniciar sesión como compras@fedoors.com

### Buscar Items
1. Ir a "Buscar Items"
2. Ingresar término de búsqueda: "TEST-001" o "pruebas"
3. Aplicar filtros por categoría o proveedor si es necesario
4. Ver resultados con precios y proveedores disponibles

### Buscar Proveedores
1. Ir a "Buscar Proveedores"
2. Buscar por nombre: "Proveedor1"
3. Ver información completa del proveedor incluyendo contactos e items suministrados

## 📋 Gestión de Órdenes de Compra

### Crear Orden de Compra desde Búsqueda de Items
1. Desde "Buscar Items", seleccionar el artículo TEST-001
2. Hacer clic en "Crear Orden"
3. En el modal de creación:
   - Seleccionar Proveedor1
   - Cantidad: 10
   - Fecha de entrega: [fecha futura]
   - Notas: Orden de prueba
4. Crear Orden

### Crear Orden de Compra desde Gestión de Proveedores
1. Ir a "Gestión de Proveedores"
2. En la tabla de proveedores, localizar Proveedor1
3. Hacer clic en el botón "📝" (Crear Orden) en la columna de acciones
4. En el modal que aparece, seleccionar los items disponibles:
   - Marcar el checkbox del artículo TEST-001
   - Ajustar la cantidad si es necesario (por defecto 1)
   - Verificar que el total se calcula automáticamente
5. Establecer fecha de entrega
6. Agregar notas si es necesario
7. Hacer clic en "Crear Orden"

### Gestionar Estados de Orden
1. Ir a "Gestión de Órdenes"
2. Ver lista de órdenes pendientes
3. Cambiar estado de "Pendiente" a "Confirmada"
4. Luego a "Enviada"

### Imprimir Orden
1. En la tabla de órdenes, localizar la orden creada
2. Hacer clic en el botón "🖨�? (Imprimir Interna) o "🧾" (Imprimir Proveedor)
3. Se abre una vista previa de impresión en el navegador
4. Hacer clic en "Imprimir" para generar la versión impresa
5. O hacer clic en "Cerrar" para volver sin imprimir

*Esta demo cubre las funcionalidades principales. Para uso avanzado, consulte la documentación completa en README.md*
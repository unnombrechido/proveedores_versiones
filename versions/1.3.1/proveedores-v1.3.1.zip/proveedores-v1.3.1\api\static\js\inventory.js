﻿// ===== INVENTORY =====
// ===== INVENTORY =====
async function loadInventory() {
    console.log('loadInventory() called');
    try {
        showLoading('Cargando inventario...');
        const response = await fetch(`${API_BASE}/items`);
        
        if (!response.ok) {
            if (response.status === 401) {
                console.error('Authentication required for items');
                window.location.href = '/login';
                return;
            } else if (response.status === 403) {
                console.error('Access denied for items');
                alert('No tienes permisos para ver items');
                return;
            } else {
                console.error('Error loading inventory:', response.status, response.statusText);
                return;
            }
        }
        
        items = await response.json();
        console.log('Loaded', items.length, 'items');
        console.log('First item sample:', items[0]);
        console.log('Item properties:', Object.keys(items[0] || {}));
        
        // Populate category filter from LOV - ensure LOVs are loaded
        const populateFilters = async () => {
            if (!lovData.itemCategories || lovData.itemCategories.length === 0) {
                console.log('LOV data not loaded, loading now...');
                await loadLOV('itemCategories', '/api/lovs/item-categories');
            }
            if (!lovData.unitsOfMeasure || lovData.unitsOfMeasure.length === 0) {
                console.log('UOM LOV data not loaded, loading now...');
                await loadLOV('unitsOfMeasure', '/api/lovs/units-of-measure');
            }
            
            const categoryFilter = document.getElementById('inventory-category-filter');
            if (categoryFilter) {
                const currentCategory = categoryFilter.value;
                categoryFilter.innerHTML = '<option value="">Todas las Categorías</option>';
                lovData.itemCategories.forEach(cat => {
                    const option = document.createElement('option');
                    option.value = cat.id;
                    option.textContent = cat.name_es;
                    if (cat.id == currentCategory) option.selected = true;
                    categoryFilter.appendChild(option);
                });
            }
        };
        
        await populateFilters();
        
        displayInventory();
    } catch (error) {
        console.error('Error loading inventory:', error);
    } finally {
        hideLoading();
    }
}

function applyInventoryFilters() {
    const searchTerm = document.getElementById('inventory-search')?.value.toLowerCase() || '';
    displayInventory(searchTerm);
}

function displayInventory(searchTerm = '') {
    console.log('currentUser:', currentUser);
    const categoryFilter = document.getElementById('inventory-category-filter').value;
    const sortBy = document.getElementById('inventory-sort').value;
    
    // Filter items
    let filteredItems = [...items];
    console.log('displayInventory() called with', items.length, 'total items');
    console.log('Starting with', filteredItems.length, 'items');
    
    // Apply search filter
    if (searchTerm) {
        filteredItems = filteredItems.filter(item => 
            item.name.toLowerCase().includes(searchTerm) ||
            item.item_code.toLowerCase().includes(searchTerm) ||
            (item.category && item.category.toLowerCase().includes(searchTerm)) ||
            (item.description && item.description.toLowerCase().includes(searchTerm))
        );
    }
    
    // Apply category filter
    if (categoryFilter) {
        filteredItems = filteredItems.filter(item => item.category_id == categoryFilter);
    }
    
    console.log('After filtering:', filteredItems.length, 'items');
    
    // Sort items
    filteredItems.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return a.name.localeCompare(b.name);
            case 'code':
                return a.item_code.localeCompare(b.item_code);
            case 'category':
                return (a.category || '').localeCompare(b.category || '');
            case 'price-asc':
                // For price, we'd need to fetch supplier prices - simplified for now
                return 0;
            case 'price-desc':
                return 0;
            default:
                return 0;
        }
    });
    
    const tbody = document.getElementById('inventory-tbody');
    console.log('tbody element:', tbody);
    if (!tbody) {
        console.error('inventory-tbody element not found!');
        return;
    }
    
    console.log('About to set tbody.innerHTML with', filteredItems.length, 'rows');
    try {
        const html = filteredItems.map(item => {
            // Check if user has edit permissions (not compras role)
            const canEdit = currentUser && (currentUser.rol === 'sysadmin' || currentUser.rol === 'admin');
            
            return `
            <tr>
                <td>${item.item_code}</td>
                <td>${item.name}</td>
                <td>${item.description || ''}</td>
                <td>${item.category || ''}</td>
                <td>${item.unit || ''}</td>
                <td>
                    <button onclick="viewSuppliersByItem(${item.id}, '${escapeHtml(item.name)}')" class="btn btn-secondary btn-sm" title="Ver Proveedores">
                        👁️
                    </button>
                </td>
                <td style="white-space: nowrap;">
                    ${canEdit ? `
                    <button onclick="editItem(${item.id})" class="btn btn-warning btn-sm" title="Editar Item">✏️</button>
                    <button onclick="manageItemSuppliers(${item.id}, '${escapeHtml(item.name)}')" class="btn btn-primary btn-sm" title="Gestionar Proveedores">
                        🏢
                    </button>
                    ` : '<span style="color: #999;">Solo lectura</span>'}
                </td>
            </tr>
            `;
        }).join('');
        console.log('Generated HTML sample:', html.substring(0, 200) + '...');
        tbody.innerHTML = html;
        console.log('tbody.innerHTML length after setting:', tbody.innerHTML.length);
        console.log('tbody.children.length:', tbody.children.length);
        console.log('First few characters of innerHTML:', tbody.innerHTML.substring(0, 100));
        
        console.log('Successfully set tbody.innerHTML');
    } catch (error) {
        console.error('Error setting tbody.innerHTML:', error);
    }
}

async function manageItemSuppliers(itemId, itemName) {
    const item = items.find(i => i.id === itemId);
    if (!item) {
        showError('Item no encontrado');
        return;
    }
    
    currentPriceItem = item;
    showSection('price-management');
}

async function viewSuppliersByItem(itemId, itemName) {
    // Show confirmation dialog
    showConfirmDialog(
        `¿Desea ver los proveedores que venden "${itemName}"?\n\nEsto lo llevará a la sección de búsqueda de proveedores.`,
        async () => {
            try {
                await loadSuppliersByItemConfirmed(itemId, itemName);
            } catch (error) {
                console.error('Error:', error);
                showError('Error al cargar proveedores del item');
            }
        }
    );
}

async function loadSuppliersByItemConfirmed(itemId, itemName) {
    try {
        // Fetch suppliers for this item
        const response = await fetch(`${API_BASE}/items/${itemId}/suppliers`);
        if (!response.ok) {
            throw new Error('Failed to fetch suppliers');
        }
        
        const suppliers = await response.json();
        
        if (suppliers.length === 0) {
            showError('Este item no tiene proveedores asociados');
            return;
        }
        
        // Switch to search vendors section
        showSection('search-vendors');
        
        // Store current search context
        currentVendorResults = suppliers;
        
        // Clear search input and populate filters
        const searchInput = document.getElementById('vendors-search');
        if (searchInput) {
            searchInput.value = '';
        }
        
        // Display the suppliers directly
        populateVendorFilters(suppliers);
        displayVendorResults(suppliers);
        
        // Show info message
        showSuccess(`Mostrando ${suppliers.length} proveedor(es) que venden: ${itemName}`);
        
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

async function editItem(itemId) {
    const item = items.find(i => i.id === itemId);
    if (!item) {
        showError('Item no encontrado');
        return;
    }
    
    // Ensure LOV data is loaded
    if (!lovData.itemCategories || lovData.itemCategories.length === 0) {
        await loadLOV('itemCategories', '/api/lovs/item-categories');
    }
    if (!lovData.unitsOfMeasure || lovData.unitsOfMeasure.length === 0) {
        await loadLOV('unitsOfMeasure', '/api/lovs/units-of-measure');
    }
    
    // Generate category options from LOV
    const categoryOptions = lovData.itemCategories.map(cat => 
        `<option value="${cat.id}" ${item.category_id == cat.id ? 'selected' : ''}>${cat.name_es}</option>`
    ).join('');
    
    // Generate UOM options from LOV
    const uomOptions = lovData.unitsOfMeasure.map(unit => 
        `<option value="${unit.id}" ${item.unit_id == unit.id ? 'selected' : ''}>${unit.name_es} (${unit.symbol})</option>`
    ).join('');
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'edit-item-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>Editar Item</h2>
                <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="edit-item-form" onsubmit="saveItemEdit(event, ${itemId})">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Código (No editable)</label>
                            <input type="text" value="${item.item_code}" disabled class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Nombre <span class="required">*</span></label>
                            <input type="text" id="edit-item-name" value="${item.name}" required class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea id="edit-item-description" class="form-control" rows="3">${item.description || ''}</textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Categoría</label>
                            <select id="edit-item-category" class="form-control">
                                <option value="">Seleccione una categoría</option>
                                ${categoryOptions}
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Unidad de Medida</label>
                            <select id="edit-item-unit" class="form-control">
                                <option value="">Seleccione una unidad</option>
                                ${uomOptions}
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="this.closest('.modal').remove()" class="btn btn-secondary">Cancelar</button>
                        <button type="submit" class="btn btn-primary">💾 Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
}

async function saveItemEdit(event, itemId) {
    event.preventDefault();
    
    const updatedItem = {
        name: document.getElementById('edit-item-name').value.trim(),
        description: document.getElementById('edit-item-description').value.trim(),
        category_id: document.getElementById('edit-item-category').value || null,
        unit_id: document.getElementById('edit-item-unit').value || null
    };
    
    if (!updatedItem.name) {
        showError('El nombre del item es requerido');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items/${itemId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedItem)
        });
        
        if (!response.ok) {
            throw new Error('Failed to update item');
        }
        
        // Close modal first
        const modal = document.getElementById('edit-item-modal');
        if (modal) {
            modal.remove();
        }
        
        // Then show success and reload
        showSuccess('Item actualizado correctamente');
        await loadInventory();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al actualizar el item');
    }
}

async function openNewItemModal() {
    // Ensure LOV data is loaded
    if (!lovData.itemCategories || lovData.itemCategories.length === 0) {
        await loadLOV('itemCategories', '/api/lovs/item-categories');
    }
    if (!lovData.unitsOfMeasure || lovData.unitsOfMeasure.length === 0) {
        await loadLOV('unitsOfMeasure', '/api/lovs/units-of-measure');
    }
    
    // Generate category options from LOV
    const categoryOptions = lovData.itemCategories.map(cat => 
        `<option value="${cat.id}">${cat.name_es}</option>`
    ).join('');
    
    // Generate UOM options from LOV
    const uomOptions = lovData.unitsOfMeasure.map(unit => 
        `<option value="${unit.id}">${unit.name_es} (${unit.symbol})</option>`
    ).join('');
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'new-item-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>Nuevo Item</h2>
                <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="new-item-form" onsubmit="saveNewItem(event)">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Código <span class="required">*</span></label>
                            <input type="text" id="new-item-code" required class="form-control" placeholder="SKU-001">
                        </div>
                        <div class="form-group">
                            <label>Nombre <span class="required">*</span></label>
                            <input type="text" id="new-item-name" required class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea id="new-item-description" class="form-control" rows="3"></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Categoría</label>
                            <select id="new-item-category" class="form-control">
                                <option value="">Seleccione una categoría</option>
                                ${categoryOptions}
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Unidad de Medida</label>
                            <select id="new-item-unit" class="form-control">
                                <option value="">Seleccione una unidad</option>
                                ${uomOptions}
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="this.closest('.modal').remove()" class="btn btn-secondary">Cancelar</button>
                        <button type="submit" class="btn btn-primary">💾 Crear Item</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
}

async function saveNewItem(event) {
    event.preventDefault();
    
    const newItem = {
        item_code: document.getElementById('new-item-code').value.trim(),
        name: document.getElementById('new-item-name').value.trim(),
        description: document.getElementById('new-item-description').value.trim(),
        category_id: document.getElementById('new-item-category').value || null,
        unit_id: document.getElementById('new-item-unit').value || null
    };
    
    if (!newItem.item_code || !newItem.name) {
        showError('Código y nombre son requeridos');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/items`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newItem)
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to create item');
        }
        
        const createdItem = await response.json();
        
        // Close modal first
        const modalToClose = document.getElementById('new-item-modal');
        if (modalToClose) {
            modalToClose.remove();
        }
        
        showSuccess('Item creado correctamente');
        
        // Ask if user wants to add suppliers now
        showConfirmDialog(
            `Item "${createdItem.name}" creado exitosamente.\n\n¿Desea agregar proveedores y precios ahora?`,
            () => {
                currentPriceItem = createdItem;
                showSection('price-management');
            },
            () => {
                loadInventory();
            }
        );
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message || 'Error al crear el item');
    }
}

async function openAddSuppliersModal(item) {
    try {
        // Load all suppliers
        const response = await fetch(`${API_BASE}/suppliers`);
        const allSuppliers = await response.json();
        
        if (allSuppliers.length === 0) {
            showError('No hay proveedores registrados. Agregue proveedores primero.');
            await loadInventory();
            return;
        }
        
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content modal-large">
                <div class="modal-header">
                    <h2>Agregar Proveedores - ${item.name}</h2>
                    <span class="close" onclick="closeAddSuppliersModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <p><strong>Item:</strong> ${item.item_code} - ${item.name}</p>
                    <hr>
                    
                    <div id="suppliers-list">
                        <h3>Seleccione proveedores y establezca precios:</h3>
                        <div class="suppliers-selector">
                            ${allSuppliers.map(supplier => `
                                <div class="supplier-row" data-supplier-id="${supplier.id}">
                                    <div class="supplier-select">
                                        <label>
                                            <input type="checkbox" class="supplier-checkbox" value="${supplier.id}">
                                            <strong>${supplier.name}</strong>
                                            <br>
                                            <small>${supplier.email || ''} ${supplier.city ? '- ' + supplier.city : ''}</small>
                                        </label>
                                    </div>
                                    <div class="supplier-price-fields" style="display: none;">
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label>Precio <span class="required">*</span></label>
                                                <input type="number" step="0.01" class="form-control price-input" placeholder="0.00" disabled>
                                            </div>
                                            <div class="form-group">
                                                <label>Código del Proveedor</label>
                                                <input type="text" class="form-control supplier-code-input" placeholder="Código interno" disabled>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label>Tiempo de Entrega (días)</label>
                                                <input type="number" class="form-control lead-time-input" placeholder="0" disabled>
                                            </div>
                                            <div class="form-group">
                                                <label>Cantidad Mínima</label>
                                                <input type="number" class="form-control min-qty-input" placeholder="1" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Notas</label>
                                            <textarea class="form-control notes-input" rows="2" disabled></textarea>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="closeAddSuppliersModal()" class="btn btn-secondary">
                            Omitir
                        </button>
                        <button type="button" onclick="saveSuppliersToItem(${item.id})" class="btn btn-primary">
                            💾 Guardar Proveedores
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        
        // Add event listeners to checkboxes
        document.querySelectorAll('.supplier-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const row = this.closest('.supplier-row');
                const fieldsDiv = row.querySelector('.supplier-price-fields');
                const inputs = row.querySelectorAll('input, textarea');
                
                if (this.checked) {
                    fieldsDiv.style.display = 'block';
                    inputs.forEach(input => {
                        if (!input.classList.contains('supplier-checkbox')) {
                            input.disabled = false;
                        }
                    });
                } else {
                    fieldsDiv.style.display = 'none';
                    inputs.forEach(input => {
                        if (!input.classList.contains('supplier-checkbox')) {
                            input.disabled = true;
                        }
                    });
                }
            });
        });
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al cargar proveedores');
        await loadInventory();
    }
}

async function saveSuppliersToItem(itemId) {
    const selectedSuppliers = [];
    
    document.querySelectorAll('.supplier-checkbox:checked').forEach(checkbox => {
        const row = checkbox.closest('.supplier-row');
        const supplierId = parseInt(checkbox.value);
        const price = parseFloat(row.querySelector('.price-input').value);
        
        if (!price || price <= 0) {
            showError(`Debe ingresar un precio válido para todos los proveedores seleccionados`);
            return;
        }
        
        selectedSuppliers.push({
            supplier_id: supplierId,
            price: price,
            supplier_item_code: row.querySelector('.supplier-code-input').value.trim(),
            lead_time_days: parseInt(row.querySelector('.lead-time-input').value) || null,
            minimum_order_quantity: parseInt(row.querySelector('.min-qty-input').value) || null,
            notes: row.querySelector('.notes-input').value.trim()
        });
    });
    
    if (selectedSuppliers.length === 0) {
        showConfirmDialog(
            'No ha seleccionado ningún proveedor.\n\n¿Desea crear el item sin proveedores?',
            () => {
                closeAddSuppliersModal();
                loadInventory();
            }
        );
        return;
    }
    
    try {
        // Add each supplier to the item
        const promises = selectedSuppliers.map(supplierData =>
            fetch(`${API_BASE}/items/${itemId}/suppliers`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(supplierData)
            })
        );
        
        await Promise.all(promises);
        
        showSuccess(`Item configurado exitosamente con ${selectedSuppliers.length} proveedor(es)`);
        closeAddSuppliersModal();
        await loadInventory();
        
    } catch (error) {
        console.error('Error:', error);
        showError('Error al guardar proveedores');
    }
}

function closeAddSuppliersModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.remove();
    }
}


function exportInventory() {
    window.location.href = `${API_BASE}/items/export`;
}


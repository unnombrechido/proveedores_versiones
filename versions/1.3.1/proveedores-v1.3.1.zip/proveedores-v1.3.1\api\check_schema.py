from database import SessionLocal, engine
from sqlalchemy import inspect

inspector = inspect(engine)
columns = inspector.get_columns('items')
for col in columns:
    print(f'{col["name"]}: {col["type"]}')